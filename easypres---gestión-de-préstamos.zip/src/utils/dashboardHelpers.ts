import { Cliente, Prestamo, Pago, CuadreCaja, Deposito, CuotaDetalle } from "../types";

export type DashboardPeriod = "todos" | "hoy" | "semana" | "mes";

export interface DashboardStats {
  totalClientes: number;
  clientesNuevosMes: number;
  prestamosActivos: number;
  prestamosAtrasados: number;
  prestamosSaldados: number;
  capitalPrestado: number;
  balancePendienteTotal: number;
  interesGeneradoTotal: number;
  cuotasVencenHoyCount: number;
  cuotasVencenHoyMonto: number;
  cuotasVencenHoyCobrado: number;
  cobrosDelDia: number;
  capitalCobrado: number;
  interesCobrado: number;
  moraCobrada: number;
  totalMoraGenerada: number;
  totalMoraCobrada: number;
  totalMoraPendiente: number;
  moraAging1to15: number;
  moraAging16to30: number;
  moraAging30Plus: number;
  totalInteresesCobradosHistoricos: number;
  totalMoraCobradaHistorica: number;
  totalInteresesProyectadosHistoricos: number;
  totalDepositado: number;
  cajaPendientePorCerrar: number;
}

export const todayStr = new Date().toISOString().split("T")[0];

export const isWithinPeriod = (dateStr: string, period: DashboardPeriod): boolean => {
  if (period === "todos") return true;
  const itemDate = new Date(dateStr.split("T")[0]);
  const today = new Date(todayStr);
  
  if (period === "hoy") {
    return dateStr.split("T")[0] === todayStr;
  }
  
  if (period === "semana") {
    const oneWeekAgo = new Date(today);
    oneWeekAgo.setDate(today.getDate() - 7);
    return itemDate >= oneWeekAgo && itemDate <= today;
  }
  
  if (period === "mes") {
    return itemDate.getMonth() === today.getMonth() && itemDate.getFullYear() === today.getFullYear();
  }
  
  return true;
};

export const isWithinPreviousPeriod = (dateStr: string, period: DashboardPeriod): boolean => {
  if (period === "todos") return false;
  const itemDate = new Date(dateStr.split("T")[0]);
  const today = new Date(todayStr);
  
  if (period === "hoy") {
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];
    return dateStr.split("T")[0] === yesterdayStr;
  }
  
  if (period === "semana") {
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(today.getDate() - 7);
    const fourteenDaysAgo = new Date(today);
    fourteenDaysAgo.setDate(today.getDate() - 14);
    return itemDate >= fourteenDaysAgo && itemDate < sevenDaysAgo;
  }
  
  if (period === "mes") {
    const firstOfCurrentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const firstOfPrevMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    return itemDate >= firstOfPrevMonth && itemDate < firstOfCurrentMonth;
  }
  
  return false;
};

export const calculateDashboardStats = (
  clientes: Cliente[],
  prestamos: Prestamo[],
  pagos: Pago[],
  cuadres: CuadreCaja[] = [],
  depositos: Deposito[] = [],
  periodFilter: DashboardPeriod,
  cobradorFilter: string,
  usePreviousPeriod: boolean = false
): DashboardStats => {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const periodMatchHelper = (dateStr: string) => {
    return usePreviousPeriod 
      ? isWithinPreviousPeriod(dateStr, periodFilter) 
      : (periodFilter === "todos" ? true : isWithinPeriod(dateStr, periodFilter));
  };

  // Filter datasets
  const filteredClientes = clientes.filter(c => {
    const cobradorMatch = !cobradorFilter ? true : c.cobradorNombre === cobradorFilter;
    const periodMatch = periodFilter === "todos" && !usePreviousPeriod ? true : periodMatchHelper(c.fechaRegistro);
    return cobradorMatch && periodMatch;
  });

  const filteredPrestamos = prestamos.filter(p => {
    const cobradorMatch = !cobradorFilter ? true : p.cobradorNombre === cobradorFilter;
    const periodMatch = periodFilter === "todos" && !usePreviousPeriod ? true : periodMatchHelper(p.fechaInicio);
    return cobradorMatch && periodMatch;
  });

  const filteredPagos = pagos.filter(p => {
    const cobradorMatch = !cobradorFilter ? true : p.cobradorNombre === cobradorFilter;
    const periodMatch = periodMatchHelper(p.fecha);
    return cobradorMatch && periodMatch;
  });

  const filteredCuadres = cuadres.filter(c => {
    const cobradorMatch = !cobradorFilter ? true : (c.cobradorNombre === cobradorFilter || c.registradoPor === cobradorFilter);
    const periodMatch = periodFilter === "todos" && !usePreviousPeriod ? true : periodMatchHelper(c.fecha);
    return cobradorMatch && periodMatch;
  });

  const filteredDepositos = depositos.filter(d => {
    const cobradorMatch = !cobradorFilter ? true : d.registradoPor === cobradorFilter;
    const periodMatch = periodFilter === "todos" && !usePreviousPeriod ? true : periodMatchHelper(d.fecha);
    return cobradorMatch && periodMatch;
  });

  // KPI math
  const totalClientes = filteredClientes.length;
  const clientesNuevosMes = filteredClientes.filter(c => {
    const regDate = new Date(c.fechaRegistro);
    return regDate.getMonth() === currentMonth && regDate.getFullYear() === currentYear;
  }).length;

  let prestamosActivos = 0;
  let prestamosAtrasados = 0;
  let prestamosSaldados = 0;
  let capitalPrestado = 0;
  let balancePendienteTotal = 0;
  let interesGeneradoTotal = 0;
  
  let totalMoraGenerada = 0;
  let totalMoraCobrada = 0;
  let totalMoraPendiente = 0;

  let cuotasVencenHoyCount = 0;
  let cuotasVencenHoyMonto = 0;
  let cuotasVencenHoyCobrado = 0;

  let moraAging1to15 = 0;
  let moraAging16to30 = 0;
  let moraAging30Plus = 0;

  filteredPrestamos.forEach(p => {
    if (p.estado === "Activo") prestamosActivos++;
    else if (p.estado === "Atrasado") prestamosAtrasados++;
    else if (p.estado === "Saldado") prestamosSaldados++;

    if (p.estado !== "Cancelado") {
      capitalPrestado += p.capitalPrestado;
      balancePendienteTotal += p.balancePendiente;
      interesGeneradoTotal += p.interesTotal;
      totalMoraPendiente += p.mora || 0;
    }

    if (p.cuotasDetalle && (p.estado === "Activo" || p.estado === "Atrasado")) {
      try {
        const cuotas: CuotaDetalle[] = JSON.parse(p.cuotasDetalle);
        if (Array.isArray(cuotas)) {
          cuotas.forEach((c) => {
            if (c.moraMonto) {
              totalMoraGenerada += c.moraMonto;
            }
            if (c.moraPagada) {
              totalMoraCobrada += c.moraPagada;
            }

            if (c.fechaVence === todayStr) {
              if (c.estado !== "Pagado") {
                cuotasVencenHoyCount++;
                cuotasVencenHoyMonto += (c.monto - c.montoPagado);
              } else {
                cuotasVencenHoyCobrado += c.monto;
              }
            }

            if (c.estado !== "Pagado" && new Date(c.fechaVence) < new Date(todayStr)) {
              const diffTime = Math.abs(new Date(todayStr).getTime() - new Date(c.fechaVence).getTime());
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
              
              const outstandingDue = c.monto - c.montoPagado;
              if (diffDays <= 15) {
                moraAging1to15 += outstandingDue;
              } else if (diffDays <= 30) {
                moraAging16to30 += outstandingDue;
              } else {
                moraAging30Plus += outstandingDue;
              }
            }
          });
        }
      } catch (e) {
        console.error("Error parsing cuotas", e);
      }
    }
  });

  let cobrosDelDia = 0;
  let capitalCobrado = 0;
  let interesCobrado = 0;
  let moraCobrada = 0;

  filteredPagos.forEach(p => {
    cobrosDelDia += p.monto;
    capitalCobrado += p.capitalPagado || 0;
    interesCobrado += p.interesPagado || 0;
    moraCobrada += p.moraPagado || 0;
  });

  const totalInteresesCobradosHistoricos = pagos.reduce((sum, p) => sum + (p.interesPagado || 0), 0);
  const totalMoraCobradaHistorica = pagos.reduce((sum, p) => sum + (p.moraPagado || 0), 0);
  const totalInteresesProyectadosHistoricos = prestamos.reduce((sum, p) => p.estado !== "Cancelado" ? sum + p.interesTotal : sum, 0);

  const totalDepositado = filteredDepositos.reduce((sum, d) => sum + d.monto, 0);
  const cajaPendientePorCerrar = filteredCuadres
    .filter(c => c.estado === "Abierta" || c.estado === "Reabierta" || c.estado === "Pendiente de cierre")
    .reduce((sum, c) => sum + (c.saldoEstimado || 0), 0);

  return {
    totalClientes,
    clientesNuevosMes,
    prestamosActivos,
    prestamosAtrasados,
    prestamosSaldados,
    capitalPrestado,
    balancePendienteTotal,
    interesGeneradoTotal,
    cuotasVencenHoyCount,
    cuotasVencenHoyMonto,
    cuotasVencenHoyCobrado,
    cobrosDelDia,
    capitalCobrado,
    interesCobrado,
    moraCobrada: moraCobrada || totalMoraCobrada,
    totalMoraGenerada,
    totalMoraCobrada: totalMoraCobrada || moraCobrada,
    totalMoraPendiente,
    moraAging1to15,
    moraAging16to30,
    moraAging30Plus,
    totalInteresesCobradosHistoricos,
    totalMoraCobradaHistorica,
    totalInteresesProyectadosHistoricos,
    totalDepositado,
    cajaPendientePorCerrar
  };
};
