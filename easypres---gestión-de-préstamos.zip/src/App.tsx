import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  collection,
  onSnapshot,
  setDoc,
  doc,
  deleteDoc,
  getDocFromServer,
  getDoc,
  enableNetwork,
  disableNetwork,
  writeBatch,
  query,
  orderBy,
  limit
} from "firebase/firestore";
import {
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser
} from "firebase/auth";
import { db, auth, OperationType, handleFirestoreError, cleanFirestoreData } from "./firebase";
import { Cliente, Prestamo, Pago, Garantia, Gasto, Banco, Configuracion, CuadreCaja, Deposito, Usuario, checkPermission, AuditoriaLog, AsignacionTemporal, HistorialAsignacion } from "./types";

import Sidebar from "./components/Sidebar";
import BottomNav from "./components/BottomNav";
import Dashboard from "./components/Dashboard";
import RutaCobro from "./components/RutaCobro";
import Clientes from "./components/Clientes";
import Prestamos from "./components/Prestamos";
import Pagos from "./components/Pagos";
import Garantias from "./components/Garantias";
import Finanzas from "./components/Finanzas";
import Reportes from "./components/Reportes";
import ConfiguracionModule from "./components/Configuracion";

import { Landmark, ArrowRight, ShieldCheck, CreditCard, Building2, User, Menu, Clock, Wifi, WifiOff, RefreshCw, CheckCircle2, X } from "lucide-react";

// Standard realistic default data for an immediate interactive out-of-the-box experience
const DEFAULT_CONFIG: Configuracion = {
  id: "general",
  nombreEmpresa: "EasyPres Finanzas",
  rnc: "131-019920-1",
  telefono: "809-555-0199",
  direccion: "Av. 27 de Febrero, Santo Domingo",
  correo: "contacto@easypres.com",
  moneda: "RD$",
  tasaInteresDefecto: 10,
  colorPrimario: "#10b981",
  colorSecundario: "#1e293b",
  timeoutInactividad: 30,
  avisoInactividadHabilitado: true,
  prioridadPagoMora: "mora_first",
  permitirOmitirMora: true,
  requerirAutorizacionOmitir: false,
  moraMaximaMonto: 5000,
  diasToleranciaMoraDefecto: 3
};

// Collision-proof ID generator for robust offline-first synchronization
const generateOfflineId = (prefix: string): string => {
  const randomStr = Math.random().toString(36).substring(2, 9);
  return `${prefix}_${Date.now()}_${randomStr}`;
};

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeModule, setActiveModule] = useState("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Firestore Synchronized States
  const [clientes, setClientes] = useState<Cliente[]>([]);
  // Network and Sync States
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [syncStatus, setSyncStatus] = useState<"synced" | "syncing" | "offline">("synced");
  const [pendingWritesMap, setPendingWritesMap] = useState<Record<string, boolean>>({});
  const [showSyncSuccessToast, setShowSyncSuccessToast] = useState(false);
  const [prestamos, setPrestamos] = useState<Prestamo[]>([]);
  const [pagos, setPagos] = useState<Pago[]>([]);
  const [garantias, setGarantias] = useState<Garantia[]>([]);
  const [gastos, setGastos] = useState<Gasto[]>([]);
  const [bancos, setBancos] = useState<Banco[]>([]);
  const [cuadres, setCuadres] = useState<CuadreCaja[]>([]);
  const [depositos, setDepositos] = useState<Deposito[]>([]);
  const [config, setConfig] = useState<Configuracion>(DEFAULT_CONFIG);
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [usuariosLoaded, setUsuariosLoaded] = useState(false);
  const [auditorias, setAuditorias] = useState<AuditoriaLog[]>([]);
  const [asignacionesTemporales, setAsignacionesTemporales] = useState<AsignacionTemporal[]>([]);
  const [historialAsignaciones, setHistorialAsignaciones] = useState<HistorialAsignacion[]>([]);

  // User/password login states for test login (admin / admin)
  const [testUsername, setTestUsername] = useState("");
  const [testPassword, setTestPassword] = useState("");
  const [testLoginError, setTestLoginError] = useState("");

  // Local Demo data migration to Firestore Cloud states
  const [showImportModal, setShowImportModal] = useState(false);
  const [sessionDismissedImport, setSessionDismissedImport] = useState(false);
  const [importingLocalData, setImportingLocalData] = useState(false);
  const [localCounts, setLocalCounts] = useState({ clientes: 0, prestamos: 0, pagos: 0, garantias: 0 });

  // Check for local storage data to migrate when a real user logs in
  useEffect(() => {
    if (user && user.uid !== "demo-user-id" && !sessionDismissedImport) {
      const c = JSON.parse(localStorage.getItem("easypres_clientes") || "[]");
      const pr = JSON.parse(localStorage.getItem("easypres_prestamos") || "[]");
      const pa = JSON.parse(localStorage.getItem("easypres_pagos") || "[]");
      const g = JSON.parse(localStorage.getItem("easypres_garantias") || "[]");

      // Filter out pre-defined demo items to only detect true user-added data
      const realLocalClientes = c.filter((item: any) => !["cli_1", "cli_2", "cli_3"].includes(item.id));
      const realLocalPrestamos = pr.filter((item: any) => !["pre_1", "pre_2"].includes(item.id));
      const realLocalPagos = pa.filter((item: any) => !["pago_1"].includes(item.id));
      const realLocalGarantias = g.filter((item: any) => !["gar_1"].includes(item.id));

      const totalItems = realLocalClientes.length + realLocalPrestamos.length + realLocalPagos.length + realLocalGarantias.length;
      if (totalItems > 0) {
        setLocalCounts({
          clientes: realLocalClientes.length,
          prestamos: realLocalPrestamos.length,
          pagos: realLocalPagos.length,
          garantias: realLocalGarantias.length
        });
        setShowImportModal(true);
      }
    }
  }, [user, sessionDismissedImport]);

  // Security & Inactivity settings states (Requirement 5)
  const [showInactivityWarning, setShowInactivityWarning] = useState(false);
  const [inactivityCountdown, setInactivityCountdown] = useState(120);
  const lastActivityRef = useRef<number>(Date.now());
  const countdownIntervalRef = useRef<any>(null);

  // BI Dashboard direct navigation linking states
  const [initialSearchQuery, setInitialSearchQuery] = useState("");
  const [initialSelectedClienteId, setInitialSelectedClienteId] = useState("");

  // Find current user profile from matching email in usuarios array
  const currentUserProfile: Usuario | null = (() => {
    if (!user) return null;
    const found = usuarios.find((u) => u.email.toLowerCase() === user.email?.toLowerCase());
    if (found) return found;

    // If database is completely empty (first initialization), we allow auto-admin bootstrap
    const hasRegisteredUsers = usuarios.length > 0;
    if (!hasRegisteredUsers) {
      return {
        id: "auto_admin",
        nombre: user.displayName || user.email?.split("@")[0] || "Administrador",
        email: user.email || "demo.supervisor@easypres.com",
        rol: "Administrador",
        activo: true
      };
    }

    // Otherwise, they are unauthorized guests and should see nothing/be logged out
    return null;
  })();

  // Utility to isolate demo sandbox data from real user data in localStorage
  const demoLocalStorage = {
    getItem: (key: string): string | null => {
      return window.localStorage.getItem(key.replace(/^easypres_(?!demo_)/, "easypres_demo_"));
    },
    setItem: (key: string, value: string): void => {
      window.localStorage.setItem(key.replace(/^easypres_(?!demo_)/, "easypres_demo_"), value);
    },
    removeItem: (key: string): void => {
      window.localStorage.removeItem(key.replace(/^easypres_(?!demo_)/, "easypres_demo_"));
    }
  };

  // Authentication State Handler
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (usr) => {
      setUser(usr);
      setAuthLoading(false);
    });
    return unsubscribe;
  }, []);

  // Dark Mode Handler
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [darkMode]);


  // Monitor browser connection status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setSyncStatus("syncing");
      console.log("El navegador está en línea. Firestore administrará la reconexión de forma nativa.");
    };

    const handleOffline = () => {
      setIsOnline(false);
      setSyncStatus("offline");
      console.log("El navegador está fuera de línea.");
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    // Initial sync status check
    if (navigator.onLine) {
      setSyncStatus("synced");
    } else {
      setSyncStatus("offline");
    }

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const anyPendingWrites = Object.values(pendingWritesMap).some(v => v);

  // Synchronize status changes
  useEffect(() => {
    if (!isOnline) {
      setSyncStatus("offline");
    } else if (anyPendingWrites) {
      setSyncStatus("syncing");
    } else {
      // Transition from syncing to synced shows the success toast
      if (syncStatus === "syncing") {
        setShowSyncSuccessToast(true);
        const timer = setTimeout(() => setShowSyncSuccessToast(false), 4000);
        return () => clearTimeout(timer);
      }
      setSyncStatus("synced");
    }
  }, [isOnline, anyPendingWrites]);

  // Manual retry/sync trigger function
  const triggerManualSync = async () => {
    if (!navigator.onLine) {
      alert("Sigues desconectado de internet. Por favor verifica tu red para sincronizar.");
      return;
    }
    setSyncStatus("syncing");
    setIsOnline(true);
    try {
      await disableNetwork(db);
      await enableNetwork(db);
      alert("¡Sincronización forzada enviada! Firestore intentará descargar/subir cambios en segundos.");
    } catch (e) {
      console.error(e);
      alert("Hubo un error al re-conectar Firestore.");
    }
  };

  // Firestore Real-time Synchronizer
  useEffect(() => {
    if (!user || user.uid === "demo-user-id") return;

    // Validate Connection as mandated by the Firebase skill
    const validateConnection = async () => {
      try {
        await getDocFromServer(doc(db, "test", "connection"));
      } catch (e) {
        console.warn("Firestore client connecting...", e);
      }
    };
    validateConnection();

    // 1. Fetch Config
    const unsubConfig = onSnapshot(
      doc(db, "configuracion", "general"),
      (docSnap) => {
        if (docSnap.exists()) {
          setConfig(docSnap.data() as Configuracion);
        } else {
          // Initialize config in Firestore if not present
          setDoc(doc(db, "configuracion", "general"), cleanFirestoreData(DEFAULT_CONFIG)).catch(err => {
            console.error("Error setting default config:", err);
          });
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, "configuracion/general")
    );

    // 2. Sync Clientes
    const unsubClientes = onSnapshot(
      collection(db, "clientes"),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, clientes: snap.metadata.hasPendingWrites }));
        const list: Cliente[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Cliente);
        });
        setClientes(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "clientes")
    );

    // 3. Sync Prestamos
    const unsubPrestamos = onSnapshot(
      collection(db, "prestamos"),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, prestamos: snap.metadata.hasPendingWrites }));
        const list: Prestamo[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Prestamo);
        });
        setPrestamos(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "prestamos")
    );

    // 4. Sync Pagos
    const unsubPagos = onSnapshot(
      query(collection(db, "pagos"), orderBy("fecha", "desc"), limit(1500)),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, pagos: snap.metadata.hasPendingWrites }));
        const list: Pago[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Pago);
        });
        setPagos(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "pagos")
    );

    // 5. Sync Garantias
    const unsubGarantias = onSnapshot(
      collection(db, "garantias"),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, garantias: snap.metadata.hasPendingWrites }));
        const list: Garantia[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Garantia);
        });
        setGarantias(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "garantias")
    );

    // 6. Sync Gastos
    const unsubGastos = onSnapshot(
      query(collection(db, "gastos"), orderBy("fecha", "desc"), limit(250)),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, gastos: snap.metadata.hasPendingWrites }));
        const list: Gasto[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Gasto);
        });
        setGastos(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "gastos")
    );

    // 7. Sync Bancos
    const unsubBancos = onSnapshot(
      collection(db, "bancos"),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, bancos: snap.metadata.hasPendingWrites }));
        const list: Banco[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Banco);
        });
        setBancos(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "bancos")
    );

    // 8. Sync Cuadres
    const unsubCuadres = onSnapshot(
      query(collection(db, "cuadres"), orderBy("fecha", "desc"), limit(150)),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, cuadres: snap.metadata.hasPendingWrites }));
        const list: CuadreCaja[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as CuadreCaja);
        });
        setCuadres(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "cuadres")
    );

    // 9. Sync Depositos
    const unsubDepositos = onSnapshot(
      query(collection(db, "depositos"), orderBy("fecha", "desc"), limit(150)),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, depositos: snap.metadata.hasPendingWrites }));
        const list: Deposito[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Deposito);
        });
        setDepositos(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "depositos")
    );

    // 10. Sync Usuarios
    const unsubUsuarios = onSnapshot(
      collection(db, "usuarios"),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, usuarios: snap.metadata.hasPendingWrites }));
        const list: Usuario[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Usuario);
        });
        setUsuarios(list);
        setUsuariosLoaded(true);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, "usuarios");
        setUsuariosLoaded(true);
      }
    );

    // 11. Sync Auditoria
    const unsubAuditorias = onSnapshot(
      query(collection(db, "auditoria"), orderBy("fecha", "desc"), limit(200)),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, auditoria: snap.metadata.hasPendingWrites }));
        const list: AuditoriaLog[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as AuditoriaLog);
        });
        // Sort by date descending
        list.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
        setAuditorias(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "auditoria")
    );

    // 12. Sync Asignaciones Temporales
    const unsubAsignacionesTemporales = onSnapshot(
      collection(db, "asignacionesTemporales"),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, asignacionesTemporales: snap.metadata.hasPendingWrites }));
        const list: AsignacionTemporal[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as AsignacionTemporal);
        });
        setAsignacionesTemporales(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "asignacionesTemporales")
    );

    // 13. Sync Historial de Asignaciones
    const unsubHistorialAsignaciones = onSnapshot(
      query(collection(db, "historialAsignaciones"), orderBy("fecha", "desc"), limit(150)),
      (snap) => {
        setPendingWritesMap(prev => ({ ...prev, historialAsignaciones: snap.metadata.hasPendingWrites }));
        const list: HistorialAsignacion[] = [];
        snap.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as HistorialAsignacion);
        });
        list.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
        setHistorialAsignaciones(list);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "historialAsignaciones")
    );

    return () => {
      unsubConfig();
      unsubClientes();
      unsubPrestamos();
      unsubPagos();
      unsubGarantias();
      unsubGastos();
      unsubBancos();
      unsubCuadres();
      unsubDepositos();
      unsubUsuarios();
      unsubAuditorias();
      unsubAsignacionesTemporales();
      unsubHistorialAsignaciones();
    };
  }, [user]);

  // Demo Sandbox Local Storage Synchronizer
  useEffect(() => {
    if (!user || user.uid !== "demo-user-id") return;

    // Migrate old keys to new demo-isolated keys if they exist, then clean them up to prevent sync prompts
    const oldKeys = [
      "clientes", "prestamos", "pagos", "garantias", "gastos", "bancos",
      "cuadres", "depositos", "config", "usuarios", "auditorias"
    ];
    oldKeys.forEach(k => {
      const oldVal = localStorage.getItem(`easypres_${k}`);
      if (oldVal !== null && localStorage.getItem(`easypres_demo_${k}`) === null) {
        localStorage.setItem(`easypres_demo_${k}`, oldVal);
      }
      // Always remove the old shared keys to prevent the real account from prompting to sync them
      localStorage.removeItem(`easypres_${k}`);
    });

    const localClientes = demoLocalStorage.getItem("easypres_clientes");
    const localPrestamos = demoLocalStorage.getItem("easypres_prestamos");
    const localPagos = demoLocalStorage.getItem("easypres_pagos");
    const localGarantias = demoLocalStorage.getItem("easypres_garantias");
    const localGastos = demoLocalStorage.getItem("easypres_gastos");
    const localBancos = demoLocalStorage.getItem("easypres_bancos");
    const localCuadres = demoLocalStorage.getItem("easypres_cuadres");
    const localDepositos = demoLocalStorage.getItem("easypres_depositos");
    const localConfig = demoLocalStorage.getItem("easypres_config");

    if (localClientes) {
      setClientes(JSON.parse(localClientes));
    } else {
      const initialClientes: Cliente[] = [
        {
          id: "cli_1",
          codigo: "CLI-0001",
          nombre: "Juan Pérez",
          cedula: "001-1234567-8",
          telefono: "809-555-0101",
          direccion: "Ensanche Naco, Santo Domingo",
          correo: "juan.perez@email.com",
          referenciasPersonales: "Pedro Martínez (Hermano) - 809-555-0202",
          referenciasLaborales: "Gerente de Ventas en Grupo Corripio",
          fechaRegistro: new Date().toISOString().split("T")[0],
          cobradorId: "cobros.perez@easypres.com",
          cobradorNombre: "Cobrador Ruta 1"
        },
        {
          id: "cli_2",
          codigo: "CLI-0002",
          nombre: "María Rodríguez",
          cedula: "002-9876543-2",
          telefono: "809-555-0102",
          direccion: "Villa Olga, Santiago",
          correo: "maria.rod@email.com",
          referenciasPersonales: "Ana Rodríguez (Madre) - 809-555-0303",
          referenciasLaborales: "Contadora en Zona Franca Santiago",
          fechaRegistro: new Date().toISOString().split("T")[0],
          cobradorId: "cobros.perez@easypres.com",
          cobradorNombre: "Cobrador Ruta 1"
        },
        {
          id: "cli_3",
          codigo: "CLI-0003",
          nombre: "Carlos Gómez",
          cedula: "001-4567890-1",
          telefono: "809-555-0103",
          direccion: "Los Cacicazgos, Santo Domingo",
          correo: "carlos.gomez@email.com",
          referenciasPersonales: "Luis Gómez (Primo) - 809-555-0404",
          referenciasLaborales: "Propietario de Colmado El Sol",
          fechaRegistro: new Date().toISOString().split("T")[0]
        }
      ];
      setClientes(initialClientes);
      demoLocalStorage.setItem("easypres_clientes", JSON.stringify(initialClientes));
    }

    if (localPrestamos) {
      setPrestamos(JSON.parse(localPrestamos));
    } else {
      const initialPrestamos: Prestamo[] = [
        {
          id: "pre_1",
          numero: "PRE-0001",
          clienteId: "cli_1",
          clienteNombre: "Juan Pérez",
          capitalPrestado: 50000,
          tasaInteres: 10,
          tipoInteres: "Cuota Fija (Amortizable)",
          frecuenciaPago: "Mensual",
          plazoCuotas: 12,
          fechaInicio: "2026-01-10",
          fechaVencimiento: "2027-01-10",
          montoCuota: 5000,
          mora: 0,
          balancePendiente: 35000,
          interesTotal: 10000,
          montoTotal: 60000,
          estado: "Activo",
          proximaCuotaFecha: "2026-07-10",
          cuotasDetalle: JSON.stringify([]),
          cobradorId: "cobros.perez@easypres.com",
          cobradorNombre: "Cobrador Ruta 1"
        },
        {
          id: "pre_2",
          numero: "PRE-0002",
          clienteId: "cli_2",
          clienteNombre: "María Rodríguez",
          capitalPrestado: 25000,
          tasaInteres: 12,
          tipoInteres: "Interés Simple",
          frecuenciaPago: "Quincenal",
          plazoCuotas: 6,
          fechaInicio: "2026-05-15",
          fechaVencimiento: "2026-08-15",
          montoCuota: 4666,
          mora: 0,
          balancePendiente: 25000,
          interesTotal: 3000,
          montoTotal: 28000,
          estado: "Activo",
          proximaCuotaFecha: "2026-07-15",
          cuotasDetalle: JSON.stringify([]),
          cobradorId: "cobros.perez@easypres.com",
          cobradorNombre: "Cobrador Ruta 1"
        }
      ];
      setPrestamos(initialPrestamos);
      demoLocalStorage.setItem("easypres_prestamos", JSON.stringify(initialPrestamos));
    }

    if (localPagos) {
      setPagos(JSON.parse(localPagos));
    } else {
      const initialPagos: Pago[] = [
        {
          id: "pago_1",
          reciboNo: "REC-0001",
          prestamoId: "pre_1",
          clienteId: "cli_1",
          clienteNombre: "Juan Pérez",
          prestamoNumero: "PRE-0001",
          fecha: "2026-02-10",
          monto: 5000,
          tipoPago: "Pago de Cuota",
          capitalPagado: 4166.67,
          interesPagado: 833.33,
          moraPagado: 0,
          balanceAntes: 50000,
          balanceDespues: 45833.33,
          notas: "Primer pago de cuota - transferencia bancaria"
        },
        {
          id: "pago_2",
          reciboNo: "REC-0002",
          prestamoId: "pre_1",
          clienteId: "cli_1",
          clienteNombre: "Juan Pérez",
          prestamoNumero: "PRE-0001",
          fecha: "2026-03-10",
          monto: 5000,
          tipoPago: "Pago de Cuota",
          capitalPagado: 4166.67,
          interesPagado: 833.33,
          moraPagado: 0,
          balanceAntes: 45833.33,
          balanceDespues: 41666.66,
          notas: "Segundo pago - depósito en efectivo"
        }
      ];
      setPagos(initialPagos);
      demoLocalStorage.setItem("easypres_pagos", JSON.stringify(initialPagos));
    }

    if (localGarantias) {
      setGarantias(JSON.parse(localGarantias));
    } else {
      const initialGarantias: Garantia[] = [
        {
          id: "gar_1",
          prestamoId: "pre_1",
          clienteId: "cli_1",
          clienteNombre: "Juan Pérez",
          descripcion: "Honda Civic Sedan 2012 Gris - Placa A612345",
          valorEstimado: 450000,
          estado: "Entregada",
          fechaRegistro: "2026-01-10"
        }
      ];
      setGarantias(initialGarantias);
      demoLocalStorage.setItem("easypres_garantias", JSON.stringify(initialGarantias));
    }

    if (localGastos) {
      setGastos(JSON.parse(localGastos));
    } else {
      const initialGastos: Gasto[] = [
        {
          id: "gas_1",
          fecha: "2026-06-05",
          descripcion: "Alquiler mensual de oficina",
          monto: 15000,
          tipoEgreso: "Servicios",
          suplidor: "Inmobiliaria Santo Domingo",
          registradoPor: "Demo Admin"
        },
        {
          id: "gas_2",
          fecha: "2026-06-10",
          descripcion: "Pago de servicio de internet de oficina",
          monto: 2500,
          tipoEgreso: "Servicios",
          suplidor: "Claro Dominicana",
          registradoPor: "Demo Admin"
        }
      ];
      setGastos(initialGastos);
      demoLocalStorage.setItem("easypres_gastos", JSON.stringify(initialGastos));
    }

    if (localBancos) {
      setBancos(JSON.parse(localBancos));
    } else {
      const initialBancos: Banco[] = [
        {
          id: "ban_1",
          nombre: "Banco Popular Dominicano",
          numeroCuenta: "748192039",
          balance: 125000,
          moneda: "RD$"
        },
        {
          id: "ban_2",
          nombre: "Banco BHD",
          numeroCuenta: "918273645",
          balance: 45000,
          moneda: "RD$"
        }
      ];
      setBancos(initialBancos);
      demoLocalStorage.setItem("easypres_bancos", JSON.stringify(initialBancos));
    }

    if (localCuadres) {
      const parsed: CuadreCaja[] = JSON.parse(localCuadres);
      const deduped: CuadreCaja[] = [];
      const seen = new Set<string>();
      for (let i = parsed.length - 1; i >= 0; i--) {
        const item = parsed[i];
        if (item && item.id) {
          if (!seen.has(item.id)) {
            seen.add(item.id);
            deduped.unshift(item);
          }
        } else {
          deduped.unshift(item);
        }
      }
      setCuadres(deduped);
      demoLocalStorage.setItem("easypres_cuadres", JSON.stringify(deduped));
    } else {
      setCuadres([]);
      demoLocalStorage.setItem("easypres_cuadres", JSON.stringify([]));
    }

    if (localDepositos) {
      const parsed: Deposito[] = JSON.parse(localDepositos);
      const deduped: Deposito[] = [];
      const seen = new Set<string>();
      for (let i = parsed.length - 1; i >= 0; i--) {
        const item = parsed[i];
        if (item && item.id) {
          if (!seen.has(item.id)) {
            seen.add(item.id);
            deduped.unshift(item);
          }
        } else {
          deduped.unshift(item);
        }
      }
      setDepositos(deduped);
      demoLocalStorage.setItem("easypres_depositos", JSON.stringify(deduped));
    } else {
      setDepositos([]);
      demoLocalStorage.setItem("easypres_depositos", JSON.stringify([]));
    }

    if (localConfig) {
      setConfig(JSON.parse(localConfig));
    } else {
      setConfig(DEFAULT_CONFIG);
      demoLocalStorage.setItem("easypres_config", JSON.stringify(DEFAULT_CONFIG));
    }

    const localUsuarios = demoLocalStorage.getItem("easypres_usuarios");
    if (localUsuarios) {
      setUsuarios(JSON.parse(localUsuarios));
    } else {
      const initialUsuarios: Usuario[] = [
        {
          id: "usr_1",
          nombre: "Jesús HG",
          email: "jesushg.004@gmail.com",
          rol: "Administrador",
          activo: true
        },
        {
          id: "usr_2",
          nombre: "Supervisor María",
          email: "supervisor.maria@easypres.com",
          rol: "Supervisor",
          activo: true,
          permisos: {
            dashboard: { ver: true },
            clientes: { ver: true, crear: true, editar: true, eliminar: false, exportar: true },
            prestamos: { ver: true, crear: true, editar: true, eliminar: false, exportar: true },
            pagos: { ver: true, crear: true, editar: true, eliminar: false, exportar: true },
            garantias: { ver: true, crear: true, editar: true, eliminar: false, exportar: true },
            finanzas: { ver: true, crear: true, editar: true, eliminar: false, exportar: true },
            reportes: { ver: true, exportar: true },
            configuracion: { ver: true, editar: false }
          }
        },
        {
          id: "usr_3",
          nombre: "Cobrador Ruta 1",
          email: "cobros.perez@easypres.com",
          rol: "Cobrador",
          activo: true,
          permisos: {
            dashboard: { ver: true },
            clientes: { ver: true, crear: true, editar: true, eliminar: false, exportar: true },
            prestamos: { ver: true, crear: true, editar: false, eliminar: false, exportar: false },
            pagos: { ver: true, crear: true, editar: false, eliminar: false, exportar: true }
          }
        }
      ];
      setUsuarios(initialUsuarios);
      demoLocalStorage.setItem("easypres_usuarios", JSON.stringify(initialUsuarios));
    }

    const localAuditorias = demoLocalStorage.getItem("easypres_auditorias");
    if (localAuditorias) {
      setAuditorias(JSON.parse(localAuditorias));
    } else {
      const initialAuditorias: AuditoriaLog[] = [
        {
          id: "aud_init_1",
          usuarioRealizo: "Sistema (easypres)",
          fecha: new Date(Date.now() - 3600000).toISOString(),
          accion: "Inicialización del sistema de seguridad",
          usuarioAfectado: "Todos los operadores",
          detalles: "Se habilitó el control granular de accesos y la auditoría automática."
        }
      ];
      setAuditorias(initialAuditorias);
      demoLocalStorage.setItem("easypres_auditorias", JSON.stringify(initialAuditorias));
    }

    const localAsignacionesTemporales = demoLocalStorage.getItem("easypres_asignaciones_temporales");
    if (localAsignacionesTemporales) {
      setAsignacionesTemporales(JSON.parse(localAsignacionesTemporales));
    } else {
      setAsignacionesTemporales([]);
      demoLocalStorage.setItem("easypres_asignaciones_temporales", JSON.stringify([]));
    }

    const localHistorialAsignaciones = demoLocalStorage.getItem("easypres_historial_asignaciones");
    if (localHistorialAsignaciones) {
      setHistorialAsignaciones(JSON.parse(localHistorialAsignaciones));
    } else {
      setHistorialAsignaciones([]);
      demoLocalStorage.setItem("easypres_historial_asignaciones", JSON.stringify([]));
    }
  }, [user]);

  // Auth operations
  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (e: any) {
      console.error("Login failed:", e);
      if (e?.code === "auth/popup-closed-by-user" || e?.message?.includes("popup-closed-by-user")) {
        alert(
          "El inicio de sesión fue cancelado porque la ventana de Google se cerró antes de completar el acceso.\n\n" +
          "Sugerencias:\n" +
          "1. Si estás usando la vista previa (iframe), haz clic en el botón de 'Abrir en pestaña nueva' arriba a la derecha para iniciar sesión sin restricciones.\n" +
          "2. O bien, haz uso de los botones de ingreso rápido (Administrador, Supervisor o Cobrador) en la sección inferior para probar todas las funcionalidades instantáneamente."
        );
      } else if (e?.code === "auth/popup-blocked" || e?.message?.includes("popup-blocked")) {
        alert(
          "El navegador bloqueó la ventana emergente de Google.\n\n" +
          "Por favor, permite las ventanas emergentes en tu navegador o abre la aplicación en una pestaña nueva usando el botón superior derecho."
        );
      } else {
        alert("Error al iniciar sesión con Google: " + (e?.message || "Intente nuevamente."));
      }
    }
  };

  // Skip Login with Demo Sandbox Mode (for smooth offline/local testing in iframe)
  const handleDemoLogin = (roleEmail: string = "jesushg.004@gmail.com", name: string = "Jesús HG") => {
    const mockUser = {
      uid: "demo-user-id",
      email: roleEmail,
      displayName: name,
      photoURL: ""
    } as any;
    setUsuariosLoaded(true);
    setUser(mockUser);
  };

  const handleLogout = async () => {
    setUsuariosLoaded(false);
    if (user?.uid === "demo-user-id") {
      setUser(null);
    } else {
      await signOut(auth);
    }
  };

  // Immediate Block of Inactive Operators (Requirement 3)
  useEffect(() => {
    if (user && currentUserProfile && currentUserProfile.id !== "auto_admin") {
      const foundInList = usuarios.find(u => u.email.toLowerCase() === user.email?.toLowerCase());
      if (foundInList && foundInList.activo === false) {
        alert("Tu cuenta de operador ha sido desactivada por el administrador. El acceso al sistema ha sido bloqueado.");
        handleLogout();
      }
    }
  }, [user, usuarios, currentUserProfile]);

  // Auto-initialize or link user profile in Firestore so Firestore Security Rules pass
  useEffect(() => {
    if (user && user.uid !== "demo-user-id" && !authLoading && usuariosLoaded) {
      // Find if there is a document in 'usuarios' where id matches user.uid
      const profileById = usuarios.find(u => u.id === user.uid);
      
      // If there's no profile keyed by user.uid, let's see if there is one keyed by their email
      const profileByEmail = usuarios.find(u => u.email?.toLowerCase() === user.email?.toLowerCase());

      const hasRegisteredUsers = usuarios.length > 0;
      const isUnregistered = !profileById && !profileByEmail;

      if (hasRegisteredUsers && isUnregistered) {
        alert(
          `Acceso Denegado.\n\nEl correo electrónico "${user.email}" no está registrado como operador en el sistema.\n\n` +
          `Por favor, pídele al administrador principal que te registre como un operador en el módulo de "Ajustes Generales" utilizando esta dirección de correo.`
        );
        handleLogout();
        return;
      }

      if (!profileById) {
        const baseProfile = profileByEmail || {
          nombre: user.displayName || user.email?.split("@")[0] || "Administrador",
          email: user.email || "",
          rol: "Administrador",
          activo: true
        };

        const newProfile: Usuario = {
          ...baseProfile,
          id: user.uid,
          uid: user.uid,
          email: user.email || baseProfile.email
        };

        const ref = doc(collection(db, "usuarios"), user.uid);
        setDoc(ref, cleanFirestoreData(newProfile))
          .then(() => {
            console.log("Perfil de usuario auto-inicializado en Firestore con UID:", user.uid);
            
            // If they had a legacy profile with a different ID, we delete the old duplicate
            if (profileByEmail && profileByEmail.id && profileByEmail.id !== user.uid) {
              const oldRef = doc(collection(db, "usuarios"), profileByEmail.id);
              deleteDoc(oldRef)
                .then(() => {
                  console.log("Se eliminó el perfil legacy duplicado:", profileByEmail.id);
                })
                .catch(err => console.error("Error al eliminar perfil legacy:", err));
            }
          })
          .catch(err => {
            console.error("Error al auto-inicializar perfil de usuario en Firestore:", err);
          });
      } else if (profileById.email !== user.email || !profileById.uid) {
        const updatedProfile = {
          ...profileById,
          uid: user.uid,
          email: user.email || profileById.email
        };
        const ref = doc(collection(db, "usuarios"), user.uid);
        setDoc(ref, cleanFirestoreData(updatedProfile)).catch(err => console.error("Error updating profile fields:", err));
      }
    }
  }, [user, usuarios, authLoading, usuariosLoaded]);

  // Reset inactivity timer on user action
  const resetInactivityTimer = useCallback(() => {
    lastActivityRef.current = Date.now();
    if (showInactivityWarning) {
      setShowInactivityWarning(false);
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
      }
    }
  }, [showInactivityWarning]);

  // Listen to user events to detect activity (Requirement 5)
  useEffect(() => {
    if (!user) return;

    const events = ["mousedown", "keydown", "touchstart", "scroll", "click", "mousemove"];
    
    // Throttle listener to be highly performant
    let lastEventTime = 0;
    const handleActivity = () => {
      const now = Date.now();
      if (now - lastEventTime > 2000) { // check every 2 seconds max
        lastEventTime = now;
        resetInactivityTimer();
      }
    };

    events.forEach(e => window.addEventListener(e, handleActivity));

    // Monitor inactivity background timer
    const monitorInterval = setInterval(() => {
      if (showInactivityWarning) return; // let countdown handle it

      const timeoutMinutes = config?.timeoutInactividad ?? 30;
      const timeoutMs = timeoutMinutes * 60 * 1000;
      const timeElapsed = Date.now() - lastActivityRef.current;
      const enableWarning = config?.avisoInactividadHabilitado ?? true;

      if (enableWarning) {
        const warningThreshold = timeoutMs - 120000; // 2 minutes before
        if (timeElapsed >= warningThreshold && timeoutMs > 120000) {
          // Calculate remaining seconds precisely
          const remainingSeconds = Math.max(0, Math.round((timeoutMs - timeElapsed) / 1000));
          setInactivityCountdown(remainingSeconds > 0 ? remainingSeconds : 120);
          setShowInactivityWarning(true);
        } else if (timeElapsed >= timeoutMs) {
          addAuditLog("Cierre de Sesión por Inactividad", "Sistema", "Sesión finalizada automáticamente tras periodo de inactividad.").then(() => {
            handleLogout();
          });
        }
      } else {
        if (timeElapsed >= timeoutMs) {
          addAuditLog("Cierre de Sesión por Inactividad", "Sistema", "Sesión finalizada automáticamente tras periodo de inactividad.").then(() => {
            handleLogout();
          });
        }
      }
    }, 10000); // Check every 10 seconds

    return () => {
      events.forEach(e => window.removeEventListener(e, handleActivity));
      clearInterval(monitorInterval);
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, [user, config, showInactivityWarning, resetInactivityTimer]);

  // Handle countdown interval when warning modal is active
  useEffect(() => {
    if (showInactivityWarning) {
      countdownIntervalRef.current = setInterval(() => {
        setInactivityCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(countdownIntervalRef.current);
            countdownIntervalRef.current = null;
            setShowInactivityWarning(false);
            addAuditLog("Cierre de Sesión por Inactividad", "Sistema", "Sesión finalizada automáticamente tras expirar la advertencia.").then(() => {
              handleLogout();
            });
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
      }
    }

    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, [showInactivityWarning]);

  // Logger for Security System Audit Logs
  const addAuditLog = async (
    accion: string,
    usuarioAfectado: string,
    detalles?: string,
    valorAnterior?: string,
    valorNuevo?: string,
    motivo?: string
  ) => {
    const operatorEmail = currentUserProfile?.email || user?.email || "Usuario Desconocido";
    const operatorName = currentUserProfile?.nombre || user?.displayName || operatorEmail;
    
    const newLog: AuditoriaLog = {
      id: generateOfflineId("aud"),
      usuarioRealizo: `${operatorName} (${operatorEmail})`,
      fecha: new Date().toISOString(),
      accion,
      usuarioAfectado,
      detalles,
      valorAnterior,
      valorNuevo,
      motivo
    };

    if (user?.uid === "demo-user-id") {
      const list = [newLog, ...auditorias];
      setAuditorias(list);
      demoLocalStorage.setItem("easypres_auditorias", JSON.stringify(list));
      return;
    }

    const path = "auditoria";
    const ref = doc(collection(db, path), newLog.id);
    try {
      await setDoc(ref, newLog);
    } catch (e) {
      console.error("Failed to write audit log:", e);
    }
  };

  // Firestore & Sandbox mutation callbacks
  const saveUsuario = async (u: Usuario) => {
    const updatedUsuario = { ...u, id: u.id || generateOfflineId("usr") };
    const isNew = !usuarios.some(item => item.id === updatedUsuario.id);
    const originalUser = usuarios.find(item => item.id === updatedUsuario.id);
    
    let detailsStr = `Rol: ${updatedUsuario.rol}, Activo: ${updatedUsuario.activo ? "Sí" : "No"}`;
    if (!isNew && originalUser) {
      // Check if permissions changed
      const originalPermsJson = JSON.stringify(originalUser.permisos || {});
      const newPermsJson = JSON.stringify(updatedUsuario.permisos || {});
      if (originalPermsJson !== newPermsJson) {
        detailsStr += " [Se actualizaron los permisos asignados]";
      }
    }

    const logAccion = isNew ? "Creación de Operador" : "Edición de Operador";

    if (user?.uid === "demo-user-id") {
      const list = usuarios.some(item => item.id === updatedUsuario.id)
        ? usuarios.map(item => item.id === updatedUsuario.id ? updatedUsuario : item)
        : [...usuarios, updatedUsuario];
      setUsuarios(list);
      demoLocalStorage.setItem("easypres_usuarios", JSON.stringify(list));
      await addAuditLog(logAccion, updatedUsuario.email, detailsStr);
      return;
    }
    const path = "usuarios";
    const ref = doc(collection(db, path), updatedUsuario.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedUsuario));
      await addAuditLog(logAccion, updatedUsuario.email, detailsStr);
    } catch (e) {
      handleFirestoreError(e as any, OperationType.WRITE, `${path}/${updatedUsuario.id}`);
      throw e;
    }
  };

  const deleteUsuario = async (id: string) => {
    const targetUser = usuarios.find(item => item.id === id);
    const affectedEmail = targetUser ? targetUser.email : `ID: ${id}`;
    
    if (user?.uid === "demo-user-id") {
      const list = usuarios.filter(item => item.id !== id);
      setUsuarios(list);
      demoLocalStorage.setItem("easypres_usuarios", JSON.stringify(list));
      await addAuditLog("Eliminación de Operador", affectedEmail, "Se eliminó de forma física al operador del sistema.");
      return;
    }
    const path = "usuarios";
    const ref = doc(collection(db, path), id);
    try {
      await deleteDoc(ref);
      await addAuditLog("Eliminación de Operador", affectedEmail, "Se eliminó de forma física al operador del sistema.");
    } catch (e) {
      handleFirestoreError(e as any, OperationType.DELETE, `${path}/${id}`);
      throw e;
    }
  };

  const saveCliente = async (cliente: Cliente) => {
    const updatedCliente = { ...cliente, id: cliente.id || generateOfflineId("cli") };
    const isNew = !clientes.some(c => c.id === updatedCliente.id);
    const logAccion = isNew ? "Creación de Cliente" : "Edición de Cliente";
    const detailsStr = `Nombre: ${updatedCliente.nombre}, Cédula: ${updatedCliente.cedula || 'N/A'}, Teléfono: ${updatedCliente.telefono || 'N/A'}`;

    if (user?.uid === "demo-user-id") {
      const list = clientes.some(c => c.id === updatedCliente.id)
        ? clientes.map(c => c.id === updatedCliente.id ? updatedCliente : c)
        : [...clientes, updatedCliente];
      setClientes(list);
      demoLocalStorage.setItem("easypres_clientes", JSON.stringify(list));
      await addAuditLog(logAccion, `Cliente: ${updatedCliente.nombre}`, detailsStr);
      return;
    }
    const path = "clientes";
    const ref = doc(collection(db, path), updatedCliente.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedCliente));
      await addAuditLog(logAccion, `Cliente: ${updatedCliente.nombre}`, detailsStr);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/${updatedCliente.id}`);
    }
  };

  const deleteCliente = async (id: string) => {
    const originalCli = clientes.find(c => c.id === id);
    const detailsStr = originalCli ? `Nombre: ${originalCli.nombre}, Cédula: ${originalCli.cedula || 'N/A'}` : `ID: ${id}`;

    if (user?.uid === "demo-user-id") {
      const list = clientes.filter(c => c.id !== id);
      setClientes(list);
      demoLocalStorage.setItem("easypres_clientes", JSON.stringify(list));
      await addAuditLog("Eliminación de Cliente", id, detailsStr);
      return;
    }
    const path = "clientes";
    try {
      await deleteDoc(doc(db, path, id));
      await addAuditLog("Eliminación de Cliente", id, detailsStr);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${path}/${id}`);
    }
  };

  const savePrestamo = async (prestamo: Prestamo) => {
    const updatedPrestamo = { ...prestamo, id: prestamo.id || generateOfflineId("pre") };
    const isNew = !prestamos.some(p => p.id === updatedPrestamo.id);
    const originalPre = prestamos.find(p => p.id === updatedPrestamo.id);

    let logAccion = isNew ? "Creación de Préstamo" : "Edición de Préstamo";
    let detailsStr = `Monto: ${config.moneda}${updatedPrestamo.capitalPrestado}, Cuotas: ${updatedPrestamo.plazoCuotas}, Frecuencia: ${updatedPrestamo.frecuenciaPago}`;
    
    if (!isNew && originalPre) {
      if (originalPre.estado !== updatedPrestamo.estado) {
        logAccion = "Cambio de Estado de Préstamo";
        detailsStr = `Estado cambió de '${originalPre.estado}' a '${updatedPrestamo.estado}'. Monto: ${config.moneda}${updatedPrestamo.capitalPrestado}`;
        if (updatedPrestamo.estado === "Activo") {
          logAccion = "Aprobación de Préstamo";
        } else if (updatedPrestamo.estado === "Cancelado") {
          logAccion = "Cancelación de Préstamo";
        } else if (updatedPrestamo.estado === "Saldado") {
          logAccion = "Saldado de Préstamo";
        }
      }
    }

    if (user?.uid === "demo-user-id") {
      const list = prestamos.some(p => p.id === updatedPrestamo.id)
        ? prestamos.map(p => p.id === updatedPrestamo.id ? updatedPrestamo : p)
        : [...prestamos, updatedPrestamo];
      setPrestamos(list);
      demoLocalStorage.setItem("easypres_prestamos", JSON.stringify(list));
      await addAuditLog(logAccion, `Préstamo: ${updatedPrestamo.id}`, detailsStr);
      return;
    }
    const path = "prestamos";
    const ref = doc(collection(db, path), updatedPrestamo.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedPrestamo));
      await addAuditLog(logAccion, `Préstamo: ${updatedPrestamo.id}`, detailsStr);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/${updatedPrestamo.id}`);
    }
  };

  const deletePrestamo = async (id: string) => {
    const originalPre = prestamos.find(p => p.id === id);
    const detailsStr = originalPre ? `Monto: ${config.moneda}${originalPre.capitalPrestado}, Estado: ${originalPre.estado}` : `ID: ${id}`;

    if (user?.uid === "demo-user-id") {
      const list = prestamos.filter(p => p.id !== id);
      setPrestamos(list);
      demoLocalStorage.setItem("easypres_prestamos", JSON.stringify(list));
      await addAuditLog("Eliminación de Préstamo", id, detailsStr);
      return;
    }
    const path = "prestamos";
    try {
      await deleteDoc(doc(db, path, id));
      await addAuditLog("Eliminación de Préstamo", id, detailsStr);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${path}/${id}`);
    }
  };

  const savePago = async (pago: Pago, updatedPrestamo: Prestamo) => {
    const updatedPago = { ...pago, id: pago.id || generateOfflineId("pago") };
    const isNew = !pagos.some(p => p.id === updatedPago.id);
    const logAccion = isNew ? "Registro de Pago" : "Edición de Pago";
    const detailsStr = `Préstamo ID: ${updatedPago.prestamoId}, Tipo: ${updatedPago.tipoPago}, Monto Recibido: ${config.moneda}${updatedPago.monto}`;

    if (user?.uid === "demo-user-id") {
      // Save Pago
      const pList = pagos.some(p => p.id === updatedPago.id)
        ? pagos.map(p => p.id === updatedPago.id ? updatedPago : p)
        : [...pagos, updatedPago];
      setPagos(pList);
      demoLocalStorage.setItem("easypres_pagos", JSON.stringify(pList));

      // Save Prestamo
      const prList = prestamos.map(pr => pr.id === updatedPrestamo.id ? updatedPrestamo : pr);
      setPrestamos(prList);
      demoLocalStorage.setItem("easypres_prestamos", JSON.stringify(prList));
      
      await addAuditLog(logAccion, `Pago ID: ${updatedPago.id}`, detailsStr);
      return;
    }
    // Secure transactional sync: Update loan balance and register payment atomically via writeBatch
    const pathPago = "pagos";
    const pathPrestamo = "prestamos";
    const refPago = doc(collection(db, pathPago), updatedPago.id);
    const refPrestamo = doc(db, pathPrestamo, updatedPrestamo.id!);
    try {
      const batch = writeBatch(db);
      batch.set(refPago, cleanFirestoreData(updatedPago));
      batch.set(refPrestamo, cleanFirestoreData(updatedPrestamo));
      await batch.commit();
      
      await addAuditLog(logAccion, `Pago ID: ${updatedPago.id}`, detailsStr);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `batch-pagos-prestamos`);
    }
  };

  const deletePago = async (id: string) => {
    const originalPago = pagos.find(p => p.id === id);
    const detailsStr = originalPago 
      ? `Monto: ${config.moneda}${originalPago.monto}, Préstamo ID: ${originalPago.prestamoId}, Tipo: ${originalPago.tipoPago}` 
      : `ID: ${id}`;

    if (user?.uid === "demo-user-id") {
      const list = pagos.filter(p => p.id !== id);
      setPagos(list);
      demoLocalStorage.setItem("easypres_pagos", JSON.stringify(list));
      await addAuditLog("Anulación de Pago", `Pago ID: ${id}`, `Se eliminó/anuló el pago. Detalles: ${detailsStr}`);
      return;
    }
    const path = "pagos";
    try {
      await deleteDoc(doc(db, path, id));
      await addAuditLog("Anulación de Pago", `Pago ID: ${id}`, `Se eliminó/anuló el pago. Detalles: ${detailsStr}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${path}/${id}`);
    }
  };

  const saveGarantia = async (garantia: Garantia) => {
    const updatedGarantia = { ...garantia, id: garantia.id || generateOfflineId("gar") };
    if (user?.uid === "demo-user-id") {
      const list = garantias.some(g => g.id === updatedGarantia.id)
        ? garantias.map(g => g.id === updatedGarantia.id ? updatedGarantia : g)
        : [...garantias, updatedGarantia];
      setGarantias(list);
      demoLocalStorage.setItem("easypres_garantias", JSON.stringify(list));
      return;
    }
    const path = "garantias";
    const ref = doc(collection(db, path), updatedGarantia.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedGarantia));
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/${updatedGarantia.id}`);
    }
  };

  const deleteGarantia = async (id: string) => {
    if (user?.uid === "demo-user-id") {
      const list = garantias.filter(g => g.id !== id);
      setGarantias(list);
      demoLocalStorage.setItem("easypres_garantias", JSON.stringify(list));
      return;
    }
    const path = "garantias";
    try {
      await deleteDoc(doc(db, path, id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${path}/${id}`);
    }
  };

  const saveGasto = async (gasto: Gasto) => {
    const updatedGasto = { ...gasto, id: gasto.id || generateOfflineId("gas") };
    if (user?.uid === "demo-user-id") {
      const list = gastos.some(g => g.id === updatedGasto.id)
        ? gastos.map(g => g.id === updatedGasto.id ? updatedGasto : g)
        : [...gastos, updatedGasto];
      setGastos(list);
      demoLocalStorage.setItem("easypres_gastos", JSON.stringify(list));
      return;
    }
    const path = "gastos";
    const ref = doc(collection(db, path), updatedGasto.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedGasto));
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/${updatedGasto.id}`);
    }
  };

  const saveBanco = async (banco: Banco) => {
    const updatedBanco = { ...banco, id: banco.id || generateOfflineId("ban") };
    if (user?.uid === "demo-user-id") {
      const list = bancos.some(b => b.id === updatedBanco.id)
        ? bancos.map(b => b.id === updatedBanco.id ? updatedBanco : b)
        : [...bancos, updatedBanco];
      setBancos(list);
      demoLocalStorage.setItem("easypres_bancos", JSON.stringify(list));
      return;
    }
    const path = "bancos";
    const ref = doc(collection(db, path), updatedBanco.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedBanco));
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/${updatedBanco.id}`);
    }
  };

  const saveCuadre = async (cuadre: CuadreCaja) => {
    const updatedCuadre = { ...cuadre, id: cuadre.id || generateOfflineId("cua") };
    if (user?.uid === "demo-user-id") {
      const list = cuadres.some(c => c.id === updatedCuadre.id)
        ? cuadres.map(c => c.id === updatedCuadre.id ? updatedCuadre : c)
        : [...cuadres, updatedCuadre];
      setCuadres(list);
      demoLocalStorage.setItem("easypres_cuadres", JSON.stringify(list));
      return;
    }
    const path = "cuadres";
    const ref = doc(collection(db, path), updatedCuadre.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedCuadre));
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/${updatedCuadre.id}`);
    }
  };

  const saveDeposito = async (deposito: Deposito) => {
    const updatedDeposito = { ...deposito, id: deposito.id || generateOfflineId("dep") };
    if (user?.uid === "demo-user-id") {
      const list = depositos.some(d => d.id === updatedDeposito.id)
        ? depositos.map(d => d.id === updatedDeposito.id ? updatedDeposito : d)
        : [...depositos, updatedDeposito];
      setDepositos(list);
      demoLocalStorage.setItem("easypres_depositos", JSON.stringify(list));

      // Auto update bank balance locally
      const updatedBancos = bancos.map(b => {
        if (b.id === deposito.bancoId) {
          return { ...b, balance: b.balance + deposito.monto };
        }
        return b;
      });
      setBancos(updatedBancos);
      demoLocalStorage.setItem("easypres_bancos", JSON.stringify(updatedBancos));
      return;
    }
    const path = "depositos";
    const ref = doc(collection(db, path), updatedDeposito.id);
    try {
      await setDoc(ref, cleanFirestoreData(updatedDeposito));
      // Auto-update bank balance in firestore
      const targetBank = bancos.find(b => b.id === deposito.bancoId);
      if (targetBank) {
        const updatedBanco = { ...targetBank, balance: targetBank.balance + deposito.monto };
        const bankRef = doc(db, "bancos", targetBank.id!);
        await setDoc(bankRef, cleanFirestoreData(updatedBanco));
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/${updatedDeposito.id}`);
    }
  };

  const saveConfiguracion = async (newConfig: Configuracion) => {
    if (user?.uid === "demo-user-id") {
      setConfig(newConfig);
      demoLocalStorage.setItem("easypres_config", JSON.stringify(newConfig));
      return;
    }
    const path = "configuracion";
    try {
      await setDoc(doc(db, path, "general"), cleanFirestoreData(newConfig));
      setConfig(newConfig);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `${path}/general`);
    }
  };

  const reassignClient = async (
    clienteId: string,
    cobradorId: string, // Email of the collector
    motivo: string,
    tipo: "Inicial" | "Permanente" | "Temporal" = "Permanente"
  ) => {
    const client = clientes.find(c => c.id === clienteId);
    if (!client) throw new Error("Cliente no encontrado");

    const matchedCobrador = usuarios.find(u => u.email === cobradorId || u.id === cobradorId);
    const cobradorNombre = matchedCobrador ? matchedCobrador.nombre : "Cobrador";
    const cobradorEmail = matchedCobrador ? matchedCobrador.email : cobradorId;

    const updatedCliente: Cliente = {
      ...client,
      cobradorId: cobradorEmail,
      cobradorNombre: cobradorNombre
    };

    const prevCobradorUid = client.cobradorId || "";
    const prevCobradorNombre = client.cobradorNombre || "Sin Cobrador";

    const historyItem: HistorialAsignacion = {
      id: generateOfflineId("asig"),
      fecha: new Date().toISOString(),
      clienteId: client.id!,
      clienteNombre: client.nombre,
      cobradorAnteriorUid: prevCobradorUid,
      cobradorAnteriorNombre: prevCobradorNombre,
      nuevoCobradorUid: cobradorEmail,
      nuevoCobradorNombre: cobradorNombre,
      usuarioRealizo: currentUserProfile?.nombre || user?.email || "Supervisor",
      motivo,
      tipo
    };

    // Find active/overdue loans for this client
    const loansToUpdate = prestamos.filter(
      p => p.clienteId === clienteId && (p.estado === "Activo" || p.estado === "Atrasado")
    ).map(p => ({
      ...p,
      cobradorId: cobradorEmail,
      cobradorNombre: cobradorNombre
    }));

    if (user?.uid === "demo-user-id") {
      // Clients update
      const newClients = clientes.map(c => c.id === clienteId ? updatedCliente : c);
      setClientes(newClients);
      demoLocalStorage.setItem("easypres_clientes", JSON.stringify(newClients));

      // Loans update
      if (loansToUpdate.length > 0) {
        const newLoans = prestamos.map(p => {
          const match = loansToUpdate.find(lu => lu.id === p.id);
          return match ? match : p;
        });
        setPrestamos(newLoans);
        demoLocalStorage.setItem("easypres_prestamos", JSON.stringify(newLoans));
      }

      // History log update
      const newHistorial = [historyItem, ...historialAsignaciones];
      setHistorialAsignaciones(newHistorial);
      demoLocalStorage.setItem("easypres_historial_asignaciones", JSON.stringify(newHistorial));

      await addAuditLog(
        `Asignación de Cobrador (${tipo})`,
        client.nombre,
        `Se asignó el cliente a ${cobradorNombre}. Anterior: ${prevCobradorNombre}. Motivo: ${motivo}`
      );
      return;
    }

    try {
      // Save client
      await setDoc(doc(db, "clientes", clienteId), cleanFirestoreData(updatedCliente));

      // Save loans
      for (const l of loansToUpdate) {
        await setDoc(doc(db, "prestamos", l.id!), cleanFirestoreData(l));
      }

      // Save history log
      await setDoc(doc(db, "historialAsignaciones", historyItem.id!), cleanFirestoreData(historyItem));

      await addAuditLog(
        `Asignación de Cobrador (${tipo})`,
        client.nombre,
        `Se asignó el cliente a ${cobradorNombre}. Anterior: ${prevCobradorNombre}. Motivo: ${motivo}`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `reassignClient/${clienteId}`);
      throw err;
    }
  };

  const saveAsignacionTemporal = async (asig: AsignacionTemporal) => {
    const updatedAsig = { ...asig, id: asig.id || generateOfflineId("asigtemp") };
    
    // Create reference history record too
    const historyItem: HistorialAsignacion = {
      id: generateOfflineId("asighist"),
      fecha: new Date().toISOString(),
      clienteId: asig.clienteId,
      clienteNombre: clientes.find(c => c.id === asig.clienteId)?.nombre || "Cliente",
      cobradorAnteriorUid: asig.cobradorOriginalUid,
      cobradorAnteriorNombre: usuarios.find(u => u.email === asig.cobradorOriginalUid)?.nombre || "Cobrador Original",
      nuevoCobradorUid: asig.cobradorTemporalUid,
      nuevoCobradorNombre: usuarios.find(u => u.email === asig.cobradorTemporalUid)?.nombre || "Cobrador Temporal",
      usuarioRealizo: currentUserProfile?.nombre || user?.email || "Supervisor",
      motivo: `Asignación Temporal: ${asig.motivo} (Desde ${asig.fechaInicio} hasta ${asig.fechaFin})`,
      tipo: "Temporal"
    };

    if (user?.uid === "demo-user-id") {
      const tempMap = asignacionesTemporales.some(a => a.id === updatedAsig.id)
        ? asignacionesTemporales.map(a => a.id === updatedAsig.id ? updatedAsig : a)
        : [updatedAsig, ...asignacionesTemporales];
      setAsignacionesTemporales(tempMap);
      demoLocalStorage.setItem("easypres_asignaciones_temporales", JSON.stringify(tempMap));

      const histMap = [historyItem, ...historialAsignaciones];
      setHistorialAsignaciones(histMap);
      demoLocalStorage.setItem("easypres_historial_asignaciones", JSON.stringify(histMap));

      await addAuditLog(
        "Asignación Temporal de Cobro",
        historyItem.clienteNombre,
        `Cobrador Temporal: ${historyItem.nuevoCobradorNombre}. Motivo: ${asig.motivo}`
      );
      return;
    }

    try {
      await setDoc(doc(db, "asignacionesTemporales", updatedAsig.id), cleanFirestoreData(updatedAsig));
      await setDoc(doc(db, "historialAsignaciones", historyItem.id), cleanFirestoreData(historyItem));

      await addAuditLog(
        "Asignación Temporal de Cobro",
        historyItem.clienteNombre,
        `Cobrador Temporal: ${historyItem.nuevoCobradorNombre}. Motivo: ${asig.motivo}`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `asignacionesTemporales/${updatedAsig.id}`);
    }
  };

  const saveHistorialAsignacion = async (hist: HistorialAsignacion) => {
    const updatedHist = { ...hist, id: hist.id || generateOfflineId("asighist") };
    if (user?.uid === "demo-user-id") {
      const list = [updatedHist, ...historialAsignaciones];
      setHistorialAsignaciones(list);
      demoLocalStorage.setItem("easypres_historial_asignaciones", JSON.stringify(list));
      return;
    }
    try {
      await setDoc(doc(db, "historialAsignaciones", updatedHist.id), cleanFirestoreData(updatedHist));
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `historialAsignaciones/${updatedHist.id}`);
    }
  };

  const transferirCartera = async (
    sourceCobradorEmail: string,
    destCobradorEmail: string,
    options: { clients: boolean; loans: boolean; route: boolean; history: boolean },
    motivo: string
  ) => {
    const sourceUser = usuarios.find(u => u.email === sourceCobradorEmail);
    const destUser = usuarios.find(u => u.email === destCobradorEmail);

    if (!sourceUser || !destUser) throw new Error("Operadores de cartera inválidos");

    const sourceName = sourceUser.nombre;
    const destName = destUser.nombre;

    // Get all clients belonging to source
    const targetClients = clientes.filter(c => c.cobradorId === sourceCobradorEmail);
    const targetClientIds = targetClients.map(c => c.id!);

    const updatedClients = targetClients.map(c => ({
      ...c,
      cobradorId: destCobradorEmail,
      cobradorNombre: destName
    }));

    // Get all active/overdue loans for these clients or directly assigned
    const targetLoans = prestamos.filter(
      p => (p.cobradorId === sourceCobradorEmail || targetClientIds.includes(p.clienteId)) && 
           (p.estado === "Activo" || p.estado === "Atrasado")
    ).map(p => ({
      ...p,
      cobradorId: destCobradorEmail,
      cobradorNombre: destName
    }));

    // Create a history logs list
    const addedHistories: HistorialAsignacion[] = [];
    if (options.history) {
      targetClients.forEach(c => {
        addedHistories.push({
          id: generateOfflineId("asighist"),
          fecha: new Date().toISOString(),
          clienteId: c.id!,
          clienteNombre: c.nombre,
          cobradorAnteriorUid: sourceCobradorEmail,
          cobradorAnteriorNombre: sourceName,
          nuevoCobradorUid: destCobradorEmail,
          nuevoCobradorNombre: destName,
          usuarioRealizo: currentUserProfile?.nombre || user?.email || "Supervisor",
          motivo: `Transferencia Masiva de Cartera: ${motivo}`,
          tipo: "Permanente"
        });
      });
    }

    if (user?.uid === "demo-user-id") {
      // Apply to clients state
      if (options.clients && updatedClients.length > 0) {
        const clientIdsToReplace = updatedClients.map(uc => uc.id);
        const newClients = clientes.map(c => {
          const match = updatedClients.find(uc => uc.id === c.id);
          return match ? match : c;
        });
        setClientes(newClients);
        demoLocalStorage.setItem("easypres_clientes", JSON.stringify(newClients));
      }

      // Apply to loans state
      if (options.loans && targetLoans.length > 0) {
        const newLoans = prestamos.map(p => {
          const match = targetLoans.find(tl => tl.id === p.id);
          return match ? match : p;
        });
        setPrestamos(newLoans);
        demoLocalStorage.setItem("easypres_prestamos", JSON.stringify(newLoans));
      }

      // Apply histories
      if (addedHistories.length > 0) {
        const newHistorial = [...addedHistories, ...historialAsignaciones];
        setHistorialAsignaciones(newHistorial);
        demoLocalStorage.setItem("easypres_historial_asignaciones", JSON.stringify(newHistorial));
      }

      await addAuditLog(
        "Transferencia de Cartera",
        destName,
        `Se transfirió la cartera de ${sourceName} a ${destName}. Clientes: ${updatedClients.length}, Préstamos: ${targetLoans.length}. Motivo: ${motivo}`
      );
      return;
    }

    // In real Firebase mode, execute sequential/batch setDocs
    try {
      if (options.clients) {
        for (const c of updatedClients) {
          await setDoc(doc(db, "clientes", c.id!), cleanFirestoreData(c));
        }
      }

      if (options.loans) {
        for (const l of targetLoans) {
          await setDoc(doc(db, "prestamos", l.id!), cleanFirestoreData(l));
        }
      }

      if (options.history) {
        for (const h of addedHistories) {
          await setDoc(doc(db, "historialAsignaciones", h.id!), cleanFirestoreData(h));
        }
      }

      await addAuditLog(
        "Transferencia de Cartera",
        destName,
        `Se transfirió la cartera de ${sourceName} a ${destName}. Clientes: ${updatedClients.length}, Préstamos: ${targetLoans.length}. Motivo: ${motivo}`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, "transferirCartera");
      throw err;
    }
  };

  const restoreBackup = async (data: any) => {
    // 1. If we are in demo sandbox mode
    if (user?.uid === "demo-user-id") {
      if (data.clientes) demoLocalStorage.setItem("easypres_clientes", JSON.stringify(data.clientes));
      if (data.prestamos) demoLocalStorage.setItem("easypres_prestamos", JSON.stringify(data.prestamos));
      if (data.pagos) demoLocalStorage.setItem("easypres_pagos", JSON.stringify(data.pagos));
      if (data.garantias) demoLocalStorage.setItem("easypres_garantias", JSON.stringify(data.garantias));
      if (data.gastos) demoLocalStorage.setItem("easypres_gastos", JSON.stringify(data.gastos));
      if (data.bancos) demoLocalStorage.setItem("easypres_bancos", JSON.stringify(data.bancos));
      if (data.cuadres) demoLocalStorage.setItem("easypres_cuadres", JSON.stringify(data.cuadres));
      if (data.depositos) demoLocalStorage.setItem("easypres_depositos", JSON.stringify(data.depositos));
      if (data.configuracion) demoLocalStorage.setItem("easypres_config", JSON.stringify(data.configuracion));
      if (data.usuarios) demoLocalStorage.setItem("easypres_usuarios", JSON.stringify(data.usuarios));
      return;
    }

    // 2. Real Firestore Mode
    const promises: Promise<void>[] = [];

    // Save configuracion
    if (data.configuracion) {
      promises.push(setDoc(doc(db, "configuracion", "general"), cleanFirestoreData(data.configuracion)));
    }

    // Function to enqueue list of docs
    const enqueueDocs = (collectionName: string, items: any[]) => {
      if (!items || !Array.isArray(items)) return;
      items.forEach(item => {
        if (item.id) {
          promises.push(setDoc(doc(db, collectionName, item.id), cleanFirestoreData(item)));
        }
      });
    };

    enqueueDocs("clientes", data.clientes);
    enqueueDocs("prestamos", data.prestamos);
    enqueueDocs("pagos", data.pagos);
    enqueueDocs("garantias", data.garantias);
    enqueueDocs("gastos", data.gastos);
    enqueueDocs("bancos", data.bancos);
    enqueueDocs("cuadres", data.cuadres);
    enqueueDocs("depositos", data.depositos);
    enqueueDocs("usuarios", data.usuarios);

    // Run all promises
    await Promise.all(promises);
  };

  const wipeDatabase = async () => {
    // 1. If we are in demo sandbox mode
    if (user?.uid === "demo-user-id") {
      demoLocalStorage.setItem("easypres_clientes", "[]");
      demoLocalStorage.setItem("easypres_prestamos", "[]");
      demoLocalStorage.setItem("easypres_pagos", "[]");
      demoLocalStorage.setItem("easypres_garantias", "[]");
      demoLocalStorage.setItem("easypres_gastos", "[]");
      demoLocalStorage.setItem("easypres_bancos", "[]");
      demoLocalStorage.setItem("easypres_cuadres", "[]");
      demoLocalStorage.setItem("easypres_depositos", "[]");

      setClientes([]);
      setPrestamos([]);
      setPagos([]);
      setGarantias([]);
      setGastos([]);
      setBancos([]);
      setCuadres([]);
      setDepositos([]);
      return;
    }

    // 2. Real Firestore Mode
    const promises: Promise<void>[] = [];

    clientes.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "clientes", item.id)));
    });
    prestamos.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "prestamos", item.id)));
    });
    pagos.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "pagos", item.id)));
    });
    garantias.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "garantias", item.id)));
    });
    gastos.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "gastos", item.id)));
    });
    bancos.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "bancos", item.id)));
    });
    cuadres.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "cuadres", item.id)));
    });
    depositos.forEach(item => {
      if (item.id) promises.push(deleteDoc(doc(db, "depositos", item.id)));
    });

    await Promise.all(promises);

    await addAuditLog(
      "Reinicio de Base de Datos",
      user?.email || "Usuario",
      "Se limpió por completo la base de datos eliminando todos los registros de clientes, préstamos, cobros, garantías, egresos y bancos para iniciar desde cero."
    );
  };

  const handleImportLocalData = async () => {
    setImportingLocalData(true);
    try {
      const c = JSON.parse(localStorage.getItem("easypres_clientes") || "[]");
      const pr = JSON.parse(localStorage.getItem("easypres_prestamos") || "[]");
      const pa = JSON.parse(localStorage.getItem("easypres_pagos") || "[]");
      const g = JSON.parse(localStorage.getItem("easypres_garantias") || "[]");

      const realLocalClientes = c.filter((item: any) => !["cli_1", "cli_2", "cli_3"].includes(item.id));
      const realLocalPrestamos = pr.filter((item: any) => !["pre_1", "pre_2"].includes(item.id));
      const realLocalPagos = pa.filter((item: any) => !["pago_1"].includes(item.id));
      const realLocalGarantias = g.filter((item: any) => !["gar_1"].includes(item.id));

      const batch = writeBatch(db);

      // Add each client to batch
      realLocalClientes.forEach((item: any) => {
        const ref = doc(collection(db, "clientes"), item.id);
        batch.set(ref, item);
      });

      // Add each loan to batch
      realLocalPrestamos.forEach((item: any) => {
        const ref = doc(collection(db, "prestamos"), item.id);
        batch.set(ref, item);
      });

      // Add each payment to batch
      realLocalPagos.forEach((item: any) => {
        const ref = doc(collection(db, "pagos"), item.id);
        batch.set(ref, item);
      });

      // Add each guarantee to batch
      realLocalGarantias.forEach((item: any) => {
        const ref = doc(collection(db, "garantias"), item.id);
        batch.set(ref, item);
      });

      await batch.commit();

      // Clear local storage demo entries to prevent prompting again
      localStorage.removeItem("easypres_clientes");
      localStorage.removeItem("easypres_prestamos");
      localStorage.removeItem("easypres_pagos");
      localStorage.removeItem("easypres_garantias");

      await addAuditLog(
        "Importación de Datos Locales",
        user?.email || "Usuario",
        `Se migraron con éxito ${realLocalClientes.length} clientes, ${realLocalPrestamos.length} préstamos, ${realLocalPagos.length} pagos y ${realLocalGarantias.length} garantías desde el almacenamiento local offline a la base de datos sincronizada en la nube.`
      );

      alert("¡Sincronización completada! Todos tus registros locales ahora están seguros en la nube y visibles en todos tus dispositivos.");
      setShowImportModal(false);
    } catch (err) {
      console.error("Error importing local data:", err);
      alert("Hubo un problema al subir los datos. Verifica tu conexión e inténtalo de nuevo.");
    } finally {
      setImportingLocalData(false);
    }
  };

  const handleDismissImport = () => {
    // Clear the local data to prevent prompting again
    localStorage.removeItem("easypres_clientes");
    localStorage.removeItem("easypres_prestamos");
    localStorage.removeItem("easypres_pagos");
    localStorage.removeItem("easypres_garantias");
    setShowImportModal(false);
    setSessionDismissedImport(true);
  };

  // Render Loader
  if (authLoading || (user && user.uid !== "demo-user-id" && !usuariosLoaded)) {
    return (
      <div className="min-h-screen bg-[#fcfcfd] dark:bg-[#0c0c0e] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-xs text-gray-400 font-semibold uppercase tracking-widest font-mono">Cargando EasyPres Finanzas...</p>
        </div>
      </div>
    );
  }

  // Render Login landing screen
  if (!user || !currentUserProfile) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#0c0c0e] flex items-center justify-center p-4">
        <div className="w-full max-w-4xl bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-3xl overflow-hidden shadow-xl grid grid-cols-1 md:grid-cols-2">
          
          {/* Left panel: Info & presentation */}
          <div className="bg-emerald-600 p-8 text-white flex flex-col justify-between space-y-8">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-white/10 rounded-lg"><Landmark size={24} /></div>
              <span className="font-bold text-lg tracking-tight">EasyPres</span>
            </div>

            <div className="space-y-4">
              <h1 className="text-3xl font-black leading-tight">Software de Gestión Financiera y Cobros</h1>
              <p className="text-xs text-emerald-100 leading-relaxed">
                Controla de manera profesional tu cartera de clientes, calcula calendarios de amortización franceses o de interés simple, emite recibos de pago con exportación a WhatsApp e imprime contratos de garantía prendaria.
              </p>
            </div>

            <div className="text-[10px] text-emerald-200 font-mono">
              EasyPres Applet v1.20 | Secure Firestore & Auth
            </div>
          </div>

          {/* Right panel: Login form */}
          <div className="p-8 flex flex-col justify-center space-y-5">
            <div className="space-y-1">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Iniciar Sesión</h2>
              <p className="text-xs text-gray-400">Accede de forma segura o utiliza las credenciales de prueba</p>
            </div>

            {/* Trial Username/Password form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (testUsername.toLowerCase().trim() === "admin" && testPassword.trim() === "admin") {
                  setTestLoginError("");
                  handleDemoLogin("jesushg.004@gmail.com", "Jesús HG");
                } else {
                  setTestLoginError("Usuario o contraseña incorrectos. Usa 'admin' / 'admin'");
                }
              }}
              className="space-y-3.5"
            >
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-gray-450 dark:text-zinc-500 uppercase tracking-wider">
                  Usuario
                </label>
                <input
                  type="text"
                  value={testUsername}
                  onChange={(e) => {
                    setTestUsername(e.target.value);
                    setTestLoginError("");
                  }}
                  placeholder="Ingresa 'admin'"
                  className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs text-gray-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-gray-450 dark:text-zinc-500 uppercase tracking-wider">
                  Contraseña
                </label>
                <input
                  type="password"
                  value={testPassword}
                  onChange={(e) => {
                    setTestPassword(e.target.value);
                    setTestLoginError("");
                  }}
                  placeholder="Ingresa 'admin'"
                  className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs text-gray-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                  required
                />
              </div>

              {testLoginError && (
                <p className="text-[10px] text-red-500 dark:text-red-400 font-semibold bg-red-50 dark:bg-red-950/20 px-2.5 py-1.5 rounded-lg border border-red-200/40 dark:border-red-900/30">
                  ⚠️ {testLoginError}
                </p>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-sm flex items-center justify-center gap-1.5"
              >
                Ingresar con credenciales
              </button>
            </form>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-zinc-200 dark:border-zinc-800"></div>
              <span className="flex-shrink mx-3 text-gray-400 text-[9px] uppercase font-bold font-mono">Otras opciones</span>
              <div className="flex-grow border-t border-zinc-200 dark:border-zinc-800"></div>
            </div>

            <div className="flex flex-col gap-2">
              <button
                onClick={handleGoogleLogin}
                className="w-full py-2.5 border border-zinc-200 dark:border-zinc-800 rounded-xl hover:bg-zinc-50 dark:hover:bg-zinc-900 font-bold text-xs flex items-center justify-center gap-2.5 cursor-pointer text-gray-700 dark:text-zinc-300 transition-colors"
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path fill="#EA4335" d="M12 5.04c1.62 0 3.08.56 4.22 1.64l3.15-3.15C17.45 1.68 14.93 1 12 1 7.24 1 3.2 3.73 1.24 7.74l3.78 2.92C5.9 7.42 8.7 5.04 12 5.04z" />
                  <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.47h6.46c-.28 1.48-1.12 2.74-2.38 3.58l3.69 2.87c2.16-1.99 3.42-4.92 3.42-8.56z" />
                  <path fill="#FBBC05" d="M4.1 14.82c-.25-.74-.39-1.53-.39-2.35s.14-1.61.39-2.35L1.24 7.74C.45 9.35 0 11.13 0 13s.45 3.65 1.24 5.26l3.78-2.92.08-.18z" />
                  <path fill="#34A853" d="M12 23c3.24 0 5.97-1.07 7.96-2.92l-3.69-2.87c-1.02.68-2.33 1.09-3.96 1.09-3.3 0-6.1-2.38-7.1-5.61l-3.78 2.92C3.2 20.27 7.24 23 12 23z" />
                </svg>
                Acceder con Google
              </button>
            </div>

            <div className="space-y-2.5" id="demo-quick-login-container">
              <p className="text-[9px] text-gray-400 font-bold uppercase text-center tracking-wider">Ingreso rápido por roles (Demo):</p>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleDemoLogin("jesushg.004@gmail.com", "Jesús HG")}
                  className="py-2 px-1 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/30 text-emerald-800 dark:text-emerald-400 rounded-xl font-bold text-[9px] text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-0.5 shadow-2xs"
                  title="Acceso total como Administrador"
                  id="btn-login-admin"
                >
                  <span className="font-sans">Admin</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoLogin("supervisor.maria@easypres.com", "María Rodríguez")}
                  className="py-2 px-1 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/20 dark:hover:bg-amber-950/40 border border-amber-100 dark:border-amber-900/30 text-amber-800 dark:text-amber-400 rounded-xl font-bold text-[9px] text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-0.5 shadow-2xs"
                  title="Acceso parcial como Supervisor"
                  id="btn-login-supervisor"
                >
                  <span className="font-sans">Supervisor</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoLogin("cobros.perez@easypres.com", "Cobrador Pérez")}
                  className="py-2 px-1 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/20 dark:hover:bg-blue-950/40 border border-blue-100 dark:border-blue-900/30 text-blue-800 dark:text-blue-400 rounded-xl font-bold text-[9px] text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-0.5 shadow-2xs"
                  title="Acceso limitado como Cobrador"
                  id="btn-login-cobrador"
                >
                  <span className="font-sans">Cobrador</span>
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    );
  }

  // Active view content mapper
  const renderActiveModule = () => {
    // Security check: restrict module access based on active operator's ver permission
    if (user && currentUserProfile && currentUserProfile.rol !== "Administrador") {
      if (!checkPermission(currentUserProfile, activeModule, "ver")) {
        // Fallback to dashboard if attempting to load an unauthorized module
        setTimeout(() => setActiveModule("dashboard"), 0);
        return null;
      }
    }

    const isCobrador = currentUserProfile?.rol === "Cobrador";
    const cobradorEmail = currentUserProfile?.email?.toLowerCase();

    // Filtered lists for Cobrador role (allows seeing assigned portfolio OR any unassigned clients/loans/payments)
    const viewClientes = isCobrador
      ? clientes.filter(c => !c.cobradorId || c.cobradorId.toLowerCase() === cobradorEmail)
      : clientes;

    const viewPrestamos = isCobrador
      ? prestamos.filter(p => !p.cobradorId || p.cobradorId.toLowerCase() === cobradorEmail || viewClientes.some(c => c.id === p.clienteId))
      : prestamos;

    const viewPagos = isCobrador
      ? pagos.filter(p => !p.cobradorId || p.cobradorId.toLowerCase() === cobradorEmail || viewClientes.some(c => c.id === p.clienteId))
      : pagos;

    const viewCuadres = isCobrador
      ? cuadres.filter(c => !c.cobradorId || c.cobradorId.toLowerCase() === cobradorEmail || c.registradoPor?.toLowerCase() === cobradorEmail)
      : cuadres;

    switch (activeModule) {
      case "dashboard":
        return (
          <Dashboard
            clientes={viewClientes}
            prestamos={viewPrestamos}
            pagos={viewPagos}
            cuadres={viewCuadres}
            depositos={depositos}
            moneda={config.moneda || "$"}
            setActiveModule={setActiveModule}
            configuracion={config}
            usuario={currentUserProfile}
            onNavigateToCliente={(clienteId, search) => {
              setInitialSelectedClienteId(clienteId);
              setInitialSearchQuery(search || "");
              setActiveModule("clientes");
            }}
          />
        );
      case "ruta_cobro":
        return (
          <RutaCobro
            clientes={clientes}
            prestamos={prestamos}
            pagos={pagos}
            moneda={config.moneda || "$"}
            onSavePago={savePago}
            currentUserProfile={currentUserProfile}
            usuarios={usuarios}
            onAddAuditLog={addAuditLog}
            configuracion={config}
          />
        );
      case "clientes":
        return (
          <Clientes
            clientes={viewClientes}
            prestamos={viewPrestamos}
            pagos={viewPagos}
            moneda={config.moneda || "$"}
            onSave={saveCliente}
            onDelete={deleteCliente}
            currentUserProfile={currentUserProfile}
            usuarios={usuarios}
            initialSearchQuery={initialSearchQuery}
            initialSelectedClienteId={initialSelectedClienteId}
            onClearInitialSelection={() => {
              setInitialSearchQuery("");
              setInitialSelectedClienteId("");
            }}
            onReassignClient={reassignClient}
          />
        );
      case "prestamos":
        return (
          <Prestamos
            prestamos={viewPrestamos}
            clientes={viewClientes}
            moneda={config.moneda || "$"}
            onSave={savePrestamo}
            onDelete={deletePrestamo}
            tasaInteresDefecto={config.tasaInteresDefecto}
            currentUserProfile={currentUserProfile}
            pagos={viewPagos}
            setActiveModule={setActiveModule}
          />
        );
      case "pagos":
        return (
          <Pagos
            pagos={viewPagos}
            prestamos={viewPrestamos}
            clientes={viewClientes}
            moneda={config.moneda || "$"}
            onSavePago={savePago}
            onDeletePago={deletePago}
            currentUserProfile={currentUserProfile}
            configuracion={config}
          />
        );
      case "garantias":
        return (
          <Garantias
            garantias={garantias}
            prestamos={viewPrestamos}
            clientes={viewClientes}
            moneda={config.moneda || "$"}
            onSave={saveGarantia}
            onDelete={deleteGarantia}
            currentUserProfile={currentUserProfile}
          />
        );
      case "finanzas":
        return (
          <Finanzas
            gastos={gastos}
            bancos={bancos}
            pagos={viewPagos}
            cuadres={viewCuadres}
            depositos={depositos}
            moneda={config.moneda || "$"}
            onSaveGasto={saveGasto}
            onSaveBanco={saveBanco}
            onSaveCuadre={saveCuadre}
            onSaveDeposito={saveDeposito}
            userEmail={user.email || "demo.supervisor@easypres.com"}
            currentUserProfile={currentUserProfile}
            configuracion={config}
            usuarios={usuarios}
            onAddAuditLog={addAuditLog}
          />
        );
      case "reportes":
        return (
          <Reportes
            clientes={viewClientes}
            prestamos={viewPrestamos}
            pagos={viewPagos}
            moneda={config.moneda || "$"}
            currentUserProfile={currentUserProfile}
          />
        );
      case "configuracion":
        return (
          <ConfiguracionModule
            configuracion={config}
            onSave={saveConfiguracion}
            usuarios={usuarios}
            onSaveUsuario={saveUsuario}
            onDeleteUsuario={deleteUsuario}
            currentUserProfile={currentUserProfile}
            auditorias={auditorias}
            onAddAuditLog={addAuditLog}
            clientes={clientes}
            prestamos={prestamos}
            pagos={pagos}
            cuadres={cuadres}
            garantias={garantias}
            gastos={gastos}
            bancos={bancos}
            depositos={depositos}
            onRestoreBackup={restoreBackup}
            onWipeDatabase={wipeDatabase}
            asignacionesTemporales={asignacionesTemporales}
            historialAsignaciones={historialAsignaciones}
            onReassignClient={reassignClient}
            onSaveAsignacionTemporal={saveAsignacionTemporal}
            onTransferirCartera={transferirCartera}
          />
        );
      default:
        return <div className="text-xs text-gray-400">Próximamente...</div>;
    }
  };

  return (
    <div className={`min-h-screen ${darkMode ? "dark bg-[#0c0c0e]" : "bg-slate-50/50"}`} id="app-wrapper">
      {/* Mobile Top Header */}
      <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-white dark:bg-[#121214] border-b border-gray-100 dark:border-zinc-800 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center gap-3 overflow-hidden">
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-gray-700 dark:text-zinc-300"
            title="Abrir menú"
          >
            <Menu size={22} />
          </button>
          {config.logo ? (
            <img
              src={config.logo}
              alt="Logo"
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-lg object-cover flex-shrink-0"
            />
          ) : (
            <div className="p-1.5 bg-emerald-600 text-white rounded-lg flex-shrink-0">
              <Landmark size={18} />
            </div>
          )}
          <span className="font-bold text-sm text-gray-900 dark:text-white truncate max-w-[120px]">
            {config.nombreEmpresa || "EasyPres"}
          </span>
        </div>
        
        {/* Active Module Indicator Badge */}
        <span className="text-[10px] uppercase font-bold font-mono tracking-wider bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded">
          {activeModule === "dashboard" ? "Inicio" : activeModule}
        </span>
      </header>

      {/* Sidebar navigation */}
      <Sidebar
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        companyName={config.nombreEmpresa}
        companyLogo={config.logo}
        userEmail={user.email || "demo.supervisor@easypres.com"}
        currentUserProfile={currentUserProfile}
        onLogout={handleLogout}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        syncStatus={syncStatus}
        onManualSync={triggerManualSync}
      />

      {/* Bottom Navigation for Mobile Screens */}
      <BottomNav
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        currentUserProfile={currentUserProfile}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        darkMode={darkMode}
        configuracion={config}
      />

      {/* Main Content Stage container */}
      <main
        className={`transition-all duration-300 ease-in-out p-4 md:p-6 min-h-screen print:p-0 print:ml-0
          ${(config.bottomNavHabilitado ?? true) ? "pb-24" : "pb-6"} lg:pb-6
          ml-0 ${sidebarCollapsed ? "lg:ml-20" : "lg:ml-64"}
        `}
        id="main-stage"
      >
        <div className="max-w-7xl mx-auto print:max-w-full print:p-0">
          {renderActiveModule()}
        </div>
      </main>

      {/* Dynamic Inactivity Session Warning Modal (Requirement 5) */}
      {showInactivityWarning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" id="inactivity-warning-modal">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4">
            <div className="mx-auto w-12 h-12 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center animate-bounce">
              <Clock size={24} />
            </div>
            
            <div className="space-y-1.5">
              <h3 className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-wider">Aviso de Inactividad</h3>
              <p className="text-xs text-gray-500 dark:text-zinc-400 font-medium">
                Tu sesión está a punto de cerrarse automáticamente por inactividad prolongada.
              </p>
            </div>

            <div className="py-3 bg-zinc-50 dark:bg-zinc-950 rounded-2xl border border-zinc-100 dark:border-zinc-800 flex flex-col items-center justify-center">
              <span className="text-4xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 tracking-tight">
                {Math.floor(inactivityCountdown / 60)}:{(inactivityCountdown % 60).toString().padStart(2, "0")}
              </span>
              <span className="text-[10px] text-gray-400 uppercase tracking-widest font-bold mt-1">Tiempo Restante</span>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                onClick={resetInactivityTimer}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                id="btn-extend-session"
              >
                Mantener Sesión Activa
              </button>
              <button
                type="button"
                onClick={async () => {
                  setShowInactivityWarning(false);
                  await addAuditLog("Cierre de Sesión Voluntario", "Sistema", "El operador decidió cerrar sesión voluntariamente tras aviso de inactividad.");
                  handleLogout();
                }}
                className="w-full py-2.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-gray-500 dark:text-zinc-400 text-xs font-bold rounded-xl transition-all cursor-pointer"
                id="btn-logout-now"
              >
                Cerrar Sesión Ahora
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Offline/Sync Status Indicator */}
      {user && user.uid !== "demo-user-id" && (
        <div className="fixed bottom-4 right-4 z-40 font-sans" id="floating-sync-indicator">
          {syncStatus === "offline" && (
            <div className="bg-amber-600 text-white rounded-full px-3 py-1.5 shadow-lg border border-amber-500/30 flex items-center gap-2 animate-fade-in text-[11px] font-medium">
              <WifiOff size={13} className="animate-pulse text-amber-100 shrink-0" />
              <span>Modo Desconectado (Seguro)</span>
              <button
                onClick={triggerManualSync}
                className="ml-1 px-2 py-0.5 bg-white hover:bg-zinc-100 text-amber-950 font-black text-[9.5px] rounded-full transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                id="btn-manual-sync-trigger"
              >
                <RefreshCw size={9} /> Reintentar
              </button>
            </div>
          )}

          {syncStatus === "syncing" && (
            <div className="bg-emerald-600 text-white rounded-full px-3 py-1.5 shadow-lg border border-emerald-500/30 flex items-center gap-2 animate-fade-in text-[11px] font-medium">
              <RefreshCw size={13} className="animate-spin text-emerald-100 shrink-0" />
              <span>Sincronizando...</span>
            </div>
          )}

          {showSyncSuccessToast && (
            <div className="bg-zinc-900 dark:bg-zinc-950 text-white rounded-full px-3 py-1.5 shadow-lg border border-zinc-800/80 flex items-center gap-2 animate-fade-in text-[11px] font-medium">
              <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
              <span className="text-zinc-200">¡Sincronizado!</span>
            </div>
          )}
        </div>
      )}

      {/* Local Demo Data Import Suggestion Modal */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" id="import-local-data-modal">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 relative">
            
            {/* Absolute close button */}
            <button
              onClick={() => {
                setShowImportModal(false);
                setSessionDismissedImport(true);
              }}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors p-1 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
              title="Omitir por ahora"
            >
              <X size={18} />
            </button>

            <div className="mx-auto w-12 h-12 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center">
              <RefreshCw size={24} className="animate-pulse" />
            </div>
            
            <div className="space-y-1.5 text-center">
              <h3 className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-wider">¿Sincronizar Datos Locales?</h3>
              <p className="text-xs text-gray-500 dark:text-zinc-400 font-medium leading-relaxed">
                Hemos detectado registros de prueba guardados en este dispositivo. ¿Deseas subirlos y sincronizarlos con tu cuenta real en la nube, o prefieres omitirlos?
              </p>
            </div>

            <div className="py-3 px-4 bg-zinc-50 dark:bg-zinc-950 rounded-2xl border border-zinc-100 dark:border-zinc-800 space-y-2 text-xs font-mono">
              <div className="text-[10px] text-gray-400 dark:text-zinc-500 uppercase font-bold tracking-wider text-center border-b border-zinc-200/55 dark:border-zinc-800/55 pb-1">Registros Detectados</div>
              <div className="flex justify-between text-gray-600 dark:text-zinc-400">
                <span>Clientes:</span>
                <span className="font-bold text-gray-900 dark:text-white">{localCounts.clientes}</span>
              </div>
              <div className="flex justify-between text-gray-600 dark:text-zinc-400">
                <span>Préstamos:</span>
                <span className="font-bold text-gray-900 dark:text-white">{localCounts.prestamos}</span>
              </div>
              <div className="flex justify-between text-gray-600 dark:text-zinc-400">
                <span>Pagos Realizados:</span>
                <span className="font-bold text-gray-900 dark:text-white">{localCounts.pagos}</span>
              </div>
              <div className="flex justify-between text-gray-600 dark:text-zinc-400">
                <span>Garantías:</span>
                <span className="font-bold text-gray-900 dark:text-white">{localCounts.garantias}</span>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                disabled={importingLocalData}
                onClick={handleImportLocalData}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                id="btn-import-local-data"
              >
                {importingLocalData ? "Sincronizando..." : "Sí, Sincronizar con la Nube"}
              </button>
              
              <div className="grid grid-cols-2 gap-2 mt-1">
                <button
                  type="button"
                  disabled={importingLocalData}
                  onClick={() => {
                    setShowImportModal(false);
                    setSessionDismissedImport(true);
                  }}
                  className="py-2 bg-zinc-50 dark:bg-zinc-800/50 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-gray-600 dark:text-zinc-300 text-xs font-bold rounded-xl transition-all cursor-pointer text-center"
                >
                  Recordar luego
                </button>
                <button
                  type="button"
                  disabled={importingLocalData}
                  onClick={handleDismissImport}
                  className="py-2 hover:bg-red-50 dark:hover:bg-red-950/20 text-red-600 dark:text-red-400 text-xs font-bold rounded-xl transition-all cursor-pointer text-center"
                  id="btn-dismiss-import"
                >
                  No, descartar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
