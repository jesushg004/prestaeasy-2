import { CuotaDetalle } from "./types";

/**
 * Agrega tiempo a una fecha basada en la frecuencia
 */
export function calcularProximaFecha(fechaBase: Date, frecuencia: string, numeroCuota: number): Date {
  const nuevaFecha = new Date(fechaBase);
  if (frecuencia === "Diario") {
    nuevaFecha.setDate(nuevaFecha.getDate() + numeroCuota);
    // Omitir domingos si es diario (opcional, pero profesional para cobros)
    if (nuevaFecha.getDay() === 0) {
      nuevaFecha.setDate(nuevaFecha.getDate() + 1);
    }
  } else if (frecuencia === "Interdiario") {
    nuevaFecha.setDate(nuevaFecha.getDate() + (numeroCuota * 2));
    if (nuevaFecha.getDay() === 0) {
      nuevaFecha.setDate(nuevaFecha.getDate() + 1);
    }
  } else if (frecuencia === "Semanal") {
    nuevaFecha.setDate(nuevaFecha.getDate() + (numeroCuota * 7));
  } else if (frecuencia === "Quincenal") {
    nuevaFecha.setDate(nuevaFecha.getDate() + (numeroCuota * 15));
  } else if (frecuencia === "Mensual") {
    nuevaFecha.setMonth(nuevaFecha.getMonth() + numeroCuota);
  }
  return nuevaFecha;
}

/**
 * Genera el plan de pagos (amortización)
 */
export function generarPlanPagos(
  capital: number,
  tasaAnualOSimple: number,
  tipoInteres: string,
  frecuencia: string,
  plazoCuotas: number,
  fechaInicioStr: string,
  diasGracia?: number,
  fechaPrimerPagoStr?: string
): { cuotas: CuotaDetalle[]; interesTotal: number; montoTotal: number; montoCuota: number } {
  const fechaInicio = new Date(fechaInicioStr);
  const cuotas: CuotaDetalle[] = [];
  let interesTotal = 0;
  let montoTotal = 0;
  let montoCuota = 0;

  const numCapital = Number(capital);
  const numPlazo = Number(plazoCuotas);
  const numTasa = Number(tasaAnualOSimple);

  // Safeguards against division by zero, invalid dates, or empty values
  if (
    isNaN(numCapital) ||
    numCapital <= 0 ||
    isNaN(numPlazo) ||
    numPlazo <= 0 ||
    !fechaInicioStr ||
    isNaN(fechaInicio.getTime())
  ) {
    return { cuotas: [], interesTotal: 0, montoTotal: 0, montoCuota: 0 };
  }

  const safeTasa = isNaN(numTasa) || numTasa < 0 ? 0 : numTasa;

  // Helper function to calculate the due date of a specific installment, considering grace days or a custom first payment date
  const obtenerFechaVence = (i: number): Date => {
    if (fechaPrimerPagoStr) {
      const firstDate = new Date(fechaPrimerPagoStr);
      if (i === 1) return firstDate;
      return calcularProximaFecha(firstDate, frecuencia, i - 1);
    } else {
      let base = new Date(fechaInicioStr);
      if (diasGracia && diasGracia > 0) {
        base.setDate(base.getDate() + Number(diasGracia));
      }
      return calcularProximaFecha(base, frecuencia, i);
    }
  };

  if (tipoInteres === "Interés Simple") {
    // Interés simple: El interés se calcula de forma fija sobre el capital total.
    // Tasa se asume como el costo por todo el período o tasa mensual aplicada.
    interesTotal = numCapital * (safeTasa / 100);
    montoTotal = numCapital + interesTotal;
    montoCuota = Number((montoTotal / numPlazo).toFixed(2));

    const capitalPorCuota = Number((numCapital / numPlazo).toFixed(2));
    const interesPorCuota = Number((interesTotal / numPlazo).toFixed(2));

    let saldoRestante = montoTotal;

    for (let i = 1; i <= numPlazo; i++) {
      saldoRestante -= montoCuota;
      if (saldoRestante < 0 || i === numPlazo) saldoRestante = 0;
      
      const fechaVence = obtenerFechaVence(i);

      cuotas.push({
        numero: i,
        monto: montoCuota,
        capital: capitalPorCuota,
        interes: interesPorCuota,
        saldoRestante: Number(saldoRestante.toFixed(2)),
        fechaVence: fechaVence.toISOString().split("T")[0],
        estado: "Pendiente",
        montoPagado: 0
      });
    }
  } else if (tipoInteres === "Interés Diario") {
    // Interés diario: El interés es diario, tasa * días
    // Asumamos un interés fijo diario sobre el capital, por ejemplo tasa% diaria
    const interesDiario = numCapital * (safeTasa / 100);
    let diasTotales = numPlazo;
    if (frecuencia === "Semanal") diasTotales = numPlazo * 7;
    else if (frecuencia === "Interdiario") diasTotales = numPlazo * 2;
    else if (frecuencia === "Quincenal") diasTotales = numPlazo * 15;
    else if (frecuencia === "Mensual") diasTotales = numPlazo * 30;

    interesTotal = interesDiario * diasTotales;
    montoTotal = numCapital + interesTotal;
    montoCuota = Number((montoTotal / numPlazo).toFixed(2));

    const capitalPorCuota = Number((numCapital / numPlazo).toFixed(2));
    const interesPorCuota = Number((interesTotal / numPlazo).toFixed(2));

    let saldoRestante = montoTotal;

    for (let i = 1; i <= numPlazo; i++) {
      saldoRestante -= montoCuota;
      if (saldoRestante < 0 || i === numPlazo) saldoRestante = 0;

      const fechaVence = obtenerFechaVence(i);

      cuotas.push({
        numero: i,
        monto: montoCuota,
        capital: capitalPorCuota,
        interes: interesPorCuota,
        saldoRestante: Number(saldoRestante.toFixed(2)),
        fechaVence: fechaVence.toISOString().split("T")[0],
        estado: "Pendiente",
        montoPagado: 0
      });
    }
  } else if (tipoInteres === "Método San") {
    // Método San: Generalmente es un plan de cuotas sin interés (0% interés), o con una tasa fija que actúa como comisión única.
    interesTotal = numCapital * (safeTasa / 100);
    montoTotal = numCapital + interesTotal;
    montoCuota = Number((montoTotal / numPlazo).toFixed(2));

    const capitalPorCuota = Number((numCapital / numPlazo).toFixed(2));
    const interesPorCuota = Number((interesTotal / numPlazo).toFixed(2));

    let saldoRestante = montoTotal;

    for (let i = 1; i <= numPlazo; i++) {
      saldoRestante -= montoCuota;
      if (saldoRestante < 0 || i === numPlazo) saldoRestante = 0;
      
      const fechaVence = obtenerFechaVence(i);

      cuotas.push({
        numero: i,
        monto: montoCuota,
        capital: capitalPorCuota,
        interes: interesPorCuota,
        saldoRestante: Number(saldoRestante.toFixed(2)),
        fechaVence: fechaVence.toISOString().split("T")[0],
        estado: "Pendiente",
        montoPagado: 0
      });
    }
  } else {
    // Cuota Fija (Amortizable / Francesa)
    // Tasa es por cuota, e.g. si es mensual, es la tasa mensual.
    const r = safeTasa / 100;
    
    if (r === 0) {
      montoCuota = numCapital / numPlazo;
      interesTotal = 0;
      montoTotal = numCapital;
    } else {
      montoCuota = (numCapital * r * Math.pow(1 + r, numPlazo)) / (Math.pow(1 + r, numPlazo) - 1);
      montoCuota = Number(montoCuota.toFixed(2));
      montoTotal = montoCuota * numPlazo;
      interesTotal = montoTotal - numCapital;
    }

    let saldoCapital = numCapital;
    let saldoRestante = montoTotal;

    for (let i = 1; i <= numPlazo; i++) {
      const interesDeCuota = Number((saldoCapital * r).toFixed(2));
      const capitalDeCuota = Number((montoCuota - interesDeCuota).toFixed(2));
      
      saldoCapital -= capitalDeCuota;
      saldoRestante -= montoCuota;
      if (saldoRestante < 0 || i === numPlazo) saldoRestante = 0;
      if (saldoCapital < 0) saldoCapital = 0;

      const fechaVence = obtenerFechaVence(i);

      cuotas.push({
        numero: i,
        monto: montoCuota,
        capital: capitalDeCuota,
        interes: interesDeCuota,
        saldoRestante: Number(saldoRestante.toFixed(2)),
        fechaVence: fechaVence.toISOString().split("T")[0],
        estado: "Pendiente",
        montoPagado: 0
      });
    }
  }

  return {
    cuotas,
    interesTotal: Number(interesTotal.toFixed(2)),
    montoTotal: Number(montoTotal.toFixed(2)),
    montoCuota: Number(montoCuota.toFixed(2))
  };
}

/**
 * Formatea una fecha de manera segura sin desfases de zona horaria (para strings YYYY-MM-DD o Dates)
 */
export function formatLocalDate(dateInput: string | Date | undefined | null): string {
  if (!dateInput) return "";
  
  if (dateInput instanceof Date) {
    const year = dateInput.getFullYear();
    const month = String(dateInput.getMonth() + 1).padStart(2, "0");
    const day = String(dateInput.getDate()).padStart(2, "0");
    return `${day}/${month}/${year}`;
  }
  
  const dateStr = String(dateInput).trim();
  // Si tiene formato YYYY-MM-DD
  const parts = dateStr.split("T")[0].split("-");
  if (parts.length === 3 && parts[0].length === 4) {
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}/${month}/${year}`;
  }
  
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  } catch (e) {
    return dateStr;
  }
}

/**
 * Formatea un número en moneda
 */
export function formatCurrency(amount: number, symbol: string = "$"): string {
  if (isNaN(amount) || amount === undefined || amount === null || !isFinite(amount)) return `${symbol}0.00`;
  return `${symbol}${amount.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/**
 * Exporta datos a formato CSV y los descarga
 */
export function exportToCSV(filename: string, headers: string[], rows: string[][]) {
  const csvContent = "data:text/csv;charset=utf-8,\uFEFF" 
    + [headers.join(","), ...rows.map(e => e.map(val => `"${(val || "").replace(/"/g, '""')}"`).join(","))].join("\n");
  
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Genera un código aleatorio secuencial ficticio si Firestore está vacío
 */
export function generateRandomCode(prefix: string): string {
  const num = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${num}`;
}

/**
 * Calcula la mora acumulada para una cuota específica según las reglas del préstamo
 */
export function calcularMoraDeCuota(
  cuota: CuotaDetalle,
  tipoMora: string | undefined,
  valorMora: number | undefined,
  diasTolerancia: number | undefined,
  fechaReferenciaStr: string = new Date().toISOString().split("T")[0]
): number {
  if (cuota.estado === "Pagado" || !tipoMora || tipoMora === "none" || !valorMora || valorMora <= 0) {
    return 0;
  }

  const fechaVence = new Date(cuota.fechaVence);
  const parts = fechaReferenciaStr.split("T")[0].split("-");
  const fechaRef = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));

  // Diferencia en milisegundos y días enteros
  const diffTime = fechaRef.getTime() - fechaVence.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  const tolerancia = Number(diasTolerancia || 0);

  // Si los días transcurridos son menores o iguales a la tolerancia, no hay mora
  if (diffDays <= tolerancia) {
    return 0;
  }

  if (tipoMora === "fixed_once") {
    // Monto fijo único
    return Number(valorMora.toFixed(2));
  } else if (tipoMora === "percentage_on_cuota") {
    // Porcentaje sobre la cuota vencida (sobre lo que falta pagar de la cuota)
    const pendiente = cuota.monto - cuota.montoPagado;
    return Number((pendiente * (valorMora / 100)).toFixed(2));
  } else if (tipoMora === "fixed_daily") {
    // Monto fijo diario por cada día de retraso acumulado
    return Number((diffDays * valorMora).toFixed(2));
  }

  return 0;
}

/**
 * Recalcula e inyecta la mora calculada en tiempo real en cada cuota no pagada
 */
export function actualizarCuotasConMora(
  cuotas: CuotaDetalle[],
  tipoMora: string | undefined,
  valorMora: number | undefined,
  diasTolerancia: number | undefined,
  fechaReferencia: string = new Date().toISOString().split("T")[0],
  moraMaximaMonto?: number
): CuotaDetalle[] {
  let acumuladoMoraUnpaid = 0;
  return cuotas.map(c => {
    if (c.estado === "Pagado") {
      return {
        ...c,
        moraMonto: c.moraMonto || 0,
        moraPagada: c.moraPagada || 0
      };
    }
    let calculatedMora = calcularMoraDeCuota(c, tipoMora, valorMora, diasTolerancia, fechaReferencia);
    
    // Si hay un tope de mora máxima, vigilar el acumulado de mora pendiente
    if (moraMaximaMonto && moraMaximaMonto > 0) {
      const moraPagadaPrevia = c.moraPagada || 0;
      const moraUnpaidEstaCuota = Math.max(0, calculatedMora - moraPagadaPrevia);
      if (acumuladoMoraUnpaid + moraUnpaidEstaCuota > moraMaximaMonto) {
        const disponible = Math.max(0, moraMaximaMonto - acumuladoMoraUnpaid);
        calculatedMora = Number((moraPagadaPrevia + disponible).toFixed(2));
      }
      acumuladoMoraUnpaid += Math.max(0, calculatedMora - moraPagadaPrevia);
    }

    return {
      ...c,
      moraMonto: calculatedMora,
      moraPagada: c.moraPagada || 0
    };
  });
}

/**
 * Genera la URL para WhatsApp Click-to-Chat
 */
export function getWhatsAppUrl(phone: string, text: string): string {
  if (!phone) return "";
  // Clean phone number: keep only numbers
  const cleanedPhone = phone.replace(/\D/g, "");
  return `https://wa.me/${cleanedPhone}?text=${encodeURIComponent(text)}`;
}

