export interface PermisosModulo {
  ver: boolean;
  crear?: boolean;
  editar?: boolean;
  eliminar?: boolean;
  exportar?: boolean;
}

export interface Usuario {
  id?: string;
  uid?: string;
  nombre: string;
  email: string;
  rol: "Administrador" | "Supervisor" | "Cobrador";
  activo: boolean;
  permisos?: {
    [moduloId: string]: PermisosModulo;
  };
}

export interface AppModulo {
  id: string;
  label: string;
}

export const APP_MODULOS: AppModulo[] = [
  { id: "dashboard", label: "Dashboard" },
  { id: "ruta_cobro", label: "Ruta de Cobro 🧭" },
  { id: "clientes", label: "Clientes" },
  { id: "prestamos", label: "Préstamos" },
  { id: "pagos", label: "Pagos y Recibos" },
  { id: "garantias", label: "Garantías" },
  { id: "finanzas", label: "Finanzas y Caja" },
  { id: "reportes", label: "Reportes" },
  { id: "configuracion", label: "Configuración" }
];

export function getOperacionesAplicables(moduloId: string): ("ver" | "crear" | "editar" | "eliminar" | "exportar")[] {
  if (moduloId === "dashboard") {
    return ["ver"];
  }
  if (moduloId === "ruta_cobro") {
    return ["ver", "crear", "editar"];
  }
  if (moduloId === "reportes") {
    return ["ver", "exportar"];
  }
  if (moduloId === "configuracion") {
    return ["ver", "editar"];
  }
  return ["ver", "crear", "editar", "eliminar", "exportar"];
}

export function checkPermission(
  user: Usuario | null | undefined,
  moduloId: string,
  operacion: "ver" | "crear" | "editar" | "eliminar" | "exportar"
): boolean {
  if (!user) return true; // Safe default during loading/transitional states
  if (user.rol === "Administrador") return true; // Master access
  if (!user.activo) return false; // Inactive users have zero access
  
  return user.permisos?.[moduloId]?.[operacion] === true;
}

export interface Cliente {
  id?: string;
  codigo: string; // e.g., CLI-0001
  nombre: string;
  cedula: string;
  telefono: string;
  direccion: string;
  correo?: string;
  foto?: string; // Base64 image
  referenciasPersonales: string; // Text field
  referenciasLaborales: string;  // Text field
  fechaRegistro: string; // ISO Date
  cobradorId?: string; // Email/UID of assigned Cobrador
  cobradorNombre?: string; // Name of assigned Cobrador
}

export interface CuotaDetalle {
  numero: number;
  monto: number;
  capital: number;
  interes: number;
  saldoRestante: number;
  fechaVence: string;
  estado: "Pendiente" | "Pagado" | "Parcial";
  montoPagado: number;
  moraMonto?: number;
  moraPagada?: number;
}

export interface Prestamo {
  id?: string;
  numero: string; // PRE-0001
  clienteId: string;
  clienteNombre: string;
  capitalPrestado: number;
  tasaInteres: number; // e.g. 10
  tipoInteres: "Interés Simple" | "Cuota Fija (Amortizable)" | "Interés Diario" | "Método San";
  frecuenciaPago: "Diario" | "Interdiario" | "Semanal" | "Quincenal" | "Mensual";
  plazoCuotas: number; // number of installments
  fechaInicio: string; // ISO Date
  fechaVencimiento: string; // ISO Date
  montoCuota: number;
  mora: number;
  balancePendiente: number;
  interesTotal: number;
  montoTotal: number;
  estado: "Activo" | "Atrasado" | "Saldado" | "Cancelado";
  proximaCuotaFecha: string; // ISO Date
  cuotasDetalle: string; // Stringified CuotaDetalle[]
  cobradorId?: string; // Email/UID of assigned Cobrador
  cobradorNombre?: string; // Name of assigned Cobrador
  metodoDesembolso?: string;
  cuentaDestino?: string;
  fiadorNombre?: string;
  fiadorCedula?: string;
  fiadorTelefono?: string;
  diasGracia?: number;
  fechaPrimerPago?: string;
  tipoMora?: "none" | "fixed_once" | "percentage_on_cuota" | "fixed_daily";
  valorMora?: number;
  diasToleranciaMora?: number;
}

export interface Pago {
  id?: string;
  reciboNo: string; // REC-0001
  prestamoId: string;
  clienteId: string;
  clienteNombre: string;
  prestamoNumero: string;
  fecha: string; // ISO Date
  monto: number;
  tipoPago: "Pago de Cuota" | "Pago Parcial" | "Pago Completo" | "Abono a Capital";
  capitalPagado: number;
  interesPagado: number;
  moraPagado: number;
  balanceAntes: number;
  balanceDespues: number;
  notas?: string;
  cobradorId?: string; // Email/UID of assigned Cobrador
  cobradorNombre?: string; // Name of assigned Cobrador
}

export interface Garantia {
  id?: string;
  prestamoId: string;
  clienteId: string;
  clienteNombre: string;
  descripcion: string;
  valorEstimado: number;
  fotografias?: string; // JSON or Base64 or single image string
  estado: "Pendiente" | "Entregada" | "Devuelta" | "Liquidada";
  fechaRegistro: string; // ISO Date
}

export interface Gasto {
  id?: string;
  fecha: string; // ISO Date
  descripcion: string;
  monto: number;
  tipoEgreso: string; // e.g., Servicios, Alquiler
  suplidor: string;
  registradoPor: string;
}

export interface Banco {
  id?: string;
  nombre: string;
  numeroCuenta: string;
  balance: number;
  moneda: string;
}

export interface Configuracion {
  id?: string;
  nombreEmpresa: string;
  rnc: string;
  telefono: string;
  direccion: string;
  correo: string;
  logo?: string; // Base64
  moneda: string; // RD$, $, €, etc.
  tasaInteresDefecto: number;
  colorPrimario: string; // hex
  colorSecundario: string; // hex
  timeoutInactividad?: number; // Inactivity timeout in minutes. If undefined, default to 30.
  avisoInactividadHabilitado?: boolean; // Whether warning modal is enabled (default true)
  bottomNavHabilitado?: boolean;
  bottomNavModulosClaves?: string[];
  // Configuración de Mora Profesional
  prioridadPagoMora?: "mora_first" | "cuota_first" | "manual" | "ask";
  permitirOmitirMora?: boolean;
  requerirAutorizacionOmitir?: boolean;
  moraMaximaMonto?: number; // Límite máximo de mora acumulada por préstamo
  diasToleranciaMoraDefecto?: number; // Días de gracia predeterminados
  metodoArqueo?: "simple" | "denominaciones" | "ambos";
  dashboardVistaDefecto?: "ejecutiva" | "bento" | "compacta" | "analitica" | "desglosada" | "adaptativo";
  dashboardPersonalizable?: boolean;
  dashboardRecordarVista?: boolean;
  // Configuración de Balance de Carga para Cobradores
  maxClientesCobrador?: number;
  maxPrestamosActivosCobrador?: number;
  maxCobrosDiariosCobrador?: number;
}

export interface CuadreCaja {
  id?: string;
  fecha: string; // ISO Date/Time
  fondoApertura: number;
  cobrosEfectivo: number;
  gastosEfectivo: number;
  depositosEfectivo?: number; // New: Depósitos hechos hoy
  saldoEstimado: number;
  saldoReal: number;
  descuadre: number; // saldoReal - saldoEstimado
  estado: "Pendiente de apertura" | "Abierta" | "Pendiente de cierre" | "Cerrada" | "Pendiente de aprobación" | "Aprobada" | "Reabierta" | "Conciliado" | "Diferencia";
  registradoPor: string; // Quien abre/registra
  notas?: string;
  cobradorId?: string; // Email/UID of assigned Cobrador
  cobradorNombre?: string; // Name of assigned Cobrador
  metodo?: "simple" | "denominaciones";
  denominacionesConteo?: { [key: string]: number };

  // New shift tracking fields:
  fechaApertura?: string;
  fechaCierre?: string;
  observacionesApertura?: string;
  denominacionesApertura?: { [key: string]: number };
  aprobadoPor?: string;
  fechaAprobacion?: string;
  notasAprobacion?: string;
  diferenciaExplicacion?: string;
  diferenciaUsuario?: string;
  diferenciaFecha?: string;
}

export interface Deposito {
  id?: string;
  fecha: string; // ISO Date/Time
  bancoId: string;
  bancoNombre: string;
  monto: number;
  voucher?: string; // Base64 image
  referencia: string; // Transaccion / voucher ID
  pagoIds?: string[]; // IDs de cobros/pagos vinculados
  registradoPor: string;
  notas?: string;
}

export interface AuditoriaLog {
  id?: string;
  usuarioRealizo: string; // email/name
  fecha: string; // ISO Date/Time
  accion: string; // "crear_usuario" | "editar_usuario" | "eliminar_usuario" | "editar_permisos" | etc.
  usuarioAfectado: string; // email/name
  detalles?: string;
  valorAnterior?: string;
  valorNuevo?: string;
  motivo?: string;
}

export interface AsignacionTemporal {
  id?: string;
  clienteId: string;
  clienteNombre: string;
  cobradorOriginalUid: string;
  cobradorOriginalNombre: string;
  cobradorTemporalUid: string;
  cobradorTemporalNombre: string;
  fechaInicio: string; // ISO Date YYYY-MM-DD
  fechaFin: string; // ISO Date YYYY-MM-DD
  motivo: string;
  activo: boolean;
  creadoPor: string;
  fechaCreado: string;
}

export interface HistorialAsignacion {
  id?: string;
  fecha: string; // ISO Date/Time
  clienteId: string;
  clienteNombre: string;
  cobradorAnteriorUid?: string;
  cobradorAnteriorNombre?: string;
  nuevoCobradorUid?: string;
  nuevoCobradorNombre?: string;
  usuarioRealizo: string; // Name/Email of the admin/supervisor
  motivo: string;
  tipo: "Inicial" | "Permanente" | "Temporal";
}


