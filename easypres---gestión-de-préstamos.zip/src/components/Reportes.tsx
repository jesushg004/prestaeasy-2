import React, { useState, useMemo } from "react";
import {
  FileSpreadsheet,
  Printer,
  Search,
  Users,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Filter
} from "lucide-react";
import { Cliente, Prestamo, Pago, Usuario, checkPermission } from "../types";
import { formatCurrency, exportToCSV } from "../utils";

interface ReportesProps {
  clientes: Cliente[];
  prestamos: Prestamo[];
  pagos: Pago[];
  moneda: string;
  currentUserProfile?: Usuario | null;
}

export default function Reportes({ clientes, prestamos, pagos, moneda, currentUserProfile }: ReportesProps) {
  const canExport = checkPermission(currentUserProfile, "reportes", "exportar");
  const [activeReport, setActiveReport] = useState<"morosos" | "activos" | "saldados" | "cobros">("cobros");
  const [filterMonth, setFilterMonth] = useState(new Date().getMonth());

  // Month select options
  const monthsList = [
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
  ];

  // 1. Morosos Report Data (Préstamos con estado "Atrasado")
  const morososData = useMemo(() => {
    return prestamos.filter(p => p.estado === "Atrasado");
  }, [prestamos]);

  // 2. Active Loans Report Data (Préstamos con estado "Activo")
  const activosData = useMemo(() => {
    return prestamos.filter(p => p.estado === "Activo");
  }, [prestamos]);

  // 3. Settled Loans Report Data (Préstamos con estado "Saldado")
  const saldadosData = useMemo(() => {
    return prestamos.filter(p => p.estado === "Saldado");
  }, [prestamos]);

  // 4. Monthly/Daily Payments (Cobros) Report
  const cobrosData = useMemo(() => {
    return pagos.filter(p => {
      const pDate = new Date(p.fecha);
      return pDate.getMonth() === filterMonth;
    });
  }, [pagos, filterMonth]);

  // CSV Export trigger
  const handleExportCSV = () => {
    if (activeReport === "cobros") {
      const headers = ["Recibo No", "Cliente", "Préstamo", "Fecha", "Monto", "Tipo Pago", "Capital Pagado", "Interés Pagado"];
      const rows = cobrosData.map(p => [
        p.reciboNo,
        p.clienteNombre,
        p.prestamoNumero,
        new Date(p.fecha).toLocaleDateString(),
        p.monto.toString(),
        p.tipoPago,
        p.capitalPagado.toString(),
        p.interesPagado.toString()
      ]);
      exportToCSV(`Reporte_Cobros_${monthsList[filterMonth]}`, headers, rows);
    } else if (activeReport === "morosos") {
      const headers = ["Contrato Nro", "Cliente", "Capital Prestado", "Tasa %", "Balance Pendiente", "Fecha de Vencimiento"];
      const rows = morososData.map(p => [
        p.numero,
        p.clienteNombre,
        p.capitalPrestado.toString(),
        p.tasaInteres.toString(),
        p.balancePendiente.toString(),
        new Date(p.fechaVencimiento).toLocaleDateString()
      ]);
      exportToCSV(`Reporte_Clientes_Morosos`, headers, rows);
    } else if (activeReport === "activos") {
      const headers = ["Contrato Nro", "Cliente", "Capital Inicial", "Balance Pendiente", "Frecuencia", "Vencimiento"];
      const rows = activosData.map(p => [
        p.numero,
        p.clienteNombre,
        p.capitalPrestado.toString(),
        p.balancePendiente.toString(),
        p.frecuenciaPago,
        new Date(p.fechaVencimiento).toLocaleDateString()
      ]);
      exportToCSV(`Reporte_Prestamos_Activos`, headers, rows);
    } else {
      const headers = ["Contrato Nro", "Cliente", "Capital Total", "Interés Generado", "Fecha Inicio", "Fecha Vencimiento"];
      const rows = saldadosData.map(p => [
        p.numero,
        p.clienteNombre,
        p.capitalPrestado.toString(),
        p.interesTotal.toString(),
        new Date(p.fechaInicio).toLocaleDateString(),
        new Date(p.fechaVencimiento).toLocaleDateString()
      ]);
      exportToCSV(`Reporte_Prestamos_Saldados`, headers, rows);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="reportes-module-view">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Fórmulas e Informes</h1>
          <p className="text-sm text-gray-500">Genera hojas de cobros, listas de moras, auditorías y exporta a Excel.</p>
        </div>

        {canExport && (
          <div className="flex gap-2 w-full sm:w-auto">
            <button
              onClick={() => window.print()}
              className="flex-1 sm:flex-initial px-4 py-2 border rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-zinc-50"
            >
              <Printer size={15} /> Imprimir Informe
            </button>
            <button
              onClick={handleExportCSV}
              className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 hover:bg-emerald-700"
            >
              <FileSpreadsheet size={15} /> Exportar Excel
            </button>
          </div>
        )}
      </div>

      {/* Selector Grid pills */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <button
          onClick={() => setActiveReport("cobros")}
          className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1
            ${activeReport === "cobros" ? "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-500 text-emerald-700 dark:text-emerald-400 font-bold" : "bg-white dark:bg-[#121214] border-gray-100 dark:border-zinc-800 text-gray-500"}
          `}
        >
          <TrendingUp size={18} />
          <span className="text-xs">Cobros Mensuales</span>
        </button>

        <button
          onClick={() => setActiveReport("morosos")}
          className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1
            ${activeReport === "morosos" ? "bg-rose-50 dark:bg-rose-950/20 border-rose-500 text-rose-700 dark:text-rose-400 font-bold" : "bg-white dark:bg-[#121214] border-gray-100 dark:border-zinc-800 text-gray-500"}
          `}
        >
          <AlertTriangle size={18} />
          <span className="text-xs">Clientes Morosos</span>
        </button>

        <button
          onClick={() => setActiveReport("activos")}
          className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1
            ${activeReport === "activos" ? "bg-blue-50 dark:bg-blue-950/20 border-blue-500 text-blue-700 dark:text-blue-400 font-bold" : "bg-white dark:bg-[#121214] border-gray-100 dark:border-zinc-800 text-gray-500"}
          `}
        >
          <Users size={18} />
          <span className="text-xs">Préstamos Activos</span>
        </button>

        <button
          onClick={() => setActiveReport("saldados")}
          className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1
            ${activeReport === "saldados" ? "bg-zinc-100 dark:bg-zinc-800 border-zinc-500 text-zinc-800 dark:text-zinc-200 font-bold" : "bg-white dark:bg-[#121214] border-gray-100 dark:border-zinc-800 text-gray-500"}
          `}
        >
          <CheckCircle size={18} />
          <span className="text-xs">Historial Saldados</span>
        </button>
      </div>

      {/* FILTER BOX FOR MONTH (ONLY SHOWN FOR COBROS TAB) */}
      {activeReport === "cobros" && (
        <div className="p-3 bg-zinc-50 dark:bg-zinc-900 border rounded-2xl flex items-center justify-between gap-4 text-xs font-semibold">
          <div className="flex items-center gap-1.5 text-gray-500">
            <Filter size={16} /> Filtrar por Período Mensual:
          </div>
          <select
            value={filterMonth}
            onChange={e => setFilterMonth(Number(e.target.value))}
            className="px-3 py-1.5 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-bold"
          >
            {monthsList.map((m, idx) => (
              <option key={idx} value={idx}>{m}</option>
            ))}
          </select>
        </div>
      )}

      {/* TABLE DATA LIST */}
      <div className="bg-white dark:bg-[#121214] border rounded-2xl shadow-sm overflow-hidden text-xs">
        
        {/* Cobros list */}
        {activeReport === "cobros" && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-zinc-50 dark:bg-zinc-900 font-semibold text-gray-400 uppercase tracking-wider border-b">
                  <th className="p-4">Recibo No.</th>
                  <th className="p-4">Cliente</th>
                  <th className="p-4">Referencia Préstamo</th>
                  <th className="p-4">Fecha Cobro</th>
                  <th className="p-4">Concepto Recibo</th>
                  <th className="p-4 text-right">Capital</th>
                  <th className="p-4 text-right">Interés</th>
                  <th className="p-4 text-right font-bold text-emerald-600">Total Recibido</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                {cobrosData.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-12 text-center text-gray-400 text-xs">
                      No se han reportado cobros o pagos para el mes de {monthsList[filterMonth]}.
                    </td>
                  </tr>
                ) : (
                  cobrosData.map(c => (
                    <tr key={c.id || c.reciboNo} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/20">
                      <td className="p-4 font-mono font-bold text-zinc-700 dark:text-zinc-300">{c.reciboNo}</td>
                      <td className="p-4 font-semibold">{c.clienteNombre}</td>
                      <td className="p-4 font-mono text-zinc-400">{c.prestamoNumero}</td>
                      <td className="p-4">{new Date(c.fecha).toLocaleDateString("es-ES")}</td>
                      <td className="p-4">
                        <span className="px-2 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-[10px] font-bold">{c.tipoPago}</span>
                      </td>
                      <td className="p-4 text-right text-gray-500">{formatCurrency(c.capitalPagado, moneda)}</td>
                      <td className="p-4 text-right text-gray-500">{formatCurrency(c.interesPagado, moneda)}</td>
                      <td className="p-4 text-right font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(c.monto, moneda)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Morosos list */}
        {activeReport === "morosos" && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-rose-50/50 dark:bg-rose-950/20 font-semibold text-rose-800 dark:text-rose-400 uppercase tracking-wider border-b">
                  <th className="p-4">Nro. Contrato</th>
                  <th className="p-4">Firma / Cliente</th>
                  <th className="p-4">Capital Desembolsado</th>
                  <th className="p-4">Tasa pactada %</th>
                  <th className="p-4">Monto Cuota</th>
                  <th className="p-4">Vencimiento del Plazo</th>
                  <th className="p-4 text-right">Balance Atrasado Insoluto</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                {morososData.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-gray-400 text-xs">
                      ¡Felicidades! No se registran clientes con préstamos en estado de mora o atraso.
                    </td>
                  </tr>
                ) : (
                  morososData.map(m => (
                    <tr key={m.id} className="hover:bg-rose-50/10 dark:hover:bg-rose-950/5">
                      <td className="p-4 font-mono font-bold text-zinc-700 dark:text-zinc-300">{m.numero}</td>
                      <td className="p-4 font-semibold">{m.clienteNombre}</td>
                      <td className="p-4">{formatCurrency(m.capitalPrestado, moneda)}</td>
                      <td className="p-4 font-mono">{m.tasaInteres}% ({m.tipoInteres})</td>
                      <td className="p-4">{formatCurrency(m.montoCuota, moneda)}</td>
                      <td className="p-4 font-mono">{new Date(m.fechaVencimiento).toLocaleDateString("es-ES")}</td>
                      <td className="p-4 text-right font-bold text-rose-500">{formatCurrency(m.balancePendiente, moneda)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Activos list */}
        {activeReport === "activos" && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-zinc-50 dark:bg-zinc-900 font-semibold text-gray-400 uppercase tracking-wider border-b">
                  <th className="p-4">Nro. Contrato</th>
                  <th className="p-4">Firma / Cliente</th>
                  <th className="p-4">Capital Inicial</th>
                  <th className="p-4">Frecuencia</th>
                  <th className="p-4">Fecha Desembolso</th>
                  <th className="p-4">Próxima Cuota</th>
                  <th className="p-4 text-right">Balance Vigente</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                {activosData.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-gray-400 text-xs">
                      No hay contratos activos circulando actualmente.
                    </td>
                  </tr>
                ) : (
                  activosData.map(a => (
                    <tr key={a.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/20">
                      <td className="p-4 font-mono font-bold text-zinc-700 dark:text-zinc-300">{a.numero}</td>
                      <td className="p-4 font-semibold">{a.clienteNombre}</td>
                      <td className="p-4">{formatCurrency(a.capitalPrestado, moneda)}</td>
                      <td className="p-4">{a.frecuenciaPago} ({a.plazoCuotas} cuotas)</td>
                      <td className="p-4 font-mono">{new Date(a.fechaInicio).toLocaleDateString("es-ES")}</td>
                      <td className="p-4 font-mono">{new Date(a.proximaCuotaFecha).toLocaleDateString("es-ES")}</td>
                      <td className="p-4 text-right font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(a.balancePendiente, moneda)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Saldados list */}
        {activeReport === "saldados" && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-zinc-50 dark:bg-zinc-900 font-semibold text-gray-400 uppercase tracking-wider border-b">
                  <th className="p-4">Nro. Contrato</th>
                  <th className="p-4">Firma / Cliente</th>
                  <th className="p-4">Capital Cobrado</th>
                  <th className="p-4">Interés Cobrado</th>
                  <th className="p-4">Fecha Inicio</th>
                  <th className="p-4 text-right">Monto Retornado Completo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                {saldadosData.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-12 text-center text-gray-400 text-xs">
                      No hay contratos saldados registrados en el historial todavía.
                    </td>
                  </tr>
                ) : (
                  saldadosData.map(s => (
                    <tr key={s.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/20">
                      <td className="p-4 font-mono font-bold text-zinc-700 dark:text-zinc-300">{s.numero}</td>
                      <td className="p-4 font-semibold">{s.clienteNombre}</td>
                      <td className="p-4">{formatCurrency(s.capitalPrestado, moneda)}</td>
                      <td className="p-4">{formatCurrency(s.interesTotal, moneda)}</td>
                      <td className="p-4 font-mono">{new Date(s.fechaInicio).toLocaleDateString("es-ES")}</td>
                      <td className="p-4 text-right font-bold text-blue-600">{formatCurrency(s.montoTotal, moneda)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
}
