import React, { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import {
  Settings,
  Building2,
  DollarSign,
  Percent,
  Palette,
  Users,
  ShieldCheck,
  CheckCircle,
  Camera,
  LogOut,
  UserCheck,
  Plus,
  Trash2,
  Edit2,
  X,
  Shield,
  Check,
  Lock,
  UserX,
  Download,
  Upload,
  ChevronDown,
  ChevronUp,
  Coins,
  Search,
  Filter,
  ArrowRight,
  Clock,
  User,
  Eye,
  Activity
} from "lucide-react";
import { 
  Configuracion as ConfiguracionType, 
  Usuario, 
  APP_MODULOS, 
  getOperacionesAplicables, 
  AuditoriaLog, 
  checkPermission, 
  Cliente, 
  Prestamo, 
  Pago, 
  CuadreCaja,
  Garantia,
  Gasto,
  Banco,
  Deposito,
  AsignacionTemporal,
  HistorialAsignacion
} from "../types";
import SupervisionPerfil from "./SupervisionPerfil";

interface BackupData {
  version: string;
  fecha: string;
  clientes: Cliente[];
  prestamos: Prestamo[];
  pagos: Pago[];
  garantias: Garantia[];
  gastos: Gasto[];
  bancos: Banco[];
  cuadres: CuadreCaja[];
  depositos: Deposito[];
  configuracion: ConfiguracionType;
  usuarios: Usuario[];
}

interface ConfiguracionProps {
  configuracion: ConfiguracionType;
  onSave: (config: ConfiguracionType) => Promise<void>;
  usuarios: Usuario[];
  onSaveUsuario: (user: Usuario) => Promise<void>;
  onDeleteUsuario: (id: string) => Promise<void>;
  currentUserProfile: Usuario | null;
  auditorias?: AuditoriaLog[];
  onAddAuditLog?: (accion: string, usuarioAfectado: string, detalles?: string) => Promise<void>;
  clientes?: Cliente[];
  prestamos?: Prestamo[];
  pagos?: Pago[];
  cuadres?: CuadreCaja[];
  garantias?: Garantia[];
  gastos?: Gasto[];
  bancos?: Banco[];
  depositos?: Deposito[];
  onRestoreBackup?: (data: BackupData) => Promise<void>;
  onWipeDatabase?: () => Promise<void>;
  
  // Assignment & Load balancing additions
  asignacionesTemporales?: AsignacionTemporal[];
  historialAsignaciones?: HistorialAsignacion[];
  onReassignClient?: (clienteId: string, cobradorId: string, motivo: string, tipo: "Inicial" | "Permanente" | "Temporal") => Promise<void>;
  onSaveAsignacionTemporal?: (asig: AsignacionTemporal) => Promise<void>;
  onTransferirCartera?: (sourceEmail: string, destEmail: string, options: { clients: boolean; loans: boolean; route: boolean; history: boolean }, motivo: string) => Promise<void>;
}

export default function Configuracion({
  configuracion,
  onSave,
  usuarios,
  onSaveUsuario,
  onDeleteUsuario,
  currentUserProfile,
  auditorias = [],
  onAddAuditLog,
  clientes = [],
  prestamos = [],
  pagos = [],
  cuadres = [],
  garantias = [],
  gastos = [],
  bancos = [],
  depositos = [],
  onRestoreBackup,
  onWipeDatabase,
  asignacionesTemporales = [],
  historialAsignaciones = [],
  onReassignClient,
  onSaveAsignacionTemporal,
  onTransferirCartera
}: ConfiguracionProps) {
  // Config form states
  const formatCurrency = (amount: number | string | undefined) => {
    if (amount === undefined) return "";
    const symbol = configuracion.moneda || "$";
    const num = typeof amount === "number" ? amount : Number(amount);
    if (isNaN(num)) return `${symbol}${amount}`;
    return `${symbol}${num.toLocaleString([], { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const [isWiping, setIsWiping] = useState(false);
  const [formNombre, setFormNombre] = useState(configuracion.nombreEmpresa || "EasyPres Finanzas");
  const [formRnc, setFormRnc] = useState(configuracion.rnc || "131-019920-1");
  const [formTelefono, setFormTelefono] = useState(configuracion.telefono || "809-555-0199");
  const [formDireccion, setFormDireccion] = useState(configuracion.direccion || "Av. 27 de Febrero, Santo Domingo");
  const [formCorreo, setFormCorreo] = useState(configuracion.correo || "contacto@easypres.com");
  const [formLogo, setFormLogo] = useState(configuracion.logo || "");
  const [formMoneda, setFormMoneda] = useState(configuracion.moneda || "RD$");
  const [formTasa, setFormTasa] = useState(configuracion.tasaInteresDefecto || 10);
  const [formPrimario, setFormPrimario] = useState(configuracion.colorPrimario || "#10b981");
  const [formTimeout, setFormTimeout] = useState(configuracion.timeoutInactividad ?? 30);
  const [formAviso, setFormAviso] = useState(configuracion.avisoInactividadHabilitado ?? true);
  const [formBottomNavHabilitado, setFormBottomNavHabilitado] = useState(configuracion.bottomNavHabilitado ?? true);
  const [formBottomNavModulos, setFormBottomNavModulos] = useState<string[]>(
    configuracion.bottomNavModulosClaves || ["dashboard", "ruta_cobro", "clientes", "prestamos"]
  );

  // Estados de Configuración de Mora Profesional
  const [formPrioridadPagoMora, setFormPrioridadPagoMora] = useState<"mora_first" | "cuota_first" | "manual" | "ask">(
    configuracion.prioridadPagoMora || "mora_first"
  );
  const [formPermitirOmitirMora, setFormPermitirOmitirMora] = useState(configuracion.permitirOmitirMora ?? true);
  const [formRequerirAutorizacionOmitir, setFormRequerirAutorizacionOmitir] = useState(configuracion.requerirAutorizacionOmitir ?? false);
  const [formMoraMaximaMonto, setFormMoraMaximaMonto] = useState(configuracion.moraMaximaMonto ?? 5000);
  const [formDiasToleranciaMoraDefecto, setFormDiasToleranciaMoraDefecto] = useState(configuracion.diasToleranciaMoraDefecto ?? 3);

  const [formMetodoArqueo, setFormMetodoArqueo] = useState<"simple" | "denominaciones" | "ambos">(
    configuracion.metodoArqueo || "ambos"
  );

  const [formDashboardVistaDefecto, setFormDashboardVistaDefecto] = useState<"ejecutiva" | "bento" | "compacta" | "analitica" | "desglosada" | "adaptativo">(
    configuracion.dashboardVistaDefecto || "bento"
  );
  const [formDashboardPersonalizable, setFormDashboardPersonalizable] = useState<boolean>(
    configuracion.dashboardPersonalizable ?? true
  );
  const [formDashboardRecordarVista, setFormDashboardRecordarVista] = useState<boolean>(
    configuracion.dashboardRecordarVista ?? true
  );

  // Collapsible states
  const [isBottomNavExpanded, setIsBottomNavExpanded] = useState(false);
  const [isSecurityMeasuresExpanded, setIsSecurityMeasuresExpanded] = useState(false);
  const [isMoraExpanded, setIsMoraExpanded] = useState(false);
  const [isCajaExpanded, setIsCajaExpanded] = useState(false);
  const [isDashboardExpanded, setIsDashboardExpanded] = useState(false);

  // Expanded Audit Trail state
  const [showFullAuditModal, setShowFullAuditModal] = useState(false);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditFilterOperator, setAuditFilterOperator] = useState("");
  const [auditFilterAction, setAuditFilterAction] = useState("");
  const [selectedAuditLog, setSelectedAuditLog] = useState<AuditoriaLog | null>(null);

  // Handle logo upload converting to base64
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormLogo(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleDownloadBackup = () => {
    try {
      const backup: BackupData = {
        version: "1.20",
        fecha: new Date().toISOString(),
        clientes,
        prestamos,
        pagos,
        garantias,
        gastos,
        bancos,
        cuadres,
        depositos,
        configuracion,
        usuarios
      };

      const jsonStr = JSON.stringify(backup, null, 2);
      const blob = new Blob([jsonStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement("a");
      const dateStr = new Date().toISOString().split("T")[0];
      link.href = url;
      link.download = `easypres_backup_${dateStr}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      if (onAddAuditLog) {
        onAddAuditLog(
          "Copia de Seguridad Descargada",
          "Ajustes de Sistema",
          "Se exportó una copia completa de toda la base de datos en formato JSON de forma local."
        );
      }
    } catch (e: any) {
      alert("Error al generar copia de seguridad: " + e.message);
    }
  };

  const handleRestoreBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm("⚠️ ADVERTENCIA CRÍTICA ⚠️\n\nAl restaurar esta copia de seguridad, se reemplazarán todos los datos actuales del sistema con los datos contenidos en el archivo de copia.\n\n¿Estás completamente seguro de que deseas proceder? Esta acción no se puede deshacer.")) {
      e.target.value = "";
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const rawText = event.target?.result as string;
        const data = JSON.parse(rawText);

        // Basic validation
        if (!data.clientes || !data.prestamos || !data.pagos) {
          alert("El archivo de copia de seguridad no parece válido o le faltan colecciones principales (clientes, prestamos, pagos).");
          return;
        }

        // Call the parent restore callback to write back to Firestore / localStorage
        if (onRestoreBackup) {
          await onRestoreBackup(data);
          alert("¡Copia de seguridad restaurada de forma exitosa en el sistema!");
          if (onAddAuditLog) {
            await onAddAuditLog(
              "Copia de Seguridad Restaurada",
              "Ajustes de Sistema",
              `Se restauró con éxito una copia de seguridad con fecha: ${data.fecha || 'Desconocida'}.`
            );
          }
          window.location.reload(); // Refresh to load restored data cleanly
        } else {
          alert("La función de restauración no está habilitada en este momento.");
        }
      } catch (err: any) {
        alert("Error al restaurar el archivo: " + err.message);
      }
    };
    reader.readAsText(file);
  };

  // Submit company configurations
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkPermission(currentUserProfile, "configuracion", "editar")) {
      alert("No tienes permisos de edición para el módulo de configuración.");
      return;
    }
    if (!formNombre || !formMoneda) {
      alert("Por favor ingrese el nombre de la empresa y símbolo de moneda.");
      return;
    }

    // Check if security configuration changed for audit trail
    const prevTimeout = configuracion.timeoutInactividad ?? 30;
    const prevAviso = configuracion.avisoInactividadHabilitado ?? true;
    
    let securityChanged = false;
    let auditDetails = "";

    if (formTimeout !== prevTimeout) {
      securityChanged = true;
      auditDetails += `Tiempo de inactividad: de ${prevTimeout} min a ${formTimeout} min. `;
    }
    if (formAviso !== prevAviso) {
      securityChanged = true;
      auditDetails += `Aviso de inactividad: de ${prevAviso ? "Sí" : "No"} a ${formAviso ? "Sí" : "No"}. `;
    }

    const payload: ConfiguracionType = {
      id: "general",
      nombreEmpresa: formNombre,
      rnc: formRnc,
      telefono: formTelefono,
      direccion: formDireccion,
      correo: formCorreo,
      logo: formLogo,
      moneda: formMoneda,
      tasaInteresDefecto: Number(formTasa),
      colorPrimario: formPrimario,
      colorSecundario: "#1e293b",
      timeoutInactividad: Number(formTimeout),
      avisoInactividadHabilitado: formAviso,
      bottomNavHabilitado: formBottomNavHabilitado,
      bottomNavModulosClaves: formBottomNavModulos,
      prioridadPagoMora: formPrioridadPagoMora,
      permitirOmitirMora: formPermitirOmitirMora,
      requerirAutorizacionOmitir: formRequerirAutorizacionOmitir,
      moraMaximaMonto: Number(formMoraMaximaMonto),
      diasToleranciaMoraDefecto: Number(formDiasToleranciaMoraDefecto),
      metodoArqueo: formMetodoArqueo,
      dashboardVistaDefecto: formDashboardVistaDefecto,
      dashboardPersonalizable: formDashboardPersonalizable,
      dashboardRecordarVista: formDashboardRecordarVista
    };

    try {
      await onSave(payload);
      if (securityChanged && onAddAuditLog) {
        await onAddAuditLog(
          "Configuración de Seguridad",
          "Ajustes de Sistema",
          `Se modificaron los parámetros de cierre automático de sesión. Detalles: ${auditDetails}`
        );
      } else if (onAddAuditLog) {
        await onAddAuditLog(
          "Configuración Corporativa",
          "Ajustes de Empresa",
          "Se modificaron los datos corporativos de la empresa."
        );
      }
      alert("¡Configuración de la empresa guardada de forma segura en Firestore!");
    } catch (err) {
      console.error(err);
      alert("Error guardando configuraciones");
    }
  };

  // --- Operadores de Sistema Modal & Permisos States ---
  const [configSection, setConfigSection] = useState<"empresa" | "operadores" | "supervision">("empresa");
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<Usuario | null>(null);
  const [modalTab, setModalTab] = useState<"datos" | "permisos">("datos");

  // Form states for Operator
  const [userName, setUserName] = useState("");
  const [userEmailInput, setUserEmailInput] = useState("");
  const [userRole, setUserRole] = useState<"Administrador" | "Supervisor" | "Cobrador">("Cobrador");
  const [userActive, setUserActive] = useState(true);
  const [userPermisos, setUserPermisos] = useState<{ [modId: string]: any }>({});

  // Prevent background scrolling when user modal is open
  useEffect(() => {
    if (showUserModal) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [showUserModal]);

  // Populate default permissions when role is selected
  const handleRoleChange = (role: "Administrador" | "Supervisor" | "Cobrador") => {
    setUserRole(role);
    const defaultPerms: { [modId: string]: any } = {};
    APP_MODULOS.forEach((mod) => {
      const ops = getOperacionesAplicables(mod.id);
      defaultPerms[mod.id] = {};
      ops.forEach((op) => {
        if (role === "Administrador") {
          defaultPerms[mod.id][op] = true;
        } else if (role === "Supervisor") {
          if (mod.id === "configuracion") {
            defaultPerms[mod.id][op] = op === "ver"; // View only for configuration
          } else {
            defaultPerms[mod.id][op] = op !== "eliminar"; // All except delete
          }
        } else if (role === "Cobrador") {
          // Cobrador has dashboard, register & edit clients, register loan requests, and process payments
          if (mod.id === "dashboard" || mod.id === "ruta_cobro") {
            defaultPerms[mod.id][op] = true;
          } else if (mod.id === "clientes") {
            defaultPerms[mod.id][op] = op === "ver" || op === "crear" || op === "editar" || op === "exportar";
          } else if (mod.id === "prestamos") {
            defaultPerms[mod.id][op] = op === "ver" || op === "crear";
          } else if (mod.id === "pagos") {
            defaultPerms[mod.id][op] = op === "ver" || op === "crear" || op === "exportar";
          } else {
            defaultPerms[mod.id][op] = false;
          }
        }
      });
    });
    setUserPermisos(defaultPerms);
  };

  // Open modal in Add mode
  const handleOpenAddUser = () => {
    if (!checkPermission(currentUserProfile, "configuracion", "editar")) {
      alert("No tienes permisos para agregar nuevos operadores.");
      return;
    }
    setEditingUser(null);
    setUserName("");
    setUserEmailInput("");
    setUserActive(true);
    setModalTab("datos");
    setShowUserModal(true);
    handleRoleChange("Cobrador"); // default role and preset default perms
  };

  // Open modal in Edit mode
  const handleOpenEditUser = (userToEdit: Usuario) => {
    const hasConfigEdit = checkPermission(currentUserProfile, "configuracion", "editar");
    const isSelf = userToEdit.email === currentUserProfile?.email;
    const canEditUser = hasConfigEdit && (currentUserProfile?.rol === "Administrador" || userToEdit.rol === "Cobrador" || isSelf);

    if (!canEditUser) {
      alert("No tienes permisos para editar este operador.");
      return;
    }

    setEditingUser(userToEdit);
    setUserName(userToEdit.nombre);
    setUserEmailInput(userToEdit.email);
    setUserRole(userToEdit.rol);
    setUserActive(userToEdit.activo);

    const initialPerms: { [modId: string]: any } = {};
    APP_MODULOS.forEach((mod) => {
      initialPerms[mod.id] = {};
      const ops = getOperacionesAplicables(mod.id);
      ops.forEach((op) => {
        initialPerms[mod.id][op] = userToEdit.permisos?.[mod.id]?.[op] ?? false;
      });
    });
    setUserPermisos(initialPerms);
    setModalTab("datos");
    setShowUserModal(true);
  };

  // Submit Operator form
  const handleSaveUserForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkPermission(currentUserProfile, "configuracion", "editar")) {
      alert("No tienes permisos para guardar o modificar operadores.");
      return;
    }
    if (!userName || !userEmailInput) {
      alert("Por favor complete el nombre y correo del operador.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(userEmailInput)) {
      alert("Por favor ingrese un correo electrónico válido.");
      return;
    }

    const targetEmail = userEmailInput.toLowerCase().trim();

    // Prevent lockout and security self-modification
    if (editingUser && editingUser.email === currentUserProfile?.email) {
      if (!userActive && currentUserProfile.activo) {
        alert("No puedes desactivar tu propio operador de sistema.");
        return;
      }
      if (userRole !== "Administrador" && currentUserProfile.rol === "Administrador") {
        alert("No puedes quitarte el rol de Administrador a ti mismo.");
        return;
      }
    }

    // Prevent deactivating or demoting the last active Admin (Requirement 4)
    if (editingUser?.rol === "Administrador" && (userRole !== "Administrador" || !userActive)) {
      const activeAdmins = usuarios.filter(u => u.rol === "Administrador" && u.activo && u.id !== editingUser.id);
      if (activeAdmins.length === 0) {
        alert("No se puede desactivar o cambiar el rol del único administrador activo del sistema.");
        return;
      }
    }

    const payload: Usuario = {
      nombre: userName,
      email: targetEmail,
      rol: userRole,
      activo: userActive,
      permisos: userRole === "Administrador" ? undefined : userPermisos // Admins have master permissions
    };

    if (editingUser?.id) {
      payload.id = editingUser.id;
      payload.uid = editingUser.uid;
    }

    try {
      await onSaveUsuario(payload);
      setShowUserModal(false);
    } catch (err) {
      console.error(err);
      alert("Error al guardar el operador");
    }
  };

  // Delete Operator -> Mark as Inactive instead of deleting
  const handleDeleteUser = async (userToDelete: Usuario) => {
    if (!checkPermission(currentUserProfile, "configuracion", "editar")) {
      alert("No tienes permisos para desactivar operadores.");
      return;
    }
    if (userToDelete.email === currentUserProfile?.email) {
      alert("No puedes desactivar tu propio operador de sistema.");
      return;
    }
    
    // Check if we are trying to deactivate the last Admin (Requirement 4)
    if (userToDelete.rol === "Administrador" && userToDelete.activo) {
      const activeAdmins = usuarios.filter(u => u.rol === "Administrador" && u.activo);
      if (activeAdmins.length <= 1) {
        alert("No se puede desactivar al único administrador activo del sistema.");
        return;
      }
    }

    if (confirm(`¿Estás seguro de que deseas desactivar al operador "${userToDelete.nombre}" (${userToDelete.email})? Por motivos de seguridad y auditoría, las cuentas de operadores no se eliminan físicamente del sistema, solo se desactivan.`)) {
      try {
        const updatedUser: Usuario = {
          ...userToDelete,
          activo: false
        };
        await onSaveUsuario(updatedUser);
      } catch (err) {
        console.error(err);
        alert("Error al desactivar el operador");
      }
    }
  };

  const isEditingSelf = editingUser?.email === currentUserProfile?.email;

  return (
    <div className="space-y-6 animate-fade-in" id="configuracion-module-view">
      
      {/* Title & Section Toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4 border-zinc-100 dark:border-zinc-850">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Ajustes Generales</h1>
          <p className="text-sm text-gray-500">Configura la identidad comercial de tu financiera, moneda de base y roles de acceso.</p>
        </div>

        {/* Dynamic section toggler for General config vs Operator Audit Profiles */}
        <div className="flex flex-wrap bg-zinc-100 dark:bg-zinc-800/80 p-1 rounded-xl shrink-0 border border-zinc-200/40 dark:border-zinc-700/40 gap-1" id="config-section-toggles">
          <button
            type="button"
            onClick={() => setConfigSection("empresa")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              configSection === "empresa"
                ? "bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm"
                : "text-gray-500 hover:text-gray-800 dark:hover:text-zinc-200"
            }`}
            id="toggle-config-empresa"
          >
            <Building2 size={14} className="text-emerald-500" />
            <span>Ajustes de Empresa</span>
          </button>
          <button
            type="button"
            onClick={() => setConfigSection("operadores")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              configSection === "operadores"
                ? "bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm"
                : "text-gray-500 hover:text-gray-800 dark:hover:text-zinc-200"
            }`}
            id="toggle-config-operadores"
          >
            <Users size={14} className="text-emerald-500" />
            <span>Operadores y Seguridad</span>
          </button>
          <button
            type="button"
            onClick={() => setConfigSection("supervision")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              configSection === "supervision"
                ? "bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm"
                : "text-gray-500 hover:text-gray-800 dark:hover:text-zinc-200"
            }`}
            id="toggle-config-supervision"
          >
            <ShieldCheck size={14} className="text-emerald-500" />
            <span>Supervisión de Perfiles</span>
          </button>
        </div>
      </div>

      {configSection === "supervision" && (
        <SupervisionPerfil
          usuarios={usuarios}
          clientes={clientes}
          prestamos={prestamos}
          pagos={pagos}
          cuadres={cuadres}
          auditorias={auditorias}
          moneda={configuracion.moneda || "$"}
          asignacionesTemporales={asignacionesTemporales}
          historialAsignaciones={historialAsignaciones}
          onReassignClient={onReassignClient}
          onSaveAsignacionTemporal={onSaveAsignacionTemporal}
          onTransferirCartera={onTransferirCartera}
          configuracion={configuracion}
          onSaveUsuario={onSaveUsuario}
        />
      )}

      {configSection === "empresa" && (
        <div className="max-w-4xl mx-auto bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-sm">
          <form onSubmit={handleSubmit} className="space-y-5">
            
            <div className="flex items-center gap-2 border-b pb-3 text-sm font-bold text-gray-900 dark:text-white">
              <Building2 className="text-emerald-500" size={18} /> Datos de la Empresa Financiera
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Nombre Comercial *</label>
                <input
                  type="text"
                  required
                  value={formNombre}
                  onChange={e => setFormNombre(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Identificación Tributaria / RNC</label>
                <input
                  type="text"
                  placeholder="Ej: 131-019920-1"
                  value={formRnc}
                  onChange={e => setFormRnc(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Teléfono Fijo</label>
                <input
                  type="tel"
                  value={formTelefono}
                  onChange={e => setFormTelefono(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Correo de Negocios</label>
                <input
                  type="email"
                  value={formCorreo}
                  onChange={e => setFormCorreo(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Dirección Física de Oficinas</label>
                <input
                  type="text"
                  value={formDireccion}
                  onChange={e => setFormDireccion(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>
            </div>

            {/* Financial Parameters Section */}
            <div className="flex items-center gap-2 border-b pt-4 pb-3 text-sm font-bold text-gray-900 dark:text-white">
              <DollarSign className="text-emerald-500" size={18} /> Parámetros de Préstamos
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Símbolo Moneda *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: RD$, $, €"
                  value={formMoneda}
                  onChange={e => setFormMoneda(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-extrabold text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Tasa Interés Defecto (%) *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 right-3 flex items-center text-gray-400">%</span>
                  <input
                    type="number"
                    required
                    step="0.1"
                    value={formTasa}
                    onChange={e => setFormTasa(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Color de Énfasis del Sistema</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={formPrimario}
                    onChange={e => setFormPrimario(e.target.value)}
                    className="w-8 h-8 rounded border-none cursor-pointer"
                  />
                  <span className="font-mono">{formPrimario}</span>
                </div>
              </div>
            </div>

            {/* Security Parameters Section (Requirement 5) */}
            <div className="flex items-center gap-2 border-b pt-4 pb-3 text-sm font-bold text-gray-900 dark:text-white" id="section-security-config">
              <Lock className="text-emerald-500" size={18} /> Seguridad y Control de Sesión
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Tiempo de Inactividad</label>
                <div className="flex gap-2">
                  <select
                    value={[10, 15, 30, 45, 60].includes(formTimeout) ? formTimeout : "custom"}
                    disabled={currentUserProfile?.rol !== "Administrador"}
                    onChange={e => {
                      const val = e.target.value;
                      if (val !== "custom") {
                        setFormTimeout(Number(val));
                      } else {
                        setFormTimeout(25); // temporary arbitrary custom value
                      }
                    }}
                    className="flex-1 px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold text-gray-800 dark:text-zinc-200 disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    <option value={10}>10 minutos</option>
                    <option value={15}>15 minutos</option>
                    <option value={30}>30 minutos (Por defecto)</option>
                    <option value={45}>45 minutos</option>
                    <option value={60}>60 minutos</option>
                    <option value="custom">Personalizado...</option>
                  </select>
                  
                  {(![10, 15, 30, 45, 60].includes(formTimeout) || formTimeout === 25) && (
                    <input
                      type="number"
                      min={1}
                      max={1440}
                      value={formTimeout}
                      disabled={currentUserProfile?.rol !== "Administrador"}
                      onChange={e => setFormTimeout(Math.max(1, Number(e.target.value)))}
                      className="w-24 px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold disabled:opacity-60 disabled:cursor-not-allowed"
                      placeholder="Minutos"
                    />
                  )}
                </div>
                <p className="text-[10px] text-gray-400 mt-1">La sesión se cerrará automáticamente tras este periodo de inactividad.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Aviso Previo de Cierre</label>
                <select
                  value={formAviso ? "true" : "false"}
                  disabled={currentUserProfile?.rol !== "Administrador"}
                  onChange={e => setFormAviso(e.target.value === "true")}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-semibold text-gray-800 dark:text-zinc-200 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  <option value="true">Sí, avisar con diálogo de advertencia</option>
                  <option value="false">No avisar, cerrar directamente</option>
                </select>
                <p className="text-[10px] text-gray-400 mt-1">Muestra una advertencia interactiva antes de cerrar la sesión.</p>
              </div>
            </div>

            {/* Bottom Nav Configuration Section */}
            <button
              type="button"
              onClick={() => setIsBottomNavExpanded(!isBottomNavExpanded)}
              className="w-full flex items-center justify-between border-b pt-4 pb-3 text-sm font-bold text-gray-900 dark:text-white hover:text-emerald-500 hover:border-emerald-500/30 transition-all text-left cursor-pointer active:scale-[0.99]"
              id="section-bottom-nav-config"
            >
              <span className="flex items-center gap-2">
                <Settings className="text-emerald-500" size={18} /> Barra de Navegación Móvil
              </span>
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-normal">
                <span>{isBottomNavExpanded ? "Ocultar" : "Configurar"}</span>
                {isBottomNavExpanded ? (
                  <ChevronUp className="text-gray-400 dark:text-zinc-500" size={16} />
                ) : (
                  <ChevronDown className="text-gray-400 dark:text-zinc-500" size={16} />
                )}
              </div>
            </button>

            {isBottomNavExpanded && (
              <div className="space-y-4 text-xs animate-fade-in pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Estado de la Barra Inferior</label>
                    <select
                      value={formBottomNavHabilitado ? "true" : "false"}
                      onChange={e => setFormBottomNavHabilitado(e.target.value === "true")}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-semibold text-gray-800 dark:text-zinc-200"
                    >
                      <option value="true">Activada (Mostrar en dispositivos móviles)</option>
                      <option value="false">Desactivada (Usar menú lateral tradicional)</option>
                    </select>
                    <p className="text-[10px] text-gray-400 mt-1">
                      Permite a los operadores acceder rápidamente a los módulos clave desde la parte inferior de la pantalla.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">
                      Módulos Claves Activos en la Barra (Máx. 4)
                    </label>
                    <p className="text-[10px] text-gray-400">
                      Selecciona exactamente entre 2 y 4 módulos principales para visualización rápida.
                    </p>
                  </div>
                </div>

                {formBottomNavHabilitado && (
                  <div className="p-4 bg-zinc-50 dark:bg-zinc-900/40 rounded-2xl border border-zinc-100 dark:border-zinc-800/60">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {APP_MODULOS.map(mod => {
                        const isChecked = formBottomNavModulos.includes(mod.id);
                        return (
                          <label
                            key={mod.id}
                            className={`flex items-center gap-2.5 p-2.5 rounded-xl border cursor-pointer select-none transition-all duration-200 ${
                              isChecked
                                ? "bg-emerald-500/5 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-bold"
                                : "bg-white dark:bg-zinc-950/40 border-zinc-200/50 dark:border-zinc-800/50 text-gray-500 hover:text-gray-800 dark:hover:text-zinc-200"
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {
                                if (isChecked) {
                                  // Allow removing but must keep at least 2 modules
                                  if (formBottomNavModulos.length <= 2) {
                                    alert("Debes seleccionar al menos 2 módulos clave para la barra inferior.");
                                    return;
                                  }
                                  setFormBottomNavModulos(formBottomNavModulos.filter(id => id !== mod.id));
                                } else {
                                  // Max 4 modules
                                  if (formBottomNavModulos.length >= 4) {
                                    alert("Puedes seleccionar un máximo de 4 módulos clave. Desmarca uno para activar otro.");
                                    return;
                                  }
                                  setFormBottomNavModulos([...formBottomNavModulos, mod.id]);
                                }
                              }}
                              className="w-4 h-4 rounded text-emerald-600 border-zinc-300 dark:border-zinc-700 focus:ring-emerald-500"
                            />
                            <span className="truncate">{mod.label.replace(/🧭|💵|⚙️|📊/g, '').trim()}</span>
                          </label>
                        );
                      })}
                    </div>
                    <div className="mt-3 flex items-center gap-2 text-[10px] text-zinc-500 dark:text-zinc-400">
                      <span className="font-bold px-1.5 py-0.5 rounded bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300">
                        {formBottomNavModulos.length} / 4
                      </span>
                      <span>módulos seleccionados. Se mostrarán en este mismo orden en la barra inferior.</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Ajustes de Mora y Recargos (Professional Late Fee Configuration) */}
            <button
              type="button"
              onClick={() => setIsMoraExpanded(!isMoraExpanded)}
              className="w-full flex items-center justify-between border-b pt-4 pb-3 text-sm font-bold text-gray-900 dark:text-white hover:text-emerald-500 hover:border-emerald-500/30 transition-all text-left cursor-pointer active:scale-[0.99]"
              id="section-mora-config"
            >
              <span className="flex items-center gap-2">
                <Percent className="text-rose-500" size={18} /> Política de Moras y Recargos
              </span>
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-normal">
                <span>{isMoraExpanded ? "Ocultar" : "Configurar"}</span>
                {isMoraExpanded ? (
                  <ChevronUp className="text-gray-400 dark:text-zinc-500" size={16} />
                ) : (
                  <ChevronDown className="text-gray-400 dark:text-zinc-500" size={16} />
                )}
              </div>
            </button>

            {isMoraExpanded && (
              <div className="space-y-4 text-xs animate-fade-in pt-1 border border-zinc-100 dark:border-zinc-800/60 p-4 rounded-2xl bg-zinc-50/50 dark:bg-zinc-900/10">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">
                      Prioridad de Aplicación del Pago *
                    </label>
                    <select
                      value={formPrioridadPagoMora}
                      onChange={e => setFormPrioridadPagoMora(e.target.value as any)}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-semibold text-gray-800 dark:text-zinc-200"
                    >
                      <option value="mora_first">Cobrar mora primero (Recomendado)</option>
                      <option value="cuota_first">Cobrar cuota primero</option>
                      <option value="manual">Distribución manual (Saldar individualmente)</option>
                      <option value="ask">Preguntar al cobrador antes de registrar</option>
                    </select>
                    <p className="text-[10px] text-gray-400 mt-1">
                      Define la regla que usará el sistema para amortizar pagos totales o parciales automáticamente.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">
                      Mora Máxima Acumulable (Monto)
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-3 flex items-center text-gray-400 font-bold">{formMoneda}</span>
                      <input
                        type="number"
                        min="0"
                        value={formMoraMaximaMonto}
                        onChange={e => setFormMoraMaximaMonto(Math.max(0, Number(e.target.value)))}
                        className="w-full pl-9 pr-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-mono font-bold"
                        placeholder="Ej: 5000"
                      />
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1">
                      Monto límite máximo de mora que un préstamo puede llegar a acumular para evitar deudas impagables. (0 = Sin límite)
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">
                      Días de Gracia / Tolerancia por Defecto
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 right-3 flex items-center text-gray-400 font-semibold">Días</span>
                      <input
                        type="number"
                        min="0"
                        value={formDiasToleranciaMoraDefecto}
                        onChange={e => setFormDiasToleranciaMoraDefecto(Math.max(0, Number(e.target.value)))}
                        className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold"
                      />
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1">
                      Días después de vencido el plazo antes de que empiece a cobrarse la mora en nuevos préstamos.
                    </p>
                  </div>

                  <div className="space-y-3 pt-2">
                    <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-zinc-300 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={formPermitirOmitirMora}
                        onChange={e => setFormPermitirOmitirMora(e.target.checked)}
                        className="w-4 h-4 rounded text-emerald-600 border-zinc-300 dark:border-zinc-700 focus:ring-emerald-500"
                      />
                      <span>Permitir cobrar solo la cuota (Omitir mora)</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-zinc-300 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={formRequerirAutorizacionOmitir}
                        onChange={e => setFormRequerirAutorizacionOmitir(e.target.checked)}
                        className="w-4 h-4 rounded text-emerald-600 border-zinc-300 dark:border-zinc-700 focus:ring-emerald-500"
                      />
                      <span>Requerir clave de Administrador para omitir</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Ajustes de Arqueo y Caja (Cash & Reconciliation Method Configuration) */}
            <button
              type="button"
              onClick={() => setIsCajaExpanded(!isCajaExpanded)}
              className="w-full flex items-center justify-between border-b pt-4 pb-3 text-sm font-bold text-gray-900 dark:text-white hover:text-emerald-500 hover:border-emerald-500/30 transition-all text-left cursor-pointer active:scale-[0.99]"
              id="section-caja-config"
            >
              <span className="flex items-center gap-2">
                <Coins className="text-emerald-500" size={18} /> Configuración de Caja y Arqueos
              </span>
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-normal">
                <span>{isCajaExpanded ? "Ocultar" : "Configurar"}</span>
                {isCajaExpanded ? (
                  <ChevronUp className="text-gray-400 dark:text-zinc-500" size={16} />
                ) : (
                  <ChevronDown className="text-gray-400 dark:text-zinc-500" size={16} />
                )}
              </div>
            </button>

            {isCajaExpanded && (
              <div className="space-y-4 text-xs animate-fade-in pt-1 border border-zinc-100 dark:border-zinc-800/60 p-4 rounded-2xl bg-zinc-50/50 dark:bg-zinc-900/10">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">
                      Método de Arqueo de Caja *
                    </label>
                    <select
                      value={formMetodoArqueo}
                      onChange={e => setFormMetodoArqueo(e.target.value as any)}
                      disabled={currentUserProfile?.rol !== "Administrador"}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-semibold text-gray-800 dark:text-zinc-200 disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      <option value="simple">Arqueo Simple (Solo monto total manual)</option>
                      <option value="denominaciones">Arqueo por Denominaciones (Desglose físico)</option>
                      <option value="ambos">Permitir ambos métodos (Seleccionar al iniciar)</option>
                    </select>
                    {currentUserProfile?.rol !== "Administrador" && (
                      <p className="text-[10px] text-rose-500 font-medium mt-1">
                        Solo el Administrador de la empresa puede modificar esta directiva.
                      </p>
                    )}
                    <p className="text-[10px] text-gray-400 mt-1">
                      Establece el nivel de control y detalle físico requerido por el sistema al registrar cierres de caja (cuadres). El método por Denominaciones exige detallar el conteo físico de billetes y monedas.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Ajustes de Visualización del Dashboard (Dashboard Layout Configuration) */}
            <button
              type="button"
              onClick={() => setIsDashboardExpanded(!isDashboardExpanded)}
              className="w-full flex items-center justify-between border-b pt-4 pb-3 text-sm font-bold text-gray-900 dark:text-white hover:text-emerald-500 hover:border-emerald-500/30 transition-all text-left cursor-pointer active:scale-[0.99]"
              id="section-dashboard-config"
            >
              <span className="flex items-center gap-2">
                <Palette className="text-indigo-500" size={18} /> Preferencias del Dashboard
              </span>
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-normal">
                <span>{isDashboardExpanded ? "Ocultar" : "Configurar"}</span>
                {isDashboardExpanded ? (
                  <ChevronUp className="text-gray-400 dark:text-zinc-500" size={16} />
                ) : (
                  <ChevronDown className="text-gray-400 dark:text-zinc-500" size={16} />
                )}
              </div>
            </button>

            {isDashboardExpanded && (
              <div className="space-y-4 text-xs animate-fade-in pt-1 border border-zinc-100 dark:border-zinc-800/60 p-4 rounded-2xl bg-zinc-50/50 dark:bg-zinc-900/10">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">
                      Vista Predeterminada de la Empresa
                    </label>
                    <select
                      value={formDashboardVistaDefecto}
                      onChange={e => setFormDashboardVistaDefecto(e.target.value as any)}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-semibold text-gray-800 dark:text-zinc-200"
                    >
                      <option value="ejecutiva">Vista Ejecutiva (Simplificada)</option>
                      <option value="bento">Bento Consolidado (Balanceado)</option>
                      <option value="compacta">Vista Compacta (Alta Densidad)</option>
                      <option value="analitica">Vista Analítica (Gráficos Primero)</option>
                      <option value="desglosada">Vista Desglosada (Detallada)</option>
                      <option value="adaptativo">Adaptación automática por dispositivo</option>
                    </select>
                    <p className="text-[10px] text-gray-400 mt-1">
                      Define qué estilo visual verán inicialmente los operadores y directivos al ingresar al sistema.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-zinc-200/60 dark:border-zinc-800/60 bg-white dark:bg-zinc-950/40 cursor-pointer select-none transition-all duration-200">
                      <input
                        type="checkbox"
                        checked={formDashboardPersonalizable}
                        onChange={e => setFormDashboardPersonalizable(e.target.checked)}
                        className="w-4 h-4 mt-0.5 rounded text-emerald-600 border-zinc-300 dark:border-zinc-700 focus:ring-emerald-500"
                      />
                      <div>
                        <span className="block text-xs font-semibold text-zinc-800 dark:text-zinc-200">Permitir personalización de usuario</span>
                        <span className="block text-[10px] text-gray-400 font-normal mt-0.5">
                          Si está activo, cada operador puede alternar la vista y su preferencia se recordará según los ajustes.
                        </span>
                      </div>
                    </label>

                    <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-zinc-200/60 dark:border-zinc-800/60 bg-white dark:bg-zinc-950/40 cursor-pointer select-none transition-all duration-200">
                      <input
                        type="checkbox"
                        checked={formDashboardRecordarVista}
                        onChange={e => setFormDashboardRecordarVista(e.target.checked)}
                        className="w-4 h-4 mt-0.5 rounded text-emerald-600 border-zinc-300 dark:border-zinc-700 focus:ring-emerald-500"
                      />
                      <div>
                        <span className="block text-xs font-semibold text-zinc-800 dark:text-zinc-200">Recordar mi última vista</span>
                        <span className="block text-[10px] text-gray-400 font-normal mt-0.5">
                          Recordar automáticamente la última vista seleccionada en este navegador (localStorage).
                        </span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Logo Section */}
            <div className="flex items-center gap-4 p-4 bg-zinc-50 dark:bg-zinc-900 rounded-2xl">
              {formLogo ? (
                <img
                  src={formLogo}
                  alt="Company Logo"
                  className="w-16 h-16 rounded-xl object-cover border border-emerald-500 shadow-sm"
                />
              ) : (
                <div className="w-16 h-16 bg-zinc-200 dark:bg-zinc-800 rounded-xl flex items-center justify-center text-gray-400">
                  <Camera size={24} />
                </div>
              )}
              <div className="space-y-1.5 flex-1">
                <h4 className="text-xs font-bold text-gray-800 dark:text-zinc-200">Logotipo Institucional</h4>
                <p className="text-[10px] text-gray-400">Se usará para la impresión de contratos y recibos de caja.</p>
                <label className="cursor-pointer inline-block px-3 py-1 bg-zinc-200 dark:bg-zinc-800 rounded text-[10px] font-bold">
                  Sugerir Logo
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoChange}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="pt-4 border-t text-right">
              <button
                type="submit"
                className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer transition-colors"
              >
                Guardar Ajustes Corporativos
              </button>
            </div>

          </form>
        </div>
      )}

      {configSection === "operadores" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
          
          {/* Left Column: Dynamic Operators List & Permissions Management (Promoted to Left Column for instant accessibility) */}
          <div className="lg:col-span-7 space-y-6" id="operators-list-section">
            
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-sm space-y-5">
              
              <div className="flex items-center justify-between border-b pb-3 border-zinc-100 dark:border-zinc-850">
                <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Users size={18} className="text-emerald-500" /> Operadores de Sistema
                </h3>
                {checkPermission(currentUserProfile, "configuracion", "editar") && (
                  <button
                    type="button"
                    onClick={handleOpenAddUser}
                    className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 dark:bg-emerald-950/30 dark:hover:bg-emerald-950/50 dark:text-emerald-400 rounded-xl transition-all flex items-center gap-1 text-[11px] font-bold uppercase cursor-pointer"
                    title="Agregar nuevo operador"
                    id="btn-add-operator"
                  >
                    <Plus size={14} /> Nuevo Operador
                  </button>
                )}
              </div>

              <div className="space-y-3">
                {usuarios.length === 0 ? (
                  <div className="text-center py-8 text-xs text-gray-400">
                    No hay operadores registrados en el sistema.
                  </div>
                ) : (
                  usuarios.map((u, idx) => {
                    const isSelf = u.email === currentUserProfile?.email;
                    const hasConfigEdit = checkPermission(currentUserProfile, "configuracion", "editar");
                    const canEditUser = hasConfigEdit && (currentUserProfile?.rol === "Administrador" || u.rol === "Cobrador" || isSelf);
                    const canDeleteUser = hasConfigEdit && (currentUserProfile?.rol === "Administrador" || u.rol === "Cobrador") && !isSelf;
                    return (
                      <div key={`${u.id || u.uid || 'usr'}-${u.email || idx}-${idx}`} className="flex flex-col gap-2.5 p-4 rounded-xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100 dark:border-zinc-800/60 text-xs hover:border-emerald-500/20 transition-all">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-1 max-w-[280px]">
                            <p className="font-bold text-sm text-gray-900 dark:text-zinc-100">{u.nombre}</p>
                            <p className="text-[11px] text-gray-400 font-mono truncate">{u.email}</p>
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 mt-1">
                              <ShieldCheck size={12} /> {u.rol} {isSelf && <span className="text-[9px] text-gray-400">(Tú)</span>}
                            </span>
                          </div>
                          <div className="text-right flex flex-col items-end">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-bold ${
                              u.activo 
                                ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" 
                                : "bg-zinc-200 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                            }`}>
                              {u.activo ? "Activo" : "Inactivo"}
                            </span>
                          </div>
                        </div>
                        
                        {(canEditUser || canDeleteUser) && (
                          <div className="flex items-center justify-end gap-1.5 pt-2.5 border-t border-zinc-100/60 dark:border-zinc-800/40 mt-1">
                            {canEditUser && (
                              <button
                                type="button"
                                onClick={() => handleOpenEditUser(u)}
                                className="px-2.5 py-1.5 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-gray-700 dark:text-zinc-300 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                                title="Editar operador"
                                id={`btn-edit-${u.id}`}
                              >
                                <Edit2 size={10} /> Editar
                              </button>
                            )}
                            {canDeleteUser && (
                              <button
                                type="button"
                                onClick={() => handleDeleteUser(u)}
                                className="px-2.5 py-1.5 bg-rose-50 dark:bg-rose-950/20 hover:bg-rose-100 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                                title="Eliminar operador"
                                id={`btn-delete-${u.id}`}
                              >
                                <Trash2 size={10} /> Eliminar
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>

          {/* Right Column: Other settings & logs (Medidas de seguridad, Copia de seguridad, Audit Logs) */}
          <div className="lg:col-span-5 space-y-6" id="operators-sidebar-section">
          
          {/* Card: Medidas de Seguridad Implementadas */}
          <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 shadow-sm space-y-3" id="medidas-seguridad-operadores">
            <button
              type="button"
              onClick={() => setIsSecurityMeasuresExpanded(!isSecurityMeasuresExpanded)}
              className="w-full flex items-center justify-between text-xs font-bold text-gray-450 dark:text-zinc-400 uppercase tracking-wider hover:text-emerald-500 transition-all text-left cursor-pointer active:scale-[0.99]"
            >
              <span className="flex items-center gap-1.5">
                <ShieldCheck size={16} className="text-emerald-500" /> Medidas de Seguridad de Operadores
              </span>
              <div className="flex items-center gap-1 text-[10px] text-gray-400 dark:text-zinc-500 font-normal normal-case">
                <span>{isSecurityMeasuresExpanded ? "Ocultar" : "Ver"}</span>
                {isSecurityMeasuresExpanded ? (
                  <ChevronUp size={14} />
                ) : (
                  <ChevronDown size={14} />
                )}
              </div>
            </button>
            
            {isSecurityMeasuresExpanded && (
              <div className="space-y-3 pt-1 animate-fade-in">
                {/* Medida 1: Control Estricto de Roles */}
                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100/60 dark:border-zinc-800/60 text-[11px]">
                  <span className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <div className="space-y-0.5">
                    <p className="font-bold text-gray-800 dark:text-zinc-200">1. Privilegio Mínimo (Roles)</p>
                    <p className="text-[10px] text-gray-400 leading-normal">
                      Tu rol activo es <strong className="text-emerald-600 dark:text-emerald-400">{currentUserProfile?.rol || "Invitado"}</strong>. Los permisos se restringen dinámicamente según la matriz de privilegios y accesos del sistema.
                    </p>
                  </div>
                </div>

                {/* Medida 2: Registro de Auditoria */}
                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100/60 dark:border-zinc-800/60 text-[11px]">
                  <span className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <div className="space-y-0.5">
                    <p className="font-bold text-gray-800 dark:text-zinc-200">2. Registro de Auditoría (Audit Trail)</p>
                    <p className="text-[10px] text-gray-400 leading-normal">
                      Las acciones críticas (creaciones, ediciones, cobros, anulaciones y cambios de ajustes) se guardan en el historial de auditoría de forma inmutable.
                    </p>
                  </div>
                </div>

                {/* Medida 3: Desactivación preventiva */}
                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100/60 dark:border-zinc-800/60 text-[11px]">
                  <span className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <div className="space-y-0.5">
                    <p className="font-bold text-gray-800 dark:text-zinc-200">3. Desactivación de Operadores</p>
                    <p className="text-[10px] text-gray-400 leading-normal">
                      Se impide la eliminación física de operadores. Al darlos de baja, se desactivan para mantener la integridad histórica de la auditoría.
                    </p>
                  </div>
                </div>

                {/* Medida 4: Restricciones de Autogestión */}
                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100/60 dark:border-zinc-800/60 text-[11px]">
                  <span className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <div className="space-y-0.5">
                    <p className="font-bold text-gray-800 dark:text-zinc-200">4. Restricciones de Autogestión</p>
                    <p className="text-[10px] text-gray-400 leading-normal">
                      Los operadores no pueden editar sus propios privilegios. El sistema bloquea la desactivación o democión del único Administrador activo.
                    </p>
                  </div>
                </div>

                {/* Medida 5: Cierre de Sesión Inteligente */}
                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100/60 dark:border-zinc-800/60 text-[11px]">
                  <span className="mt-1 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <div className="space-y-0.5">
                    <p className="font-bold text-gray-800 dark:text-zinc-200">5. Control de Inactividad Inteligente</p>
                    <p className="text-[10px] text-gray-400 leading-normal">
                      Cierre automático de sesión activo tras <strong className="text-emerald-600 dark:text-emerald-400">{configuracion.timeoutInactividad ?? 30} minutos</strong> de inactividad, con advertencia interactiva.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Card: Copia de Seguridad y Restauración */}
          <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 shadow-sm space-y-4" id="copia-seguridad-seccion">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Download size={16} className="text-emerald-500" /> Copia de Seguridad y Restauración
            </h3>

            <p className="text-[11px] text-gray-500 dark:text-gray-400 leading-relaxed">
              Exporta una copia completa de toda la base de datos (clientes, préstamos, cobros, garantías, finanzas, ajustes y usuarios) a un archivo local de forma segura, o restáurala en cualquier momento.
            </p>

            <div className="flex flex-col gap-2.5 pt-2">
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-900 dark:hover:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs font-bold text-gray-700 dark:text-zinc-300 transition-colors cursor-pointer"
              >
                <Download size={14} className="text-emerald-500" />
                Descargar Copia de Seguridad
              </button>

              {checkPermission(currentUserProfile, "configuracion", "editar") && (
                <>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100/60 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 rounded-xl text-xs font-bold text-emerald-600 dark:text-emerald-400 transition-colors cursor-pointer"
                  >
                    <Upload size={14} />
                    Restaurar Copia de Seguridad
                  </button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept=".json"
                    onChange={handleRestoreBackup}
                    className="hidden"
                  />
                </>
              )}
            </div>
          </div>

          {/* Zona de Peligro (Solo para Administrador) */}
          {currentUserProfile?.rol === "Administrador" && onWipeDatabase && (
            <div className="bg-white dark:bg-[#121214] border border-red-200 dark:border-red-950/40 rounded-2xl p-5 shadow-sm space-y-4" id="zona-peligro-seccion">
              <h3 className="text-xs font-bold text-red-500 uppercase tracking-wider flex items-center gap-1.5">
                <Trash2 size={16} /> Zona de Peligro (Iniciar de Nuevo)
              </h3>

              <p className="text-[11px] text-gray-500 dark:text-gray-400 leading-relaxed">
                ¿Deseas iniciar el programa limpio desde cero? Esta opción eliminará de forma permanente todos los clientes, préstamos, cobros, garantías, egresos y movimientos de banco. El operador administrador con el que iniciaste sesión se mantendrá activo. <strong>Esta acción no se puede deshacer.</strong>
              </p>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={async () => {
                    const confirm1 = window.confirm(
                      "¿Estás seguro de que deseas restablecer la aplicación por completo? Se eliminarán permanentemente todos tus clientes, préstamos, cobros, garantías y datos financieros."
                    );
                    if (!confirm1) return;

                    const confirm2 = window.prompt(
                      'Para confirmar que realmente deseas borrar todo, escribe "BORRAR TODO" en el siguiente campo:'
                    );
                    if (confirm2 !== "BORRAR TODO") {
                      alert("Confirmación incorrecta. No se realizaron cambios.");
                      return;
                    }

                    try {
                      setIsWiping(true);
                      await onWipeDatabase();
                      alert("¡Base de datos restablecida con éxito! La aplicación ahora está completamente limpia y lista para su uso.");
                    } catch (err: any) {
                      alert("Error al limpiar la base de datos: " + err.message);
                    } finally {
                      setIsWiping(false);
                    }
                  }}
                  disabled={isWiping}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl text-xs font-bold text-red-600 dark:text-red-400 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Trash2 size={14} />
                  {isWiping ? "Restableciendo..." : "Borrar Todo y Comenzar de Cero"}
                </button>
              </div>
            </div>
          )}



          {/* Audit Logs Timeline Section */}
          <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 shadow-sm space-y-4" id="audit-logs-sidebar">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="text-emerald-500" size={15} /> Control de Auditoría
              </h3>
              <button
                type="button"
                onClick={() => setShowFullAuditModal(true)}
                className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5 cursor-pointer"
              >
                <Eye size={12} /> Ver Bitácora Completa
              </button>
            </div>
            
            <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
              {auditorias.length === 0 ? (
                <div className="text-center py-6 text-xs text-gray-400">
                  No hay registros de auditoría aún.
                </div>
              ) : (
                auditorias.slice(0, 5).map((log) => {
                  const isCritical = [
                    "Anulación de Pago",
                    "Eliminación de Préstamo",
                    "Eliminación de Operador",
                    "Reapertura de Caja"
                  ].includes(log.accion);

                  return (
                    <div key={log.id} className={`p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-900 border text-[11px] leading-relaxed space-y-1 hover:border-emerald-500/30 transition-colors cursor-pointer relative overflow-hidden
                      ${isCritical ? "border-rose-100 dark:border-rose-950/40" : "border-zinc-100 dark:border-zinc-800"}
                    `}
                    onClick={() => {
                      setSelectedAuditLog(log);
                      setShowFullAuditModal(true);
                    }}
                    >
                      {isCritical && <span className="absolute left-0 top-0 bottom-0 w-[2px] bg-rose-500" />}
                      <div className="flex items-center justify-between font-bold text-gray-800 dark:text-zinc-200">
                        <span className={`truncate max-w-[130px] ${isCritical ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                          {log.accion}
                        </span>
                        <span className="text-[9px] text-gray-400 font-mono font-normal">
                          {new Date(log.fecha).toLocaleDateString([], { month: 'short', day: 'numeric' })} {new Date(log.fecha).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-gray-500 dark:text-gray-400 text-[10px] truncate">
                        <strong>Operador:</strong> {log.usuarioRealizo.replace(/ \(.+\)/, "")}
                      </p>
                      <p className="text-gray-400 dark:text-zinc-500 text-[10px] truncate">
                        <strong>Sujeto:</strong> {log.usuarioAfectado}
                      </p>
                    </div>
                  );
                })
              )}
            </div>

            {auditorias.length > 0 && (
              <button
                type="button"
                onClick={() => setShowFullAuditModal(true)}
                className="w-full py-2 bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-900 dark:hover:bg-zinc-850/80 border border-zinc-200 dark:border-zinc-800 text-xs font-bold text-gray-700 dark:text-zinc-350 rounded-xl text-center transition-colors cursor-pointer"
              >
                Abrir Visor de Integridad ({auditorias.length} eventos)
              </button>
            )}
          </div>

        </div>

      </div>
      )}

      {/* Dynamic User & Permissions Administration Modal */}
      {showUserModal && createPortal(
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 z-50 animate-fade-in" id="operator-modal">
          <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl sm:rounded-3xl w-full max-w-2xl max-h-[95vh] sm:max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-gray-100 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-900">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500 text-white rounded-xl">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                    {editingUser ? "Editar Operador de Sistema" : "Agregar Operador de Sistema"}
                  </h3>
                  <p className="text-[11px] text-gray-400">Asigna un perfil comercial y controla sus accesos específicos.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowUserModal(false)}
                className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-200 transition-colors"
                title="Cerrar modal"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Tabs Header */}
            <div className="flex border-b border-gray-100 dark:border-zinc-800 px-5 bg-zinc-50 dark:bg-zinc-900">
              <button
                type="button"
                onClick={() => setModalTab("datos")}
                className={`py-3 px-4 font-bold text-xs border-b-2 transition-all ${
                  modalTab === "datos"
                    ? "border-emerald-500 text-emerald-600 dark:text-emerald-400"
                    : "border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-zinc-300"
                }`}
                id="tab-user-datos"
              >
                Datos de Operador
              </button>
              {currentUserProfile?.rol !== "Supervisor" && (
                <button
                  type="button"
                  onClick={() => setModalTab("permisos")}
                  className={`py-3 px-4 font-bold text-xs border-b-2 transition-all ${
                    modalTab === "permisos"
                      ? "border-emerald-500 text-emerald-600 dark:text-emerald-400"
                      : "border-transparent text-gray-400 hover:text-gray-600 dark:hover:text-zinc-300"
                  }`}
                  id="tab-user-permisos"
                >
                  Pestaña Permisos
                </button>
              )}
            </div>

            {/* Modal Content - Scrollable Form */}
            <form onSubmit={handleSaveUserForm} className="flex-1 overflow-y-auto p-6 space-y-5">
              
              {modalTab === "datos" ? (
                <div className="space-y-4 animate-fade-in" id="tab-content-datos">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Nombre Completo *</label>
                      <input
                        type="text"
                        required
                        placeholder="Ej: Pedro Martínez"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold"
                        id="user-input-nombre"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Correo Electrónico *</label>
                      <input
                        type="email"
                        required
                        placeholder="Ej: pedro@easypres.com"
                        value={userEmailInput}
                        onChange={(e) => setUserEmailInput(e.target.value)}
                        className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-mono text-xs"
                        id="user-input-email"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Rol Comercial *</label>
                      <select
                        value={userRole}
                        disabled={isEditingSelf || currentUserProfile?.rol !== "Administrador"}
                        onChange={(e) => handleRoleChange(e.target.value as any)}
                        className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-bold text-gray-800 dark:text-zinc-200 disabled:opacity-60 disabled:cursor-not-allowed"
                        id="user-select-rol"
                      >
                        <option value="Administrador">Administrador</option>
                        <option value="Supervisor">Supervisor</option>
                        <option value="Cobrador">Cobrador</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Estado Operador *</label>
                      <select
                        value={userActive ? "activo" : "inactivo"}
                        disabled={isEditingSelf || currentUserProfile?.rol !== "Administrador"}
                        onChange={(e) => setUserActive(e.target.value === "activo")}
                        className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-gray-800 dark:text-zinc-200 disabled:opacity-60 disabled:cursor-not-allowed"
                        id="user-select-estado"
                      >
                        <option value="activo">Activo</option>
                        <option value="inactivo">Inactivo</option>
                      </select>
                    </div>
                  </div>

                  {/* Info helper depending on the role */}
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 text-xs text-emerald-800 dark:text-emerald-400 leading-relaxed">
                    <p className="font-bold mb-1 flex items-center gap-1">
                      <Shield size={14} /> Resumen de Roles y Configuración
                    </p>
                    {userRole === "Administrador" && (
                      <p>El **Administrador** tiene acceso ilimitado a todos los módulos y acciones, incluyendo la capacidad de registrar, editar y desactivar operadores, cambiar parámetros corporativos y auditar toda la cartera. Sus permisos no pueden ser restringidos.</p>
                    )}
                    {userRole === "Supervisor" && (
                      <p>El **Supervisor** tiene acceso de control general para supervisar operaciones, emitir préstamos y desembolsar capital. Tiene habilitadas todas las opciones excepto la eliminación física de registros e históricos financieros.</p>
                    )}
                    {userRole === "Cobrador" && (
                      <p>El **Cobrador** está configurado para la gestión de campo. Solo puede visualizar de forma segura su padrón de clientes asignados, ver préstamos activos y registrar abonos de cuotas con impresión del recibo de caja correspondiente.</p>
                    )}
                    <p className="mt-2 text-[10px] text-emerald-600/70 dark:text-emerald-400/60 font-mono">Nota: Puedes modificar los permisos de Supervisor o Cobrador en la pestaña superior de forma personalizada.</p>
                  </div>

                </div>
              ) : (
                <div className="space-y-4 animate-fade-in" id="tab-content-permisos">
                  
                  {userRole === "Administrador" && (
                    <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 text-xs text-emerald-800 dark:text-emerald-400 leading-relaxed mb-4">
                      <p className="font-bold mb-1 flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400">
                        <Shield size={16} className="text-emerald-500 animate-pulse" /> Acceso Maestro Habilitado
                      </p>
                      <p>Como Administrador, este operador posee privilegios elevados automáticos de lectura, escritura y borrado. Puede ver y modificar de manera opcional las casillas del patrón granular de accesos a continuación.</p>
                    </div>
                  )}

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-gray-800 dark:text-zinc-200">Tabla de Matriz de Accesos</h4>
                        <p className="text-[10px] text-gray-400">Activa o desactiva las operaciones que este operador puede ejecutar.</p>
                      </div>
                    </div>

                    <div className="overflow-x-auto rounded-xl border border-gray-100 dark:border-zinc-800">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-zinc-50 dark:bg-zinc-900 border-b border-gray-100 dark:border-zinc-800 text-gray-500 font-bold uppercase tracking-wider">
                            <th className="p-2.5">Módulo</th>
                            <th className="p-2.5 text-center">Ver</th>
                            <th className="p-2.5 text-center">Crear</th>
                            <th className="p-2.5 text-center">Editar</th>
                            <th className="p-2.5 text-center">Eliminar</th>
                            <th className="p-2.5 text-center">Exportar</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-zinc-800">
                          {APP_MODULOS.map((mod) => {
                            const ops = getOperacionesAplicables(mod.id);
                            const isVer = ops.includes("ver");
                            const isCrear = ops.includes("crear");
                            const isEditar = ops.includes("editar");
                            const isEliminar = ops.includes("eliminar");
                            const isExportar = ops.includes("exportar");

                            const hasVer = !!userPermisos[mod.id]?.ver;

                            return (
                              <tr key={mod.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-900/30">
                                <td className="p-2.5 font-bold text-gray-700 dark:text-zinc-300">
                                  {mod.label}
                                </td>
                                <td className="p-2.5 text-center">
                                  {isVer ? (
                                    <input
                                      type="checkbox"
                                      checked={hasVer}
                                      disabled={isEditingSelf || currentUserProfile?.rol !== "Administrador"}
                                      onChange={(e) => {
                                        const checked = e.target.checked;
                                        setUserPermisos((prev) => ({
                                          ...prev,
                                          [mod.id]: {
                                            ...prev[mod.id],
                                            ver: checked,
                                            ...(checked ? {} : { crear: false, editar: false, eliminar: false, exportar: false })
                                          }
                                        }));
                                      }}
                                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                    />
                                  ) : "-"}
                                </td>
                                <td className="p-2.5 text-center">
                                  {isCrear ? (
                                    <input
                                      type="checkbox"
                                      checked={!!userPermisos[mod.id]?.crear}
                                      disabled={isEditingSelf || currentUserProfile?.rol !== "Administrador" || !hasVer}
                                      onChange={(e) => {
                                        setUserPermisos((prev) => ({
                                          ...prev,
                                          [mod.id]: { ...prev[mod.id], crear: e.target.checked }
                                        }));
                                      }}
                                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                    />
                                  ) : "-"}
                                </td>
                                <td className="p-2.5 text-center">
                                  {isEditar ? (
                                    <input
                                      type="checkbox"
                                      checked={!!userPermisos[mod.id]?.editar}
                                      disabled={isEditingSelf || currentUserProfile?.rol !== "Administrador" || !hasVer}
                                      onChange={(e) => {
                                        setUserPermisos((prev) => ({
                                          ...prev,
                                          [mod.id]: { ...prev[mod.id], editar: e.target.checked }
                                        }));
                                      }}
                                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                    />
                                  ) : "-"}
                                </td>
                                <td className="p-2.5 text-center">
                                  {isEliminar ? (
                                    <input
                                      type="checkbox"
                                      checked={!!userPermisos[mod.id]?.eliminar}
                                      disabled={isEditingSelf || currentUserProfile?.rol !== "Administrador" || !hasVer}
                                      onChange={(e) => {
                                        setUserPermisos((prev) => ({
                                          ...prev,
                                          [mod.id]: { ...prev[mod.id], eliminar: e.target.checked }
                                        }));
                                      }}
                                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                    />
                                  ) : "-"}
                                </td>
                                <td className="p-2.5 text-center">
                                  {isExportar ? (
                                    <input
                                      type="checkbox"
                                      checked={!!userPermisos[mod.id]?.exportar}
                                      disabled={isEditingSelf || currentUserProfile?.rol !== "Administrador" || !hasVer}
                                      onChange={(e) => {
                                        setUserPermisos((prev) => ({
                                          ...prev,
                                          [mod.id]: { ...prev[mod.id], exportar: e.target.checked }
                                        }));
                                      }}
                                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                                    />
                                  ) : "-"}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

              {/* Modal Footer */}
              <div className="pt-4 border-t border-gray-100 dark:border-zinc-800 flex items-center justify-end gap-3 bg-zinc-50 dark:bg-zinc-900 -mx-6 -mb-6 p-4">
                <button
                  type="button"
                  onClick={() => setShowUserModal(false)}
                  className="px-4 py-2 border rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-gray-500 dark:text-zinc-400 font-bold text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1 shadow-sm transition-all"
                  id="btn-save-operator-form"
                >
                  <Check size={14} /> {editingUser ? "Actualizar Acceso" : "Crear Operador"}
                </button>
              </div>

            </form>

          </div>
        </div>,
        document.body
      )}

      {showFullAuditModal && createPortal(
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 z-50 animate-fade-in" id="full-audit-modal">
          <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl sm:rounded-3xl w-full max-w-5xl h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-gray-100 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-900">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500 text-white rounded-xl">
                  <Activity size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                    Bitácora Completa de Auditoría e Integridad
                  </h3>
                  <p className="text-[11px] text-gray-400">Historial inmutable de operaciones, control de caja chica y auditoría de operadores.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowFullAuditModal(false);
                  setSelectedAuditLog(null);
                }}
                className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-200 transition-colors"
                title="Cerrar modal"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Content Split Grid */}
            <div className="flex-1 flex overflow-hidden min-h-0 bg-slate-50/50 dark:bg-[#0c0c0e]">
              
              {/* Left filter and list panel */}
              <div className="flex-1 flex flex-col min-h-0 border-r border-gray-100 dark:border-zinc-800">
                
                {/* Search and Filters Bar */}
                <div className="p-4 bg-white dark:bg-[#121214] border-b border-gray-100 dark:border-zinc-800 space-y-3">
                  <div className="flex flex-col sm:flex-row gap-2.5">
                    
                    {/* Search input */}
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-2.5 text-gray-450 dark:text-zinc-500" size={14} />
                      <input
                        type="text"
                        placeholder="Buscar por acción, operador, ID..."
                        value={auditSearch}
                        onChange={(e) => setAuditSearch(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs text-gray-700 dark:text-zinc-200 placeholder-gray-450 dark:placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                      />
                      {auditSearch && (
                        <button
                          onClick={() => setAuditSearch("")}
                          className="absolute right-2.5 top-2 py-0.5 px-1 rounded hover:bg-zinc-200 text-xs text-gray-400"
                        >
                          ×
                        </button>
                      )}
                    </div>

                    {/* Operator filter */}
                    <div className="sm:w-48 relative">
                      <select
                        value={auditFilterOperator}
                        onChange={(e) => setAuditFilterOperator(e.target.value)}
                        className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs text-gray-700 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer appearance-none"
                      >
                        <option value="">Todos los Operadores</option>
                        {Array.from(new Set(auditorias.map(l => {
                          const match = l.usuarioRealizo.match(/\(([^)]+)\)/);
                          return match ? match[1] : l.usuarioRealizo;
                        }))).map(op => (
                          <option key={op} value={op}>{op}</option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-3 top-3 text-gray-450 dark:text-zinc-500 pointer-events-none" size={12} />
                    </div>

                    {/* Action filter */}
                    <div className="sm:w-48 relative">
                      <select
                        value={auditFilterAction}
                        onChange={(e) => setAuditFilterAction(e.target.value)}
                        className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs text-gray-700 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer appearance-none"
                      >
                        <option value="">Todas las Acciones</option>
                        {Array.from(new Set(auditorias.map(l => l.accion))).map(act => (
                          <option key={act} value={act}>{act}</option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-3 top-3 text-gray-450 dark:text-zinc-500 pointer-events-none" size={12} />
                    </div>

                  </div>

                  {/* Summary row */}
                  <div className="flex justify-between items-center text-[10px] text-gray-400">
                    <span>
                      Mostrando <strong>{auditorias.filter(log => {
                        const searchMatch = !auditSearch ? true : (
                          log.accion.toLowerCase().includes(auditSearch.toLowerCase()) ||
                          log.usuarioRealizo.toLowerCase().includes(auditSearch.toLowerCase()) ||
                          (log.usuarioAfectado && log.usuarioAfectado.toLowerCase().includes(auditSearch.toLowerCase())) ||
                          (log.detalles && log.detalles.toLowerCase().includes(auditSearch.toLowerCase())) ||
                          (log.motivo && log.motivo.toLowerCase().includes(auditSearch.toLowerCase()))
                        );
                        const operatorMatch = !auditFilterOperator ? true : log.usuarioRealizo.toLowerCase().includes(auditFilterOperator.toLowerCase());
                        const actionMatch = !auditFilterAction ? true : log.accion === auditFilterAction;
                        return searchMatch && operatorMatch && actionMatch;
                      }).length}</strong> de <strong>{auditorias.length}</strong> eventos registrados.
                    </span>
                    {(auditSearch || auditFilterOperator || auditFilterAction) && (
                      <button
                        onClick={() => {
                          setAuditSearch("");
                          setAuditFilterOperator("");
                          setAuditFilterAction("");
                        }}
                        className="text-emerald-500 hover:underline font-bold cursor-pointer"
                      >
                        Restablecer filtros
                      </button>
                    )}
                  </div>
                </div>

                {/* Audit Logs Table / Timeline List */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {auditorias.filter(log => {
                    const searchMatch = !auditSearch ? true : (
                      log.accion.toLowerCase().includes(auditSearch.toLowerCase()) ||
                      log.usuarioRealizo.toLowerCase().includes(auditSearch.toLowerCase()) ||
                      (log.usuarioAfectado && log.usuarioAfectado.toLowerCase().includes(auditSearch.toLowerCase())) ||
                      (log.detalles && log.detalles.toLowerCase().includes(auditSearch.toLowerCase())) ||
                      (log.motivo && log.motivo.toLowerCase().includes(auditSearch.toLowerCase()))
                    );
                    const operatorMatch = !auditFilterOperator ? true : log.usuarioRealizo.toLowerCase().includes(auditFilterOperator.toLowerCase());
                    const actionMatch = !auditFilterAction ? true : log.accion === auditFilterAction;
                    return searchMatch && operatorMatch && actionMatch;
                  }).length === 0 ? (
                    <div className="text-center py-16 space-y-2">
                      <Shield className="mx-auto text-gray-300 dark:text-zinc-700" size={32} />
                      <p className="text-xs text-gray-400 dark:text-zinc-500">No se encontraron eventos coincidentes con los filtros activos.</p>
                    </div>
                  ) : (
                    auditorias.filter(log => {
                      const searchMatch = !auditSearch ? true : (
                        log.accion.toLowerCase().includes(auditSearch.toLowerCase()) ||
                        log.usuarioRealizo.toLowerCase().includes(auditSearch.toLowerCase()) ||
                        (log.usuarioAfectado && log.usuarioAfectado.toLowerCase().includes(auditSearch.toLowerCase())) ||
                        (log.detalles && log.detalles.toLowerCase().includes(auditSearch.toLowerCase())) ||
                        (log.motivo && log.motivo.toLowerCase().includes(auditSearch.toLowerCase()))
                      );
                      const operatorMatch = !auditFilterOperator ? true : log.usuarioRealizo.toLowerCase().includes(auditFilterOperator.toLowerCase());
                      const actionMatch = !auditFilterAction ? true : log.accion === auditFilterAction;
                      return searchMatch && operatorMatch && actionMatch;
                    }).map((log) => {
                      const isCritical = [
                        "Anulación de Pago",
                        "Eliminación de Préstamo",
                        "Eliminación de Operador",
                        "Reapertura de Caja"
                      ].includes(log.accion);

                      const isApproval = [
                        "Aprobación de Cierre",
                        "Aprobación de Préstamo"
                      ].includes(log.accion);

                      const isCreation = [
                        "Creación de Préstamo",
                        "Creación de Operador",
                        "Creación de Cliente",
                        "Registro de Pago"
                      ].includes(log.accion);

                      let badgeColor = "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300";
                      if (isCritical) badgeColor = "bg-rose-50 text-rose-600 dark:bg-rose-950/30 dark:text-rose-400 border border-rose-100 dark:border-rose-900/30";
                      else if (isApproval) badgeColor = "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/30 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30";
                      else if (isCreation) badgeColor = "bg-sky-50 text-sky-600 dark:bg-sky-950/30 dark:text-sky-400 border border-sky-100 dark:border-sky-900/30";

                      const isSelected = selectedAuditLog?.id === log.id;

                      return (
                        <div
                          key={log.id}
                          onClick={() => setSelectedAuditLog(log)}
                          className={`p-3.5 rounded-2xl border text-[11px] leading-relaxed transition-all cursor-pointer flex items-start gap-3.5 relative overflow-hidden group
                            ${isSelected 
                              ? "bg-emerald-500/10 border-emerald-500 dark:border-emerald-500/50" 
                              : "bg-white dark:bg-[#121214] border-gray-100 dark:border-zinc-800 hover:border-gray-200 dark:hover:border-zinc-700"
                            }
                          `}
                        >
                          {/* Top indicator ribbon */}
                          {isCritical && <span className="absolute left-0 top-0 bottom-0 w-[3px] bg-rose-500" />}
                          {isApproval && <span className="absolute left-0 top-0 bottom-0 w-[3px] bg-emerald-500" />}

                          {/* Time & Badge */}
                          <div className="flex flex-col items-center text-center shrink-0 w-20">
                            <span className="text-[10px] text-gray-800 dark:text-zinc-200 font-extrabold">
                              {new Date(log.fecha).toLocaleDateString([], { month: "short", day: "numeric" })}
                            </span>
                            <span className="text-[9px] text-gray-400 font-mono">
                              {new Date(log.fecha).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                          </div>

                          {/* Content */}
                          <div className="flex-1 space-y-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold tracking-wide uppercase ${badgeColor}`}>
                                {log.accion}
                              </span>
                              <span className="text-gray-400 dark:text-zinc-500 text-[10px]">
                                en <strong>{log.usuarioAfectado}</strong>
                              </span>
                            </div>

                            <p className="text-gray-600 dark:text-zinc-300 font-normal leading-normal text-[10px] line-clamp-2">
                              {log.detalles || "Sin detalles adicionales."}
                            </p>

                            <div className="flex items-center gap-1.5 text-[9px] text-gray-400 pt-1">
                              <span className="font-extrabold text-gray-500 dark:text-zinc-400">Operador:</span>
                              <span className="truncate max-w-[180px]" title={log.usuarioRealizo}>{log.usuarioRealizo}</span>
                            </div>
                          </div>

                          <div className="shrink-0 pt-1 text-gray-300 group-hover:text-emerald-500 dark:text-zinc-700 transition-colors">
                            <Eye size={14} />
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Right Detail Inspection Side-drawer */}
              <div className="w-80 sm:w-96 bg-white dark:bg-[#121214] flex flex-col min-h-0 overflow-hidden shrink-0 border-l border-gray-100 dark:border-zinc-800">
                {selectedAuditLog ? (
                  <div className="flex-1 flex flex-col min-h-0 p-5 space-y-5 overflow-y-auto">
                    
                    <div className="space-y-1.5 border-b border-gray-100 dark:border-zinc-800 pb-4">
                      <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-widest flex items-center gap-1">
                        <Activity size={10} /> Análisis de Evento
                      </p>
                      <h4 className="text-sm font-extrabold text-gray-900 dark:text-white leading-tight">
                        {selectedAuditLog.accion}
                      </h4>
                      <div className="flex items-center gap-1 text-[10px] text-gray-400 font-mono">
                        <Clock size={10} /> {new Date(selectedAuditLog.fecha).toLocaleString()}
                      </div>
                    </div>

                    {/* Metadata Card */}
                    <div className="bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-100 dark:border-zinc-800/60 rounded-2xl p-4 space-y-3">
                      <h5 className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Actores de la operación</h5>
                      
                      <div className="flex items-start gap-2.5 text-[11px]">
                        <div className="p-1 bg-emerald-500/10 text-emerald-500 rounded-lg mt-0.5 shrink-0">
                          <User size={12} />
                        </div>
                        <div className="space-y-0.5">
                          <p className="font-bold text-gray-400 text-[10px]">Realizado por (Operador)</p>
                          <p className="text-gray-800 dark:text-zinc-200 font-medium leading-tight">{selectedAuditLog.usuarioRealizo}</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-2.5 text-[11px] border-t border-zinc-150/40 dark:border-zinc-800/40 pt-2.5">
                        <div className="p-1 bg-sky-500/10 text-sky-500 rounded-lg mt-0.5 shrink-0">
                          <ShieldCheck size={12} />
                        </div>
                        <div className="space-y-0.5">
                          <p className="font-bold text-gray-400 text-[10px]">Sujeto o Entidad Afectada</p>
                          <p className="text-gray-800 dark:text-zinc-200 font-semibold">{selectedAuditLog.usuarioAfectado}</p>
                        </div>
                      </div>
                    </div>

                    {/* Details and Description */}
                    <div className="space-y-1.5">
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Descripción del Suceso</p>
                      <div className="p-3 bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 text-xs rounded-xl font-medium text-gray-700 dark:text-zinc-350 leading-relaxed whitespace-pre-wrap font-mono text-[10px]">
                        {selectedAuditLog.detalles || "Sin detalles descriptivos."}
                      </div>
                    </div>

                    {/* Diffs: Before and After */}
                    {(selectedAuditLog.valorAnterior || selectedAuditLog.valorNuevo) && (
                      <div className="space-y-2.5 border-t border-gray-100 dark:border-zinc-800 pt-4">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Trazabilidad de Ajuste (Valores)</p>
                        
                        <div className="grid grid-cols-1 gap-2.5">
                          {selectedAuditLog.valorAnterior && (
                            <div className="border border-red-100 dark:border-red-950/40 rounded-xl overflow-hidden">
                              <div className="bg-red-50 dark:bg-red-950/20 px-3 py-1.5 border-b border-red-100 dark:border-red-950/40 text-[9px] font-bold text-red-600 dark:text-red-400 uppercase tracking-wider">
                                Valor Anterior (Previo)
                              </div>
                              <div className="p-3 bg-red-500/[0.01] dark:bg-red-500/[0.02] text-[10px] font-mono text-red-700 dark:text-red-450 leading-tight">
                                {selectedAuditLog.valorAnterior}
                              </div>
                            </div>
                          )}

                          {selectedAuditLog.valorNuevo && (
                            <div className="border border-emerald-100 dark:border-emerald-950/40 rounded-xl overflow-hidden">
                              <div className="bg-emerald-50 dark:bg-emerald-950/20 px-3 py-1.5 border-b border-emerald-100 dark:border-emerald-950/40 text-[9px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                                Valor Nuevo (Posterior)
                              </div>
                              <div className="p-3 bg-emerald-500/[0.01] dark:bg-emerald-500/[0.02] text-[10px] font-mono text-emerald-700 dark:text-emerald-450 leading-tight">
                                {selectedAuditLog.valorNuevo}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Motivo de la Acción */}
                    {selectedAuditLog.motivo && (
                      <div className="space-y-2 border-t border-gray-100 dark:border-zinc-800 pt-4">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Motivo Registrado</p>
                        <div className="p-3 bg-amber-500/5 border border-amber-500/10 dark:bg-amber-500/10 rounded-xl relative overflow-hidden">
                          <span className="absolute top-1.5 right-2 text-2xl text-amber-500/20 font-serif leading-none select-none">”</span>
                          <p className="text-xs text-amber-800 dark:text-amber-400 font-medium italic pr-4">
                            "{selectedAuditLog.motivo}"
                          </p>
                        </div>
                      </div>
                    )}

                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-2.5">
                    <Activity className="text-gray-300 dark:text-zinc-700 animate-pulse" size={32} />
                    <div>
                      <h5 className="text-xs font-bold text-gray-500 dark:text-zinc-400">Inspector de Integridad</h5>
                      <p className="text-[10px] text-gray-400 max-w-[200px]">Seleccione cualquier evento de auditoría para analizar los valores comparativos y metadatos de control.</p>
                    </div>
                  </div>
                )}
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-gray-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 flex items-center justify-end">
              <button
                type="button"
                onClick={() => {
                  setShowFullAuditModal(false);
                  setSelectedAuditLog(null);
                }}
                className="px-5 py-2 bg-zinc-800 hover:bg-zinc-900 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
              >
                Cerrar Visor
              </button>
            </div>

          </div>
        </div>,
        document.body
      )}

    </div>
  );
}
