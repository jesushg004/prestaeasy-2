import React, { useState, useEffect } from "react";
import { X, Send, MessageCircle, Copy, Check } from "lucide-react";
import { Cliente, Prestamo } from "../types";
import { formatCurrency, getWhatsAppUrl } from "../utils";

interface WhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  cliente: Cliente | null;
  prestamo?: Prestamo | null;
  moneda?: string;
  montoSugerido?: number; // E.g., next payment amount or loan quota
}

export default function WhatsAppModal({
  isOpen,
  onClose,
  cliente,
  prestamo,
  moneda = "$",
  montoSugerido,
}: WhatsAppModalProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<number>(0);
  const [customText, setCustomText] = useState<string>("");
  const [copied, setCopied] = useState<boolean>(false);

  // Auto-reset when modal opens/changes
  useEffect(() => {
    if (isOpen) {
      setSelectedTemplate(0);
      setCopied(false);
    }
  }, [isOpen, cliente]);

  if (!isOpen || !cliente) return null;

  // Derive values for templates
  const nombre = cliente.nombre || "Cliente";
  const cuotaMonto = montoSugerido 
    ? formatCurrency(montoSugerido, moneda) 
    : (prestamo ? formatCurrency(prestamo.montoCuota, moneda) : formatCurrency(0, moneda));
  const montoTotalPrestamo = prestamo ? formatCurrency(prestamo.montoTotal, moneda) : formatCurrency(0, moneda);
  const nroPrestamo = prestamo ? (prestamo.numero || "N/D") : "N/D";

  // List of templates with placeholders
  const templates = [
    {
      id: 0,
      title: "📅 Visita de Cobro",
      text: `Hola *${nombre}*, hoy pasaremos a registrar tu cuota de *${cuotaMonto}* de tu préstamo de EasyPres. ¡Que tengas un excelente día! ☀️`,
    },
    {
      id: 1,
      title: "🤝 Recordatorio de Pago",
      text: `Estimado(a) *${nombre}*, le recordamos de manera amigable que su cuota de *${cuotaMonto}* de su préstamo *#${nroPrestamo}* vence hoy. Agradecemos su puntualidad. 🙏`,
    },
    {
      id: 2,
      title: "⚠️ Notificación de Atraso",
      text: `Hola *${nombre}*, le informamos que tiene una cuota vencida de *${cuotaMonto}* en su cuenta de EasyPres. Por favor, regularice su situación para evitar recargos por mora adicionales. Saludos.`,
    },
    {
      id: 3,
      title: "🎉 Préstamo Aprobado",
      text: `¡Buenas noticias *${nombre}*! Tu solicitud de préstamo ha sido aprobada con éxito por un monto total de *${montoTotalPrestamo}*. Estaremos en contacto para coordinar la entrega. 🥳✨`,
    },
    {
      id: 4,
      title: "✍️ Mensaje Personalizado",
      text: `Hola *${nombre}*, le saludamos del equipo de EasyPres...`,
      isCustom: true,
    },
  ];

  const activeTemplate = templates[selectedTemplate];
  const finalMessage = activeTemplate.isCustom ? customText : activeTemplate.text;

  // Handle WhatsApp Click
  const handleSend = () => {
    const url = getWhatsAppUrl(cliente.telefono, finalMessage);
    window.open(url, "_blank");
    onClose();
  };

  // Handle Clipboard Copy
  const handleCopy = () => {
    navigator.clipboard.writeText(finalMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white dark:bg-[#121214] border border-zinc-150 dark:border-zinc-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-xl animate-scale-in">
        
        {/* Header */}
        <div className="p-5 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between bg-emerald-50/50 dark:bg-emerald-950/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <MessageCircle size={18} className="stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900 dark:text-zinc-100">
                Enviar WhatsApp a {nombre}
              </h3>
              <p className="text-[10px] text-gray-400 dark:text-zinc-500 font-medium">
                Acceso rápido Click-to-Chat sin registrar contacto
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-200 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg transition-all"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          
          {/* Tel info bar */}
          <div className="p-3 bg-zinc-50 dark:bg-zinc-900/60 rounded-2xl border border-zinc-100 dark:border-zinc-800/80 flex justify-between items-center text-xs">
            <span className="text-gray-500">Número destino:</span>
            <span className="font-mono font-bold text-gray-800 dark:text-zinc-200">{cliente.telefono}</span>
          </div>

          {/* Template Selector */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">
              Seleccionar Plantilla Dinámica
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {templates.map((tpl) => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => {
                    setSelectedTemplate(tpl.id);
                    if (tpl.isCustom && !customText) {
                      setCustomText(`Hola *${nombre}*, `);
                    }
                  }}
                  className={`p-3 text-left text-xs font-semibold rounded-2xl border transition-all active:scale-[0.98] ${
                    selectedTemplate === tpl.id
                      ? "border-emerald-500 bg-emerald-50/20 text-emerald-700 dark:text-emerald-400 dark:bg-emerald-950/20"
                      : "border-zinc-150 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-gray-600 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-900"
                  }`}
                >
                  {tpl.title}
                </button>
              ))}
            </div>
          </div>

          {/* Preview / Edit Area */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">
                {activeTemplate.isCustom ? "Escribir Mensaje" : "Vista Previa en Formato WhatsApp"}
              </label>
              
              {/* Copy button */}
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400"
                title="Copiar texto al portapapeles"
              >
                {copied ? (
                  <>
                    <Check size={12} /> ¡Copiado!
                  </>
                ) : (
                  <>
                    <Copy size={12} /> Copiar texto
                  </>
                )}
              </button>
            </div>

            {activeTemplate.isCustom ? (
              <textarea
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                rows={4}
                className="w-full p-3.5 border rounded-2xl bg-zinc-50 dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs text-gray-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                placeholder="Escribe tu mensaje aquí..."
              />
            ) : (
              <div className="p-3.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-xs text-gray-800 dark:text-zinc-200 whitespace-pre-wrap leading-relaxed font-mono">
                {activeTemplate.text}
              </div>
            )}
          </div>

          <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl text-[10px] text-emerald-700 dark:text-emerald-400 leading-relaxed">
            💡 <strong>Sugerencia:</strong> El texto con asteriscos (ej. *negrita*) se mostrará en negrita automáticamente en la aplicación móvil de WhatsApp.
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-5 border-t border-zinc-100 dark:border-zinc-800 flex justify-end gap-3 bg-zinc-50/50 dark:bg-zinc-950/20">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-gray-500 hover:text-gray-700 dark:text-zinc-400 dark:hover:text-zinc-200"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSend}
            disabled={activeTemplate.isCustom && !customText.trim()}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-all hover:scale-[1.02] shadow-sm active:scale-[0.98]"
          >
            <Send size={14} /> Abrir WhatsApp
          </button>
        </div>

      </div>
    </div>
  );
}
