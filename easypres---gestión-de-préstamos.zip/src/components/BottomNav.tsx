import React from "react";
import {
  LayoutDashboard,
  Users,
  Landmark,
  CreditCard,
  ShieldCheck,
  FileSpreadsheet,
  Wallet,
  Settings,
  MapPin,
  Menu
} from "lucide-react";
import { APP_MODULOS, Usuario, Configuracion } from "../types";

interface BottomNavProps {
  activeModule: string;
  setActiveModule: (module: string) => void;
  currentUserProfile?: Usuario | null;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  darkMode: boolean;
  configuracion?: Configuracion;
}

const moduleIcons: { [key: string]: React.ComponentType<any> } = {
  dashboard: LayoutDashboard,
  ruta_cobro: MapPin,
  clientes: Users,
  prestamos: Landmark,
  pagos: CreditCard,
  garantias: ShieldCheck,
  finanzas: Wallet,
  reportes: FileSpreadsheet,
  configuracion: Settings
};

const moduleLabels: { [key: string]: string } = {
  dashboard: "Inicio",
  ruta_cobro: "Ruta",
  clientes: "Clientes",
  prestamos: "Préstamos",
  pagos: "Pagos",
  garantias: "Garantías",
  finanzas: "Finanzas",
  reportes: "Reportes",
  configuracion: "Ajustes"
};

export default function BottomNav({
  activeModule,
  setActiveModule,
  currentUserProfile,
  mobileMenuOpen,
  setMobileMenuOpen,
  darkMode,
  configuracion
}: BottomNavProps) {
  // If bottom nav is explicitly disabled in the system settings, do not render it
  const isBottomNavEnabled = configuracion?.bottomNavHabilitado ?? true;
  if (!isBottomNavEnabled) {
    return null;
  }

  // Get active key modules chosen by user or fallback to standard quick-access modules
  const customModulesKeys = configuracion?.bottomNavModulosClaves || ["dashboard", "ruta_cobro", "clientes", "prestamos"];

  // Map and filter active chosen modules according to Operator Permissions
  const allowedItems = customModulesKeys
    .map((key) => {
      const mod = APP_MODULOS.find((m) => m.id === key);
      if (!mod) return null;
      return {
        id: mod.id,
        label: moduleLabels[mod.id] || mod.label,
        icon: moduleIcons[mod.id] || Settings
      };
    })
    .filter((item): item is NonNullable<typeof item> => {
      if (!item) return false;
      if (!currentUserProfile) return true;
      if (currentUserProfile.rol === "Administrador") return true;
      return currentUserProfile.permisos?.[item.id]?.ver === true;
    });

  // Take first 4 primary allowed items for display
  const primaryNavItems = allowedItems.slice(0, 4);

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-30 lg:hidden border-t backdrop-blur-md shadow-[0_-4px_24px_-4px_rgba(0,0,0,0.06)] transition-all duration-300 print:hidden
        ${darkMode 
          ? "bg-[#121214]/95 border-zinc-800/80 text-gray-400" 
          : "bg-white/95 border-gray-100 text-gray-500"
        }
        pb-[env(safe-area-inset-bottom,16px)] pt-2 px-4
      `}
      id="mobile-bottom-nav"
    >
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {primaryNavItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeModule === item.id && !mobileMenuOpen;

          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveModule(item.id);
                setMobileMenuOpen(false);
              }}
              className={`flex flex-col items-center justify-center flex-1 py-1.5 px-1 relative transition-all duration-200 active:scale-95 group cursor-pointer`}
              id={`bottom-nav-${item.id}`}
            >
              <div
                className={`p-1.5 rounded-xl transition-all duration-200 ${
                  isActive
                    ? "text-emerald-600 dark:text-emerald-400 font-bold"
                    : "text-gray-400 dark:text-zinc-500 group-hover:text-gray-600 dark:group-hover:text-zinc-300"
                }`}
              >
                <IconComponent size={20} className="transition-transform duration-200 group-active:scale-90" />
              </div>
              <span
                className={`text-[9.5px] font-bold tracking-tight transition-colors duration-200 ${
                  isActive
                    ? "text-emerald-600 dark:text-emerald-400 font-extrabold"
                    : "text-gray-400 dark:text-zinc-500 font-medium"
                }`}
              >
                {item.label}
              </span>

              {/* Active Indicator bar */}
              {isActive && (
                <span className="absolute bottom-0 w-1.5 h-1.5 bg-emerald-600 dark:bg-emerald-400 rounded-full" />
              )}
            </button>
          );
        })}

        {/* 5th Tab: "Menú" button to open drawer/sidebar */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 px-1 relative transition-all duration-200 active:scale-95 group cursor-pointer`}
          id="bottom-nav-more"
        >
          <div
            className={`p-1.5 rounded-xl transition-all duration-200 ${
              mobileMenuOpen
                ? "text-emerald-600 dark:text-emerald-400 bg-emerald-500/10"
                : "text-gray-400 dark:text-zinc-500 group-hover:text-gray-600 dark:group-hover:text-zinc-300"
            }`}
          >
            <Menu size={20} className="transition-transform duration-200 group-active:scale-90" />
          </div>
          <span
            className={`text-[9.5px] font-bold tracking-tight transition-colors duration-200 ${
              mobileMenuOpen
                ? "text-emerald-600 dark:text-emerald-400 font-extrabold"
                : "text-gray-400 dark:text-zinc-500 font-medium"
            }`}
          >
            Menú
          </span>

          {mobileMenuOpen && (
            <span className="absolute bottom-0 w-1.5 h-1.5 bg-emerald-600 dark:bg-emerald-400 rounded-full" />
          )}
        </button>
      </div>
    </div>
  );
}
