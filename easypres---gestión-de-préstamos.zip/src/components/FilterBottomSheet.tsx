import React, { useEffect } from "react";
import { X, RotateCcw, Check } from "lucide-react";

interface FilterBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  onClear?: () => void;
  onApply?: () => void;
  children: React.ReactNode;
}

export default function FilterBottomSheet({
  isOpen,
  onClose,
  title = "Filtros y Ordenamiento",
  onClear,
  onApply,
  children
}: FilterBottomSheetProps) {
  // Prevent body scroll when the bottom sheet is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" id="filter-bottom-sheet-root">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
        id="filter-bottom-sheet-backdrop"
      />

      {/* Bottom Sheet Drawer */}
      <div
        className="relative w-full max-w-md bg-white dark:bg-[#121214] rounded-t-[28px] sm:rounded-[24px] shadow-[0_-8px_32px_rgba(0,0,0,0.15)] sm:shadow-[0_12px_40px_rgba(0,0,0,0.25)] border-t sm:border border-gray-100 dark:border-zinc-800/80 max-h-[85vh] sm:max-h-[90vh] flex flex-col overflow-hidden animate-slide-up transition-transform duration-300"
        id="filter-bottom-sheet-container"
      >
        {/* Handle Bar */}
        <div className="flex justify-center py-3 cursor-pointer" onClick={onClose}>
          <div className="w-12 h-1.5 rounded-full bg-zinc-200 dark:bg-zinc-800" />
        </div>

        {/* Header */}
        <div className="px-6 pb-4 flex items-center justify-between border-b border-gray-100 dark:border-zinc-800/60">
          <h3 className="text-base font-extrabold text-zinc-900 dark:text-zinc-100 tracking-tight flex items-center gap-2">
            {title}
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-zinc-100 dark:bg-zinc-900 text-gray-500 hover:text-gray-800 dark:hover:text-zinc-200 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content (Scrollable) */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5" style={{ WebkitOverflowScrolling: "touch" }}>
          {children}
        </div>

        {/* Footer actions */}
        <div className="p-5 border-t border-gray-100 dark:border-zinc-800/60 bg-zinc-50/50 dark:bg-zinc-950/40 flex items-center gap-3">
          {onClear && (
            <button
              onClick={() => {
                onClear();
                if (!onApply) onClose(); // Auto close on clear if no explicit apply
              }}
              className="flex-1 py-3 px-4 rounded-xl border border-zinc-200 dark:border-zinc-800 font-bold text-xs text-gray-500 hover:text-gray-800 dark:hover:text-zinc-200 hover:bg-zinc-100/50 dark:hover:bg-zinc-900/40 transition-all flex items-center justify-center gap-2 active:scale-95"
            >
              <RotateCcw size={14} />
              Limpiar
            </button>
          )}
          <button
            onClick={() => {
              if (onApply) onApply();
              onClose();
            }}
            className="flex-2 py-3 px-4 rounded-xl bg-emerald-600 dark:bg-emerald-500 hover:bg-emerald-700 dark:hover:bg-emerald-600 font-extrabold text-xs text-white shadow-md shadow-emerald-600/10 transition-all flex items-center justify-center gap-2 active:scale-95"
          >
            <Check size={14} />
            Aplicar Filtros
          </button>
        </div>
      </div>
    </div>
  );
}
