import React, { useMemo } from "react";
import { 
  AlertCircle, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Coins, 
  Clock, 
  ChevronRight,
  Sparkles
} from "lucide-react";
import { Prestamo, CuadreCaja, CuotaDetalle, Deposito } from "../types";
import { formatCurrency } from "../utils";
import { todayStr } from "../utils/dashboardHelpers";

interface DashboardAlertsProps {
  prestamos: Prestamo[];
  cuadres?: CuadreCaja[];
  depositos?: Deposito[];
  moneda: string;
  setActiveModule: (module: string) => void;
  cuotasVencenHoyCount: number;
  cuotasVencenHoyMonto: number;
  readyToSettleCount: number;
}

export default function DashboardAlerts({
  prestamos,
  cuadres = [],
  depositos = [],
  moneda,
  setActiveModule,
  cuotasVencenHoyCount,
  cuotasVencenHoyMonto,
  readyToSettleCount
}: DashboardAlertsProps) {

  const alertsList = useMemo(() => {
    const list: { id: string; color: "red" | "orange" | "yellow" | "blue" | "green" | "purple"; mensaje: string; modulo: string; actionText: string; title: string }[] = [];

    // 1. 🔴 Clientes vencidos hoy (Cuotas que vencen hoy)
    if (cuotasVencenHoyCount > 0) {
      list.push({
        id: "alert-cuotas-hoy",
        color: "red",
        title: "Clientes vencidos hoy",
        mensaje: `Hoy vencen ${cuotasVencenHoyCount} cuota(s) por cobrar con saldo de ${formatCurrency(cuotasVencenHoyMonto, moneda)}.`,
        modulo: "ruta_cobro",
        actionText: "Ver Ruta 🧭"
      });
    }

    // 2. 🟠 Clientes con mora superior a 30 días
    let countMora30 = 0;
    prestamos.forEach(p => {
      if ((p.estado === "Activo" || p.estado === "Atrasado") && p.cuotasDetalle) {
        try {
          const cuotas: CuotaDetalle[] = JSON.parse(p.cuotasDetalle);
          if (Array.isArray(cuotas)) {
            const hasOverdue30 = cuotas.some(c => {
              if (c.estado !== "Pagado") {
                const diffTime = new Date(todayStr).getTime() - new Date(c.fechaVence).getTime();
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                return diffDays > 30;
              }
              return false;
            });
            if (hasOverdue30) countMora30++;
          }
        } catch (e) {}
      }
    });

    if (countMora30 > 0) {
      list.push({
        id: "alert-mora-30",
        color: "orange",
        title: "Mora superior a 30 días",
        mensaje: `Hay ${countMora30} préstamo(s) en mora crítica superior a 30 días. Requiere gestión urgente.`,
        modulo: "prestamos",
        actionText: "Gestionar Mora ⚠️"
      });
    }

    // 3. 🟡 Depósitos pendientes de conciliación o verificación
    // (We look for any deposits where payment ids are empty/none linked, or default if some exist)
    const pendingDepositsCount = (depositos && depositos.length > 0) 
      ? depositos.filter(d => !d.pagoIds || d.pagoIds.length === 0).length 
      : 0;
    if (pendingDepositsCount > 0) {
      list.push({
        id: "alert-depositos-pendientes",
        color: "yellow",
        title: "Depósitos pendientes",
        mensaje: `Se detectaron ${pendingDepositsCount} depósito(s) bancario(s) recibidos sin vincular a cobros.`,
        modulo: "finanzas",
        actionText: "Vincular Depósitos 🏦"
      });
    } else {
      // Dynamic fallback to keep it interactive
      list.push({
        id: "alert-depositos-pendientes-ok",
        color: "yellow",
        title: "Depósitos al día",
        mensaje: `Todos los depósitos bancarios se encuentran debidamente conciliados.`,
        modulo: "finanzas",
        actionText: "Ver Historial 🧾"
      });
    }

    // 4. 🔵 Arqueos con diferencias (discrepancias)
    const differenceBoxes = cuadres.filter(c => Math.abs(c.descuadre || 0) > 0);
    if (differenceBoxes.length > 0) {
      list.push({
        id: "alert-arqueos-diferencias",
        color: "blue",
        title: "Arqueos con diferencias",
        mensaje: `¡Alerta! Hay ${differenceBoxes.length} cuadre(s) de caja cerrado(s) con descuadre de efectivo.`,
        modulo: "finanzas",
        actionText: "Auditar Cajas 🔍"
      });
    }

    // 5. 🟢 Cajas sin cerrar (Abiertas)
    const openBoxes = cuadres.filter(c => c.estado === "Abierta" || c.estado === "Reabierta" || c.estado === "Pendiente de cierre");
    if (openBoxes.length > 0) {
      list.push({
        id: "alert-cajas-abiertas",
        color: "green",
        title: "Cajas sin cerrar",
        mensaje: `Hay ${openBoxes.length} caja(s) de cobro activas que aún no han sido cuadradas por los cobradores.`,
        modulo: "finanzas",
        actionText: "Ver Cajas 🔑"
      });
    }

    // 6. 🟣 Préstamos próximos a liquidarse (menos del 10% de balance restante)
    if (readyToSettleCount > 0) {
      list.push({
        id: "alert-liquidar-prestamos",
        color: "purple",
        title: "Préstamos por liquidar",
        mensaje: `Hay ${readyToSettleCount} préstamo(s) cerca del saldo completo (menos del 10% pendiente).`,
        modulo: "prestamos",
        actionText: "Ver Préstamos 🎓"
      });
    }

    return list;
  }, [prestamos, cuadres, depositos, moneda, cuotasVencenHoyCount, cuotasVencenHoyMonto, readyToSettleCount]);

  if (alertsList.length === 0) return null;

  return (
    <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-3xl p-5 shadow-xs">
      <div className="flex items-center gap-1.5 mb-4 border-b border-zinc-100 dark:border-zinc-800/40 pb-3">
        <span className="p-1.5 bg-indigo-500/10 text-indigo-500 rounded-xl shrink-0">
          <AlertCircle size={16} />
        </span>
        <div>
          <h3 className="text-xs font-black text-gray-900 dark:text-white uppercase tracking-widest flex items-center gap-1">
            Centro de Control & Alertas de Operación (BI)
          </h3>
          <p className="text-[10px] text-zinc-400">
            Monitoreo en tiempo real de cartera vencida, arqueos descuadrados, depósitos bancarios y cierres operativos.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {alertsList.map(al => {
          // Color styles mapping
          let colorBadge = "🔴";
          let bgClass = "bg-rose-50/40 dark:bg-rose-950/10 border-rose-100/50 dark:border-rose-900/10 text-rose-700 dark:text-rose-450";
          let bulletBg = "bg-rose-500";
          let icon = <ShieldAlert size={14} className="text-rose-500" />;

          if (al.color === "orange") {
            colorBadge = "🟠";
            bgClass = "bg-orange-50/40 dark:bg-orange-950/10 border-orange-100/50 dark:border-orange-900/10 text-orange-700 dark:text-orange-450";
            bulletBg = "bg-orange-500";
            icon = <AlertTriangle size={14} className="text-orange-500" />;
          } else if (al.color === "yellow") {
            colorBadge = "🟡";
            bgClass = "bg-yellow-50/30 dark:bg-yellow-950/5 border-yellow-100/30 dark:border-yellow-900/10 text-yellow-700 dark:text-yellow-450";
            bulletBg = "bg-amber-500";
            icon = <Clock size={14} className="text-amber-500" />;
          } else if (al.color === "blue") {
            colorBadge = "🔵";
            bgClass = "bg-sky-50/40 dark:bg-sky-950/10 border-sky-100/50 dark:border-sky-900/10 text-sky-700 dark:text-sky-400";
            bulletBg = "bg-sky-500";
            icon = <Coins size={14} className="text-sky-500" />;
          } else if (al.color === "green") {
            colorBadge = "🟢";
            bgClass = "bg-emerald-50/40 dark:bg-emerald-950/10 border-emerald-100/50 dark:border-emerald-900/10 text-emerald-700 dark:text-emerald-400";
            bulletBg = "bg-emerald-500";
            icon = <CheckCircle2 size={14} className="text-emerald-500" />;
          } else if (al.color === "purple") {
            colorBadge = "🟣";
            bgClass = "bg-purple-50/40 dark:bg-purple-950/10 border-purple-100/50 dark:border-purple-900/10 text-purple-700 dark:text-purple-400";
            bulletBg = "bg-purple-500";
            icon = <Sparkles size={14} className="text-purple-500" />;
          }

          return (
            <div
              key={al.id}
              onClick={() => setActiveModule(al.modulo)}
              className={`p-3 rounded-xl border text-[11px] font-bold cursor-pointer transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between gap-2 shadow-2xs group hover:shadow-xs active:scale-98
                ${bgClass}
              `}
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 border-b border-current/10 pb-1">
                  <span className="text-[10px]">{colorBadge}</span>
                  <span className="text-[10px] font-extrabold uppercase tracking-wide truncate">
                    {al.title}
                  </span>
                </div>
                <p className="leading-relaxed text-zinc-700 dark:text-zinc-200 text-[10px] font-medium line-clamp-3">
                  {al.mensaje}
                </p>
              </div>
              
              <div className="flex items-center justify-between border-t border-current/10 pt-1.5 mt-1">
                <span className="text-[9px] uppercase tracking-wider font-extrabold opacity-85 group-hover:opacity-100 flex items-center gap-0.5">
                  {al.actionText} <ChevronRight size={10} className="transition-transform group-hover:translate-x-0.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
