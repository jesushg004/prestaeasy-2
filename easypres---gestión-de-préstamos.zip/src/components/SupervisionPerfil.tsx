import React, { useState, useMemo } from "react";
import {
  User,
  Shield,
  ShieldCheck,
  DollarSign,
  CheckCircle,
  TrendingUp,
  Search,
  FileText,
  Calendar,
  ArrowUpRight,
  Check,
  Activity,
  MapPin,
  Clock,
  Sparkles,
  RefreshCw,
  SlidersHorizontal,
  FileBarChart,
  UserCheck
} from "lucide-react";
import { Usuario, Cliente, Prestamo, Pago, CuadreCaja, AuditoriaLog, AsignacionTemporal, HistorialAsignacion, Configuracion as ConfiguracionType } from "../types";

interface SupervisionPerfilProps {
  usuarios: Usuario[];
  clientes: Cliente[];
  prestamos: Prestamo[];
  pagos: Pago[];
  cuadres: CuadreCaja[];
  auditorias?: AuditoriaLog[];
  moneda: string;
  asignacionesTemporales?: AsignacionTemporal[];
  historialAsignaciones?: HistorialAsignacion[];
  onReassignClient?: (clienteId: string, cobradorId: string, motivo: string, tipo: "Inicial" | "Permanente" | "Temporal") => Promise<void>;
  onSaveAsignacionTemporal?: (asig: AsignacionTemporal) => Promise<void>;
  onTransferirCartera?: (sourceEmail: string, destEmail: string, options: { clients: boolean; loans: boolean; route: boolean; history: boolean }, motivo: string) => Promise<void>;
  configuracion?: ConfiguracionType;
  onSaveUsuario?: (user: Usuario) => Promise<void>;
}

export default function SupervisionPerfil({
  usuarios,
  clientes = [],
  prestamos = [],
  pagos = [],
  cuadres = [],
  auditorias = [],
  moneda,
  asignacionesTemporales = [],
  historialAsignaciones = [],
  onReassignClient,
  onSaveAsignacionTemporal,
  onTransferirCartera,
  configuracion,
  onSaveUsuario
}: SupervisionPerfilProps) {
  // Select which user profile to supervise. Default to first Cobrador or first non-admin user
  const cobradores = useMemo(() => {
    return usuarios.filter(u => u.rol === "Cobrador");
  }, [usuarios]);

  const activeUsers = useMemo(() => {
    return usuarios.filter(u => u.activo);
  }, [usuarios]);

  const [selectedUserEmail, setSelectedUserEmail] = useState<string>(() => {
    // Default to the first cobrador if exists, otherwise first active user, otherwise empty string
    if (cobradores.length > 0) return cobradores[0].email;
    if (activeUsers.length > 0) return activeUsers[0].email;
    return usuarios[0]?.email || "";
  });

  // Find the currently selected user profile
  const selectedUser = useMemo(() => {
    return usuarios.find(u => u.email.toLowerCase() === selectedUserEmail.toLowerCase()) || null;
  }, [usuarios, selectedUserEmail]);

  // Tab state inside the supervisor profile detail
  const [profileTab, setProfileTab] = useState<"clientes" | "prestamos" | "abonos" | "cuadres" | "auditoria" | "asignaciones">("clientes");

  // Portfolio Transfer Modal States
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [transferTargetEmail, setTransferTargetEmail] = useState("");
  const [transferOptions, setTransferOptions] = useState({
    clients: true,
    loans: true,
    route: true,
    history: true
  });
  const [transferMotivo, setTransferMotivo] = useState("");
  const [isSubmittingTransfer, setIsSubmittingTransfer] = useState(false);

  // Temporary Assignment Modal States
  const [showTempModal, setShowTempModal] = useState(false);
  const [tempTargetEmail, setTempTargetEmail] = useState("");
  const [tempDateInicio, setTempDateInicio] = useState("");
  const [tempDateFin, setTempDateFin] = useState("");
  const [tempMotivo, setTempMotivo] = useState("");
  const [isSubmittingTemp, setIsSubmittingTemp] = useState(false);

  // Deactivation Modal States
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);

  // Search input for list filtering
  const [searchTerm, setSearchTerm] = useState("");

  // Filters for sub-lists
  const [statusFilter, setStatusFilter] = useState("todos");

  // Get filtered dataset for the selected user
  const emailLower = selectedUser?.email?.toLowerCase() || "";

  // 1. Clients assigned to selected operator
  const assignedClientes = useMemo(() => {
    if (!selectedUser) return [];
    return clientes.filter(c => c.cobradorId?.toLowerCase() === emailLower);
  }, [clientes, selectedUser, emailLower]);

  // 2. Loans assigned to selected operator (or managed through their clients)
  const assignedPrestamos = useMemo(() => {
    if (!selectedUser) return [];
    return prestamos.filter(
      p => p.cobradorId?.toLowerCase() === emailLower || assignedClientes.some(c => c.id === p.clienteId)
    );
  }, [prestamos, selectedUser, emailLower, assignedClientes]);

  // 3. Payments registered by this operator (or collected on their assigned loans/clients)
  const userPagos = useMemo(() => {
    if (!selectedUser) return [];
    return pagos.filter(
      p => p.cobradorId?.toLowerCase() === emailLower || assignedPrestamos.some(pr => pr.id === p.prestamoId)
    );
  }, [pagos, selectedUser, emailLower, assignedPrestamos]);

  // 4. Cash reconciliations for this operator
  const userCuadres = useMemo(() => {
    if (!selectedUser) return [];
    return cuadres.filter(
      c => c.cobradorId?.toLowerCase() === emailLower || c.registradoPor?.toLowerCase() === emailLower
    );
  }, [cuadres, selectedUser, emailLower]);

  // 5. System logs for this operator
  const userAuditorias = useMemo(() => {
    if (!selectedUser) return [];
    return auditorias.filter(
      log => log.usuarioRealizo?.toLowerCase() === emailLower || log.usuarioRealizo === selectedUser.nombre
    );
  }, [auditorias, selectedUser, emailLower]);

  // 6. Assignment history & temporary allocations for this operator
  const relevantHistorial = useMemo(() => {
    const email = selectedUser?.email || "";
    return historialAsignaciones.filter(
      h => h.cobradorAnteriorUid?.toLowerCase() === email.toLowerCase() ||
           h.nuevoCobradorUid?.toLowerCase() === email.toLowerCase()
    );
  }, [historialAsignaciones, selectedUser]);

  const relevantTemporales = useMemo(() => {
    const email = selectedUser?.email || "";
    return asignacionesTemporales.filter(
      t => t.cobradorOriginalUid?.toLowerCase() === email.toLowerCase() ||
           t.cobradorTemporalUid?.toLowerCase() === email.toLowerCase()
    );
  }, [asignacionesTemporales, selectedUser]);

  // Dynamic calculation of pending collections today
  const cobrosPendientesHoy = useMemo(() => {
    if (!selectedUser) return 0;
    // Active or overdue loans assigned to this cobrador/clients
    const activeLoans = prestamos.filter(
      p => (p.estado === "Activo" || p.estado === "Atrasado") &&
           p.balancePendiente > 0 &&
           (p.cobradorId?.toLowerCase() === emailLower || assignedClientes.some(c => c.id === p.clienteId))
    );
    // Paid loans today
    const todayStr = new Date().toISOString().split("T")[0];
    const paidTodayLoanIds = pagos
      .filter(p => p.fecha?.startsWith(todayStr))
      .map(p => p.prestamoId);

    return activeLoans.filter(p => !paidTodayLoanIds.includes(p.id!)).length;
  }, [selectedUser, prestamos, emailLower, assignedClientes, pagos]);

  // Handle direct deactivation
  const handleDirectDeactivate = async () => {
    if (!selectedUser || !onSaveUsuario) return;
    try {
      await onSaveUsuario({
        ...selectedUser,
        activo: false
      });
      setShowDeactivateModal(false);
    } catch (e) {
      console.error("Error al desactivar el usuario:", e);
    }
  };

  // Handle reactivation
  const handleReactivate = async () => {
    if (!selectedUser || !onSaveUsuario) return;
    try {
      await onSaveUsuario({
        ...selectedUser,
        activo: true
      });
    } catch (e) {
      console.error("Error al reactivar el usuario:", e);
    }
  };

  // Submit Mass Portfolio Transfer
  const handleTransferSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !onTransferirCartera) return;
    if (!transferTargetEmail) {
      alert("Por favor selecciona un cobrador de destino.");
      return;
    }
    if (transferTargetEmail.toLowerCase() === selectedUser.email.toLowerCase()) {
      alert("El cobrador de destino debe ser diferente al actual.");
      return;
    }
    try {
      setIsSubmittingTransfer(true);
      await onTransferirCartera(
        selectedUser.email,
        transferTargetEmail,
        transferOptions,
        transferMotivo || "Transferencia masiva de cartera"
      );
      setShowTransferModal(false);
      setTransferMotivo("");
      alert("Cartera transferida de forma exitosa mediante Batch Write.");
    } catch (err: any) {
      alert("Error al transferir cartera: " + err.message);
    } finally {
      setIsSubmittingTransfer(false);
    }
  };

  // Submit Temporary Collector Assignment Replacement
  const handleTempSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !onSaveAsignacionTemporal) return;
    if (!tempTargetEmail) {
      alert("Por favor selecciona un cobrador temporal.");
      return;
    }
    if (!tempDateInicio || !tempDateFin) {
      alert("Por favor selecciona las fechas de inicio y fin.");
      return;
    }
    if (tempTargetEmail.toLowerCase() === selectedUser.email.toLowerCase()) {
      alert("El cobrador temporal debe ser diferente al actual.");
      return;
    }

    try {
      setIsSubmittingTemp(true);
      if (assignedClientes.length === 0) {
        alert("Este cobrador no tiene clientes asignados actualmente.");
        return;
      }

      // Save assignments for each client in the portfolio
      for (const client of assignedClientes) {
        const tempCobMatch = usuarios.find(u => u.email.toLowerCase() === tempTargetEmail.toLowerCase());
        const payload: AsignacionTemporal = {
          clienteId: client.id!,
          clienteNombre: client.nombre,
          cobradorOriginalUid: selectedUser.email,
          cobradorOriginalNombre: selectedUser.nombre,
          cobradorTemporalUid: tempTargetEmail,
          cobradorTemporalNombre: tempCobMatch ? tempCobMatch.nombre : tempTargetEmail,
          fechaInicio: tempDateInicio,
          fechaFin: tempDateFin,
          motivo: tempMotivo || "Reemplazo temporal",
          activo: true,
          creadoPor: "Supervisor de EasyPres",
          fechaCreado: new Date().toISOString()
        };
        await onSaveAsignacionTemporal(payload);
      }

      setShowTempModal(false);
      setTempMotivo("");
      alert("Asignaciones temporales creadas para todos los clientes de su cartera.");
    } catch (err: any) {
      alert("Error al guardar asignación temporal: " + err.message);
    } finally {
      setIsSubmittingTemp(false);
    }
  };

  // Calculations & Analytics for the selected operator
  const kpis = useMemo(() => {
    const totalClientesCount = assignedClientes.length;
    const activePrestamos = assignedPrestamos.filter(p => p.estado === "Activo" || p.estado === "Atrasado");
    const activeLoansCount = activePrestamos.length;

    // Total outstanding balance managed by this operator
    const totalOutstandingBalance = activePrestamos.reduce((sum, p) => sum + (p.balancePendiente || 0), 0);

    // Total capital active portfolio
    const totalCapitalActive = activePrestamos.reduce((sum, p) => sum + (p.capitalPrestado || 0), 0);

    // Total collected amount by this operator
    const totalCollected = userPagos.reduce((sum, p) => sum + p.monto, 0);

    // Overdue loan count (atrasado)
    const overdueLoansCount = assignedPrestamos.filter(p => p.estado === "Atrasado").length;

    // Average collection efficiency (paid vs scheduled payments)
    const totalPaymentsCount = userPagos.length;

    return {
      totalClientesCount,
      activeLoansCount,
      totalOutstandingBalance,
      totalCapitalActive,
      totalCollected,
      overdueLoansCount,
      totalPaymentsCount
    };
  }, [assignedClientes, assignedPrestamos, userPagos]);

  // Search filter implementation per active sub-tab
  const filteredData = useMemo(() => {
    const term = searchTerm.toLowerCase();

    if (profileTab === "clientes") {
      return assignedClientes.filter(c => {
        const matchesSearch = c.nombre.toLowerCase().includes(term) ||
          (c.cedula && c.cedula.includes(term)) ||
          (c.telefono && c.telefono.includes(term)) ||
          (c.direccion && c.direccion.toLowerCase().includes(term));
        
        if (statusFilter === "todos") return matchesSearch;
        // Mocking check on status if needed, otherwise matchesSearch
        return matchesSearch;
      });
    }

    if (profileTab === "prestamos") {
      return assignedPrestamos.filter(p => {
        const matchesSearch = p.numero.toLowerCase().includes(term) ||
          p.clienteNombre.toLowerCase().includes(term);
        
        if (statusFilter === "todos") return matchesSearch;
        return matchesSearch && p.estado.toLowerCase() === statusFilter.toLowerCase();
      });
    }

    if (profileTab === "abonos") {
      return userPagos.filter(p => {
        const matchesSearch = p.reciboNo.toLowerCase().includes(term) ||
          p.clienteNombre.toLowerCase().includes(term) ||
          p.tipoPago.toLowerCase().includes(term);
        
        if (statusFilter === "todos") return matchesSearch;
        return matchesSearch && p.tipoPago.toLowerCase().includes(statusFilter.toLowerCase());
      });
    }

    if (profileTab === "cuadres") {
      return userCuadres.filter(c => {
        const matchesSearch = (c.notas && c.notas.toLowerCase().includes(term)) ||
          c.estado.toLowerCase().includes(term);
        
        if (statusFilter === "todos") return matchesSearch;
        return matchesSearch && c.estado.toLowerCase() === statusFilter.toLowerCase();
      });
    }

    if (profileTab === "auditoria") {
      return userAuditorias.filter(log => {
        return log.accion.toLowerCase().includes(term) ||
          log.modulo.toLowerCase().includes(term) ||
          (log.detalles && log.detalles.toLowerCase().includes(term));
      });
    }

    return [];
  }, [profileTab, searchTerm, statusFilter, assignedClientes, assignedPrestamos, userPagos, userCuadres, userAuditorias]);

  if (!selectedUser) {
    return (
      <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-8 text-center text-gray-500 dark:text-zinc-400">
        <User size={48} className="mx-auto text-gray-400 mb-2" />
        <p className="text-sm font-semibold">No se encontraron operadores registrados para supervisar.</p>
        <p className="text-xs text-gray-400 mt-1">Registra operadores en la sección anterior de Ajustes Generales.</p>
      </div>
    );
  }

  // Generate color palette based on user role
  const roleBadgeStyles = (role: string) => {
    switch (role) {
      case "Administrador":
        return {
          bg: "bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20",
          dot: "bg-purple-500",
          gradient: "from-purple-500 to-indigo-600"
        };
      case "Supervisor":
        return {
          bg: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20",
          dot: "bg-blue-500",
          gradient: "from-blue-500 to-cyan-500"
        };
      default: // Cobrador
        return {
          bg: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20",
          dot: "bg-amber-500",
          gradient: "from-amber-500 to-orange-500"
        };
    }
  };

  const currentRoleStyle = roleBadgeStyles(selectedUser.rol);

  // Quick print handler for operator audit file
  const handlePrintAudit = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="supervision-operadores-container">
      
      {/* Upper Selector Panel */}
      <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <label className="block text-[10px] font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider">Supervisar Operador de Cartera</label>
          <div className="flex items-center gap-2">
            <UserCheck className="text-emerald-500 shrink-0" size={18} />
            <select
              value={selectedUserEmail}
              onChange={(e) => {
                setSelectedUserEmail(e.target.value);
                setSearchTerm("");
                setStatusFilter("todos");
              }}
              className="text-sm font-bold bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-gray-800 dark:text-zinc-100 min-w-[240px]"
              id="select-operator-supervision"
            >
              <optgroup label="Cobradores en Campo">
                {usuarios.filter(u => u.rol === "Cobrador").map((u, idx) => (
                  <option key={`${u.id || u.uid || 'cob'}-${u.email || idx}-${idx}`} value={u.email}>
                    {u.nombre} ({u.email}) {!u.activo ? "[Inactivo]" : ""}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Supervisores y Directivos">
                {usuarios.filter(u => u.rol !== "Cobrador").map((u, idx) => (
                  <option key={`${u.id || u.uid || 'sup'}-${u.email || idx}-${idx}`} value={u.email}>
                    [{u.rol}] {u.nombre} {!u.activo ? "[Inactivo]" : ""}
                  </option>
                ))}
              </optgroup>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handlePrintAudit}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-gray-600 dark:text-zinc-300 bg-gray-100 dark:bg-zinc-800 hover:bg-gray-200 dark:hover:bg-zinc-700 rounded-xl transition-colors"
            title="Imprimir hoja de auditoría"
            id="btn-print-audit-sheet"
          >
            <FileText size={14} /> Ficha de Auditoría
          </button>
          <span className="text-xs text-gray-400 font-mono hidden lg:inline">
            Filtro de Seguridad Activo: <strong className="text-emerald-600">Admin-Ledger</strong>
          </span>
        </div>
      </div>

      {/* Main Profile Info & KPI Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Profile Card Column */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Main User Card */}
          <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-sm relative overflow-hidden text-center">
            {/* Top decorative gradient bar */}
            <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${currentRoleStyle.gradient}`} />
            
            {/* User status badge absolute top right */}
            <div className="absolute top-4 right-4 flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full ${selectedUser.activo ? "bg-emerald-500 animate-pulse" : "bg-red-400"}`} />
              <span className="text-[9px] uppercase tracking-wider font-bold text-gray-500 dark:text-zinc-400">
                {selectedUser.activo ? "En Línea" : "Desactivado"}
              </span>
            </div>

            {/* Initials Avatar Bubble */}
            <div className={`w-20 h-20 rounded-2xl mx-auto flex items-center justify-center text-2xl font-black bg-gradient-to-br ${currentRoleStyle.gradient} text-white shadow-md relative group mt-3 mb-4`}>
              {selectedUser.nombre.substring(0, 2).toUpperCase()}
              {selectedUser.activo && (
                <div className="absolute -bottom-1 -right-1 bg-white dark:bg-[#121214] p-1 rounded-full border border-gray-50 dark:border-zinc-900">
                  <div className="w-3 h-3 bg-emerald-500 rounded-full" />
                </div>
              )}
            </div>

            {/* Name and Basic Data */}
            <h2 className="text-base font-bold text-gray-900 dark:text-white" id="supervision-operator-name">
              {selectedUser.nombre}
            </h2>
            <p className="text-xs text-gray-500 dark:text-zinc-400 mt-0.5 font-mono select-all">
              {selectedUser.email}
            </p>

            {/* Role indicator badge */}
            <span className={`inline-block mt-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${currentRoleStyle.bg}`}>
              {selectedUser.rol}
            </span>

            {/* Meta summary */}
            <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-zinc-100 dark:border-zinc-900 text-left text-xs">
              <div>
                <p className="text-gray-500 dark:text-zinc-400 text-[10px] uppercase font-bold tracking-wider">Identificador</p>
                <p className="font-mono text-gray-700 dark:text-zinc-300 font-semibold truncate" title={selectedUser.id}>
                  {selectedUser.id || selectedUser.uid || "Interno"}
                </p>
              </div>
              <div>
                <p className="text-gray-500 dark:text-zinc-400 text-[10px] uppercase font-bold tracking-wider">Estado de Firma</p>
                <p className="font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-0.5">
                  <ShieldCheck size={12} /> Verificado
                </p>
              </div>
            </div>

            {/* Summary text about what this user can do based on role */}
            <div className="mt-4 p-3 bg-zinc-50 dark:bg-zinc-900/50 rounded-xl border border-zinc-100/60 dark:border-zinc-800/40 text-left text-[11px] text-gray-500 dark:text-zinc-400 leading-relaxed">
              {selectedUser.rol === "Cobrador" ? (
                <span>
                  Este <strong>Cobrador</strong> tiene asignado un padrón de clientes específicos de cobro en campo. Puede emitir recibos de caja, registrar solicitudes de crédito, y requiere conciliación diaria de cuadre.
                </span>
              ) : selectedUser.rol === "Supervisor" ? (
                <span>
                  Este <strong>Supervisor</strong> posee permisos de visualización extendidos, puede monitorear cobros, autorizar solicitudes, y realizar pre-liquidaciones de carteras de campo de forma intermedia.
                </span>
              ) : (
                <span>
                  Este **Administrador** posee privilegios de control absoluto en todo el sistema. No tiene restricciones de cartera, puede alterar tasas, desactivar operadores, y auditar toda la financiera.
                </span>
              )}
            </div>
          </div>

          {/* Quick Route Status Info */}
          {selectedUser.rol === "Cobrador" && (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 shadow-sm space-y-3">
              <h3 className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <MapPin size={14} className="text-emerald-500" /> Sectores y Cobertura de Ruta
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {assignedClientes.map(c => c.direccion?.split(",")[0] || "General").filter((v, i, self) => v && self.indexOf(v) === i).slice(0, 5).map((dir, idx) => (
                  <span key={idx} className="bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 px-2.5 py-1 rounded-lg text-[11px] font-semibold border border-zinc-200/50 dark:border-zinc-700/50 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    {dir}
                  </span>
                ))}
                {assignedClientes.length === 0 && (
                  <span className="text-xs text-gray-500 dark:text-zinc-400 italic">No tiene clientes asociados en su ruta</span>
                )}
              </div>
            </div>
          )}

          {/* Load Limits & Portfolio Actions Card */}
          {selectedUser.rol === "Cobrador" && (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 shadow-sm space-y-4">
              <h3 className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <SlidersHorizontal size={14} className="text-emerald-500" /> Límites y Control de Carga
              </h3>
              
              <div className="space-y-3 text-xs">
                {/* Clients limit progress */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-zinc-600 dark:text-zinc-400">
                    <span>Límite de Clientes Activos</span>
                    <span className="font-mono font-bold">
                      {assignedClientes.length} / {configuracion?.maxClientesCobrador || "100"}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-300 ${
                        assignedClientes.length >= (configuracion?.maxClientesCobrador || 100)
                          ? "bg-rose-500"
                          : assignedClientes.length >= (configuracion?.maxClientesCobrador || 100) * 0.8
                          ? "bg-amber-500"
                          : "bg-emerald-500"
                      }`}
                      style={{ width: `${Math.min(100, (assignedClientes.length / (configuracion?.maxClientesCobrador || 100)) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Active Loans limit progress */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-zinc-600 dark:text-zinc-400">
                    <span>Límite de Préstamos Activos</span>
                    <span className="font-mono font-bold">
                      {assignedPrestamos.filter(p => p.estado === "Activo" || p.estado === "Atrasado").length} / {configuracion?.maxPrestamosActivosCobrador || "100"}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-300 ${
                        assignedPrestamos.filter(p => p.estado === "Activo" || p.estado === "Atrasado").length >= (configuracion?.maxPrestamosActivosCobrador || 100)
                          ? "bg-rose-500"
                          : assignedPrestamos.filter(p => p.estado === "Activo" || p.estado === "Atrasado").length >= (configuracion?.maxPrestamosActivosCobrador || 100) * 0.8
                          ? "bg-amber-500"
                          : "bg-emerald-500"
                      }`}
                      style={{ width: `${Math.min(100, (assignedPrestamos.filter(p => p.estado === "Activo" || p.estado === "Atrasado").length / (configuracion?.maxPrestamosActivosCobrador || 100)) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Quick Actions Panel */}
              <div className="pt-3 border-t border-zinc-100 dark:border-zinc-850 space-y-2">
                <span className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Acciones Administrativas</span>
                <div className="grid grid-cols-1 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTransferTargetEmail("");
                      setTransferMotivo("");
                      setShowTransferModal(true);
                    }}
                    className="w-full py-2 px-3 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw size={13} />
                    <span>Reasignación Masiva (Cartera)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTempTargetEmail("");
                      setTempDateInicio("");
                      setTempDateFin("");
                      setTempMotivo("");
                      setShowTempModal(true);
                    }}
                    className="w-full py-2 px-3 text-xs font-bold text-zinc-700 dark:text-zinc-200 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-750 rounded-xl active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Calendar size={13} />
                    <span>Sustitución Temporal</span>
                  </button>

                  {selectedUser.activo ? (
                    <button
                      type="button"
                      onClick={() => {
                        setShowDeactivateModal(true);
                      }}
                      className="w-full py-2 px-3 text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 dark:hover:bg-rose-950/30 rounded-xl active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-rose-200/50 dark:border-rose-900/30"
                      id="btn-deactivate-operator"
                    >
                      <UserCheck size={13} className="rotate-180 text-rose-500" />
                      <span>Dar de Baja Cobrador</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleReactivate}
                      className="w-full py-2 px-3 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/30 rounded-xl active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-emerald-200/50 dark:border-emerald-900/30"
                      id="btn-reactivate-operator"
                    >
                      <UserCheck size={13} className="text-emerald-500" />
                      <span>Reactivar Cobrador</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Dashboard KPIs and Detailed tables */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* KPI Mini Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            
            {/* Card 1: Clientes */}
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                <User size={20} />
              </div>
              <div className="space-y-0.5 min-w-0">
                <p className="text-[10px] text-gray-500 dark:text-zinc-400 uppercase font-bold tracking-wider truncate">Clientes</p>
                <p className="text-lg font-black text-gray-800 dark:text-zinc-100" id="supervision-kpi-clientes">
                  {kpis.totalClientesCount}
                </p>
              </div>
            </div>

            {/* Card 2: Préstamos Activos */}
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                <FileText size={20} />
              </div>
              <div className="space-y-0.5 min-w-0">
                <p className="text-[10px] text-gray-500 dark:text-zinc-400 uppercase font-bold tracking-wider truncate">Préstamos</p>
                <p className="text-lg font-black text-gray-800 dark:text-zinc-100" id="supervision-kpi-loans">
                  {kpis.activeLoansCount} <span className="text-[10px] font-normal text-gray-500 dark:text-zinc-400">act.</span>
                </p>
              </div>
            </div>

            {/* Card 3: Saldo Cartera */}
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 flex items-center justify-center shrink-0">
                <TrendingUp size={20} />
              </div>
              <div className="space-y-0.5 min-w-0">
                <p className="text-[10px] text-gray-500 dark:text-zinc-400 uppercase font-bold tracking-wider truncate">Saldo Cartera</p>
                <p className="text-lg font-black text-orange-600 dark:text-orange-400 truncate" id="supervision-kpi-balance">
                  {moneda}{kpis.totalOutstandingBalance.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Card 4: Recaudado total */}
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <DollarSign size={20} />
              </div>
              <div className="space-y-0.5 min-w-0">
                <p className="text-[10px] text-gray-500 dark:text-zinc-400 uppercase font-bold tracking-wider truncate">Recaudado</p>
                <p className="text-lg font-black text-emerald-600 dark:text-emerald-400 truncate" id="supervision-kpi-recaudado">
                  {moneda}{kpis.totalCollected.toLocaleString()}
                </p>
              </div>
            </div>

          </div>

          {/* Interactive Audited Ledger Sheet with Tabs */}
          <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-sm space-y-4">
            
            {/* Header Tabs with Filter Row */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-zinc-100 dark:border-zinc-800/80 pb-4 gap-4">
              
              {/* Profile Internal Tabs */}
              <div className="flex flex-wrap gap-1" id="supervision-internal-tabs">
                <button
                  onClick={() => { setProfileTab("clientes"); setSearchTerm(""); setStatusFilter("todos"); }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                    profileTab === "clientes"
                      ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 shadow-sm"
                      : "text-gray-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-200"
                  }`}
                  id="tab-supervision-clientes"
                >
                  Clientes ({assignedClientes.length})
                </button>
                <button
                  onClick={() => { setProfileTab("prestamos"); setSearchTerm(""); setStatusFilter("todos"); }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                    profileTab === "prestamos"
                      ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 shadow-sm"
                      : "text-gray-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-200"
                  }`}
                  id="tab-supervision-prestamos"
                >
                  Préstamos ({assignedPrestamos.length})
                </button>
                <button
                  onClick={() => { setProfileTab("abonos"); setSearchTerm(""); setStatusFilter("todos"); }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                    profileTab === "abonos"
                      ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 shadow-sm"
                      : "text-gray-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-200"
                  }`}
                  id="tab-supervision-abonos"
                >
                  Recibos ({userPagos.length})
                </button>
                <button
                  onClick={() => { setProfileTab("cuadres"); setSearchTerm(""); setStatusFilter("todos"); }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                    profileTab === "cuadres"
                      ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 shadow-sm"
                      : "text-gray-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-200"
                  }`}
                  id="tab-supervision-cuadres"
                >
                  Cuadres ({userCuadres.length})
                </button>
                <button
                  onClick={() => { setProfileTab("auditoria"); setSearchTerm(""); setStatusFilter("todos"); }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                    profileTab === "auditoria"
                      ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 shadow-sm"
                      : "text-gray-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-200"
                  }`}
                  id="tab-supervision-auditoria"
                >
                  Acciones ({userAuditorias.length})
                </button>
                {selectedUser.rol === "Cobrador" && (
                  <button
                    onClick={() => { setProfileTab("asignaciones"); setSearchTerm(""); setStatusFilter("todos"); }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                      profileTab === "asignaciones"
                        ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 shadow-sm"
                        : "text-gray-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-200"
                    }`}
                    id="tab-supervision-asignaciones"
                  >
                    Asignaciones ({relevantHistorial.length + relevantTemporales.length})
                  </button>
                )}
              </div>

              {/* Quick Search */}
              <div className="relative">
                <Search className="absolute left-3 top-2.5 text-gray-400" size={13} />
                <input
                  type="text"
                  placeholder="Buscar..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full sm:w-44 pl-8 pr-3 py-1.5 border border-zinc-200 dark:border-zinc-800 rounded-xl bg-zinc-50 dark:bg-zinc-950 text-xs text-zinc-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

            </div>

            {/* Sub-filtering Options according to selected Tab */}
            {(profileTab === "prestamos" || profileTab === "cuadres") && (
              <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-zinc-400 bg-zinc-50 dark:bg-zinc-900/40 p-2 rounded-xl">
                <SlidersHorizontal size={12} className="text-zinc-400" />
                <span>Estado:</span>
                <button
                  onClick={() => setStatusFilter("todos")}
                  className={`px-2 py-0.5 rounded ${statusFilter === "todos" ? "bg-zinc-200 dark:bg-zinc-800 text-gray-800 dark:text-zinc-100 font-bold" : "hover:text-gray-800 dark:hover:text-zinc-200"}`}
                >
                  Todos
                </button>
                {profileTab === "prestamos" && (
                  <>
                    <button
                      onClick={() => setStatusFilter("activo")}
                      className={`px-2 py-0.5 rounded ${statusFilter === "activo" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 font-bold" : "hover:text-gray-800 dark:hover:text-zinc-200"}`}
                    >
                      Activos
                    </button>
                    <button
                      onClick={() => setStatusFilter("atrasado")}
                      className={`px-2 py-0.5 rounded ${statusFilter === "atrasado" ? "bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-400 font-bold" : "hover:text-gray-800 dark:hover:text-zinc-200"}`}
                    >
                      Atrasados
                    </button>
                    <button
                      onClick={() => setStatusFilter("saldado")}
                      className={`px-2 py-0.5 rounded ${statusFilter === "saldado" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400 font-bold" : "hover:text-gray-800 dark:hover:text-zinc-200"}`}
                    >
                      Saldados
                    </button>
                  </>
                )}
                {profileTab === "cuadres" && (
                  <>
                    <button
                      onClick={() => setStatusFilter("conciliado")}
                      className={`px-2 py-0.5 rounded ${statusFilter === "conciliado" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 font-bold" : "hover:text-gray-800 dark:hover:text-zinc-200"}`}
                    >
                      Conciliados
                    </button>
                    <button
                      onClick={() => setStatusFilter("diferencia")}
                      className={`px-2 py-0.5 rounded ${statusFilter === "diferencia" ? "bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-400 font-bold" : "hover:text-gray-800 dark:hover:text-zinc-200"}`}
                    >
                      Diferencias
                    </button>
                  </>
                )}
              </div>
            )}

            {/* List Panels container */}
            <div className="overflow-x-auto min-h-[300px]">
              {filteredData.length === 0 ? (
                <div className="text-center py-16 text-gray-400 space-y-2">
                  <Activity size={32} className="mx-auto text-gray-300" />
                  <p className="text-xs font-semibold">Sin registros coincidentes</p>
                  <p className="text-[10px] text-gray-400">Prueba cambiando el término de búsqueda o filtros.</p>
                </div>
              ) : (
                <>
                  {/* --- TAB 1: CLIENTES --- */}
                  {profileTab === "clientes" && (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-100 dark:border-zinc-800 text-gray-500 dark:text-zinc-400">
                          <th className="py-2.5 font-bold">Cliente</th>
                          <th className="py-2.5 font-bold">Cédula / ID</th>
                          <th className="py-2.5 font-bold">Teléfono</th>
                          <th className="py-2.5 font-bold">Dirección</th>
                          <th className="py-2.5 font-bold text-right">Créditos</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(filteredData as Cliente[]).map((c) => {
                          const associatedLoans = prestamos.filter(p => p.clienteId === c.id);
                          const activeLoans = associatedLoans.filter(p => p.estado === "Activo" || p.estado === "Atrasado");
                          return (
                            <tr key={c.id} className="border-b border-zinc-50 dark:border-zinc-900/60 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 text-gray-700 dark:text-zinc-300">
                              <td className="py-3 font-bold text-gray-900 dark:text-zinc-100">
                                {c.nombre}
                              </td>
                              <td className="py-3 font-mono text-zinc-500">{c.cedula || "--"}</td>
                              <td className="py-3">{c.telefono}</td>
                              <td className="py-3">
                                <span className="bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded font-semibold text-[10px] truncate max-w-[120px] inline-block" title={c.direccion}>
                                  {c.direccion || "General"}
                                </span>
                              </td>
                              <td className="py-3 text-right">
                                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${activeLoans.length > 0 ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-gray-100 text-gray-400 dark:bg-zinc-800 dark:text-zinc-500"}`}>
                                  {activeLoans.length} activos ({associatedLoans.length} tot.)
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}

                  {/* --- TAB 2: PRESTAMOS --- */}
                  {profileTab === "prestamos" && (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-100 dark:border-zinc-800 text-gray-500 dark:text-zinc-400">
                          <th className="py-2.5 font-bold">No. Préstamo</th>
                          <th className="py-2.5 font-bold">Cliente</th>
                          <th className="py-2.5 font-bold">Monto Original</th>
                          <th className="py-2.5 font-bold">Frecuencia</th>
                          <th className="py-2.5 font-bold">Estado</th>
                          <th className="py-2.5 font-bold text-right">Saldo Pendiente</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(filteredData as Prestamo[]).map((p) => (
                          <tr key={p.id} className="border-b border-zinc-50 dark:border-zinc-900/60 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 text-gray-700 dark:text-zinc-300">
                            <td className="py-3 font-mono font-bold text-gray-950 dark:text-white">
                              {p.numero}
                            </td>
                            <td className="py-3 font-medium">{p.clienteNombre}</td>
                            <td className="py-3 font-semibold">{moneda}{p.capitalPrestado?.toLocaleString()}</td>
                            <td className="py-3 text-[10px] uppercase font-bold text-gray-400">{p.frecuenciaPago}</td>
                            <td className="py-3">
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                                p.estado === "Activo"
                                  ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400"
                                  : p.estado === "Atrasado"
                                  ? "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400 animate-pulse"
                                  : "bg-gray-100 text-gray-600 dark:bg-zinc-800 dark:text-zinc-400"
                              }`}>
                                {p.estado}
                              </span>
                            </td>
                            <td className="py-3 text-right font-black text-gray-900 dark:text-zinc-100">
                              {moneda}{p.balancePendiente?.toLocaleString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {/* --- TAB 3: RECEIPT PAYMENTS --- */}
                  {profileTab === "abonos" && (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-100 dark:border-zinc-800 text-gray-500 dark:text-zinc-400">
                          <th className="py-2.5 font-bold">Recibo No.</th>
                          <th className="py-2.5 font-bold">Fecha / Hora</th>
                          <th className="py-2.5 font-bold">Cliente</th>
                          <th className="py-2.5 font-bold">Concepto</th>
                          <th className="py-2.5 font-bold text-right">Cobrado</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(filteredData as Pago[]).map((pa) => (
                          <tr key={pa.id} className="border-b border-zinc-50 dark:border-zinc-900/60 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 text-gray-700 dark:text-zinc-300">
                            <td className="py-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                              {pa.reciboNo}
                            </td>
                            <td className="py-3 font-mono text-[11px]">
                              {pa.fecha ? pa.fecha.replace("T", " ").substring(0, 16) : "--"}
                            </td>
                            <td className="py-3 font-medium">{pa.clienteNombre}</td>
                            <td className="py-3 text-[10px] text-gray-500 dark:text-zinc-400 font-semibold">{pa.tipoPago}</td>
                            <td className="py-3 text-right font-bold text-gray-900 dark:text-white">
                              {moneda}{pa.monto?.toLocaleString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {/* --- TAB 4: CUADRES DE CAJA --- */}
                  {profileTab === "cuadres" && (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-100 dark:border-zinc-800 text-gray-500 dark:text-zinc-400">
                          <th className="py-2.5 font-bold">Fecha Registro</th>
                          <th className="py-2.5 font-bold">Fondo Apertura</th>
                          <th className="py-2.5 font-bold">Cobros</th>
                          <th className="py-2.5 font-bold">Físico en Caja</th>
                          <th className="py-2.5 font-bold">Estado</th>
                          <th className="py-2.5 font-bold text-right">Diferencia</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(filteredData as CuadreCaja[]).map((c) => (
                          <tr key={c.id} className="border-b border-zinc-50 dark:border-zinc-900/60 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 text-gray-700 dark:text-zinc-300">
                            <td className="py-3 font-mono text-[11px]">
                              {c.fecha ? c.fecha.replace("T", " ").substring(0, 16) : "--"}
                            </td>
                            <td className="py-3">{moneda}{c.fondoApertura?.toLocaleString()}</td>
                            <td className="py-3 text-emerald-600 font-semibold">+{moneda}{c.cobrosEfectivo?.toLocaleString()}</td>
                            <td className="py-3 font-bold">{moneda}{c.saldoReal?.toLocaleString()}</td>
                            <td className="py-3">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                c.estado === "Conciliado"
                                  ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400"
                                  : "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400"
                              }`}>
                                {c.estado}
                              </span>
                            </td>
                            <td className={`py-3 text-right font-bold ${c.descuadre === 0 ? "text-gray-400" : c.descuadre > 0 ? "text-emerald-600" : "text-rose-600"}`}>
                              {c.descuadre === 0 ? "Perfecto" : `${c.descuadre > 0 ? "+" : ""}${moneda}${c.descuadre}`}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {/* --- TAB 5: AUDIT TRAIL ACTION LOGS --- */}
                  {profileTab === "auditoria" && (
                    <div className="space-y-2.5 max-h-[400px] overflow-y-auto pr-2">
                      {(filteredData as AuditoriaLog[]).map((log, index) => (
                        <div key={log.id || index} className="p-3 bg-zinc-50 dark:bg-zinc-900/60 rounded-xl border border-zinc-100 dark:border-zinc-800 text-[11px] flex items-start gap-3">
                          <div className="p-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg text-zinc-500 shrink-0 mt-0.5">
                            <Clock size={12} />
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <p className="font-bold text-gray-900 dark:text-zinc-100">{log.accion}</p>
                              <span className="text-[9px] font-mono text-gray-500 dark:text-zinc-400">{log.fecha ? log.fecha.substring(11, 19) : ""}</span>
                            </div>
                            <p className="text-gray-500 dark:text-zinc-400 leading-normal">{log.detalles || "Sin detalles adicionales."}</p>
                            <div className="flex items-center gap-2 text-[9px] text-gray-500 dark:text-zinc-400">
                              <span className="bg-zinc-200 dark:bg-zinc-800 px-1 py-0.5 rounded font-bold uppercase">Auditoría</span>
                              <span>• Sujeto: {log.usuarioAfectado || "Sistema"}</span>
                              <span>• Fecha: {log.fecha ? log.fecha.substring(0, 10) : ""}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* --- TAB 6: ASIGNACIONES & REEMPLAZOS --- */}
                  {profileTab === "asignaciones" && (
                    <div className="space-y-6">
                      
                      {/* Section 1: Temporary Assignments */}
                      <div>
                        <h4 className="text-xs font-bold text-gray-750 dark:text-zinc-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                          Sustituciones Temporales Activas ({relevantTemporales.length})
                        </h4>
                        
                        {relevantTemporales.length === 0 ? (
                          <div className="p-4 rounded-xl border border-dashed border-zinc-200 dark:border-zinc-850 text-center text-xs text-gray-500 dark:text-zinc-400 bg-zinc-50/50 dark:bg-zinc-950/20">
                            No hay sustituciones temporales activas para este cobrador.
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {relevantTemporales.map((t, idx) => {
                              const clientObj = clientes.find(c => c.id === t.clienteId);
                              const targetUser = usuarios.find(u => u.email.toLowerCase() === t.cobadorTemporalUid?.toLowerCase() || u.email.toLowerCase() === t.cobradorTemporalUid?.toLowerCase());
                              const originalUser = usuarios.find(u => u.email.toLowerCase() === t.cobradorOriginalUid?.toLowerCase());
                              return (
                                <div key={idx} className="p-3 bg-zinc-50 dark:bg-zinc-900/60 rounded-xl border border-zinc-100 dark:border-zinc-800/85 text-xs space-y-2">
                                  <div className="flex justify-between items-center">
                                    <span className="font-bold text-gray-950 dark:text-zinc-100">
                                      {clientObj ? clientObj.nombre : `Cliente ID: ${t.clienteId.substring(0,6)}`}
                                    </span>
                                    <span className={`px-1.5 py-0.2 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded text-[9px] font-extrabold uppercase`}>
                                      Temporal
                                    </span>
                                  </div>
                                  
                                  <div className="grid grid-cols-2 gap-1 text-[11px] text-gray-500 dark:text-zinc-400">
                                    <div>
                                      <p className="font-bold uppercase text-[9px] text-zinc-450 dark:text-zinc-500">Original</p>
                                      <p className="truncate">{originalUser ? originalUser.nombre : t.cobradorOriginalUid}</p>
                                    </div>
                                    <div>
                                      <p className="font-bold uppercase text-[9px] text-zinc-455 dark:text-zinc-500">Sustituto</p>
                                      <p className="truncate font-semibold text-emerald-600 dark:text-emerald-400">{targetUser ? targetUser.nombre : t.cobradorTemporalUid}</p>
                                    </div>
                                  </div>

                                  <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800 text-[10px] text-gray-400 flex justify-between">
                                    <span>Vigencia: {t.fechaInicio} al {t.fechaFin}</span>
                                    <span className="font-medium max-w-[120px] truncate" title={t.motivo}>{t.motivo}</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {/* Section 2: Historical Assignments & Changes */}
                      <div>
                        <h4 className="text-xs font-bold text-gray-750 dark:text-zinc-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                          <Clock size={12} className="text-zinc-400" />
                          Historial Completo de Reasignaciones ({relevantHistorial.length})
                        </h4>
                        
                        {relevantHistorial.length === 0 ? (
                          <div className="p-4 rounded-xl border border-dashed border-zinc-200 dark:border-zinc-850 text-center text-xs text-gray-500 dark:text-zinc-400 bg-zinc-50/50 dark:bg-zinc-950/20">
                            No hay historial de reasignación registrado.
                          </div>
                        ) : (
                          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                            {relevantHistorial.map((h, idx) => {
                              const clientObj = clientes.find(c => c.id === h.clienteId);
                              const oldCob = usuarios.find(u => u.email.toLowerCase() === h.cobradorAnteriorUid?.toLowerCase());
                              const newCob = usuarios.find(u => u.email.toLowerCase() === h.nuevoCobradorUid?.toLowerCase());
                              return (
                                <div key={idx} className="p-2.5 bg-zinc-50 dark:bg-zinc-900/40 rounded-xl border border-zinc-100 dark:border-zinc-800 text-[11px] flex justify-between items-center gap-3">
                                  <div className="space-y-0.5 min-w-0 flex-1">
                                    <p className="font-bold text-gray-950 dark:text-zinc-100 truncate">
                                      {clientObj ? clientObj.nombre : h.clienteNombre || `Cliente ID: ${h.clienteId.substring(0,6)}`}
                                    </p>
                                    <p className="text-gray-500 dark:text-zinc-450 truncate">
                                      {oldCob ? oldCob.nombre : h.cobradorAnteriorNombre || h.cobradorAnteriorUid || "Sin cobrador"} ➔ {newCob ? newCob.nombre : h.nuevoCobradorNombre || h.nuevoCobradorUid}
                                    </p>
                                    <p className="text-[10px] text-zinc-400 italic truncate">Motivo: {h.motivo}</p>
                                  </div>
                                  <div className="text-right shrink-0">
                                    <span className="font-mono text-[9px] text-gray-400 block">{h.fecha?.replace("T", " ").substring(0, 16)}</span>
                                    <span className={`px-1 rounded text-[8px] font-bold ${h.tipo === "Temporal" ? "bg-amber-100 text-amber-800 dark:bg-amber-950/30 dark:text-amber-400" : "bg-blue-100 text-blue-800 dark:bg-blue-950/30 dark:text-blue-400"}`}>
                                      {h.tipo}
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                    </div>
                  )}
                </>
              )}
            </div>

            {/* Bottom summary and guidance */}
            <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 flex flex-col sm:flex-row items-center justify-between text-[10px] text-gray-500 dark:text-zinc-400 gap-2">
              <p>Hojas de auditoría sincronizadas automáticamente con Firestore.</p>
              <p className="font-mono">EasyPres Security Guard Protocol v2.5</p>
            </div>

          </div>

        </div>

      </div>

      {/* Portfolio Transfer Modal */}
      {showTransferModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-[#121214] border border-zinc-100 dark:border-zinc-800 rounded-2xl w-full max-w-md p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-gray-950 dark:text-white flex items-center gap-1.5 mb-2">
              <RefreshCw size={18} className="text-emerald-500 animate-spin-once" />
              Reasignación Masiva de Cartera
            </h3>
            <p className="text-xs text-gray-500 dark:text-zinc-400 mb-4 leading-relaxed">
              Transfiere de manera definitiva toda la cartera de clientes de <strong>{selectedUser.nombre}</strong> a otro cobrador de campo. Esta acción utiliza Batch Writes de Firestore para garantizar la consistencia transaccional e integridad de la ruta.
            </p>

            <form onSubmit={handleTransferSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Cobrador de Destino (Recomendado con Menor Carga)</label>
                <select
                  required
                  value={transferTargetEmail}
                  onChange={(e) => setTransferTargetEmail(e.target.value)}
                  className="w-full text-xs font-semibold bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="">-- Seleccionar cobrador --</option>
                  {usuarios
                    .filter(u => u.rol === "Cobrador" && u.email.toLowerCase() !== selectedUser.email.toLowerCase() && u.activo)
                    .map((u) => {
                      const otherClients = clientes.filter(c => c.cobradorId?.toLowerCase() === u.email.toLowerCase()).length;
                      return (
                        <option key={u.id || u.uid} value={u.email}>
                          {u.nombre} ({otherClients} clientes asignados)
                        </option>
                      );
                    })}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Opciones de Transferencia</label>
                <div className="space-y-1.5 text-xs text-gray-700 dark:text-zinc-300">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={transferOptions.clients}
                      onChange={(e) => setTransferOptions({ ...transferOptions, clients: e.target.checked })}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Reasignar cartera de Clientes</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={transferOptions.loans}
                      onChange={(e) => setTransferOptions({ ...transferOptions, loans: e.target.checked })}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Reasignar Préstamos activos</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={transferOptions.route}
                      onChange={(e) => setTransferOptions({ ...transferOptions, route: e.target.checked })}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Sincronizar Ruta de Cobro de forma atómica</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={transferOptions.history}
                      onChange={(e) => setTransferOptions({ ...transferOptions, history: e.target.checked })}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Generar Historiales de Auditoría individuales</span>
                  </label>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Motivo de la Reasignación</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Por ej: Renuncia del operador, reestructuración de zonas, etc."
                  value={transferMotivo}
                  onChange={(e) => setTransferMotivo(e.target.value)}
                  className="w-full text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowTransferModal(false)}
                  className="px-4 py-2 text-xs font-bold text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-900 rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingTransfer}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:bg-zinc-400 rounded-xl shadow-sm transition-all flex items-center gap-1.5"
                >
                  {isSubmittingTransfer ? "Procesando..." : "Confirmar Reasignación"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Temporary Replacement Assignment Modal */}
      {showTempModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-[#121214] border border-zinc-100 dark:border-zinc-800 rounded-2xl w-full max-w-md p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-gray-950 dark:text-white flex items-center gap-1.5 mb-2">
              <Calendar size={18} className="text-emerald-500" />
              Sustitución Temporal (Reemplazo)
            </h3>
            <p className="text-xs text-gray-500 dark:text-zinc-400 mb-4 leading-relaxed">
              Reemplaza temporalmente a <strong>{selectedUser.nombre}</strong> con otro cobrador durante un período determinado (como vacaciones o incapacidad médica). La Ruta de Cobro determinará dinámicamente quién cobra cada cliente según las fechas.
            </p>

            <form onSubmit={handleTempSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Cobrador Sustituto (Soporte)</label>
                <select
                  required
                  value={tempTargetEmail}
                  onChange={(e) => setTempTargetEmail(e.target.value)}
                  className="w-full text-xs font-semibold bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="">-- Seleccionar sustituto --</option>
                  {usuarios
                    .filter(u => u.rol === "Cobrador" && u.email.toLowerCase() !== selectedUser.email.toLowerCase() && u.activo)
                    .map((u) => {
                      const otherClients = clientes.filter(c => c.cobradorId?.toLowerCase() === u.email.toLowerCase()).length;
                      return (
                        <option key={u.id || u.uid} value={u.email}>
                          {u.nombre} ({otherClients} clientes)
                        </option>
                      );
                    })}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Fecha Inicio</label>
                  <input
                    type="date"
                    required
                    value={tempDateInicio}
                    onChange={(e) => setTempDateInicio(e.target.value)}
                    className="w-full text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Fecha Fin</label>
                  <input
                    type="date"
                    required
                    value={tempDateFin}
                    onChange={(e) => setTempDateFin(e.target.value)}
                    className="w-full text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Motivo de la Sustitución</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Por ej: Vacaciones anuales, Licencia médica, etc."
                  value={tempMotivo}
                  onChange={(e) => setTempMotivo(e.target.value)}
                  className="w-full text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowTempModal(false)}
                  className="px-4 py-2 text-xs font-bold text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-900 rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingTemp}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:bg-zinc-400 rounded-xl shadow-sm transition-all flex items-center gap-1.5"
                >
                  {isSubmittingTemp ? "Creando..." : "Crear Reemplazo"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Safe Deactivation Modal */}
      {showDeactivateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-[#121214] border border-zinc-100 dark:border-zinc-800 rounded-2xl w-full max-w-md p-6 shadow-2xl relative">
            <h3 className="text-base font-bold text-gray-950 dark:text-white flex items-center gap-2 mb-2">
              <span className="p-1.5 bg-rose-50 dark:bg-rose-950/30 text-rose-500 rounded-lg">
                <SlidersHorizontal size={18} />
              </span>
              Dar de Baja Cobrador (Desactivación Segura)
            </h3>
            <p className="text-xs text-gray-500 dark:text-zinc-400 mb-4 leading-relaxed">
              Estás iniciando el protocolo de desactivación para <strong>{selectedUser.nombre}</strong>. El sistema requiere conciliar su cartera asignada para garantizar la continuidad operativa.
            </p>

            {/* Metrics Display */}
            <div className="grid grid-cols-3 gap-2.5 mb-6">
              <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800/60 p-2.5 rounded-xl text-center">
                <span className="block text-[9px] text-gray-400 uppercase tracking-wider font-bold">Clientes Asignados</span>
                <strong className="text-base font-black text-gray-800 dark:text-zinc-200 block mt-1">
                  {assignedClientes.length}
                </strong>
              </div>
              <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800/60 p-2.5 rounded-xl text-center">
                <span className="block text-[9px] text-gray-400 uppercase tracking-wider font-bold">Préstamos Activos</span>
                <strong className="text-base font-black text-amber-600 dark:text-amber-400 block mt-1">
                  {assignedPrestamos.filter(p => p.estado === "Activo" || p.estado === "Atrasado").length}
                </strong>
              </div>
              <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800/60 p-2.5 rounded-xl text-center">
                <span className="block text-[9px] text-gray-400 uppercase tracking-wider font-bold">Cobros Hoy</span>
                <strong className="text-base font-black text-rose-500 block mt-1">
                  {cobrosPendientesHoy}
                </strong>
              </div>
            </div>

            {/* Action Options */}
            <div className="space-y-3 mb-6">
              <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Seleccione una acción para mitigar el impacto:</label>
              
              <div className="space-y-2">
                {/* Option 1: Transfer Wallet */}
                <button
                  type="button"
                  onClick={() => {
                    setShowDeactivateModal(false);
                    setTransferTargetEmail("");
                    setTransferMotivo(`Baja de cobrador ${selectedUser.nombre}`);
                    setShowTransferModal(true);
                  }}
                  className="w-full text-left p-3 rounded-xl border border-zinc-200 dark:border-zinc-850 hover:border-emerald-500 dark:hover:border-emerald-500/50 bg-zinc-50/50 dark:bg-zinc-950/30 hover:bg-emerald-500/5 dark:hover:bg-emerald-500/5 transition-all flex items-start gap-3 group"
                >
                  <div className="p-2 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-lg mt-0.5 shrink-0 group-hover:scale-105 transition-transform">
                    <RefreshCw size={14} />
                  </div>
                  <div>
                    <strong className="block text-xs font-bold text-gray-900 dark:text-zinc-100">Transferir cartera</strong>
                    <span className="block text-[10px] text-gray-500 dark:text-zinc-400 mt-0.5">Reasignar todos sus clientes y préstamos a otro cobrador activo de forma permanente.</span>
                  </div>
                </button>

                {/* Option 2: Program Temporary Replacement */}
                <button
                  type="button"
                  onClick={() => {
                    setShowDeactivateModal(false);
                    setTempTargetEmail("");
                    setTempDateInicio(new Date().toISOString().split("T")[0]);
                    setTempDateFin("");
                    setTempMotivo(`Reemplazo por baja temporal de ${selectedUser.nombre}`);
                    setShowTempModal(true);
                  }}
                  className="w-full text-left p-3 rounded-xl border border-zinc-200 dark:border-zinc-850 hover:border-amber-500 dark:hover:border-amber-500/50 bg-zinc-50/50 dark:bg-zinc-950/30 hover:bg-amber-500/5 dark:hover:bg-amber-500/5 transition-all flex items-start gap-3 group"
                >
                  <div className="p-2 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 rounded-lg mt-0.5 shrink-0 group-hover:scale-105 transition-transform">
                    <Calendar size={14} />
                  </div>
                  <div>
                    <strong className="block text-xs font-bold text-gray-900 dark:text-zinc-100">Programar reemplazo temporal</strong>
                    <span className="block text-[10px] text-gray-500 dark:text-zinc-400 mt-0.5">Asignar un cobrador suplente por un rango de fechas específico.</span>
                  </div>
                </button>

                {/* Option 3: Deactivate Directly */}
                <button
                  type="button"
                  onClick={handleDirectDeactivate}
                  className="w-full text-left p-3 rounded-xl border border-zinc-200 dark:border-zinc-850 hover:border-rose-500 dark:hover:border-rose-500/50 bg-zinc-50/50 dark:bg-zinc-950/30 hover:bg-rose-500/5 dark:hover:bg-rose-500/5 transition-all flex items-start gap-3 group"
                >
                  <div className="p-2 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-lg mt-0.5 shrink-0 group-hover:scale-105 transition-transform">
                    <UserCheck size={14} className="rotate-180 text-rose-500" />
                  </div>
                  <div>
                    <strong className="block text-xs font-bold text-gray-900 dark:text-zinc-100">Desactivar operador directamente</strong>
                    <span className="block text-[10px] text-gray-500 dark:text-zinc-400 mt-0.5">Marcar operador como inactivo. Su cartera de clientes quedará sin supervisor hasta que sea reasignada.</span>
                  </div>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-100 dark:border-zinc-900">
              <button
                type="button"
                onClick={() => setShowDeactivateModal(false)}
                className="w-full sm:w-auto px-4 py-2 text-xs font-bold text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-900 rounded-xl transition-colors text-center"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
