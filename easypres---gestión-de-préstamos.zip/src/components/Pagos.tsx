import React, { useState, useMemo, useEffect } from "react";
import {
  Plus,
  Search,
  CreditCard,
  DollarSign,
  Printer,
  Share2,
  Calendar,
  X,
  FileSpreadsheet,
  CheckCircle,
  Eye,
  ArrowLeft,
  Check,
  Coins,
  TrendingDown,
  User,
  Clock,
  ShieldCheck,
  SlidersHorizontal
} from "lucide-react";
import { Cliente, Prestamo, Pago, CuotaDetalle, Usuario, checkPermission } from "../types";
import { formatCurrency, generateRandomCode, actualizarCuotasConMora } from "../utils";
import FilterBottomSheet from "./FilterBottomSheet";

interface PagosProps {
  pagos: Pago[];
  prestamos: Prestamo[];
  clientes: Cliente[];
  moneda: string;
  onSavePago: (pago: Pago, updatedPrestamo: Prestamo) => Promise<void>;
  onDeletePago: (id: string) => Promise<void>;
  currentUserProfile?: Usuario | null;
  configuracion?: any;
}

export default function Pagos({
  pagos,
  prestamos,
  clientes,
  moneda,
  onSavePago,
  onDeletePago,
  currentUserProfile,
  configuracion
}: PagosProps) {
  const canCreate = checkPermission(currentUserProfile, "pagos", "crear");
  const canEdit = checkPermission(currentUserProfile, "pagos", "editar");
  const canDelete = checkPermission(currentUserProfile, "pagos", "eliminar");
  const canExport = checkPermission(currentUserProfile, "pagos", "exportar");
  const [searchQuery, setSearchQuery] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [selectedPago, setSelectedPago] = useState<Pago | null>(null);
  const [receiptPrint, setReceiptPrint] = useState<Pago | null>(null);

  // Form states
  const [formPrestamoId, setFormPrestamoId] = useState("");
  const [formMonto, setFormMonto] = useState<number>(0);
  const [formTipoPago, setFormTipoPago] = useState<"Pago de Cuota" | "Pago Parcial" | "Pago Completo" | "Abono a Capital">("Pago de Cuota");
  const [formNotas, setFormNotas] = useState("");
  const [formFecha, setFormFecha] = useState(new Date().toISOString().split("T")[0]);

  // Estados de Distribución Manual/Política de Mora
  const [useCustomDistribution, setUseCustomDistribution] = useState(false);
  const [manualMoraPago, setManualMoraPago] = useState<number>(0);
  const [manualCuotaPago, setManualCuotaPago] = useState<number>(0);

  // Non-saldado active loans for the dropdown select list
  const activeLoansForSelect = useMemo(() => {
    return prestamos.filter(p => p.estado === "Activo" || p.estado === "Atrasado");
  }, [prestamos]);

  // Selected loan details helper for automatic amount defaults
  const currentSelectedLoan = useMemo(() => {
    if (!formPrestamoId) return null;
    return prestamos.find(p => p.id === formPrestamoId) || null;
  }, [formPrestamoId, prestamos]);

  // Detalles de Mora en Tiempo Real para el Préstamo Seleccionado
  const selectedLoanMoraDetails = useMemo(() => {
    if (!currentSelectedLoan) return { cuotasConMora: [], totalUnpaidMora: 0, totalCuotaNormal: 0 };
    let rawCuotas: CuotaDetalle[] = [];
    try {
      rawCuotas = JSON.parse(currentSelectedLoan.cuotasDetalle || "[]");
    } catch (e) {
      console.error(e);
    }
    const cuotasConMora = actualizarCuotasConMora(
      rawCuotas,
      currentSelectedLoan.tipoMora,
      currentSelectedLoan.valorMora,
      currentSelectedLoan.diasToleranciaMora,
      formFecha,
      configuracion?.moraMaximaMonto
    );
    const totalUnpaidMora = cuotasConMora.reduce((sum, c) => sum + Math.max(0, (c.moraMonto || 0) - (c.moraPagada || 0)), 0);
    const firstUnpaid = cuotasConMora.find(c => c.estado !== "Pagado");
    const totalCuotaNormal = firstUnpaid ? firstUnpaid.monto - firstUnpaid.montoPagado : currentSelectedLoan.montoCuota;
    return { cuotasConMora, totalUnpaidMora, totalCuotaNormal };
  }, [currentSelectedLoan, formFecha, configuracion?.moraMaximaMonto]);

  // Distribución del pago según la política configurada
  const liveDistribution = useMemo(() => {
    const total = Number(formMonto) || 0;
    const totalMora = selectedLoanMoraDetails.totalUnpaidMora;
    const policy = configuracion?.prioridadPagoMora || "mora_first";
    
    let moraApp = 0;
    let cuotaApp = 0;
    
    if (policy === "mora_first") {
      moraApp = Math.min(total, totalMora);
      cuotaApp = Number((total - moraApp).toFixed(2));
    } else if (policy === "cuota_first") {
      const pendingInst = currentSelectedLoan ? Number(currentSelectedLoan.balancePendiente.toFixed(2)) : 0;
      cuotaApp = Math.min(total, pendingInst);
      moraApp = Number((total - cuotaApp).toFixed(2));
      moraApp = Math.min(moraApp, totalMora);
    } else {
      // manual or ask
      moraApp = Math.min(total, totalMora);
      cuotaApp = Number((total - moraApp).toFixed(2));
    }
    
    return { moraApp, cuotaApp };
  }, [formMonto, selectedLoanMoraDetails.totalUnpaidMora, currentSelectedLoan, configuracion?.prioridadPagoMora]);

  // Sincronizar estados de cobro manual con la distribución automática en tiempo real
  useEffect(() => {
    if (!useCustomDistribution) {
      setManualMoraPago(liveDistribution.moraApp);
      setManualCuotaPago(liveDistribution.cuotaApp);
    }
  }, [liveDistribution, useCustomDistribution]);

  // Advanced Filter states
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [tipoPagoFilter, setTipoPagoFilter] = useState("todos"); // 'todos', 'Pago de Cuota', 'Pago Parcial', 'Pago Completo', 'Abono a Capital'
  const [cobradorFilter, setCobradorFilter] = useState("todos");
  const [dateFilter, setDateFilter] = useState("todos"); // 'todos', 'hoy', 'ayer', '7_dias', 'este_mes'
  const [sortBy, setSortBy] = useState("recientes"); // 'recientes', 'monto_desc', 'cliente_asc'

  // Extract unique cobradores present in the list for mobile filtering
  const availableCobradores = useMemo(() => {
    const list: { id: string; nombre: string }[] = [];
    const ids = new Set<string>();
    pagos.forEach(p => {
      if (p.cobradorId && p.cobradorNombre && !ids.has(p.cobradorId)) {
        ids.add(p.cobradorId);
        list.push({ id: p.cobradorId, nombre: p.cobradorNombre });
      }
    });
    return list;
  }, [pagos]);

  // Filter payments
  const filteredPagos = useMemo(() => {
    let result = [...pagos];

    // Search query filter
    const q = searchQuery.toLowerCase().trim();
    if (q) {
      result = result.filter(
        p =>
          p.reciboNo.toLowerCase().includes(q) ||
          p.clienteNombre.toLowerCase().includes(q) ||
          p.prestamoNumero.toLowerCase().includes(q) ||
          p.tipoPago.toLowerCase().includes(q)
      );
    }

    // Payment Type Filter
    if (tipoPagoFilter !== "todos") {
      result = result.filter(p => p.tipoPago === tipoPagoFilter);
    }

    // Cobrador Filter
    if (cobradorFilter !== "todos") {
      result = result.filter(p => p.cobradorId === cobradorFilter);
    }

    // Date Filter
    if (dateFilter !== "todos") {
      const today = new Date();
      const todayStr = today.toISOString().split("T")[0];
      
      const yesterday = new Date();
      yesterday.setDate(today.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split("T")[0];

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(today.getDate() - 7);
      
      const firstOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

      result = result.filter(p => {
        const paymentDate = p.fecha.split("T")[0];
        
        if (dateFilter === "hoy") {
          return paymentDate === todayStr;
        }
        if (dateFilter === "ayer") {
          return paymentDate === yesterdayStr;
        }
        if (dateFilter === "7_dias") {
          const d = new Date(p.fecha);
          return d >= sevenDaysAgo;
        }
        if (dateFilter === "este_mes") {
          const d = new Date(p.fecha);
          return d >= firstOfMonth;
        }
        return true;
      });
    }

    // Sorting
    result.sort((a, b) => {
      if (sortBy === "recientes") {
        // High receipt numbers first, or descending timestamp
        const dateA = new Date(a.fecha).getTime();
        const dateB = new Date(b.fecha).getTime();
        return dateB - dateA || b.reciboNo.localeCompare(a.reciboNo);
      }
      if (sortBy === "monto_desc") {
        return b.monto - a.monto;
      }
      if (sortBy === "cliente_asc") {
        return a.clienteNombre.localeCompare(b.clienteNombre);
      }
      return 0;
    });

    return result;
  }, [pagos, searchQuery, tipoPagoFilter, cobradorFilter, dateFilter, sortBy]);

  // Handle loan selection changes and load default amounts
  const handleLoanChange = (loanId: string) => {
    setFormPrestamoId(loanId);
    const loan = prestamos.find(p => p.id === loanId);
    if (loan) {
      if (formTipoPago === "Pago de Cuota") {
        setFormMonto(loan.montoCuota);
      } else if (formTipoPago === "Pago Completo") {
        setFormMonto(loan.balancePendiente);
      } else if (formTipoPago === "Pago Parcial") {
        setFormMonto(Math.round(loan.montoCuota / 2));
      } else {
        setFormMonto(1000); // default abono
      }
    }
  };

  // Adjust default amount based on type
  const handleTipoPagoChange = (tipo: any) => {
    setFormTipoPago(tipo);
    if (currentSelectedLoan) {
      if (tipo === "Pago de Cuota") {
        setMontoWithBounds(currentSelectedLoan.montoCuota);
      } else if (tipo === "Pago Completo") {
        setMontoWithBounds(currentSelectedLoan.balancePendiente);
      } else if (tipo === "Pago Parcial") {
        setMontoWithBounds(Math.round(currentSelectedLoan.montoCuota / 2));
      } else {
        setMontoWithBounds(Math.round(currentSelectedLoan.capitalPrestado * 0.1)); // 10% principal
      }
    }
  };

  const setMontoWithBounds = (val: number) => {
    if (currentSelectedLoan && val > currentSelectedLoan.balancePendiente) {
      setFormMonto(currentSelectedLoan.balancePendiente);
    } else {
      setFormMonto(val);
    }
  };

  // Register payment submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formPrestamoId || formMonto <= 0) {
      alert("Por favor seleccione un préstamo y especifique un monto válido.");
      return;
    }

    const loan = currentSelectedLoan;
    if (!loan) return;

    // Use calculated real-time late fees
    const { cuotasConMora, totalUnpaidMora } = selectedLoanMoraDetails;
    const maxPermitido = Number((loan.balancePendiente + totalUnpaidMora).toFixed(2));

    if (formMonto > maxPermitido) {
      alert(`El monto no puede exceder el total pendiente del préstamo incluyendo recargos (${formatCurrency(maxPermitido, moneda)})`);
      return;
    }

    // Determine the split between Mora and scheduled installment
    let moraPagado = useCustomDistribution ? Number(manualMoraPago) : liveDistribution.moraApp;
    let cuotaPagado = useCustomDistribution ? Number(manualCuotaPago) : liveDistribution.cuotaApp;

    // Double check that split sums to formMonto
    const calculatedSum = Number((moraPagado + cuotaPagado).toFixed(2));
    if (Math.abs(calculatedSum - formMonto) > 0.02) {
      // Re-normalize if floating errors occur
      cuotaPagado = Number((formMonto - moraPagado).toFixed(2));
    }

    // POLICY FLOW: "Cobrar solo la cuota" (Omitting Mora) warning
    if (totalUnpaidMora > 0 && moraPagado < totalUnpaidMora) {
      if (configuracion?.requerirAutorizacionOmitir) {
        const pin = prompt(`AUTORIZACIÓN REQUERIDA: Este cliente tiene una mora acumulada de ${formatCurrency(totalUnpaidMora, moneda)}.\nIntroduzca la clave de Administrador o Supervisor para omitir cobrar la mora y registrar solo la cuota:`);
        if (pin !== "1234" && pin !== "admin") {
          alert("Clave de seguridad inválida. No tiene autorización para omitir el recargo de mora.");
          return;
        }
      } else {
        const confirmOmit = window.confirm(
          `Este cliente tiene una mora pendiente de ${formatCurrency(totalUnpaidMora, moneda)}.\n¿Desea cobrar solamente la cuota y dejar la mora pendiente para futuras visitas?`
        );
        if (!confirmOmit) {
          return;
        }
      }
    }

    const reciboNo = generateRandomCode("REC");
    const balanceAntes = loan.balancePendiente;

    // Allocate payment across individual installments
    let capitalPagado = 0;
    let interesPagado = 0;
    let remainingMoraToDistribute = moraPagado;
    let remainingCuotaToDistribute = cuotaPagado;

    const updatedCuotas = cuotasConMora.map(c => {
      // 1. Pay pending late fee for this installment first
      const unpaidMoraInCuota = Math.max(0, (c.moraMonto || 0) - (c.moraPagada || 0));
      let currentCuotaMoraPaid = 0;
      if (unpaidMoraInCuota > 0 && remainingMoraToDistribute > 0) {
        currentCuotaMoraPaid = Math.min(remainingMoraToDistribute, unpaidMoraInCuota);
        remainingMoraToDistribute = Number((remainingMoraToDistribute - currentCuotaMoraPaid).toFixed(2));
      }

      // 2. Pay scheduled installment amount
      const cuotaPending = c.monto - c.montoPagado;
      let currentCuotaAmtPaid = 0;
      if (cuotaPending > 0 && remainingCuotaToDistribute > 0) {
        currentCuotaAmtPaid = Math.min(remainingCuotaToDistribute, cuotaPending);
        remainingCuotaToDistribute = Number((remainingCuotaToDistribute - currentCuotaAmtPaid).toFixed(2));
        
        // Calculate capital and interest ratios paid
        const ratio = currentCuotaAmtPaid / c.monto;
        capitalPagado += c.capital * ratio;
        interesPagado += c.interes * ratio;
      }

      const totalMontoPagado = Number((c.montoPagado + currentCuotaAmtPaid).toFixed(2));
      const totalMoraPagada = Number(((c.moraPagada || 0) + currentCuotaMoraPaid).toFixed(2));

      let finalEstado: "Pagado" | "Pendiente" | "Parcial" = c.estado;
      if (totalMontoPagado >= c.monto) {
        finalEstado = "Pagado";
      } else if (totalMontoPagado > 0) {
        finalEstado = "Parcial";
      }

      return {
        ...c,
        montoPagado: totalMontoPagado,
        moraPagada: totalMoraPagada,
        estado: finalEstado
      };
    });

    capitalPagado = Number(capitalPagado.toFixed(2));
    interesPagado = Number(interesPagado.toFixed(2));
    moraPagado = Number(moraPagado.toFixed(2));

    // Scheduled balance (representing outstanding principal) decreases strictly by capital component paid
    const balanceDespues = Number(Math.max(0, balanceAntes - capitalPagado).toFixed(2));

    // Determine new state of loan
    let nuevoEstado = loan.estado;
    if (balanceDespues <= 0) {
      nuevoEstado = "Saldado";
    }

    // Find next pending cuota date
    const nextPending = updatedCuotas.find(c => c.estado !== "Pagado");
    const proximaCuotaFecha = nextPending ? nextPending.fechaVence : loan.fechaVencimiento;

    const updatedLoan: Prestamo = {
      ...loan,
      balancePendiente: balanceDespues,
      estado: nuevoEstado,
      proximaCuotaFecha,
      cuotasDetalle: JSON.stringify(updatedCuotas)
    };

    const newPago: Pago = {
      reciboNo,
      prestamoId: formPrestamoId,
      clienteId: loan.clienteId,
      clienteNombre: loan.clienteNombre,
      prestamoNumero: loan.numero,
      fecha: formFecha + "T" + new Date().toTimeString().split(" ")[0],
      monto: formMonto,
      tipoPago: formTipoPago,
      capitalPagado,
      interesPagado,
      moraPagado,
      balanceAntes,
      balanceDespues,
      notas: formNotas,
      cobradorId: currentUserProfile?.email || "",
      cobradorNombre: currentUserProfile?.nombre || "Cobrador de Oficina"
    };

    try {
      await onSavePago(newPago, updatedLoan);
      setIsAdding(false);
      setReceiptPrint(newPago); // Automatically show thermal receipt print preview!
      // reset forms
      setFormPrestamoId("");
      setFormMonto(0);
      setFormNotas("");
    } catch (e) {
      console.error(e);
      alert("Error guardando el pago");
    }
  };

  // WhatsApp link generator
  const getWhatsAppShareLink = (pago: Pago) => {
    const selectedCli = clientes.find(c => c.id === pago.clienteId);
    const telefono = selectedCli ? selectedCli.telefono.replace(/\D/g, "") : "";
    const text = encodeURIComponent(
      `*EasyPres - Recibo de Pago*\n` +
      `---------------------------------\n` +
      `*Recibo Nro:* ${pago.reciboNo}\n` +
      `*Cliente:* ${pago.clienteNombre}\n` +
      `*Préstamo:* ${pago.prestamoNumero}\n` +
      `*Fecha:* ${new Date(pago.fecha).toLocaleDateString("es-ES")}\n` +
      `*Tipo:* ${pago.tipoPago}\n` +
      `*Monto Pagado:* ${formatCurrency(pago.monto, moneda)}\n` +
      `---------------------------------\n` +
      `*Balance Anterior:* ${formatCurrency(pago.balanceAntes, moneda)}\n` +
      `*Nuevo Balance:* ${formatCurrency(pago.balanceDespues, moneda)}\n` +
      `\n_¡Gracias por su puntualidad!_`
    );
    return `https://api.whatsapp.com/send?phone=${telefono}&text=${text}`;
  };

  return (
    <div className="space-y-6" id="pagos-module-view">
      
      {/* 1. Register Payment overlay */}
      {isAdding && (
        <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-md max-w-xl mx-auto animate-fade-in">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <CreditCard className="text-emerald-500" /> Registrar Nuevo Cobro
            </h2>
            <button onClick={() => setIsAdding(false)} className="p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400">
              <X size={18} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Préstamo Vigente *</label>
              <select
                value={formPrestamoId}
                onChange={e => handleLoanChange(e.target.value)}
                required
                className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold"
              >
                <option value="">Seleccione contrato activo...</option>
                {activeLoansForSelect.map(l => (
                  <option key={l.id} value={l.id}>
                    {l.clienteNombre} - {l.numero} (Pendiente: {formatCurrency(l.balancePendiente, moneda)})
                  </option>
                ))}
              </select>
            </div>

            {currentSelectedLoan && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3 p-3 bg-zinc-50 dark:bg-zinc-900 rounded-xl text-xs font-mono">
                  <p><strong>Monto Cuota Normal:</strong> {formatCurrency(currentSelectedLoan.montoCuota, moneda)}</p>
                  <p><strong>Balance Restante:</strong> {formatCurrency(currentSelectedLoan.balancePendiente, moneda)}</p>
                </div>

                {/* ADVISORY CARD: Late fees detected */}
                {selectedLoanMoraDetails.totalUnpaidMora > 0 && (
                  <div className="bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 p-4 rounded-xl space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-extrabold uppercase tracking-wider text-[11px]">
                      <span className="text-sm">⚠️</span> Cliente con mora acumulada
                    </div>
                    <div className="grid grid-cols-2 gap-y-1.5 font-semibold text-zinc-600 dark:text-zinc-300">
                      <span>Cuota del día:</span>
                      <span className="text-right text-zinc-900 dark:text-white font-extrabold">{formatCurrency(selectedLoanMoraDetails.totalCuotaNormal, moneda)}</span>
                      <span>Mora acumulada:</span>
                      <span className="text-right text-rose-500 font-extrabold">+{formatCurrency(selectedLoanMoraDetails.totalUnpaidMora, moneda)}</span>
                      
                      <div className="col-span-2 border-t border-rose-200/50 dark:border-rose-900/40 my-1"></div>

                      <span className="text-zinc-950 dark:text-white font-black uppercase text-[10px]">Total recomendado a cobrar:</span>
                      <span className="text-right text-emerald-600 dark:text-emerald-400 font-black text-sm">
                        {formatCurrency(Number((selectedLoanMoraDetails.totalCuotaNormal + selectedLoanMoraDetails.totalUnpaidMora).toFixed(2)), moneda)}
                      </span>
                    </div>
                  </div>
                )}

                {/* DISTRIBUTION BREAKDOWN PANEL */}
                <div className="p-3.5 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-100 dark:border-zinc-800 rounded-xl space-y-2.5 text-xs">
                  <div className="flex justify-between items-center pb-1.5 border-b border-zinc-200/50 dark:border-zinc-800">
                    <span className="font-bold text-gray-700 dark:text-zinc-300">Distribución de Fondos:</span>
                    <button
                      type="button"
                      onClick={() => setUseCustomDistribution(!useCustomDistribution)}
                      className="text-[10px] text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 font-bold uppercase tracking-wide border border-emerald-200 dark:border-emerald-900 px-2 py-0.5 rounded"
                    >
                      {useCustomDistribution ? "Usar Automática" : "Ajustar Manual"}
                    </button>
                  </div>

                  {useCustomDistribution ? (
                    <div className="grid grid-cols-2 gap-3 pt-1 animate-fade-in">
                      <div>
                        <label className="block text-[10px] text-gray-400 uppercase font-semibold mb-1">Aplicar a Mora ({moneda})</label>
                        <input
                          type="number"
                          step="any"
                          min="0"
                          max={selectedLoanMoraDetails.totalUnpaidMora}
                          value={manualMoraPago}
                          onChange={e => {
                            const val = Math.max(0, Number(e.target.value));
                            setManualMoraPago(val);
                            setManualCuotaPago(Math.max(0, Number((formMonto - val).toFixed(2))));
                          }}
                          className="w-full px-2.5 py-1.5 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded font-mono font-bold text-rose-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-gray-400 uppercase font-semibold mb-1">Aplicar a Cuota ({moneda})</label>
                        <input
                          type="number"
                          step="any"
                          min="0"
                          value={manualCuotaPago}
                          onChange={e => {
                            const val = Math.max(0, Number(e.target.value));
                            setManualCuotaPago(val);
                            setManualMoraPago(Math.max(0, Number((formMonto - val).toFixed(2))));
                          }}
                          className="w-full px-2.5 py-1.5 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded font-mono font-bold text-emerald-600"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-y-1 text-gray-500">
                      <span>Mora abonada:</span>
                      <span className="text-right font-mono font-extrabold text-rose-500">+{formatCurrency(liveDistribution.moraApp, moneda)}</span>
                      <span>Cuota/Capital abonado:</span>
                      <span className="text-right font-mono font-extrabold text-emerald-600">{formatCurrency(liveDistribution.cuotaApp, moneda)}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Concepto / Tipo de Cobro</label>
                <select
                  value={formTipoPago}
                  onChange={e => handleTipoPagoChange(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold"
                >
                  <option value="Pago de Cuota">Pago de Cuota Normal</option>
                  <option value="Pago Parcial">Abono Parcial a Cuota</option>
                  <option value="Pago Completo">Saldar Préstamo Completo</option>
                  <option value="Abono a Capital">Abono Extraordinario a Capital</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Monto a Cobrar *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">{moneda}</span>
                  <input
                    type="number"
                    step="any"
                    required
                    min={1}
                    value={formMonto}
                    onChange={e => setMontoWithBounds(Number(e.target.value))}
                    className="w-full pl-8 pr-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-extrabold text-sm text-emerald-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Fecha Recibo</label>
                <input
                  type="date"
                  value={formFecha}
                  onChange={e => setFormFecha(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Notas / Comentarios</label>
                <input
                  type="text"
                  placeholder="Ej: Pago de cuota 3 sin mora"
                  value={formNotas}
                  onChange={e => setFormNotas(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 border rounded-xl text-xs hover:bg-zinc-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700"
              >
                Procesar Cobro e Imprimir
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 2. Receipt Thermal/Standard printing overlay preview */}
      {receiptPrint && (
        <div className="fixed inset-0 bg-black/70 z-50 flex justify-center items-center p-3 overflow-y-auto">
          <div className="bg-white text-zinc-900 max-w-sm w-full p-4 sm:p-5 rounded-xl shadow-2xl relative border-t-4 border-emerald-500 font-mono text-xs">
            {/* Tear-off serrated top/bottom look represented by a dashed accent */}
            <div className="absolute -top-2.5 left-0 right-0 flex justify-between px-2 text-zinc-300 pointer-events-none font-sans text-[10px]">
              ••••••••••••••••••••••••••••••••••••••••••
            </div>
            
            <button
              onClick={() => setReceiptPrint(null)}
              className="absolute top-2 right-2 p-1 text-gray-400 hover:text-black print:hidden rounded-full hover:bg-zinc-100 transition-colors"
            >
              <X size={15} />
            </button>

            {/* Thermal Slip Content */}
            <div className="text-center space-y-0.5 mb-3 border-b border-dashed border-zinc-200 pb-2.5">
              <h2 className="text-sm font-black uppercase tracking-tight text-zinc-900">EASYPRES FINANZAS</h2>
              <p className="text-[9px] font-bold text-emerald-600 tracking-wider">COMPROBANTE DE TRANSACCIÓN</p>
              <p className="text-[8px] text-gray-450">Tel: 809-555-0199 • Santo Domingo, RD</p>
            </div>

            <div className="space-y-1.5 border-b border-dashed border-zinc-200 pb-2.5 text-[10px] sm:text-[11px] text-zinc-800">
              <div className="flex justify-between">
                <span className="text-zinc-400">RECIBO NRO:</span>
                <span className="font-bold text-zinc-900">{receiptPrint.reciboNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">CLIENTE:</span>
                <span className="font-bold text-zinc-900 text-right max-w-[170px] truncate">{receiptPrint.clienteNombre}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">CONTRATO:</span>
                <span className="font-bold text-zinc-900">{receiptPrint.prestamoNumero}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">FECHA:</span>
                <span className="font-bold text-zinc-900">{new Date(receiptPrint.fecha).toLocaleString("es-ES", { dateStyle: "short", timeStyle: "short" })}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">TIPO DE PAGO:</span>
                <span className="font-extrabold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded text-[9px]">{receiptPrint.tipoPago}</span>
              </div>
            </div>

            <div className="py-2.5 border-b border-dashed border-zinc-200 text-[10px] sm:text-[11px] space-y-1.5">
              <div className="flex justify-between text-zinc-600">
                <span>Imputado a Capital:</span>
                <span>{formatCurrency(receiptPrint.capitalPagado, moneda)}</span>
              </div>
              <div className="flex justify-between text-zinc-600">
                <span>Imputado a Interés:</span>
                <span>{formatCurrency(receiptPrint.interesPagado, moneda)}</span>
              </div>
              <div className="flex justify-between text-zinc-600">
                <span>Mora / Recargos:</span>
                <span className={receiptPrint.moraPagado && receiptPrint.moraPagado > 0 ? "text-rose-500 font-bold" : ""}>
                  {formatCurrency(receiptPrint.moraPagado || 0, moneda)}
                </span>
              </div>
              <div className="flex justify-between font-black text-xs sm:text-sm pt-2 border-t border-dashed border-zinc-200 text-zinc-900">
                <span>MONTO PAGADO:</span>
                <span className="text-emerald-600">{formatCurrency(receiptPrint.monto, moneda)}</span>
              </div>
            </div>

            <div className="py-2 text-[9px] sm:text-[10px] space-y-1 text-zinc-500 border-b border-dashed border-zinc-200 mb-2.5 bg-zinc-50/50 p-2 rounded-lg">
              <div className="flex justify-between">
                <span>Balance anterior:</span>
                <span>{formatCurrency(receiptPrint.balanceAntes, moneda)}</span>
              </div>
              <div className="flex justify-between font-bold text-zinc-800">
                <span>Balance restante:</span>
                <span>{formatCurrency(receiptPrint.balanceDespues, moneda)}</span>
              </div>
            </div>

            {/* Simulated barcode / stamp */}
            <div className="flex flex-col items-center justify-center space-y-0.5 py-0.5 mb-2.5">
              <div className="font-mono text-[8px] text-zinc-300 tracking-[0.2em] select-none">
                ||||||| | ||||| |||| | ||| ||||||| | |||
              </div>
              <p className="text-[7px] text-zinc-450 uppercase tracking-widest">SOPORTE DIGITAL VERIFICADO</p>
            </div>

            <div className="text-center text-[9px] text-zinc-400 mb-3 border-t border-zinc-100 pt-2">
              <p>¡Gracias por mantener su firma!</p>
              <p className="text-[8px] mt-0.5 text-zinc-300">EasyPres System • Transacción Segura</p>
            </div>

            {/* Print & share controls */}
            <div className="flex gap-2 print:hidden">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 bg-zinc-900 hover:bg-black text-white text-[10px] sm:text-[11px] font-bold rounded-lg flex items-center justify-center gap-1 transition-all shadow-sm"
              >
                <Printer size={12} /> Imprimir
              </button>
              <a
                href={getWhatsAppShareLink(receiptPrint)}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2 bg-emerald-650 hover:bg-emerald-700 text-white text-[10px] sm:text-[11px] font-bold rounded-lg flex items-center justify-center gap-1 transition-all shadow-sm"
              >
                <Share2 size={12} /> WhatsApp
              </a>
            </div>

            <div className="absolute -bottom-2.5 left-0 right-0 flex justify-between px-2 text-zinc-300 pointer-events-none font-sans text-[10px]">
              ••••••••••••••••••••••••••••••••••••••••••
            </div>
          </div>
        </div>
      )}

      {/* 3. Payments Main Grid/Table list view */}
      {!isAdding && (
        <>
          {selectedPago ? (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800/80 rounded-2xl p-5 md:p-6 shadow-md space-y-6 animate-fade-in">
              <button
                onClick={() => setSelectedPago(null)}
                className="flex items-center gap-1.5 text-xs font-black text-zinc-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
              >
                <ArrowLeft size={14} className="stroke-[2.5]" /> Volver a la lista
              </button>

              {/* Enhanced Interactive Digital Voucher */}
              <div className="relative border border-zinc-100 dark:border-zinc-800/80 rounded-2xl overflow-hidden bg-gradient-to-b from-zinc-50/50 to-white dark:from-zinc-950/20 dark:to-zinc-900/10">
                {/* Glowing status accent bar */}
                <div className="h-2 bg-emerald-500 w-full" />
                
                {/* Content area */}
                <div className="p-5 md:p-6 space-y-6">
                  {/* Voucher Header */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-zinc-100 dark:border-zinc-800/50 pb-5">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/30 flex items-center justify-center text-emerald-500 shrink-0">
                        <ShieldCheck size={26} className="stroke-[2]" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-mono text-[10px] font-black uppercase tracking-wider">
                            {selectedPago.reciboNo}
                          </span>
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 border border-emerald-500/10">
                            <span className="w-1 h-1 rounded-full bg-emerald-500"></span>
                            Procesado
                          </span>
                        </div>
                        <h2 className="text-base font-black text-zinc-900 dark:text-zinc-100 tracking-tight mt-1">Comprobante de Pago Electrónico</h2>
                        <p className="text-[10px] text-zinc-400 font-semibold mt-0.5 flex items-center gap-1">
                          <Clock size={11} /> {new Date(selectedPago.fecha).toLocaleString("es-ES")}
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-2 w-full sm:w-auto shrink-0">
                      {canExport && (
                        <>
                          <button
                            onClick={() => setReceiptPrint(selectedPago)}
                            className="flex-1 sm:flex-initial px-4 py-2 bg-zinc-900 hover:bg-black text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                          >
                            <Printer size={13} /> Re-imprimir Ticket
                          </button>
                          <a
                            href={getWhatsAppShareLink(selectedPago)}
                            target="_blank"
                            rel="noreferrer"
                            className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm"
                          >
                            <Share2 size={13} /> WhatsApp
                          </a>
                        </>
                      )}
                    </div>
                  </div>

                  {/* 3-Column Detailed Information Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Col 1: Customer Details */}
                    <div className="bg-white dark:bg-[#151518] p-4 border border-zinc-100 dark:border-zinc-800/60 rounded-xl space-y-3 shadow-sm">
                      <span className="flex items-center gap-1 text-[9px] text-zinc-400 dark:text-zinc-500 uppercase font-bold tracking-wider">
                        <User size={12} className="text-emerald-500" />
                        Cliente y Contrato
                      </span>
                      <div className="space-y-1">
                        <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-50">{selectedPago.clienteNombre}</h4>
                        <p className="text-[10px] text-zinc-400 font-mono">ID de Contrato: <span className="font-bold text-zinc-700 dark:text-zinc-300">{selectedPago.prestamoNumero}</span></p>
                        {selectedPago.cobradorNombre && (
                          <p className="text-[10px] text-zinc-400 mt-1">Registrado por: <span className="font-semibold text-zinc-650 dark:text-zinc-350">{selectedPago.cobradorNombre}</span></p>
                        )}
                      </div>
                    </div>

                    {/* Col 2: Amortization Breakdown */}
                    <div className="bg-white dark:bg-[#151518] p-4 border border-zinc-100 dark:border-zinc-800/60 rounded-xl space-y-3 shadow-sm">
                      <span className="flex items-center gap-1 text-[9px] text-zinc-400 dark:text-zinc-500 uppercase font-bold tracking-wider">
                        <Coins size={12} className="text-blue-500" />
                        Desglose de Amortización
                      </span>
                      <div className="text-[11px] space-y-1.5 text-zinc-600 dark:text-zinc-400">
                        <div className="flex justify-between">
                          <span>Capital Amortizado:</span>
                          <span className="font-bold text-zinc-800 dark:text-zinc-200">{formatCurrency(selectedPago.capitalPagado, moneda)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Interés Pagado:</span>
                          <span className="font-bold text-zinc-800 dark:text-zinc-200">{formatCurrency(selectedPago.interesPagado, moneda)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Recargo por Mora:</span>
                          <span className={`font-bold ${selectedPago.moraPagado && selectedPago.moraPagado > 0 ? "text-rose-500" : ""}`}>
                            {formatCurrency(selectedPago.moraPagado || 0, moneda)}
                          </span>
                        </div>
                        <div className="flex justify-between font-black text-emerald-600 dark:text-emerald-400 pt-2 border-t border-zinc-150/40 dark:border-zinc-800/40 text-[13px]">
                          <span>Total Recibido:</span>
                          <span>{formatCurrency(selectedPago.monto, moneda)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Col 3: Balances Tracker */}
                    <div className="bg-white dark:bg-[#151518] p-4 border border-zinc-100 dark:border-zinc-800/60 rounded-xl space-y-3 shadow-sm">
                      <span className="flex items-center gap-1 text-[9px] text-zinc-400 dark:text-zinc-500 uppercase font-bold tracking-wider">
                        <TrendingDown size={12} className="text-amber-500" />
                        Seguimiento de Balances
                      </span>
                      <div className="text-[11px] space-y-1.5 text-zinc-600 dark:text-zinc-400">
                        <div className="flex justify-between">
                          <span>Balance Anterior:</span>
                          <span className="font-bold text-zinc-500">{formatCurrency(selectedPago.balanceAntes, moneda)}</span>
                        </div>
                        <div className="flex justify-between font-bold text-zinc-800 dark:text-zinc-100">
                          <span>Nuevo Balance:</span>
                          <span className="text-rose-600 dark:text-rose-400">{formatCurrency(selectedPago.balanceDespues, moneda)}</span>
                        </div>
                        
                        {/* Balance Reduction visual slider bar */}
                        <div className="pt-2">
                          <div className="flex justify-between text-[8px] text-zinc-400 font-bold uppercase mb-1">
                            <span>Reducción de Deuda</span>
                            <span className="text-emerald-600">-{Math.round(((selectedPago.balanceAntes - selectedPago.balanceDespues) / (selectedPago.balanceAntes || 1)) * 100)}%</span>
                          </div>
                          <div className="w-full bg-zinc-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden flex">
                            <div 
                              className="bg-emerald-500 h-2 rounded-full" 
                              style={{ width: `${Math.min(100, Math.max(5, Math.round((1 - (selectedPago.balanceDespues / (selectedPago.balanceAntes || 1))) * 100)))}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Notes / Metadata block */}
                  {selectedPago.notas && (
                    <div className="p-3 bg-zinc-50/50 dark:bg-zinc-900/30 border border-zinc-150/40 dark:border-zinc-800/40 rounded-xl text-[10px] text-zinc-400 leading-relaxed italic">
                      <span className="font-bold uppercase not-italic text-[9px] text-zinc-500 block mb-0.5">Notas / Comentarios de Ruta:</span>
                      {selectedPago.notas}
                    </div>
                  )}
                </div>
              </div>

            </div>
          ) : (
            // Full payments list
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl shadow-sm overflow-hidden animate-fade-in">
              <div className="p-5 flex flex-col sm:flex-row justify-between items-center gap-4 border-b border-gray-100 dark:border-zinc-800">
                <div className="flex w-full sm:w-auto items-center gap-2">
                  <div className="relative flex-1 sm:w-72">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 pointer-events-none">
                      <Search size={16} />
                    </span>
                    <input
                      type="text"
                      placeholder="Buscar recibos por número, cliente o contrato..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 border rounded-xl bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-xs"
                    />
                  </div>
                  <button
                    onClick={() => setIsFilterSheetOpen(true)}
                    className="p-2 border rounded-xl bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-gray-500 hover:text-emerald-500 hover:border-emerald-500/30 transition-all relative cursor-pointer active:scale-95"
                    title="Filtros avanzados"
                  >
                    <SlidersHorizontal size={16} />
                    {(tipoPagoFilter !== "todos" || cobradorFilter !== "todos" || dateFilter !== "todos" || sortBy !== "recientes") && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-white dark:border-zinc-950" />
                    )}
                  </button>
                </div>
                {canCreate && (
                  <button
                    onClick={() => setIsAdding(true)}
                    className="w-full sm:w-auto px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus size={16} /> Registrar Cobro / Pago
                  </button>
                )}
              </div>

              {filteredPagos.length === 0 ? (
                <div className="p-12 text-center text-gray-400 text-xs">
                  No se han registrado transacciones de pago en el historial.
                </div>
              ) : (
                <>
                  {/* Desktop view: Full table */}
                  <div className="hidden md:block overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-zinc-50/50 dark:bg-zinc-900/50 text-gray-400 font-semibold border-b border-gray-100 dark:border-zinc-800 uppercase tracking-wider">
                          <th className="p-4">Nro. Recibo</th>
                          <th className="p-4">Cliente</th>
                          <th className="p-4">Préstamo</th>
                          <th className="p-4">Fecha Pago</th>
                          <th className="p-4">Concepto</th>
                          <th className="p-4 text-right">Amort. Capital</th>
                          <th className="p-4 text-right">Recargo Mora</th>
                          <th className="p-4 text-right font-bold text-emerald-600">Monto</th>
                          <th className="p-4 text-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                        {filteredPagos.map(p => (
                          <tr key={p.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/20">
                            <td className="p-4 font-mono font-bold text-zinc-700 dark:text-zinc-300">{p.reciboNo}</td>
                            <td className="p-4 font-semibold">{p.clienteNombre}</td>
                            <td className="p-4 font-mono text-zinc-400">{p.prestamoNumero}</td>
                            <td className="p-4">{new Date(p.fecha).toLocaleDateString("es-ES")}</td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold
                                ${p.tipoPago === "Pago Completo" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400" : ""}
                                ${p.tipoPago === "Pago de Cuota" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" : ""}
                                ${p.tipoPago === "Pago Parcial" ? "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400" : ""}
                                ${p.tipoPago === "Abono a Capital" ? "bg-purple-100 text-purple-800 dark:bg-purple-950/40 dark:text-purple-400" : ""}
                              `}>
                                {p.tipoPago}
                              </span>
                            </td>
                            <td className="p-4 text-right">{formatCurrency(p.capitalPagado, moneda)}</td>
                            <td className="p-4 text-right text-rose-500 font-medium">{p.moraPagado && p.moraPagado > 0 ? formatCurrency(p.moraPagado, moneda) : "-"}</td>
                            <td className="p-4 text-right font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(p.monto, moneda)}</td>
                            <td className="p-4 text-center">
                              <div className="flex justify-center gap-1.5">
                                <button
                                  onClick={() => setSelectedPago(p)}
                                  className="p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-lg text-gray-500 hover:text-emerald-500"
                                  title="Ver detalles del desglose"
                                >
                                  <Eye size={15} />
                                </button>
                                {canExport && (
                                  <button
                                    onClick={() => setReceiptPrint(p)}
                                    className="p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-lg text-gray-500 hover:text-blue-500"
                                    title="Imprimir soporte térmico"
                                  >
                                    <Printer size={15} />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile view: Compact payment cards */}
                  <div className="block md:hidden p-2.5 space-y-2.5 bg-zinc-50/50 dark:bg-zinc-950/10">
                    {filteredPagos.map(p => {
                      // Determine border left color based on payment concept
                      const borderCol = 
                        p.tipoPago === "Pago Completo" ? "border-l-4 border-l-blue-500" :
                        p.tipoPago === "Pago de Cuota" ? "border-l-4 border-l-emerald-500" :
                        p.tipoPago === "Pago Parcial" ? "border-l-4 border-l-amber-500" :
                        "border-l-4 border-l-purple-500";

                      return (
                        <div 
                          key={p.id} 
                          className={`bg-white dark:bg-[#121214] border border-zinc-150/50 dark:border-zinc-800/80 rounded-xl p-3 shadow-xs space-y-2.5 hover:shadow-sm transition-all ${borderCol}`}
                        >
                          <div className="flex justify-between items-start gap-2">
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-[8px] font-mono font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">
                                  {p.reciboNo}
                                </span>
                                <span className="text-[9px] font-mono text-zinc-400">
                                  Contrato: <strong className="text-zinc-600 dark:text-zinc-300">{p.prestamoNumero}</strong>
                                </span>
                              </div>
                              <h4 className="font-bold text-[13px] text-zinc-950 dark:text-zinc-50 mt-0.5">{p.clienteNombre}</h4>
                            </div>
                            
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider shrink-0
                              ${p.tipoPago === "Pago Completo" ? "bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400" : ""}
                              ${p.tipoPago === "Pago de Cuota" ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400" : ""}
                              ${p.tipoPago === "Pago Parcial" ? "bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400" : ""}
                              ${p.tipoPago === "Abono a Capital" ? "bg-purple-50 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400" : ""}
                            `}>
                              {p.tipoPago}
                            </span>
                          </div>

                          {/* Quick sub-totals row in a single compact line */}
                          <div className="grid grid-cols-2 gap-2 text-[10px]">
                            <div className="bg-zinc-50/50 dark:bg-zinc-900/20 py-1 px-2 rounded-lg border border-zinc-100/30 dark:border-zinc-800/20 flex justify-between items-center">
                              <span className="text-[8px] text-zinc-400 uppercase font-bold tracking-wider">Amort.</span>
                              <span className="font-bold text-zinc-800 dark:text-zinc-200">{formatCurrency(p.capitalPagado, moneda)}</span>
                            </div>
                            <div className="bg-zinc-50/50 dark:bg-zinc-900/20 py-1 px-2 rounded-lg border border-zinc-100/30 dark:border-zinc-800/20 flex justify-between items-center">
                              <span className="text-[8px] text-rose-455 uppercase font-bold tracking-wider">Mora</span>
                              <span className={`font-bold ${p.moraPagado && p.moraPagado > 0 ? "text-rose-500 font-extrabold" : "text-zinc-400"}`}>
                                {p.moraPagado && p.moraPagado > 0 ? formatCurrency(p.moraPagado, moneda) : "-"}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-zinc-100/60 dark:border-zinc-900/40">
                            <div>
                              <span className="text-[9px] text-zinc-400 block font-mono">
                                {new Date(p.fecha).toLocaleDateString("es-ES")} • {new Date(p.fecha).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                              </span>
                              <p className="font-black text-emerald-600 dark:text-emerald-400 text-sm mt-0.5">{formatCurrency(p.monto, moneda)}</p>
                            </div>
                            
                            <div className="flex gap-1.5 shrink-0">
                              <button
                                onClick={() => setSelectedPago(p)}
                                className="min-h-[32px] px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:hover:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 font-bold transition-all text-[10px] flex items-center justify-center gap-1"
                              >
                                <Eye size={12} className="stroke-[2.5]" /> Detalle
                              </button>
                              {canExport && (
                                <button
                                  onClick={() => setReceiptPrint(p)}
                                  className="min-h-[32px] px-2.5 py-1 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-750 text-zinc-700 dark:text-zinc-200 font-bold transition-all text-[10px] flex items-center justify-center gap-1"
                                >
                                  <Printer size={12} /> Recibo
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          )}
        </>
      )}

      {/* Mobile Filter Bottom Sheet */}
      <FilterBottomSheet
        isOpen={isFilterSheetOpen}
        onClose={() => setIsFilterSheetOpen(false)}
        title="Filtros de Pagos"
        onClear={() => {
          setTipoPagoFilter("todos");
          setCobradorFilter("todos");
          setDateFilter("todos");
          setSortBy("recientes");
        }}
      >
        <div className="space-y-4">
          {/* Ordenamiento */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Ordenar por
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "recientes", label: "Fecha (Recientes)" },
                { id: "monto_desc", label: "Monto (Mayor)" },
                { id: "cliente_asc", label: "Cliente (A-Z)" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setSortBy(opt.id)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                    sortBy === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro de Tipo de Pago */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Tipo de Pago
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "todos", label: "Todos" },
                { id: "Pago de Cuota", label: "Cuota ordinaria" },
                { id: "Pago Parcial", label: "Pago parcial" },
                { id: "Pago Completo", label: "Pago completo" },
                { id: "Abono a Capital", label: "Abono a capital" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setTipoPagoFilter(opt.id)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                    tipoPagoFilter === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Rango de Fecha */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Fecha de Registro
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "todos", label: "Cualquier fecha" },
                { id: "hoy", label: "Hoy" },
                { id: "ayer", label: "Ayer" },
                { id: "7_dias", label: "Últimos 7 días" },
                { id: "este_mes", label: "Este mes" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setDateFilter(opt.id)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                    dateFilter === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro de Cobrador */}
          {availableCobradores.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                Cobrado por
              </label>
              <div className="space-y-2">
                <button
                  onClick={() => setCobradorFilter("todos")}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                    cobradorFilter === "todos"
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  <span>Todos los cobradores</span>
                  {cobradorFilter === "todos" && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                </button>

                {availableCobradores.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => setCobradorFilter(u.id)}
                    className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                      cobradorFilter === u.id
                        ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                        : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                    }`}
                  >
                    <span>{u.nombre}</span>
                    {cobradorFilter === u.id && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </FilterBottomSheet>
    </div>
  );
}
