import React, { useState, useMemo, useEffect } from "react";
import {
  Plus,
  TrendingDown,
  TrendingUp,
  Wallet,
  Landmark,
  FileSpreadsheet,
  DollarSign,
  Calculator,
  User,
  Clock,
  ArrowRightLeft,
  X,
  CheckCircle,
  AlertCircle,
  History,
  FileText,
  Check,
  Upload,
  Image as ImageIcon,
  Layers,
  Coins,
  Banknote,
  Shield,
  Lock,
  Unlock,
  RefreshCw
} from "lucide-react";
import { Gasto, Banco, Pago, CuadreCaja, Deposito, Usuario, checkPermission, Configuracion } from "../types";
import { formatCurrency } from "../utils";

interface FinanzasProps {
  gastos: Gasto[];
  bancos: Banco[];
  pagos: Pago[];
  cuadres?: CuadreCaja[];
  depositos?: Deposito[];
  moneda: string;
  onSaveGasto: (gasto: Gasto) => Promise<void>;
  onSaveBanco: (banco: Banco) => Promise<void>;
  onSaveCuadre?: (cuadre: CuadreCaja) => Promise<void>;
  onSaveDeposito?: (deposito: Deposito) => Promise<void>;
  userEmail: string;
  currentUserProfile?: Usuario | null;
  configuracion: Configuracion;
  usuarios?: Usuario[];
  onAddAuditLog?: (
    accion: string,
    usuarioAfectado: string,
    detalles?: string,
    valorAnterior?: string,
    valorNuevo?: string,
    motivo?: string
  ) => Promise<void>;
}

export default function Finanzas({
  gastos,
  bancos,
  pagos,
  cuadres = [],
  depositos = [],
  moneda,
  onSaveGasto,
  onSaveBanco,
  onSaveCuadre,
  onSaveDeposito,
  userEmail,
  currentUserProfile,
  configuracion,
  usuarios = [],
  onAddAuditLog
}: FinanzasProps) {
  const canCreate = checkPermission(currentUserProfile, "finanzas", "crear");
  const canEdit = checkPermission(currentUserProfile, "finanzas", "editar");
  const canDelete = checkPermission(currentUserProfile, "finanzas", "eliminar");
  const canExport = checkPermission(currentUserProfile, "finanzas", "exportar");
  const [activeSubTab, setActiveSubTab] = useState<"movimientos" | "bancos" | "cuadre" | "depositos">("movimientos");
  const [isAddingGasto, setIsAddingGasto] = useState(false);
  const [isAddingBanco, setIsAddingBanco] = useState(false);

  // Gasto Form states
  const [formGastoDesc, setFormGastoDesc] = useState("");
  const [formGastoMonto, setFormGastoMonto] = useState(0);
  const [formGastoTipo, setFormGastoTipo] = useState("Servicios");
  const [formGastoSuplidor, setFormGastoSuplidor] = useState("");

  // Banco Form states
  const [formBancoNombre, setFormBancoNombre] = useState("");
  const [formBancoNumero, setFormBancoNumero] = useState("");
  const [formBancoBalance, setFormBancoBalance] = useState(0);

  // Cuadre de Caja shift balances
  const activeShift = useMemo(() => {
    const userEmailLower = userEmail?.toLowerCase();
    const userShifts = cuadres.filter(c => 
      c.registradoPor?.toLowerCase() === userEmailLower || 
      c.cobradorId?.toLowerCase() === userEmailLower
    );
    userShifts.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
    const latest = userShifts[0];
    if (latest && (latest.estado === "Abierta" || latest.estado === "Reabierta")) {
      return latest;
    }
    return null;
  }, [cuadres, userEmail]);

  const currentShiftStats = useMemo(() => {
    if (!activeShift) {
      return {
        cobrosHoy: 0,
        gastosHoy: 0,
        depositosHoy: 0,
        cajaChicaActual: 0,
        pettyFloat: 0
      };
    }
    const openTimeStr = activeShift.fechaApertura || activeShift.fecha;
    const openTime = new Date(openTimeStr).getTime();
    const userEmailLower = (activeShift.cobradorId || activeShift.registradoPor || userEmail).toLowerCase();

    const cobrosHoy = pagos
      .filter(p => {
        const pTime = new Date(p.fecha).getTime();
        const pUser = (p.cobradorId || "").toLowerCase();
        return pTime >= openTime && pUser === userEmailLower;
      })
      .reduce((sum, p) => sum + p.monto, 0);

    const gastosHoy = gastos
      .filter(g => {
        const gTime = new Date(g.fecha).getTime();
        const gUser = (g.registradoPor || "").toLowerCase();
        return gTime >= openTime && gUser === userEmailLower;
      })
      .reduce((sum, g) => sum + g.monto, 0);

    const depositosHoy = depositos
      .filter(d => {
        const dTime = new Date(d.fecha).getTime();
        const dUser = (d.registradoPor || "").toLowerCase();
        return dTime >= openTime && dUser === userEmailLower;
      })
      .reduce((sum, d) => sum + d.monto, 0);

    const pettyFloat = activeShift.fondoApertura || 0;
    const cajaChicaActual = pettyFloat + cobrosHoy - gastosHoy - depositosHoy;

    return {
      cobrosHoy,
      gastosHoy,
      depositosHoy,
      cajaChicaActual,
      pettyFloat
    };
  }, [activeShift, pagos, gastos, depositos, userEmail]);

  const cuadreStats = useMemo(() => {
    if (activeShift) {
      return currentShiftStats;
    }

    const todayStr = new Date().toISOString().split("T")[0];
    const cobrosHoy = pagos
      .filter(p => p.fecha.split("T")[0] === todayStr)
      .reduce((sum, p) => sum + p.monto, 0);

    const gastosHoy = gastos
      .filter(g => g.fecha.split("T")[0] === todayStr)
      .reduce((sum, g) => sum + g.monto, 0);

    const depositosHoy = depositos
      .filter(d => d.fecha.split("T")[0] === todayStr)
      .reduce((sum, d) => sum + d.monto, 0);

    const totalCajaChicaAprox = 15000;
    const cajaChicaActual = totalCajaChicaAprox + cobrosHoy - gastosHoy - depositosHoy;

    return {
      cobrosHoy,
      gastosHoy,
      depositosHoy,
      cajaChicaActual,
      pettyFloat: totalCajaChicaAprox
    };
  }, [activeShift, currentShiftStats, pagos, gastos, depositos]);

  // Depositos form states
  const [isAddingDeposito, setIsAddingDeposito] = useState(false);
  const [depositoBancoId, setDepositoBancoId] = useState("");
  const [depositoMonto, setDepositoMonto] = useState<string>("");
  const [depositoReferencia, setDepositoReferencia] = useState("");
  const [depositoNotas, setDepositoNotas] = useState("");
  const [selectedPagosIds, setSelectedPagosIds] = useState<string[]>([]);
  const [voucherFile, setVoucherFile] = useState<string | null>(null);

  // Filter states for reports
  const [filterDepositoFecha, setFilterDepositoFecha] = useState<"todos" | "hoy" | "semana">("todos");
  const [filterDepositoUsuario, setFilterDepositoUsuario] = useState("todos");
  const [filterDepositoBanco, setFilterDepositoBanco] = useState("todos");

  // Selected Deposito detail modal
  const [viewDetailDeposito, setViewDetailDeposito] = useState<Deposito | null>(null);

  // Cuadre Form states
  const [saldoRealInput, setSaldoRealInput] = useState<string>("");
  const [notasCuadre, setNotasCuadre] = useState("");
  const [successCuadre, setSuccessCuadre] = useState<CuadreCaja | null>(null);
  const [selectedCuadre, setSelectedCuadre] = useState<CuadreCaja | null>(null);

  // Apertura de caja states
  const [fondoAperturaInput, setFondoAperturaInput] = useState<string>("15000");
  const [observacionesApertura, setObservacionesApertura] = useState<string>("");
  const [metodoAperturaSeleccionado, setMetodoAperturaSeleccionado] = useState<"simple" | "denominaciones">("simple");
  const [conteoDenominacionesApertura, setConteoDenominacionesApertura] = useState<{ [key: string]: number }>({
    "2000": 0, "1000": 0, "500": 0, "200": 0, "100": 0, "50": 0, "25": 0, "10": 0, "5": 0, "1": 0
  });
  const [selectedCobradorApertura, setSelectedCobradorApertura] = useState<string>(userEmail);

  // Role based helper variables
  const isSupervisor = currentUserProfile?.rol === "Supervisor" || currentUserProfile?.rol === "Administrador";
  const isAdmin = currentUserProfile?.rol === "Administrador";

  const [metodoSeleccionado, setMetodoSeleccionado] = useState<"simple" | "denominaciones">("denominaciones");
  const [conteoDenominaciones, setConteoDenominaciones] = useState<{ [key: string]: number }>({
    "2000": 0,
    "1000": 0,
    "500": 0,
    "200": 0,
    "100": 0,
    "50": 0,
    "25": 0,
    "10": 0,
    "5": 0,
    "1": 0
  });

  // Automatically initialize selected method from configuration settings
  useEffect(() => {
    const configMetodo = configuracion?.metodoArqueo || "ambos";
    if (configMetodo === "simple") {
      setMetodoSeleccionado("simple");
    } else {
      setMetodoSeleccionado("denominaciones");
    }
  }, [configuracion?.metodoArqueo]);

  // Recalculate physical count dynamically based on selected denominaciones
  useEffect(() => {
    if (metodoSeleccionado === "denominaciones") {
      let total = 0;
      Object.entries(conteoDenominaciones).forEach(([denomStr, count]) => {
        total += Number(denomStr) * Number(count || 0);
      });
      setSaldoRealInput(total.toString());
    }
  }, [conteoDenominaciones, metodoSeleccionado]);

  // Recalculate opening fund dynamically based on selected opening denominaciones
  useEffect(() => {
    if (metodoAperturaSeleccionado === "denominaciones") {
      let total = 0;
      Object.entries(conteoDenominacionesApertura).forEach(([denomStr, count]) => {
        total += Number(denomStr) * Number(count || 0);
      });
      setFondoAperturaInput(total.toString());
    }
  }, [conteoDenominacionesApertura, metodoAperturaSeleccionado]);

  // Default the physical cash counted input to estimated cash on subtab change for simple mode
  useEffect(() => {
    if (activeSubTab === "cuadre" && metodoSeleccionado === "simple" && (saldoRealInput === "" || saldoRealInput === "0")) {
      setSaldoRealInput(cuadreStats.cajaChicaActual.toString());
    }
  }, [activeSubTab, cuadreStats.cajaChicaActual, metodoSeleccionado]);

  // Submit expense
  const handleSubmitGasto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formGastoDesc || formGastoMonto <= 0) {
      alert("Por favor rellene todos los campos obligatorios.");
      return;
    }

    const payload: Gasto = {
      fecha: new Date().toISOString(),
      descripcion: formGastoDesc,
      monto: Number(formGastoMonto),
      tipoEgreso: formGastoTipo,
      suplidor: formGastoSuplidor,
      registradoPor: userEmail || "Sistema"
    };

    try {
      await onSaveGasto(payload);
      setIsAddingGasto(false);
      // Reset
      setFormGastoDesc("");
      setFormGastoMonto(0);
      setFormGastoSuplidor("");
    } catch (err) {
      console.error(err);
      alert("Error al registrar gasto");
    }
  };

  // Submit bank
  const handleSubmitBanco = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formBancoNombre || !formBancoNumero) {
      alert("Por favor rellene los campos obligatorios.");
      return;
    }

    const payload: Banco = {
      nombre: formBancoNombre,
      numeroCuenta: formBancoNumero,
      balance: Number(formBancoBalance),
      moneda: "DOP"
    };

    try {
      await onSaveBanco(payload);
      setIsAddingBanco(false);
      // Reset
      setFormBancoNombre("");
      setFormBancoNumero("");
      setFormBancoBalance(0);
    } catch (err) {
      console.error(err);
      alert("Error al guardar banco");
    }
  };

  // Submit Apertura de Caja
  const handleAbrirCaja = async () => {
    let openingFloat = Number(fondoAperturaInput);
    if (metodoAperturaSeleccionado === "denominaciones") {
      let totalDenom = 0;
      Object.entries(conteoDenominacionesApertura).forEach(([denomStr, count]) => {
        totalDenom += Number(denomStr) * Number(count || 0);
      });
      openingFloat = totalDenom;
    }

    if (isNaN(openingFloat) || openingFloat < 0) {
      alert("Por favor ingrese un fondo de apertura válido.");
      return;
    }

    const assignedUser = selectedCobradorApertura || userEmail;
    const assignedUserProfile = usuarios.find(u => u.email.toLowerCase() === assignedUser.toLowerCase());

    const payload: CuadreCaja = {
      id: `caja_${Date.now()}`,
      fecha: new Date().toISOString(),
      fondoApertura: openingFloat,
      cobrosEfectivo: 0,
      gastosEfectivo: 0,
      depositosEfectivo: 0,
      saldoEstimado: openingFloat,
      saldoReal: openingFloat,
      descuadre: 0,
      estado: "Abierta",
      registradoPor: userEmail,
      cobradorId: assignedUser,
      cobradorNombre: assignedUserProfile?.nombre || assignedUser,
      metodo: metodoAperturaSeleccionado,
      denominacionesApertura: metodoAperturaSeleccionado === "denominaciones" ? conteoDenominacionesApertura : undefined,
      observacionesApertura: observacionesApertura,
      fechaApertura: new Date().toISOString()
    };

    try {
      if (onSaveCuadre) {
        await onSaveCuadre(payload);
      }
      if (onAddAuditLog) {
        await onAddAuditLog(
          "Apertura de Caja",
          assignedUser,
          `Se abrió la caja de ${assignedUser} con un fondo inicial de ${moneda}${openingFloat}. Método: ${metodoAperturaSeleccionado}`,
          undefined,
          `${moneda}${openingFloat}`,
          observacionesApertura || "Apertura de turno de cobros estándar"
        );
      }
      alert("¡Caja abierta exitosamente!");
      setObservacionesApertura("");
      setConteoDenominacionesApertura({
        "2000": 0, "1000": 0, "500": 0, "200": 0, "100": 0, "50": 0, "25": 0, "10": 0, "5": 0, "1": 0
      });
    } catch (err) {
      console.error(err);
      alert("Error al abrir la caja.");
    }
  };

  // Submit cash-up / balance closure (Cierre de Caja)
  const handleSaveCuadre = async () => {
    if (!activeShift) {
      alert("No hay una caja activa para cerrar.");
      return;
    }

    const realAmount = saldoRealInput === "" ? cuadreStats.cajaChicaActual : Number(saldoRealInput);
    if (isNaN(realAmount) || realAmount < 0) {
      alert("Por favor ingrese un monto válido para el dinero físico real.");
      return;
    }

    const discrepancy = realAmount - cuadreStats.cajaChicaActual;
    const isMatched = discrepancy === 0;

    // Requirement 4: Observaciones obligatorias si hay descuadre
    if (!isMatched && !notasCuadre.trim()) {
      alert("Existe una diferencia (faltante o sobrante) en el arqueo. Debe ingresar una observación explicativa obligatoria antes de guardar.");
      return;
    }

    const updatedShift: CuadreCaja = {
      ...activeShift,
      fechaCierre: new Date().toISOString(),
      cobrosEfectivo: cuadreStats.cobrosHoy,
      gastosEfectivo: cuadreStats.gastosHoy,
      depositosEfectivo: cuadreStats.depositosHoy,
      saldoEstimado: cuadreStats.cajaChicaActual,
      saldoReal: realAmount,
      descuadre: discrepancy,
      estado: "Pendiente de aprobación",
      metodo: metodoSeleccionado,
      denominacionesConteo: metodoSeleccionado === "denominaciones" ? conteoDenominaciones : undefined,
      notas: notasCuadre || "Cierre de caja",
      diferenciaExplicacion: !isMatched ? notasCuadre : undefined,
      diferenciaUsuario: !isMatched ? userEmail : undefined,
      diferenciaFecha: !isMatched ? new Date().toISOString() : undefined
    };

    try {
      if (onSaveCuadre) {
        await onSaveCuadre(updatedShift);
      }
      if (onAddAuditLog) {
        await onAddAuditLog(
          "Cierre de Caja",
          activeShift.cobradorId || userEmail,
          `Se cerró la caja con saldo estimado de ${formatCurrency(cuadreStats.cajaChicaActual, moneda)}, saldo real de ${formatCurrency(realAmount, moneda)}, diferencia de ${formatCurrency(discrepancy, moneda)}. Método: ${metodoSeleccionado}`,
          `Saldo Estimado: ${formatCurrency(cuadreStats.cajaChicaActual, moneda)}`,
          `Saldo Real: ${formatCurrency(realAmount, moneda)} (Diferencia: ${formatCurrency(discrepancy, moneda)})`,
          notasCuadre || "Cierre de caja registrado"
        );
      }
      setSuccessCuadre(updatedShift);
      setNotasCuadre("");
      setSaldoRealInput("");
      setConteoDenominaciones({
        "2000": 0, "1000": 0, "500": 0, "200": 0, "100": 0, "50": 0, "25": 0, "10": 0, "5": 0, "1": 0
      });
    } catch (err) {
      console.error(err);
      alert("Error al registrar el cierre de caja.");
    }
  };

  // Supervisor Approvals & Reopenings
  const handleAprobarCierre = async (caja: CuadreCaja) => {
    const updated = {
      ...caja,
      estado: "Aprobada" as const,
      aprobadoPor: userEmail,
      fechaAprobacion: new Date().toISOString(),
      notasAprobacion: "Aprobado por supervisor/administrador"
    };

    try {
      if (onSaveCuadre) {
        await onSaveCuadre(updated);
      }
      if (onAddAuditLog) {
        await onAddAuditLog(
          "Aprobación de Cierre",
          caja.cobradorId || caja.registradoPor,
          `Se aprobó formalmente el cierre de caja con ID ${caja.id} por el supervisor ${userEmail}. Diferencia final: ${formatCurrency(caja.descuadre, moneda)}`,
          "Estado: Pendiente de aprobación",
          "Estado: Aprobada",
          "Validación de arqueo físico por supervisión"
        );
      }
      alert("Cierre de caja aprobado exitosamente.");
      if (selectedCuadre && selectedCuadre.id === caja.id) {
        setSelectedCuadre(updated);
      }
    } catch (err) {
      console.error(err);
      alert("Error al aprobar cierre.");
    }
  };

  const handleReabrirCaja = async (caja: CuadreCaja) => {
    const reason = prompt("Por favor, ingrese el motivo o justificación para reabrir esta caja:");
    if (reason === null) return; // Cancelled
    const motivoReapertura = reason.trim() || "Reapertura por solicitud de supervisor";

    const updated = {
      ...caja,
      estado: "Reabierta" as const,
      fechaCierre: undefined,
      saldoReal: caja.fondoApertura,
      descuadre: 0,
      notas: motivoReapertura,
    };

    try {
      if (onSaveCuadre) {
        await onSaveCuadre(updated);
      }
      if (onAddAuditLog) {
        await onAddAuditLog(
          "Reapertura de Caja",
          caja.cobradorId || caja.registradoPor,
          `Se reabrió/rechazó la caja con ID ${caja.id} por supervisor ${userEmail}. Motivo: ${motivoReapertura}`,
          "Estado: Pendiente de aprobación",
          "Estado: Reabierta",
          motivoReapertura
        );
      }
      alert("Caja reabierta exitosamente.");
      if (selectedCuadre && selectedCuadre.id === caja.id) {
        setSelectedCuadre(updated);
      }
    } catch (err) {
      console.error(err);
      alert("Error al reabrir caja.");
    }
  };

  // Submit bank deposit from drawer cash
  const handleSaveDepositoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!depositoBancoId) {
      alert("Por favor seleccione la cuenta bancaria de destino.");
      return;
    }
    const amount = Number(depositoMonto);
    if (isNaN(amount) || amount <= 0) {
      alert("Por favor ingrese un monto válido para el depósito bancario.");
      return;
    }
    if (!depositoReferencia.trim()) {
      alert("Por favor ingrese el número de referencia o transacción del depósito.");
      return;
    }

    const selectedBank = bancos.find(b => b.id === depositoBancoId);
    if (!selectedBank) return;

    const payload: Deposito = {
      fecha: new Date().toISOString(),
      bancoId: depositoBancoId,
      bancoNombre: selectedBank.nombre,
      monto: amount,
      voucher: voucherFile || undefined,
      referencia: depositoReferencia.trim(),
      pagoIds: selectedPagosIds,
      registradoPor: userEmail || "Supervisor de Caja",
      notes: depositoNotas || "Depósito bancario de fondos recaudados",
      notas: depositoNotas || "Depósito bancario de fondos recaudados"
    } as any;

    try {
      if (onSaveDeposito) {
        await onSaveDeposito(payload);
      }
      if (onAddAuditLog) {
        await onAddAuditLog(
          "Registro de Depósito",
          payload.bancoNombre,
          `Se depositó ${formatCurrency(payload.monto, moneda)} de caja en la cuenta bancaria ${payload.bancoNombre} (Ref: ${payload.referencia})`,
          `Balance anterior de banco: ${formatCurrency(selectedBank.balance, moneda)}`,
          `Balance nuevo de banco: ${formatCurrency(selectedBank.balance + payload.monto, moneda)}`,
          payload.notas || "Depósito de fondos recaudados"
        );
      }
      alert("¡Depósito registrado con éxito! El balance del banco ha sido actualizado.");
      // Reset form states
      setDepositoBancoId("");
      setDepositoMonto("");
      setDepositoReferencia("");
      setDepositoNotas("");
      setSelectedPagosIds([]);
      setVoucherFile(null);
      setIsAddingDeposito(false);
    } catch (err) {
      console.error(err);
      alert("Error al registrar depósito bancario.");
    }
  };

  // Unified Transaction History list (Inflows from Payments, Outflows from Expenses)
  const unifiedTransactions = useMemo(() => {
    const list: {
      id: string;
      fecha: string;
      tipo: "Ingreso" | "Egreso";
      concepto: string;
      categoria: string;
      monto: number;
      actor: string;
    }[] = [];

    // Push payments
    pagos.forEach(p => {
      list.push({
        id: p.id || p.reciboNo,
        fecha: p.fecha,
        tipo: "Ingreso",
        concepto: `Cobro Préstamo ${p.prestamoNumero} - ${p.tipoPago}`,
        categoria: "Cobro Préstamo",
        monto: p.monto,
        actor: p.clienteNombre
      });
    });

    // Push expenses
    gastos.forEach(g => {
      list.push({
        id: g.id || g.fecha,
        fecha: g.fecha,
        tipo: "Egreso",
        concepto: g.descripcion,
        categoria: g.tipoEgreso,
        monto: g.monto,
        actor: g.suplidor || g.registradoPor
      });
    });

    // Sort by date desc
    return list.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
  }, [pagos, gastos]);

  // Bank deposits helper structures and calculations
  const cobrosEfectivoHoy = useMemo(() => {
    const todayStr = new Date().toISOString().split("T")[0];
    return pagos.filter(p => p.fecha.split("T")[0] === todayStr).reduce((sum, p) => sum + p.monto, 0);
  }, [pagos]);

  const depositosEfectivoHoy = useMemo(() => {
    const todayStr = new Date().toISOString().split("T")[0];
    return (depositos || []).filter(d => d.fecha.split("T")[0] === todayStr).reduce((sum, d) => sum + d.monto, 0);
  }, [depositos]);

  const efectividadHoy = useMemo(() => {
    if (cobrosEfectivoHoy === 0) return 100;
    return Math.min(Math.round((depositosEfectivoHoy / cobrosEfectivoHoy) * 100), 100);
  }, [cobrosEfectivoHoy, depositosEfectivoHoy]);

  // Find all payment IDs that are already associated with any previous deposit to prevent duplicate deposits
  const associatedPagoIds = useMemo(() => {
    const set = new Set<string>();
    (depositos || []).forEach(d => {
      if (Array.isArray(d.pagoIds)) {
        d.pagoIds.forEach(id => {
          if (id) set.add(id);
        });
      }
    });
    return set;
  }, [depositos]);

  const recentPagosParaAsociar = useMemo(() => {
    const todayStr = new Date().toISOString().split("T")[0];
    return pagos.filter(p => {
      const isToday = p.fecha.split("T")[0] === todayStr;
      if (!isToday) return false;
      const id = p.id;
      const rNo = p.reciboNo;
      const isAssociated = (id && associatedPagoIds.has(id)) || (rNo && associatedPagoIds.has(rNo));
      return !isAssociated;
    });
  }, [pagos, associatedPagoIds]);

  const togglePagoAssociation = (pagoId: string) => {
    let newSelected: string[];
    if (selectedPagosIds.includes(pagoId)) {
      newSelected = selectedPagosIds.filter(id => id !== pagoId);
    } else {
      newSelected = [...selectedPagosIds, pagoId];
    }
    setSelectedPagosIds(newSelected);

    // Auto-fill deposit amount
    const sum = pagos
      .filter(p => newSelected.includes(p.id! || p.reciboNo))
      .reduce((total, p) => total + p.monto, 0);
    setDepositoMonto(sum > 0 ? sum.toString() : "");
  };

  const filteredDepositos = useMemo(() => {
    return (depositos || []).filter(d => {
      if (filterDepositoFecha === "hoy") {
        const todayStr = new Date().toISOString().split("T")[0];
        if (d.fecha.split("T")[0] !== todayStr) return false;
      } else if (filterDepositoFecha === "semana") {
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
        if (new Date(d.fecha).getTime() < oneWeekAgo.getTime()) return false;
      }

      if (filterDepositoBanco !== "todos" && d.bancoId !== filterDepositoBanco) {
        return false;
      }

      if (filterDepositoUsuario !== "todos" && d.registradoPor !== filterDepositoUsuario) {
        return false;
      }

      return true;
    }).sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
  }, [depositos, filterDepositoFecha, filterDepositoBanco, filterDepositoUsuario]);

  const uniqueSupervisores = useMemo(() => {
    const set = new Set<string>();
    (depositos || []).forEach(d => {
      if (d.registradoPor) set.add(d.registradoPor);
    });
    return Array.from(set);
  }, [depositos]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setVoucherFile(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="finanzas-module-view">
      
      {/* Module Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Finanzas y Caja</h1>
        <p className="text-sm text-gray-500">Administra tus gastos operativos, saldos en bancos y el cuadre diario.</p>
      </div>

      {/* Sub tabs header */}
      <div className="flex border-b border-gray-100 dark:border-zinc-800 text-xs font-bold gap-4">
        <button
          onClick={() => setActiveSubTab("movimientos")}
          className={`pb-3 border-b-2 px-1 transition-colors ${activeSubTab === "movimientos" ? "border-emerald-600 text-emerald-600 dark:text-emerald-400" : "border-transparent text-gray-400 hover:text-gray-600"}`}
        >
          Caja Chica y Gastos
        </button>
        <button
          onClick={() => setActiveSubTab("bancos")}
          className={`pb-3 border-b-2 px-1 transition-colors ${activeSubTab === "bancos" ? "border-emerald-600 text-emerald-600 dark:text-emerald-400" : "border-transparent text-gray-400 hover:text-gray-600"}`}
        >
          Cuentas Bancarias
        </button>
        <button
          onClick={() => setActiveSubTab("cuadre")}
          className={`pb-3 border-b-2 px-1 transition-colors ${activeSubTab === "cuadre" ? "border-emerald-600 text-emerald-600 dark:text-emerald-400" : "border-transparent text-gray-400 hover:text-gray-600"}`}
        >
          Cuadre de Caja Diario
        </button>
        <button
          onClick={() => setActiveSubTab("depositos")}
          className={`pb-3 border-b-2 px-1 transition-colors ${activeSubTab === "depositos" ? "border-emerald-600 text-emerald-600 dark:text-emerald-400" : "border-transparent text-gray-400 hover:text-gray-600"}`}
        >
          Depósitos y Vouchers
        </button>
      </div>

      {/* TAB 1: Petty Cash and Gastos Log */}
      {activeSubTab === "movimientos" && (
        <div className="space-y-4">
          
          {/* KPI Mini-widgets */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-semibold">
            <div className="p-4 bg-white dark:bg-[#121214] border rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-gray-400 font-medium">Ingresos Totales (Cobros)</p>
                <p className="text-lg font-black text-emerald-600 mt-1">
                  {formatCurrency(pagos.reduce((sum, p) => sum + p.monto, 0), moneda)}
                </p>
              </div>
              <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-xl"><TrendingUp size={20} /></div>
            </div>

            <div className="p-4 bg-white dark:bg-[#121214] border rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-gray-400 font-medium">Gastos Registrados</p>
                <p className="text-lg font-black text-rose-500 mt-1">
                  {formatCurrency(gastos.reduce((sum, g) => sum + g.monto, 0), moneda)}
                </p>
              </div>
              <div className="p-2.5 bg-rose-100 dark:bg-rose-950 text-rose-600 rounded-xl"><TrendingDown size={20} /></div>
            </div>

            <div className="p-4 bg-white dark:bg-[#121214] border rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-gray-400 font-medium">Fondo Caja de Bóveda</p>
                <p className="text-lg font-bold text-gray-700 dark:text-zinc-300 mt-1">
                  {formatCurrency(15000 + pagos.reduce((sum, p) => sum + p.monto, 0) - gastos.reduce((sum, g) => sum + g.monto, 0), moneda)}
                </p>
              </div>
              <div className="p-2.5 bg-zinc-100 dark:bg-zinc-800 text-gray-600 rounded-xl"><Wallet size={20} /></div>
            </div>
          </div>

          {/* Form to add Expense/Gasto */}
          {isAddingGasto && (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 shadow-sm max-w-md mx-auto animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-1"><TrendingDown className="text-rose-500" size={16} /> Registrar Egreso / Gasto</h3>
                <button onClick={() => setIsAddingGasto(false)} className="text-gray-400"><X size={16} /></button>
              </div>

              <form onSubmit={handleSubmitGasto} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Descripción / Concepto *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Pago de Luz local central"
                    value={formGastoDesc}
                    onChange={e => setFormGastoDesc(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Monto del Gasto *</label>
                    <input
                      type="number"
                      step="any"
                      required
                      min={1}
                      value={formGastoMonto || ""}
                      onChange={e => setFormGastoMonto(Number(e.target.value))}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Categoría Egreso</label>
                    <select
                      value={formGastoTipo}
                      onChange={e => setFormGastoTipo(e.target.value)}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold"
                    >
                      <option value="Servicios">Servicios Básicos</option>
                      <option value="Alquiler">Alquiler de Local</option>
                      <option value="Comisiones">Comisiones Cobradores</option>
                      <option value="Papelería">Papelería e Impresión</option>
                      <option value="Caja Chica">Reposición Caja Chica</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Suplidor / Destinatario</label>
                  <input
                    type="text"
                    placeholder="Ej: Edesur S.A."
                    value={formGastoSuplidor}
                    onChange={e => setFormGastoSuplidor(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t">
                  <button type="button" onClick={() => setIsAddingGasto(false)} className="px-3.5 py-1.5 border rounded-lg text-xs">Cancelar</button>
                  <button type="submit" className="px-4 py-1.5 bg-rose-600 text-white rounded-lg text-xs font-bold">Aplicar Egreso</button>
                </div>
              </form>
            </div>
          )}

          {/* Log List */}
          {!isAddingGasto && (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl shadow-sm overflow-hidden">
              <div className="p-4 flex justify-between items-center border-b">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Historial de Transacciones Unificadas</h3>
                {canCreate && (
                  <button
                    onClick={() => setIsAddingGasto(true)}
                    className="px-3 py-1.5 bg-rose-600 text-white text-xs font-bold rounded-lg flex items-center gap-1"
                  >
                    <Plus size={14} /> Registrar Egreso
                  </button>
                )}
              </div>

              {unifiedTransactions.length === 0 ? (
                <p className="p-8 text-center text-gray-400 text-xs">No hay movimientos financieros cargados.</p>
              ) : (
                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-zinc-50 dark:bg-zinc-900 font-semibold text-gray-400 uppercase border-b tracking-wider">
                        <th className="p-3">Fecha</th>
                        <th className="p-3">Tipo</th>
                        <th className="p-3">Concepto / Detalle</th>
                        <th className="p-3">Categoría</th>
                        <th className="p-3">Actor / Contraparte</th>
                        <th className="p-3 text-right">Monto</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                      {unifiedTransactions.map((t, idx) => (
                        <tr key={idx} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/20">
                          <td className="p-3 text-zinc-500">{new Date(t.fecha).toLocaleString("es-ES")}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded-full font-bold text-[9px]
                              ${t.tipo === "Ingreso" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" : "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400"}
                            `}>
                              {t.tipo}
                            </span>
                          </td>
                          <td className="p-3 font-medium">{t.concepto}</td>
                          <td className="p-3 text-gray-400">{t.categoria}</td>
                          <td className="p-3 text-zinc-600 dark:text-zinc-400">{t.actor}</td>
                          <td className={`p-3 text-right font-bold ${t.tipo === "Ingreso" ? "text-emerald-600" : "text-rose-500"}`}>
                            {t.tipo === "Ingreso" ? "+" : "-"}{formatCurrency(t.monto, moneda)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

        </div>
      )}

      {/* TAB 2: Bank Vault Accounts */}
      {activeSubTab === "bancos" && (
        <div className="space-y-4">
          
          {/* Gasto/Bank creation block */}
          {isAddingBanco && (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-5 shadow-sm max-w-md mx-auto animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-1"><Landmark className="text-emerald-500" size={16} /> Agregar Cuenta de Banco</h3>
                <button onClick={() => setIsAddingBanco(false)} className="text-gray-400"><X size={16} /></button>
              </div>

              <form onSubmit={handleSubmitBanco} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Nombre Entidad Financiera *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Banco Popular Dominicano"
                    value={formBancoNombre}
                    onChange={e => setFormBancoNombre(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Número de Cuenta *</label>
                    <input
                      type="text"
                      required
                      placeholder="Ej: 778019920"
                      value={formBancoNumero}
                      onChange={e => setFormBancoNumero(e.target.value)}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Balance Inicial *</label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={formBancoBalance}
                      onChange={e => setFormBancoBalance(Number(e.target.value))}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t">
                  <button type="button" onClick={() => setIsAddingBanco(false)} className="px-3.5 py-1.5 border rounded-lg text-xs">Cancelar</button>
                  <button type="submit" className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold">Guardar Cuenta</button>
                </div>
              </form>
            </div>
          )}

          {!isAddingBanco && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Cuentas Bancarias Disponibles ({bancos.length})</h3>
                {canCreate && (
                  <button
                    onClick={() => setIsAddingBanco(true)}
                    className="px-3 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded-lg flex items-center gap-1"
                  >
                    <Plus size={14} /> Registrar Cuenta
                  </button>
                )}
              </div>

              {bancos.length === 0 ? (
                <p className="p-8 text-center text-gray-400 text-xs bg-white dark:bg-[#121214] border rounded-2xl">No hay cuentas bancarias registradas.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {bancos.map(b => (
                    <div key={b.id} className="bg-white dark:bg-[#121214] border rounded-2xl p-4 shadow-sm space-y-3">
                      <div className="flex justify-between items-start">
                        <div className="space-y-0.5">
                          <h4 className="font-bold text-sm text-gray-800 dark:text-zinc-200">{b.nombre}</h4>
                          <p className="text-[10px] text-gray-400 font-mono">Cta: {b.numeroCuenta}</p>
                        </div>
                        <div className="p-2 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-lg"><Landmark size={18} /></div>
                      </div>
                      <div className="pt-2 border-t text-right">
                        <p className="text-[10px] text-gray-400">BALANCE DISPONIBLE</p>
                        <p className="text-lg font-black text-emerald-600 mt-0.5">{formatCurrency(b.balance, moneda)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      )}

      {/* TAB 3: Cash balance close reconciliation */}
      {activeSubTab === "cuadre" && (
        <div className="space-y-6">
          {successCuadre ? (
            /* SUCCESS STATE RECEIPT PANELS */
            <div className="max-w-xl mx-auto bg-white dark:bg-[#121214] border border-emerald-500/30 rounded-3xl p-6 shadow-lg space-y-6 animate-fade-in">
              <div className="text-center space-y-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                  <CheckCircle size={28} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Cierre de Caja Registrado</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">El arqueo de caja chica ha sido conciliado y guardado en el sistema.</p>
              </div>

              {/* Receipt Details Block */}
              <div className="border border-dashed border-gray-200 dark:border-zinc-800 rounded-2xl p-5 space-y-4 bg-zinc-50/50 dark:bg-zinc-900/30 font-sans">
                <div className="flex justify-between items-center text-xs border-b border-dashed pb-3">
                  <span className="text-gray-400">ID REGISTRO</span>
                  <span className="font-mono font-bold text-gray-700 dark:text-zinc-300">
                    {successCuadre.id}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">FECHA Y HORA</span>
                  <span className="font-semibold text-gray-700 dark:text-zinc-300">
                    {new Date(successCuadre.fecha).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">RESPONSABLE</span>
                  <span className="font-semibold text-emerald-600 dark:text-emerald-400 truncate max-w-[200px]">
                    {successCuadre.registradoPor}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs border-b border-dashed pb-3">
                  <span className="text-gray-400">ESTADO</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    successCuadre.estado === "Conciliado"
                      ? "bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400"
                      : "bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400"
                  }`}>
                    {successCuadre.estado === "Conciliado" ? "✔ CONCILIADO" : "⚠ CON DIFERENCIA"}
                  </span>
                </div>

                {/* Cash Metrics Grid */}
                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-500">1. Fondo Apertura (Apertura)</span>
                    <span className="font-medium text-gray-700 dark:text-zinc-300">{formatCurrency(successCuadre.fondoApertura, moneda)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                    <span>2. (+) Cobros en efectivo hoy</span>
                    <span className="font-bold">+{formatCurrency(successCuadre.cobrosEfectivo, moneda)}</span>
                  </div>
                  <div className="flex justify-between text-rose-600 dark:text-rose-400">
                    <span>3. (-) Gastos en efectivo hoy</span>
                    <span className="font-bold">-{formatCurrency(successCuadre.gastosEfectivo, moneda)}</span>
                  </div>
                  <div className="flex justify-between border-t pt-2 text-gray-500">
                    <span>Saldo Estimado en Custodia</span>
                    <span className="font-semibold">{formatCurrency(successCuadre.saldoEstimado, moneda)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-gray-900 dark:text-white text-sm bg-zinc-100 dark:bg-zinc-800/60 p-2 rounded-lg">
                    <span>Saldo Real Contado</span>
                    <span>{formatCurrency(successCuadre.saldoReal, moneda)}</span>
                  </div>

                  {/* Discrepancy indicator */}
                  <div className="flex justify-between items-center border-t border-dashed pt-2">
                    <span className="text-gray-400 text-[11px]">DIFERENCIA (DESCUADRE)</span>
                    <span className={`font-mono font-bold text-xs ${
                      successCuadre.descuadre === 0 
                        ? "text-emerald-500" 
                        : successCuadre.descuadre < 0 
                        ? "text-rose-500" 
                        : "text-blue-500"
                    }`}>
                      {successCuadre.descuadre === 0 
                        ? "Caja Cuadrada (0.00)" 
                        : successCuadre.descuadre < 0 
                        ? `Faltante: ${formatCurrency(successCuadre.descuadre, moneda)}` 
                        : `Sobrante: +${formatCurrency(successCuadre.descuadre, moneda)}`
                      }
                    </span>
                  </div>
                </div>

                {successCuadre.notas && (
                  <div className="border-t border-dashed pt-3 mt-1">
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Observaciones</p>
                    <p className="text-xs text-gray-600 dark:text-zinc-400 italic font-medium">"{successCuadre.notas}"</p>
                  </div>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    // Try to use browser native print
                    window.print();
                  }}
                  className="flex-1 py-2.5 bg-zinc-100 dark:bg-zinc-800 text-gray-700 dark:text-white rounded-xl text-xs font-semibold hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors flex items-center justify-center gap-1.5"
                >
                  <FileText size={16} /> Imprimir Comprobante
                </button>
                <button
                  onClick={() => {
                    setSuccessCuadre(null);
                  }}
                  className="flex-1 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition-colors"
                >
                  Nuevo Arqueo / Cierre
                </button>
              </div>
            </div>
          ) : (
            /* ACTIVE ARQUEO FORM & HISTORICAL LOG GRID */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* Left Column: Form & Calculator (8 cols) */}
              <div className="lg:col-span-7 space-y-6">
                {!activeShift ? (
                  /* APERTURA DE CAJA FORM */
                  <div className="bg-white dark:bg-[#121214] border rounded-2xl p-6 shadow-sm space-y-5">
                    <div className="border-b pb-4">
                      <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                        <Unlock size={22} className="animate-pulse" />
                        <h3 className="font-bold text-base text-gray-900 dark:text-white">
                          Apertura de Caja / Turno
                        </h3>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">
                        Establece el fondo inicial (caja chica / float) para comenzar a operar transacciones y registrar cobros en el sistema.
                      </p>
                    </div>

                    {/* Method Selector for Apertura */}
                    <div className="grid grid-cols-2 gap-2 bg-zinc-100 dark:bg-zinc-800/80 p-1.5 rounded-xl border border-zinc-200/50 dark:border-zinc-700/50 mb-1">
                      <button
                        type="button"
                        onClick={() => setMetodoAperturaSeleccionado("simple")}
                        className={`py-2 px-3 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          metodoAperturaSeleccionado === "simple"
                            ? "bg-white dark:bg-zinc-900 text-emerald-600 dark:text-emerald-400 shadow-xs"
                            : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                        }`}
                      >
                        <Calculator size={13} /> Fondo Fijo Simple
                      </button>
                      <button
                        type="button"
                        onClick={() => setMetodoAperturaSeleccionado("denominaciones")}
                        className={`py-2 px-3 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          metodoAperturaSeleccionado === "denominaciones"
                            ? "bg-white dark:bg-zinc-900 text-emerald-600 dark:text-emerald-400 shadow-xs"
                            : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                        }`}
                      >
                        <Coins size={13} /> Desglose Inicial
                      </button>
                    </div>

                    {metodoAperturaSeleccionado === "simple" ? (
                      <div className="space-y-2 animate-fade-in">
                        <label className="text-xs font-bold text-gray-700 dark:text-zinc-300">
                          Monto de Apertura (Efectivo Base) <span className="text-rose-500">*</span>
                        </label>
                        <div className="relative rounded-xl shadow-sm">
                          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400 font-bold text-xs">
                            {moneda}
                          </div>
                          <input
                            type="number"
                            step="any"
                            placeholder="Ej. 15000"
                            value={fondoAperturaInput}
                            onChange={(e) => setFondoAperturaInput(e.target.value)}
                            className="w-full text-xs pl-8 pr-3 py-3 rounded-xl border bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono font-bold"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3 animate-fade-in">
                        <div className="flex justify-between items-center border-b pb-1.5 border-zinc-100 dark:border-zinc-800">
                          <label className="text-xs font-extrabold text-gray-700 dark:text-zinc-300 uppercase tracking-wider">
                            Desglose de Fondo Base
                          </label>
                          <button
                            type="button"
                            onClick={() => {
                              setConteoDenominacionesApertura({
                                "2000": 0, "1000": 0, "500": 0, "200": 0, "100": 0, "50": 0,
                                "25": 0, "10": 0, "5": 0, "1": 0
                              });
                            }}
                            className="text-[10px] text-rose-500 font-bold hover:underline cursor-pointer"
                          >
                            Limpiar cantidades
                          </button>
                        </div>

                        <div className="max-h-[220px] overflow-y-auto pr-1 space-y-1.5 border rounded-2xl p-2.5 bg-zinc-50/50 dark:bg-zinc-900/10 border-zinc-150/80 dark:border-zinc-800/60">
                          {[
                            { val: 2000, label: "RD$ 2,000", tipo: "Billete" },
                            { val: 1000, label: "RD$ 1,000", tipo: "Billete" },
                            { val: 500, label: "RD$ 500", tipo: "Billete" },
                            { val: 200, label: "RD$ 200", tipo: "Billete" },
                            { val: 100, label: "RD$ 100", tipo: "Billete" },
                            { val: 50, label: "RD$ 50", tipo: "Billete" },
                            { val: 25, label: "RD$ 25", tipo: "Moneda" },
                            { val: 10, label: "RD$ 10", tipo: "Moneda" },
                            { val: 5, label: "RD$ 5", tipo: "Moneda" },
                            { val: 1, label: "RD$ 1", tipo: "Moneda" }
                          ].map((denom) => {
                            const count = conteoDenominacionesApertura[denom.val.toString()] || 0;
                            const subtotal = denom.val * count;

                            return (
                              <div
                                key={denom.val}
                                className="flex items-center justify-between gap-3 p-1.5 bg-white dark:bg-zinc-950 rounded-xl border border-zinc-150 dark:border-zinc-800/80 hover:border-emerald-500/20 transition-all shadow-2xs"
                              >
                                <div className="flex items-center gap-2">
                                  <span className={`w-2 h-2 rounded-full ${denom.tipo === "Billete" ? "bg-emerald-500" : "bg-amber-400"}`} />
                                  <div className="text-left">
                                    <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">{denom.label}</p>
                                  </div>
                                </div>

                                <div className="flex items-center gap-3">
                                  <div className="flex items-center border border-zinc-200 dark:border-zinc-800 rounded-lg overflow-hidden bg-zinc-50 dark:bg-zinc-900">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setConteoDenominacionesApertura(prev => ({
                                          ...prev,
                                          [denom.val.toString()]: Math.max(0, (prev[denom.val.toString()] || 0) - 1)
                                        }));
                                      }}
                                      className="px-2 py-0.5 text-xs text-gray-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 font-black active:bg-zinc-200 cursor-pointer select-none"
                                    >
                                      -
                                    </button>
                                    <input
                                      type="number"
                                      min="0"
                                      value={count === 0 ? "" : count}
                                      placeholder="0"
                                      onChange={(e) => {
                                        const v = e.target.value === "" ? 0 : Math.max(0, parseInt(e.target.value) || 0);
                                        setConteoDenominacionesApertura(prev => ({
                                          ...prev,
                                          [denom.val.toString()]: v
                                        }));
                                      }}
                                      className="w-10 text-center text-xs font-bold bg-transparent border-none focus:outline-none focus:ring-0 text-gray-800 dark:text-zinc-100 p-0 font-mono"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setConteoDenominacionesApertura(prev => ({
                                          ...prev,
                                          [denom.val.toString()]: (prev[denom.val.toString()] || 0) + 1
                                        }));
                                      }}
                                      className="px-2 py-0.5 text-xs text-gray-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 font-black active:bg-zinc-200 cursor-pointer select-none"
                                    >
                                      +
                                    </button>
                                  </div>

                                  <div className="w-16 text-right">
                                    <span className="font-mono text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                                      {formatCurrency(subtotal, moneda)}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Calculated base float total card */}
                        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex justify-between items-center">
                          <span className="text-[10px] font-extrabold text-emerald-800 dark:text-emerald-400 tracking-wider">TOTAL DESGLOSADO:</span>
                          <span className="font-mono text-sm font-black text-emerald-700 dark:text-emerald-400">
                            {formatCurrency(Number(fondoAperturaInput || 0), moneda)}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Supervisor options: Choose who the shift is for */}
                    {(isSupervisor || isAdmin) && (
                      <div className="space-y-1.5 animate-fade-in">
                        <label className="text-xs font-bold text-gray-700 dark:text-zinc-300">
                          Asignar Operador de Turno <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={selectedCobradorApertura}
                          onChange={(e) => setSelectedCobradorApertura(e.target.value)}
                          className="w-full text-xs p-3 rounded-xl border bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                        >
                          <option value={userEmail}>Yo ({userEmail})</option>
                          {usuarios
                            .filter(u => u.email.toLowerCase() !== userEmail.toLowerCase())
                            .map(u => (
                              <option key={u.id} value={u.email}>
                                {u.nombre} ({u.email} - {u.rol})
                              </option>
                            ))
                          }
                        </select>
                      </div>
                    )}

                    {/* Opening Notes */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-gray-500">
                        Observaciones / Notas de Apertura
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Ej. Fondo entregado en sobre, caja chica de repuesto..."
                        value={observacionesApertura}
                        onChange={(e) => setObservacionesApertura(e.target.value)}
                        className="w-full text-xs p-3 rounded-xl border bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <button
                      onClick={handleAbrirCaja}
                      disabled={!canCreate}
                      className="w-full text-center py-3 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 transition-colors shadow-sm shadow-emerald-600/10 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Unlock size={16} /> Abrir Caja y Habilitar Cobros
                    </button>
                  </div>
                ) : (
                  /* ACTIVE ARQUEO / CIERRE DE CAJA FORM */
                  <div className="bg-white dark:bg-[#121214] border rounded-2xl p-6 shadow-sm space-y-5">
                    <div className="border-b pb-4 flex justify-between items-start">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5 text-amber-500">
                          <Lock size={18} />
                          <h3 className="font-extrabold text-base text-gray-900 dark:text-white">
                            Cerrar Turno de Caja
                          </h3>
                        </div>
                        <p className="text-[10px] text-gray-400 font-medium">
                          Operador: <span className="font-bold text-gray-700 dark:text-zinc-200">{activeShift.cobradorNombre || activeShift.cobradorId}</span>
                        </p>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[9px] font-extrabold uppercase bg-amber-500/10 text-amber-600 dark:text-amber-400 animate-pulse border border-amber-500/20">
                        TURNO ACTIVO
                      </span>
                    </div>

                    {/* Indicators Grid */}
                    <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
                      <div className="p-2 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200/50 dark:border-zinc-800/50 rounded-xl">
                        <p className="text-[9px] text-gray-400 uppercase font-bold">Apertura</p>
                        <p className="text-xs font-bold text-gray-700 dark:text-zinc-300 mt-1">{formatCurrency(cuadreStats.pettyFloat, moneda)}</p>
                      </div>
                      <div className="p-2 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-500/10 rounded-xl">
                        <p className="text-[9px] text-emerald-600 dark:text-emerald-400 uppercase font-bold">Cobros</p>
                        <p className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">+{formatCurrency(cuadreStats.cobrosHoy, moneda)}</p>
                      </div>
                      <div className="p-2 bg-rose-50 dark:bg-rose-950/20 border border-rose-500/10 rounded-xl">
                        <p className="text-[9px] text-rose-600 dark:text-rose-400 uppercase font-bold">Gastos</p>
                        <p className="text-xs font-extrabold text-rose-600 dark:text-rose-400 mt-1">-{formatCurrency(cuadreStats.gastosHoy, moneda)}</p>
                      </div>
                      <div className="p-2 bg-blue-50 dark:bg-blue-950/20 border border-blue-500/10 rounded-xl">
                        <p className="text-[9px] text-blue-600 dark:text-blue-400 uppercase font-bold">Depósitos</p>
                        <p className="text-xs font-extrabold text-blue-600 dark:text-blue-400 mt-1">-{formatCurrency(cuadreStats.depositosHoy, moneda)}</p>
                      </div>
                    </div>

                    {/* Main mathematical expected balance */}
                    <div className="p-4 bg-zinc-950 text-white rounded-2xl flex items-center justify-between shadow-inner">
                      <div className="space-y-0.5 text-left">
                        <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-extrabold">SALDO ESTIMADO EN CAJA</p>
                        <p className="text-[10px] text-zinc-500">Calculado automáticamente</p>
                      </div>
                      <span className="font-mono text-xl font-black text-emerald-400">{formatCurrency(cuadreStats.cajaChicaActual, moneda)}</span>
                    </div>

                    {/* Counting form */}
                    <div className="space-y-4 pt-1">
                      {/* Method Selector */}
                      {(configuracion?.metodoArqueo === "ambos" || !configuracion?.metodoArqueo) && (
                        <div className="grid grid-cols-2 gap-2 bg-zinc-100 dark:bg-zinc-800/80 p-1.5 rounded-xl border border-zinc-200/50 dark:border-zinc-700/50 mb-3">
                          <button
                            type="button"
                            onClick={() => setMetodoSeleccionado("denominaciones")}
                            className={`py-2 px-3 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                              metodoSeleccionado === "denominaciones"
                                ? "bg-white dark:bg-zinc-900 text-emerald-600 dark:text-emerald-400 shadow-xs"
                                : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                            }`}
                          >
                            <Coins size={13} /> Desglosado
                          </button>
                          <button
                            type="button"
                            onClick={() => setMetodoSeleccionado("simple")}
                            className={`py-2 px-3 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                              metodoSeleccionado === "simple"
                                ? "bg-white dark:bg-zinc-900 text-emerald-600 dark:text-emerald-400 shadow-xs"
                                : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                            }`}
                          >
                            <Calculator size={13} /> Arqueo Simple
                          </button>
                        </div>
                      )}

                      {metodoSeleccionado === "simple" ? (
                        <div className="space-y-2 animate-fade-in" id="arqueo-simple-container">
                          <div className="flex justify-between items-center">
                            <label className="text-xs font-bold text-gray-700 dark:text-zinc-300">
                              Efectivo Físico Real Contado <span className="text-rose-500">*</span>
                            </label>
                            <button
                              type="button"
                              onClick={() => setSaldoRealInput(cuadreStats.cajaChicaActual.toString())}
                              className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold hover:underline cursor-pointer"
                            >
                              Auto-completar estimado
                            </button>
                          </div>
                          
                          <div className="relative rounded-xl shadow-sm">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400 font-bold text-xs">
                              {moneda}
                            </div>
                            <input
                              type="number"
                              step="any"
                              placeholder="0.00"
                              value={saldoRealInput}
                              onChange={(e) => setSaldoRealInput(e.target.value)}
                              className="w-full text-xs pl-8 pr-3 py-3 rounded-xl border bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono font-bold"
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3 animate-fade-in" id="arqueo-denominaciones-container">
                          <div className="flex justify-between items-center border-b pb-1.5 border-zinc-100 dark:border-zinc-800">
                            <label className="text-xs font-extrabold text-gray-700 dark:text-zinc-300 uppercase tracking-wider">
                              Desglose de Efectivo Físico
                            </label>
                            <button
                              type="button"
                              onClick={() => {
                                setConteoDenominaciones({
                                  "2000": 0, "1000": 0, "500": 0, "200": 0, "100": 0, "50": 0,
                                  "25": 0, "10": 0, "5": 0, "1": 0
                                });
                              }}
                              className="text-[10px] text-rose-500 font-bold hover:underline cursor-pointer"
                            >
                              Limpiar cantidades
                            </button>
                          </div>

                          <div className="max-h-[220px] overflow-y-auto pr-1 space-y-1.5 border rounded-2xl p-2.5 bg-zinc-50/50 dark:bg-zinc-900/10 border-zinc-150/80 dark:border-zinc-800/60">
                            {[
                              { val: 2000, label: "RD$ 2,000", tipo: "Billete" },
                              { val: 1000, label: "RD$ 1,000", tipo: "Billete" },
                              { val: 500, label: "RD$ 500", tipo: "Billete" },
                              { val: 200, label: "RD$ 200", tipo: "Billete" },
                              { val: 100, label: "RD$ 100", tipo: "Billete" },
                              { val: 50, label: "RD$ 50", tipo: "Billete" },
                              { val: 25, label: "RD$ 25", tipo: "Moneda" },
                              { val: 10, label: "RD$ 10", tipo: "Moneda" },
                              { val: 5, label: "RD$ 5", tipo: "Moneda" },
                              { val: 1, label: "RD$ 1", tipo: "Moneda" }
                            ].map((denom) => {
                              const count = conteoDenominaciones[denom.val.toString()] || 0;
                              const subtotal = denom.val * count;

                              return (
                                <div
                                  key={denom.val}
                                  className="flex items-center justify-between gap-3 p-1.5 bg-white dark:bg-zinc-950 rounded-xl border border-zinc-150 dark:border-zinc-800/80 hover:border-emerald-500/20 transition-all shadow-2xs"
                                >
                                  <div className="flex items-center gap-2">
                                    <span className={`w-2 h-2 rounded-full ${denom.tipo === "Billete" ? "bg-emerald-500" : "bg-amber-400"}`} />
                                    <div className="text-left">
                                      <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">{denom.label}</p>
                                    </div>
                                  </div>

                                  <div className="flex items-center gap-3">
                                    <div className="flex items-center border border-zinc-200 dark:border-zinc-800 rounded-lg overflow-hidden bg-zinc-50 dark:bg-zinc-900">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setConteoDenominaciones(prev => ({
                                            ...prev,
                                            [denom.val.toString()]: Math.max(0, (prev[denom.val.toString()] || 0) - 1)
                                          }));
                                        }}
                                        className="px-2 py-0.5 text-xs text-gray-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 font-black active:bg-zinc-200 cursor-pointer select-none"
                                      >
                                        -
                                      </button>
                                      <input
                                        type="number"
                                        min="0"
                                        value={count === 0 ? "" : count}
                                        placeholder="0"
                                        onChange={(e) => {
                                          const v = e.target.value === "" ? 0 : Math.max(0, parseInt(e.target.value) || 0);
                                          setConteoDenominaciones(prev => ({
                                            ...prev,
                                            [denom.val.toString()]: v
                                          }));
                                        }}
                                        className="w-10 text-center text-xs font-bold bg-transparent border-none focus:outline-none focus:ring-0 text-gray-800 dark:text-zinc-100 p-0 font-mono"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setConteoDenominaciones(prev => ({
                                            ...prev,
                                            [denom.val.toString()]: (prev[denom.val.toString()] || 0) + 1
                                          }));
                                        }}
                                        className="px-2 py-0.5 text-xs text-gray-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 font-black active:bg-zinc-200 cursor-pointer select-none"
                                      >
                                        +
                                      </button>
                                    </div>

                                    <div className="w-16 text-right">
                                      <span className="font-mono text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                                        {formatCurrency(subtotal, moneda)}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          {/* Total Contado Summary card */}
                          <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex justify-between items-center animate-fade-in">
                            <span className="text-[10px] font-extrabold text-emerald-800 dark:text-emerald-400 tracking-wider">TOTAL CONTADO:</span>
                            <span className="font-mono text-sm font-black text-emerald-700 dark:text-emerald-400">
                              {formatCurrency(Number(saldoRealInput || 0), moneda)}
                            </span>
                          </div>
                        </div>
                      )}

                      {/* LIVE DISCREPANCY DETECTOR BANNER */}
                      {(() => {
                        const real = saldoRealInput === "" ? cuadreStats.cajaChicaActual : Number(saldoRealInput);
                        const diff = real - cuadreStats.cajaChicaActual;
                        if (isNaN(real)) return null;

                        if (diff === 0) {
                          return (
                            <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-xs flex items-start gap-2.5 animate-fade-in">
                              <CheckCircle size={18} className="flex-shrink-0 mt-0.5 text-emerald-600" />
                              <div className="text-left">
                                <p className="font-bold">¡Caja Cuadrada Perfectamente!</p>
                                <p className="text-[11px] opacity-90 mt-0.5">El monto físico contado coincide de forma exacta con los registros del sistema.</p>
                              </div>
                            </div>
                          );
                        } else if (diff < 0) {
                          return (
                            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-700 dark:text-rose-400 text-xs flex items-start gap-2.5 animate-fade-in">
                              <AlertCircle size={18} className="flex-shrink-0 mt-0.5 text-rose-600" />
                              <div className="text-left">
                                <p className="font-bold">Faltante en Caja: <span className="font-mono">{formatCurrency(diff, moneda)}</span></p>
                                <p className="text-[11px] opacity-90 mt-0.5">El efectivo real reportado es menor que el esperado. Es obligatorio ingresar una explicación en las observaciones.</p>
                              </div>
                            </div>
                          );
                        } else {
                          return (
                            <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-700 dark:text-blue-400 text-xs flex items-start gap-2.5 animate-fade-in">
                              <CheckCircle size={18} className="flex-shrink-0 mt-0.5 text-blue-600" />
                              <div className="text-left">
                                <p className="font-bold">Sobrante en Caja: <span className="font-mono">+{formatCurrency(diff, moneda)}</span></p>
                                <p className="text-[11px] opacity-90 mt-0.5">Se ha reportado más efectivo físico del que el sistema estima. Es obligatorio ingresar una explicación en las observaciones.</p>
                              </div>
                            </div>
                          );
                        }
                      })()}

                      {/* Observations */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-gray-500">
                          Observaciones del Arqueo / Cierre <span className="text-rose-500">*</span>
                        </label>
                        <textarea
                          rows={2}
                          placeholder="Ingresa notas o comentarios que justifiquen el descuadre (obligatorio si no está cuadrado)"
                          value={notasCuadre}
                          onChange={(e) => setNotasCuadre(e.target.value)}
                          className="w-full text-xs p-3 rounded-xl border bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                      </div>
                    </div>

                    <button
                      onClick={handleSaveCuadre}
                      disabled={!canCreate}
                      className="w-full text-center py-3 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 transition-colors shadow-sm shadow-emerald-600/10 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Lock size={16} /> Cerrar Caja y Enviar a Aprobación
                    </button>
                  </div>
                )}
              </div>

              {/* Right Column: Historical Closures Log (5 cols) */}
              <div className="lg:col-span-5 space-y-4">
                <div className="bg-white dark:bg-[#121214] border rounded-2xl p-5 shadow-sm space-y-4">
                  <div className="border-b pb-3 flex items-center justify-between">
                    <h3 className="font-bold text-xs text-gray-900 dark:text-white flex items-center gap-1.5">
                      <History size={16} className="text-gray-400" /> Historial de Cuadres
                    </h3>
                    <span className="text-[10px] bg-zinc-100 dark:bg-zinc-800 text-gray-500 px-2 py-0.5 rounded-full font-mono">
                      {cuadres.length} registros
                    </span>
                  </div>

                  {cuadres.length === 0 ? (
                    <div className="text-center py-10 px-4 space-y-2">
                      <div className="mx-auto w-10 h-10 rounded-full bg-zinc-50 dark:bg-zinc-900 flex items-center justify-center text-zinc-400">
                        <FileSpreadsheet size={18} />
                      </div>
                      <p className="text-xs font-medium text-gray-500">Sin cierres registrados</p>
                      <p className="text-[10px] text-gray-400">Presiona "Confirmar Cierre de Caja y Guardar" para iniciar el historial.</p>
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                      {[...cuadres]
                        .sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())
                        .map((c) => (
                          <div
                            key={c.id}
                            onClick={() => setSelectedCuadre(c)}
                            className="p-3 border rounded-xl hover:border-emerald-500/40 bg-zinc-50/40 dark:bg-zinc-900/10 cursor-pointer transition-all hover:shadow-sm flex items-center justify-between group"
                          >
                            <div className="space-y-1 text-left min-w-0">
                              <p className="text-[10px] text-gray-400 font-mono flex items-center gap-1">
                                <Clock size={10} />
                                {new Date(c.fecha).toLocaleDateString()} {new Date(c.fecha).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </p>
                              <p className="text-xs font-bold text-gray-700 dark:text-zinc-200 truncate pr-2">
                                Saldo Real: <span className="font-mono">{formatCurrency(c.saldoReal, moneda)}</span>
                              </p>
                              <p className="text-[10px] text-gray-400 truncate max-w-[170px]">
                                Por: {c.registradoPor}
                              </p>
                            </div>

                            <div className="text-right flex flex-col items-end gap-1 flex-shrink-0">
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                                c.estado === "Conciliado" || c.estado === "Aprobada"
                                  ? "bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400"
                                  : c.estado === "Pendiente de aprobación"
                                  ? "bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-400"
                                  : "bg-zinc-100 dark:bg-zinc-850/50 text-zinc-600 dark:text-zinc-400"
                              }`}>
                                {c.estado === "Pendiente de aprobación" ? "Pendiente" : c.estado}
                              </span>
                              <span className={`text-[10px] font-mono font-bold ${
                                c.descuadre === 0 
                                  ? "text-emerald-500" 
                                  : c.descuadre < 0 
                                  ? "text-rose-500" 
                                  : "text-blue-500"
                              }`}>
                                {c.descuadre === 0 
                                  ? "Cuadrado" 
                                  : c.descuadre < 0 
                                  ? `${formatCurrency(c.descuadre, moneda)}` 
                                  : `+${formatCurrency(c.descuadre, moneda)}`
                                }
                              </span>
                            </div>
                          </div>
                        ))
                      }
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* HISTORIC DETAIL OVERLAY MODAL */}
          {selectedCuadre && (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-3xl p-6 shadow-2xl max-w-md w-full space-y-5 animate-fade-in text-left">
                
                {/* Header */}
                <div className="flex justify-between items-start">
                  <div className="space-y-0.5">
                    <h4 className="font-bold text-sm text-gray-900 dark:text-white flex items-center gap-1.5">
                      <FileText size={18} className="text-emerald-600" /> Detalle de Cuadre Guardado
                    </h4>
                    <p className="text-[10px] text-gray-400 font-mono">ID: {selectedCuadre.id}</p>
                  </div>
                  <button
                    onClick={() => setSelectedCuadre(null)}
                    className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-gray-400"
                  >
                    <X size={18} />
                  </button>
                </div>

                {/* Content table */}
                <div className="space-y-3.5 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Fecha y Hora</span>
                    <span className="font-semibold text-gray-700 dark:text-zinc-300">
                      {new Date(selectedCuadre.fecha).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Supervisor Responsable</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                      {selectedCuadre.registradoPor}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Estado</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      selectedCuadre.estado === "Conciliado" || selectedCuadre.estado === "Aprobada"
                        ? "bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400"
                        : selectedCuadre.estado === "Pendiente de aprobación"
                        ? "bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400"
                        : "bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400"
                    }`}>
                      {selectedCuadre.estado === "Conciliado"
                        ? "✔ CONCILIADO"
                        : selectedCuadre.estado === "Aprobada"
                        ? "✔ APROBADO"
                        : "⚠ PENDIENTE"}
                    </span>
                  </div>

                  <div className="border-t border-dashed pt-3 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Fondo Inicial Apertura</span>
                      <span className="font-medium">{formatCurrency(selectedCuadre.fondoApertura, moneda)}</span>
                    </div>
                    <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                      <span>(+) Cobros en efectivo</span>
                      <span className="font-semibold">+{formatCurrency(selectedCuadre.cobrosEfectivo, moneda)}</span>
                    </div>
                    <div className="flex justify-between text-rose-600 dark:text-rose-400">
                      <span>(-) Gastos en efectivo</span>
                      <span className="font-semibold">-{formatCurrency(selectedCuadre.gastosEfectivo, moneda)}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2 text-gray-500">
                      <span>Saldo Estimado Sistema</span>
                      <span className="font-semibold">{formatCurrency(selectedCuadre.saldoEstimado, moneda)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-gray-900 dark:text-white bg-zinc-100 dark:bg-zinc-800/60 p-2 rounded-lg">
                      <span>Saldo Físico Contado</span>
                      <span>{formatCurrency(selectedCuadre.saldoReal, moneda)}</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center border-t border-dashed pt-2.5">
                    <span className="text-gray-400 font-semibold text-[10px]">DIFERENCIA (DESCUADRE)</span>
                    <span className={`font-mono font-bold ${
                      selectedCuadre.descuadre === 0 
                        ? "text-emerald-500" 
                        : selectedCuadre.descuadre < 0 
                        ? "text-rose-500" 
                        : "text-blue-500"
                    }`}>
                      {selectedCuadre.descuadre === 0 
                        ? "Caja Cuadrada" 
                        : selectedCuadre.descuadre < 0 
                        ? `Faltante: ${formatCurrency(selectedCuadre.descuadre, moneda)}` 
                        : `Sobrante: +${formatCurrency(selectedCuadre.descuadre, moneda)}`
                      }
                    </span>
                  </div>

                  {/* Método de Arqueo */}
                  <div className="flex justify-between items-center border-t border-dashed pt-2.5 text-xs">
                    <span className="text-gray-400">Método de Arqueo</span>
                    <span className="font-semibold text-gray-700 dark:text-zinc-300">
                      {selectedCuadre.metodo === "denominaciones" ? "Denominaciones (Desglosado)" : "Arqueo Simple"}
                    </span>
                  </div>

                  {/* Conteo Físico por Denominaciones */}
                  {selectedCuadre.metodo === "denominaciones" && selectedCuadre.denominacionesConteo && (
                    <div className="border-t border-dashed pt-3 space-y-1.5 bg-zinc-50 dark:bg-zinc-950/40 p-3 rounded-2xl border border-zinc-100 dark:border-zinc-800/80">
                      <p className="text-[9px] text-gray-400 uppercase tracking-wider font-extrabold mb-1">CONTEO DE BILLETES Y MONEDAS</p>
                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        {[
                          { val: 2000, label: "RD$ 2,000" },
                          { val: 1000, label: "RD$ 1,000" },
                          { val: 500, label: "RD$ 500" },
                          { val: 200, label: "RD$ 200" },
                          { val: 100, label: "RD$ 100" },
                          { val: 50, label: "RD$ 50" },
                          { val: 25, label: "RD$ 25" },
                          { val: 10, label: "RD$ 10" },
                          { val: 5, label: "RD$ 5" },
                          { val: 1, label: "RD$ 1" }
                        ].map((denom) => {
                          const cant = selectedCuadre.denominacionesConteo?.[denom.val.toString()] || 0;
                          if (cant === 0) return null;
                          const sub = denom.val * cant;
                          return (
                            <div key={denom.val} className="flex justify-between items-center py-0.5 border-b border-dashed border-zinc-200/50 dark:border-zinc-800/50">
                              <span className="text-gray-500 font-medium">{denom.label} x {cant}</span>
                              <span className="font-mono text-gray-800 dark:text-zinc-200 font-bold">{formatCurrency(sub, moneda)}</span>
                            </div>
                          );
                        })}
                        {Object.values(selectedCuadre.denominacionesConteo || {}).every(v => Number(v) === 0) && (
                          <div className="col-span-2 text-center text-gray-400 text-[10px] py-1 italic">
                            No se ingresaron denominaciones físicas (Conteo en cero).
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {(selectedCuadre.notes || selectedCuadre.notas) && (
                    <div className="border-t border-dashed pt-3">
                      <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Notas del supervisor</p>
                      <p className="text-xs text-gray-600 dark:text-zinc-400 italic">"{selectedCuadre.notas || selectedCuadre.notes}"</p>
                    </div>
                  )}

                  {isSupervisor && selectedCuadre.estado === "Pendiente de aprobación" && (
                    <div className="border-t border-dashed pt-3 space-y-2 bg-amber-500/5 dark:bg-amber-500/10 p-3 rounded-2xl border border-amber-500/20">
                      <p className="text-[10px] text-amber-700 dark:text-amber-400 font-extrabold uppercase tracking-wider flex items-center gap-1.5">
                        <Shield size={12} className="text-amber-600" /> Decisiones de Supervisión
                      </p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleReabrirCaja(selectedCuadre)}
                          className="flex-1 py-1.5 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200/50 dark:border-rose-900/30 rounded-lg text-[10px] font-extrabold hover:bg-rose-100 dark:hover:bg-rose-950/60 transition-colors"
                        >
                          Reabrir Caja
                        </button>
                        <button
                          onClick={() => handleAprobarCierre(selectedCuadre)}
                          className="flex-1 py-1.5 bg-emerald-600 text-white rounded-lg text-[10px] font-extrabold hover:bg-emerald-700 transition-colors shadow-sm"
                        >
                          Aprobar Cierre
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    onClick={() => {
                      // print
                      window.print();
                    }}
                    className="flex-1 py-2 bg-zinc-100 dark:bg-zinc-800 text-gray-700 dark:text-white rounded-xl text-xs font-semibold hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                  >
                    Imprimir
                  </button>
                  <button
                    onClick={() => setSelectedCuadre(null)}
                    className="flex-1 py-2 bg-zinc-800 dark:bg-zinc-700 text-white rounded-xl text-xs font-semibold hover:bg-zinc-700 dark:hover:bg-zinc-600 transition-colors"
                  >
                    Cerrar Detalle
                  </button>
                </div>

              </div>
            </div>
          )}

        </div>
      )}

      {/* TAB 4: Depósitos y Vouchers */}
      {activeSubTab === "depositos" && (
        <div className="space-y-6 animate-fade-in text-left">
          
          {/* KPI Dashboard */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs font-semibold">
            <div className="p-4 bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-gray-400 font-medium">Caja en Custodia (Disponible)</p>
                <p className="text-lg font-black text-emerald-600 mt-1 font-sans">
                  {formatCurrency(cuadreStats.cajaChicaActual, moneda)}
                </p>
              </div>
              <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-xl">
                <Wallet size={18} />
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-gray-400 font-medium">Total Depositado en Banco</p>
                <p className="text-lg font-black text-blue-600 mt-1 font-sans">
                  {formatCurrency((depositos || []).reduce((sum, d) => sum + d.monto, 0), moneda)}
                </p>
              </div>
              <div className="p-2.5 bg-blue-100 dark:bg-blue-950 text-blue-600 rounded-xl">
                <Landmark size={18} />
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-gray-400 font-medium">Depositado Hoy</p>
                <p className="text-lg font-black text-indigo-600 mt-1 font-sans">
                  {formatCurrency(depositosEfectivoHoy, moneda)}
                </p>
              </div>
              <div className="p-2.5 bg-indigo-100 dark:bg-indigo-950 text-indigo-600 rounded-xl">
                <TrendingUp size={18} />
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-gray-400 font-medium">Efectividad de Depósito</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-lg font-black text-rose-600 dark:text-rose-400 font-sans">{efectividadHoy}%</span>
                  <span className="text-[10px] text-gray-400 font-normal">de cobros de hoy</span>
                </div>
              </div>
              <div className="p-2.5 bg-rose-100 dark:bg-rose-950 text-rose-600 rounded-xl">
                <Layers size={18} />
              </div>
            </div>
          </div>

          {/* Interactive Workspace Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
            
            {/* Left side: Log & Reports (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-3xl p-5 shadow-sm space-y-4">
                
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <h3 className="font-bold text-sm text-gray-900 dark:text-white">Historial de Depósitos</h3>
                    <p className="text-[10px] text-gray-400">Auditoría inmutable de vouchers y efectivo enviado a bancos</p>
                  </div>

                  {/* Filters bar */}
                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <select
                      value={filterDepositoFecha}
                      onChange={(e: any) => setFilterDepositoFecha(e.target.value)}
                      className="p-1.5 rounded-lg border bg-gray-50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-600 dark:text-zinc-300 font-semibold"
                    >
                      <option value="todos">Cualquier fecha</option>
                      <option value="hoy">Hoy</option>
                      <option value="semana">Últimos 7 días</option>
                    </select>

                    <select
                      value={filterDepositoBanco}
                      onChange={(e: any) => setFilterDepositoBanco(e.target.value)}
                      className="p-1.5 rounded-lg border bg-gray-50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-600 dark:text-zinc-300 font-semibold max-w-[120px] truncate"
                    >
                      <option value="todos">Todos los Bancos</option>
                      {bancos.map(b => (
                        <option key={b.id} value={b.id}>{b.nombre}</option>
                      ))}
                    </select>

                    <select
                      value={filterDepositoUsuario}
                      onChange={(e: any) => setFilterDepositoUsuario(e.target.value)}
                      className="p-1.5 rounded-lg border bg-gray-50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-600 dark:text-zinc-300 font-semibold max-w-[120px] truncate"
                    >
                      <option value="todos">Todos los Usuarios</option>
                      {uniqueSupervisores.map(user => (
                        <option key={user} value={user}>{user}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Table list */}
                <div className="overflow-x-auto border border-gray-100 dark:border-zinc-800/80 rounded-2xl">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-gray-50 dark:bg-zinc-900 text-gray-400 uppercase tracking-wider text-[10px] font-bold">
                      <tr>
                        <th className="py-2.5 px-3">Fecha</th>
                        <th className="py-2.5 px-3">Cuenta Destino</th>
                        <th className="py-2.5 px-3 text-right">Monto</th>
                        <th className="py-2.5 px-3">Ref / Voucher</th>
                        <th className="py-2.5 px-3">Registrado Por</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-zinc-800/50">
                      {filteredDepositos.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-12 text-center text-gray-400">
                            <div className="space-y-2">
                              <FileSpreadsheet className="mx-auto text-gray-300 dark:text-zinc-700" size={36} />
                              <p className="font-medium text-xs text-gray-600 dark:text-zinc-400">No se encontraron depósitos</p>
                              <p className="text-[10px] text-gray-400">Prueba cambiando los filtros o registra uno nuevo</p>
                            </div>
                          </td>
                        </tr>
                      ) : (
                        filteredDepositos.map(d => (
                          <tr
                            key={d.id}
                            onClick={() => setViewDetailDeposito(d)}
                            className="hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer transition-colors"
                          >
                            <td className="py-3 px-3 font-medium text-gray-600 dark:text-zinc-300 whitespace-nowrap">
                              {new Date(d.fecha).toLocaleDateString()}
                            </td>
                            <td className="py-3 px-3 font-semibold text-gray-900 dark:text-white">
                              {d.bancoNombre}
                            </td>
                            <td className="py-3 px-3 text-right font-black text-emerald-600 dark:text-emerald-400 whitespace-nowrap font-sans">
                              {formatCurrency(d.monto, moneda)}
                            </td>
                            <td className="py-3 px-3 whitespace-nowrap">
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded text-gray-600 dark:text-zinc-300 text-[10px]">
                                  {d.referencia}
                                </span>
                                {d.voucher && (
                                  <span className="text-[9px] bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 px-1 rounded font-bold">
                                    Voucher
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="py-3 px-3 text-gray-500 max-w-[120px] truncate">
                              {d.registradoPor.split("@")[0]}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

              </div>

              {/* Cobros vs Depósitos Analysis (Relación de cobros y depósitos) */}
              <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-3xl p-5 shadow-sm space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-gray-900 dark:text-white flex items-center gap-2">
                    <Layers size={16} className="text-indigo-600" /> Relación Cobros vs Depósitos de Hoy
                  </h3>
                  <p className="text-[10px] text-gray-400">Conciliación de efectivo diario ingresado vs resguardado en el banco</p>
                </div>

                <div className="space-y-3">
                  <div className="grid grid-cols-3 gap-3 text-center text-xs">
                    <div className="p-3 bg-gray-50 dark:bg-zinc-900/50 rounded-2xl border border-gray-100 dark:border-zinc-800/50">
                      <p className="text-gray-400 text-[10px] font-medium">Cobrado en Efectivo</p>
                      <p className="text-sm font-extrabold text-gray-800 dark:text-zinc-200 mt-1 font-sans">
                        {formatCurrency(cobrosEfectivoHoy, moneda)}
                      </p>
                    </div>
                    <div className="p-3 bg-gray-50 dark:bg-zinc-900/50 rounded-2xl border border-gray-100 dark:border-zinc-800/50">
                      <p className="text-gray-400 text-[10px] font-medium">Depositado en Banco</p>
                      <p className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 mt-1 font-sans">
                        {formatCurrency(depositosEfectivoHoy, moneda)}
                      </p>
                    </div>
                    <div className="p-3 bg-gray-50 dark:bg-zinc-900/50 rounded-2xl border border-gray-100 dark:border-zinc-800/50">
                      <p className="text-gray-400 text-[10px] font-medium">Pendiente en Caja</p>
                      <p className="text-sm font-extrabold text-rose-500 mt-1 font-sans">
                        {formatCurrency(Math.max(0, cobrosEfectivoHoy - depositosEfectivoHoy), moneda)}
                      </p>
                    </div>
                  </div>

                  {/* Progress completion bar */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-gray-400">
                      <span>Nivel de Resguardo en Banco</span>
                      <span className="text-emerald-600 dark:text-emerald-400 font-sans">{efectividadHoy}% completado</span>
                    </div>
                    <div className="h-2.5 bg-gray-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                        style={{ width: `${efectividadHoy}%` }}
                      ></div>
                    </div>
                    <p className="text-[10px] text-gray-400 italic">
                      {efectividadHoy === 100 
                        ? "Todo el efectivo recolectado hoy ya se encuentra depositado y respaldado en banco."
                        : "Se aconseja depositar el efectivo sobrante al final del turno para mitigar riesgos de caja chica."}
                    </p>
                  </div>
                </div>

              </div>

            </div>

            {/* Right side: Register Deposit Form (5 cols) */}
            <div className="lg:col-span-5">
              
              <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-3xl p-5 shadow-sm space-y-4 text-left">
                <div>
                  <h3 className="font-bold text-sm text-gray-900 dark:text-white">Registrar Depósito Bancario</h3>
                  <p className="text-[10px] text-gray-400">Descarga fondos físicos en custodia a una cuenta de banco</p>
                </div>

                {bancos.length === 0 ? (
                  <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-2xl text-center space-y-3">
                    <AlertCircle className="mx-auto text-amber-500" size={24} />
                    <p className="text-xs text-amber-800 dark:text-amber-300 font-bold">
                      No hay cuentas bancarias registradas en el sistema.
                    </p>
                    <button
                      onClick={() => setActiveSubTab("bancos")}
                      className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition-colors"
                    >
                      Crear Cuenta Bancaria
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSaveDepositoSubmit} className="space-y-4 text-xs">
                    
                    {/* Bank Account Selection */}
                    <div className="space-y-1">
                      <label className="block font-bold text-gray-600 dark:text-zinc-400">Cuenta de Banco Destino *</label>
                      <select
                        value={depositoBancoId}
                        required
                        onChange={(e) => setDepositoBancoId(e.target.value)}
                        className="w-full p-2.5 rounded-xl border bg-gray-50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-zinc-100"
                      >
                        <option value="">Selecciona cuenta bancaria...</option>
                        {bancos.map(b => (
                          <option key={b.id} value={b.id}>
                            {b.nombre} - {b.numeroCuenta} ({formatCurrency(b.balance, b.moneda || moneda)})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Checkable cobros list of today */}
                    <div className="space-y-1.5">
                      <label className="block font-bold text-gray-600 dark:text-zinc-400 flex justify-between items-center">
                        <span>Asociar Cobros de Hoy</span>
                        <span className="text-[10px] font-normal text-gray-400">
                          {selectedPagosIds.length} seleccionados
                        </span>
                      </label>
                      
                      {recentPagosParaAsociar.length === 0 ? (
                        <p className="p-3 border border-dashed rounded-xl text-center text-gray-400 text-[10px] bg-gray-50 dark:bg-zinc-900/30">
                          No hay cobros registrados hoy para vincular.
                        </p>
                      ) : (
                        <div className="max-h-[140px] overflow-y-auto border border-gray-150 dark:border-zinc-800 rounded-xl divide-y divide-gray-100 dark:divide-zinc-800/80 p-1 bg-gray-50 dark:bg-zinc-900/30 space-y-1">
                          {recentPagosParaAsociar.map(p => {
                            const isSelected = selectedPagosIds.includes(p.id! || p.reciboNo);
                            return (
                              <button
                                type="button"
                                key={p.id || p.reciboNo}
                                onClick={() => togglePagoAssociation(p.id! || p.reciboNo)}
                                className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors ${
                                  isSelected 
                                    ? "bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold" 
                                    : "hover:bg-black/5 dark:hover:bg-white/5 text-gray-600 dark:text-zinc-400"
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${
                                    isSelected ? "border-emerald-500 bg-emerald-500 text-white" : "border-gray-300"
                                  }`}>
                                    {isSelected && <Check size={10} />}
                                  </div>
                                  <div className="truncate max-w-[150px]">
                                    <p className="text-[11px] truncate font-bold">{p.clienteNombre}</p>
                                    <p className="text-[9px] text-gray-400">{p.prestamoNumero} • {p.reciboNo}</p>
                                  </div>
                                </div>
                                <span className="font-extrabold text-[11px] whitespace-nowrap font-sans">
                                  {formatCurrency(p.monto, moneda)}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {/* Amount Input */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <label className="block font-bold text-gray-600 dark:text-zinc-400">Monto del Depósito *</label>
                        {selectedPagosIds.length > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedPagosIds([]);
                              setDepositoMonto("");
                            }}
                            className="text-[10px] text-rose-500 hover:underline"
                          >
                            Desvincular cobros
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <span className="absolute left-3.5 top-2.5 text-gray-400 font-bold">{moneda}</span>
                        <input
                          type="number"
                          step="any"
                          required
                          placeholder="Monto a depositar"
                          value={depositoMonto}
                          onChange={(e) => setDepositoMonto(e.target.value)}
                          className="w-full pl-8 p-2.5 rounded-xl border bg-gray-50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-zinc-100 font-bold"
                        />
                      </div>
                      <p className="text-[9px] text-gray-400 italic font-sans">
                        El monto máximo a depositar sugerido de hoy es {formatCurrency(cuadreStats.cajaChicaActual, moneda)}.
                      </p>
                    </div>

                    {/* Reference / Voucher Code */}
                    <div className="space-y-1">
                      <label className="block font-bold text-gray-600 dark:text-zinc-400">Código de Referencia o Transacción *</label>
                      <input
                        type="text"
                        required
                        placeholder="Nro. operación del banco (e.g. 1928374)"
                        value={depositoReferencia}
                        onChange={(e) => setDepositoReferencia(e.target.value)}
                        className="w-full p-2.5 rounded-xl border bg-gray-50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-zinc-100 font-mono"
                      />
                    </div>

                    {/* Voucher Image Upload */}
                    <div className="space-y-1">
                      <label className="block font-bold text-gray-600 dark:text-zinc-400">Voucher / Comprobante de Depósito</label>
                      <div className="border-2 border-dashed border-gray-200 dark:border-zinc-800 rounded-2xl p-4 text-center cursor-pointer hover:border-emerald-500 transition-colors relative">
                        <input
                          type="file"
                          accept="image/*"
                          className="absolute inset-0 opacity-0 cursor-pointer"
                          onChange={handleFileChange}
                        />
                        {voucherFile ? (
                          <div className="space-y-2">
                            <img src={voucherFile} alt="Vista previa del voucher" className="max-h-32 mx-auto rounded-lg object-contain shadow-sm" />
                            <p className="text-[9px] text-gray-400 font-bold truncate">Voucher cargado correctamente</p>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setVoucherFile(null);
                              }}
                              className="text-[10px] text-rose-500 hover:underline font-bold"
                            >
                              Eliminar imagen
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-1 text-gray-400">
                            <Upload className="mx-auto text-gray-300 dark:text-zinc-700" size={24} />
                            <p className="text-[11px] font-bold text-gray-600 dark:text-zinc-400">Cargar imagen del Voucher</p>
                            <p className="text-[9px]">Haz clic o arrastra una foto para registrarla</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Notes */}
                    <div className="space-y-1">
                      <label className="block font-bold text-gray-600 dark:text-zinc-400">Observaciones</label>
                      <textarea
                        rows={2}
                        placeholder="Comentarios adicionales sobre el depósito..."
                        value={depositoNotas}
                        onChange={(e) => setDepositoNotas(e.target.value)}
                        className="w-full p-2.5 rounded-xl border bg-gray-50 dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-800 dark:text-zinc-100"
                      ></textarea>
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={!canCreate}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 text-white font-extrabold rounded-2xl transition-colors shadow-lg shadow-emerald-500/10 text-xs"
                      title={!canCreate ? "No tiene permisos para registrar depósitos bancarios" : ""}
                    >
                      Confirmar Depósito y Descargar Caja
                    </button>

                  </form>
                )}

              </div>

            </div>

          </div>

          {/* SINGLE DEPOSITO DETAIL OVERLAY MODAL */}
          {viewDetailDeposito && (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-3xl p-6 shadow-2xl max-w-lg w-full space-y-5 animate-fade-in text-left">
                
                {/* Header */}
                <div className="flex justify-between items-start">
                  <div className="space-y-0.5">
                    <h4 className="font-bold text-sm text-gray-900 dark:text-white flex items-center gap-1.5">
                      <Landmark size={18} className="text-emerald-600" /> Detalle de Depósito Bancario
                    </h4>
                    <p className="text-[10px] text-gray-400 font-mono">ID de Transacción: {viewDetailDeposito.id}</p>
                  </div>
                  <button
                    onClick={() => setViewDetailDeposito(null)}
                    className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-gray-400"
                  >
                    <X size={18} />
                  </button>
                </div>

                {/* Content grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-3.5">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-medium">Banco Receptor</span>
                      <span className="font-bold text-gray-800 dark:text-zinc-200">{viewDetailDeposito.bancoNombre}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-medium">Monto Acreditado</span>
                      <span className="font-black text-emerald-600 dark:text-emerald-400 text-sm font-sans">
                        {formatCurrency(viewDetailDeposito.monto, moneda)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-medium">Fecha de Depósito</span>
                      <span className="font-semibold text-gray-700 dark:text-zinc-300">
                        {new Date(viewDetailDeposito.fecha).toLocaleString()}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-medium">Nro. de Referencia</span>
                      <span className="font-mono bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded text-gray-600 dark:text-zinc-300 font-bold">
                        {viewDetailDeposito.referencia}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-400 font-medium">Registrado Por</span>
                      <span className="font-semibold text-gray-700 dark:text-zinc-300">
                        {viewDetailDeposito.registradoPor}
                      </span>
                    </div>

                    {viewDetailDeposito.pagoIds && viewDetailDeposito.pagoIds.length > 0 && (
                      <div className="border-t border-dashed pt-3 space-y-1">
                        <span className="text-[10px] text-gray-400 uppercase tracking-wider font-bold block">Cobros Asociados</span>
                        <div className="bg-gray-50 dark:bg-zinc-900 rounded-xl p-2 font-mono text-[9px] text-gray-600 dark:text-zinc-400 max-h-24 overflow-y-auto space-y-1">
                          {viewDetailDeposito.pagoIds.map(id => {
                            const matchedPago = pagos.find(p => p.id === id || p.reciboNo === id);
                            return (
                              <div key={id} className="flex justify-between font-sans">
                                <span className="truncate max-w-[120px]">{matchedPago ? matchedPago.clienteNombre : "Cobro"}</span>
                                <span className="font-bold">{matchedPago ? formatCurrency(matchedPago.monto, moneda) : id}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {viewDetailDeposito.notas && (
                      <div className="border-t border-dashed pt-3">
                        <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-bold">Observaciones</p>
                        <p className="text-[11px] text-gray-600 dark:text-zinc-400 italic">"{viewDetailDeposito.notas}"</p>
                      </div>
                    )}
                  </div>

                  {/* Image/Voucher preview column */}
                  <div className="flex flex-col justify-center items-center p-3 bg-gray-50 dark:bg-zinc-900 rounded-2xl border border-gray-150 dark:border-zinc-800/50 min-h-[160px]">
                    {viewDetailDeposito.voucher ? (
                      <div className="space-y-2 text-center w-full">
                        <span className="text-[10px] text-gray-400 uppercase tracking-wider font-bold block">Voucher Respaldado</span>
                        <a href={viewDetailDeposito.voucher} target="_blank" rel="noreferrer">
                          <img
                            src={viewDetailDeposito.voucher}
                            alt="Comprobante bancario"
                            className="max-h-48 mx-auto rounded-lg object-contain shadow-sm border dark:border-zinc-800 cursor-zoom-in animate-fade-in"
                            referrerPolicy="no-referrer"
                          />
                        </a>
                        <span className="text-[9px] text-gray-400">Haz clic en la imagen para ampliar</span>
                      </div>
                    ) : (
                      <div className="text-center text-gray-400 space-y-1">
                        <ImageIcon size={32} className="mx-auto text-gray-300 dark:text-zinc-700" />
                        <p className="text-[10px] font-bold text-gray-600 dark:text-zinc-400">Sin Voucher Digital</p>
                        <p className="text-[9px] text-gray-400">Este depósito fue guardado sin comprobante escaneado.</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    onClick={() => window.print()}
                    className="flex-1 py-2 bg-zinc-100 dark:bg-zinc-800 text-gray-700 dark:text-white rounded-xl text-xs font-semibold hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                  >
                    Imprimir Comprobante
                  </button>
                  <button
                    onClick={() => setViewDetailDeposito(null)}
                    className="flex-1 py-2 bg-zinc-800 dark:bg-zinc-700 text-white rounded-xl text-xs font-semibold hover:bg-zinc-700 dark:hover:bg-zinc-600 transition-colors"
                  >
                    Cerrar Detalle
                  </button>
                </div>

              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
