import React from "react";
import {
  LayoutDashboard,
  Users,
  Landmark,
  CreditCard,
  ShieldCheck,
  FileSpreadsheet,
  Wallet,
  Settings,
  Menu,
  X,
  Sun,
  Moon,
  LogOut,
  Building2,
  MapPin,
  Wifi,
  WifiOff,
  RefreshCw,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { APP_MODULOS, Usuario } from "../types";

interface SidebarProps {
  activeModule: string;
  setActiveModule: (module: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
  darkMode: boolean;
  setDarkMode: (darkMode: boolean) => void;
  companyName: string;
  companyLogo?: string;
  userEmail?: string;
  currentUserProfile?: Usuario | null;
  onLogout?: () => void;
  mobileMenuOpen?: boolean;
  setMobileMenuOpen?: (open: boolean) => void;
  syncStatus?: "synced" | "syncing" | "offline";
  onManualSync?: () => void;
}

const moduleIcons: { [key: string]: React.ComponentType<any> } = {
  dashboard: LayoutDashboard,
  ruta_cobro: MapPin,
  clientes: Users,
  prestamos: Landmark,
  pagos: CreditCard,
  garantias: ShieldCheck,
  finanzas: Wallet,
  reportes: FileSpreadsheet,
  configuracion: Settings
};

export default function Sidebar({
  activeModule,
  setActiveModule,
  collapsed,
  setCollapsed,
  darkMode,
  setDarkMode,
  companyName,
  companyLogo,
  userEmail,
  currentUserProfile,
  onLogout,
  mobileMenuOpen = false,
  setMobileMenuOpen,
  syncStatus = "synced",
  onManualSync
}: SidebarProps) {
  // Dynamically build and filter menu items based on module permissions
  const menuItems = APP_MODULOS.map((mod) => ({
    id: mod.id,
    label: mod.label,
    icon: moduleIcons[mod.id] || Settings
  })).filter((item) => {
    if (!currentUserProfile) return true; // Default to showing if profile not loaded yet
    if (currentUserProfile.rol === "Administrador") return true;
    return currentUserProfile.permisos?.[item.id]?.ver === true;
  });

  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden transition-opacity duration-300"
          onClick={() => setMobileMenuOpen && setMobileMenuOpen(false)}
        />
      )}

      <aside
        className={`fixed top-0 left-0 h-screen z-40 flex flex-col justify-between transition-all duration-300 ease-in-out border-r
          ${darkMode 
            ? "bg-[#121214] text-gray-100 border-[#27272a]" 
            : "bg-white text-gray-800 border-gray-100"
          }
          ${collapsed ? "lg:w-20" : "lg:w-64"}
          w-64
          lg:translate-x-0
          ${mobileMenuOpen ? "translate-x-0" : "-translate-x-full"}
        `}
        id="main-sidebar"
      >
        {/* Top Brand Info */}
        <div>
          <div className={`flex ${collapsed ? "flex-col gap-3 items-center" : "items-center justify-between"} p-4 border-b border-opacity-10 border-current transition-all duration-300`}>
            <div className="flex items-center gap-3 overflow-hidden">
              {companyLogo ? (
                <img
                  src={companyLogo}
                  alt="Logo"
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-lg object-cover flex-shrink-0 border border-gray-300 dark:border-zinc-700"
                />
              ) : (
                <div className="p-2 bg-emerald-600 text-white rounded-lg flex-shrink-0">
                  <Building2 size={22} id="brand-fallback-icon" />
                </div>
              )}
              {(!collapsed || mobileMenuOpen) && (
                <span className="font-semibold text-lg tracking-tight truncate max-w-[140px]" id="sidebar-company-name">
                  {companyName || "EasyPres"}
                </span>
              )}
            </div>
            {/* Collapse toggle is only helpful/visible on desktop */}
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="hidden lg:block p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 text-gray-500 dark:text-gray-400 transition-colors"
              id="toggle-sidebar-button"
              title={collapsed ? "Expandir menú" : "Contraer menú"}
            >
              {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
            </button>
            {/* Close button for mobile layout */}
            <button
              onClick={() => setMobileMenuOpen && setMobileMenuOpen(false)}
              className="block lg:hidden p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-gray-500"
              title="Cerrar menú"
            >
              <X size={20} />
            </button>
          </div>

          {/* Navigation Menu Links */}
          <nav className="p-3 space-y-1">
            {menuItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = activeModule === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveModule(item.id);
                    if (setMobileMenuOpen) setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-all duration-150 group relative
                    ${collapsed && !mobileMenuOpen ? "justify-center" : "justify-start"}
                    ${isActive 
                      ? "bg-emerald-600 text-white shadow-sm shadow-emerald-600/10" 
                      : "hover:bg-black/5 dark:hover:bg-white/5 text-gray-500 dark:text-gray-400"
                    }
                  `}
                  id={`nav-${item.id}`}
                  title={collapsed ? item.label : ""}
                >
                  <IconComponent 
                    size={20} 
                    className={`flex-shrink-0 transition-transform group-hover:scale-105 ${isActive ? "text-white" : "text-gray-400 dark:text-gray-500"}`} 
                  />
                  {(!collapsed || mobileMenuOpen) && (
                    <span className="truncate">{item.label}</span>
                  )}
                  
                  {/* Collapsed Tooltip */}
                  {collapsed && !mobileMenuOpen && (
                    <div className="absolute left-16 opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-200 bg-gray-900 dark:bg-zinc-800 text-white text-xs rounded-xl px-3 py-2 z-50 pointer-events-none whitespace-nowrap shadow-xl border border-zinc-800 dark:border-zinc-700 font-sans font-medium">
                      {item.label}
                    </div>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

       {/* Footer / Settings Quick Actions */}
      <div className="p-3 border-t border-opacity-10 border-current space-y-2">
        {/* Connection & Sync Status Widget */}
        <div className="px-1 py-0.5">
          {collapsed && !mobileMenuOpen ? (
            <div className="flex justify-center py-2 animate-fade-in" title={
              syncStatus === "offline" ? "Sin conexión (Seguro)" :
              syncStatus === "syncing" ? "Sincronizando con la nube..." :
              "Conectado y Sincronizado"
            }>
              {syncStatus === "offline" ? (
                <WifiOff size={18} className="text-amber-500 animate-pulse" />
              ) : syncStatus === "syncing" ? (
                <RefreshCw size={18} className="text-emerald-500 animate-spin" />
              ) : (
                <Wifi size={18} className="text-emerald-500" />
              )}
            </div>
          ) : (
            <div className={`p-2.5 rounded-xl border text-[11px] transition-all
              ${syncStatus === "offline" 
                ? "bg-amber-500/10 border-amber-500/20 text-amber-700 dark:text-amber-400" 
                : syncStatus === "syncing"
                ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-700 dark:text-emerald-400 animate-pulse"
                : "bg-emerald-500/5 border-emerald-500/10 text-zinc-500 dark:text-zinc-400"
              }
            `}>
              <div className="flex items-center gap-2">
                {syncStatus === "offline" ? (
                  <WifiOff size={14} className="flex-shrink-0 text-amber-500" />
                ) : syncStatus === "syncing" ? (
                  <RefreshCw size={14} className="flex-shrink-0 text-emerald-500 animate-spin" />
                ) : (
                  <Wifi size={14} className="flex-shrink-0 text-emerald-500" />
                )}
                <div className="font-medium truncate flex-1">
                  {syncStatus === "offline" ? "Modo Desconectado" :
                   syncStatus === "syncing" ? "Sincronizando..." :
                   "Datos Sincronizados"}
                </div>
              </div>
              {syncStatus === "offline" && onManualSync && (
                <button
                  onClick={onManualSync}
                  className="mt-1.5 w-full py-1 bg-amber-500 hover:bg-amber-600 text-white font-bold text-[9px] rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                >
                  <RefreshCw size={9} /> Reintentar Conexión
                </button>
              )}
            </div>
          )}
        </div>

        {/* Dark/Light mode toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className={`w-full flex items-center px-3 py-2.5 rounded-xl text-xs font-medium hover:bg-black/5 dark:hover:bg-white/5 text-gray-500 dark:text-gray-400 transition-colors
            ${collapsed && !mobileMenuOpen ? "justify-center" : "justify-between"}
          `}
          id="toggle-theme-button"
          title={collapsed ? (darkMode ? "Modo Claro" : "Modo Oscuro") : ""}
        >
          <div className="flex items-center gap-3">
            {darkMode ? <Sun size={18} className="text-amber-500" /> : <Moon size={18} className="text-indigo-500" />}
            {(!collapsed || mobileMenuOpen) && <span>{darkMode ? "Modo Claro" : "Modo Oscuro"}</span>}
          </div>
          {(!collapsed || mobileMenuOpen) && (
            <span className="px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 text-[10px]">
              {darkMode ? "Dark" : "Light"}
            </span>
          )}
        </button>

        {/* User Badge & Logout */}
        <div className="pt-2">
          {userEmail && (!collapsed || mobileMenuOpen) && (
            <div className="px-3 py-1.5 mb-2 rounded bg-black/5 dark:bg-white/5 overflow-hidden">
              <p className="text-[10px] text-gray-400 truncate">Sesión iniciada:</p>
              <p className="text-xs font-semibold truncate text-emerald-500">{userEmail}</p>
            </div>
          )}
          {onLogout && (
            <button
              onClick={onLogout}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium text-rose-500 hover:bg-rose-500/10 transition-colors
                ${collapsed && !mobileMenuOpen ? "justify-center" : "justify-start"}
              `}
              id="logout-button"
              title={collapsed ? "Cerrar Sesión" : ""}
            >
              <LogOut size={18} />
              {(!collapsed || mobileMenuOpen) && <span>Cerrar Sesión</span>}
            </button>
          )}
        </div>
      </div>
    </aside>
    </>
  );
}
