import React from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Clock, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Briefcase, 
  Coins, 
  Target,
  ArrowRightLeft,
  PiggyBank,
  Percent,
  LayoutGrid,
  Layers,
  ArrowUpRight,
  Info,
  Lock,
  GripVertical,
  RotateCcw,
  Sparkles,
  Eye,
  EyeOff
} from "lucide-react";
import { DashboardStats } from "../utils/dashboardHelpers";
import { formatCurrency } from "../utils";
import { Configuracion, Usuario } from "../types";

interface DashboardKPIsProps {
  stats: DashboardStats;
  prevStats: DashboardStats | null;
  periodFilter: string;
  moneda: string;
  configuracion?: Configuracion;
  viewMode: "ejecutiva" | "bento" | "compacta" | "analitica" | "desglosada";
  setViewMode: (mode: "ejecutiva" | "bento" | "compacta" | "analitica" | "desglosada") => void;
  visibleWidgets: Record<string, boolean>;
  cardOrder: string[];
  setCardOrder: (order: string[]) => void;
  usuario?: Usuario | null;
}

export default function DashboardKPIs({ 
  stats, 
  prevStats, 
  periodFilter, 
  moneda, 
  configuracion,
  viewMode,
  setViewMode,
  visibleWidgets,
  cardOrder,
  setCardOrder,
  usuario
}: DashboardKPIsProps) {
  const isPersonalizable = configuracion?.dashboardPersonalizable ?? true;

  // Drag and Drop implementation for card reordering
  const handleDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.setData("text/plain", index.toString());
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    const sourceIndex = parseInt(e.dataTransfer.getData("text/plain"), 10);
    if (isNaN(sourceIndex) || sourceIndex === targetIndex) return;
    
    const newOrder = [...cardOrder];
    const [removed] = newOrder.splice(sourceIndex, 1);
    newOrder.splice(targetIndex, 0, removed);
    setCardOrder(newOrder);
    localStorage.setItem("dashboard_card_order", JSON.stringify(newOrder));
  };

  // Trend helper inside individual cards
  const renderTrend = (current: number, prev: number | undefined | null, lowerIsBetter: boolean = false) => {
    if (periodFilter === "todos" || prev === undefined || prev === null) {
      return (
        <span className="text-[10px] text-zinc-400 dark:text-zinc-500 font-semibold block mt-1">
          Histórico
        </span>
      );
    }
    
    if (prev === 0) {
      if (current > 0) {
        return (
          <span className={`text-[10px] font-bold flex items-center gap-0.5 mt-1 ${lowerIsBetter ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"}`}>
            ▲ +100% vs ant.
          </span>
        );
      }
      return (
        <span className="text-[10px] text-zinc-400 dark:text-zinc-500 font-semibold block mt-1">
          Sin cambios (0%)
        </span>
      );
    }

    const diff = ((current - prev) / prev) * 100;
    if (Math.abs(diff) < 0.1) {
      return (
        <span className="text-[10px] text-zinc-400 dark:text-zinc-500 font-semibold block mt-1">
          Estable (0%)
        </span>
      );
    }
    const isPositive = diff >= 0;
    const absDiff = Math.abs(diff).toFixed(1);

    let isGood = isPositive;
    if (lowerIsBetter) {
      isGood = !isPositive;
    }

    const colorClass = isGood 
      ? "text-emerald-600 dark:text-emerald-400" 
      : "text-rose-600 dark:text-rose-450";

    return (
      <span className={`text-[10px] font-bold flex items-center gap-0.5 mt-1 ${colorClass}`}>
        {isPositive ? "▲" : "▼"} {isPositive ? "+" : "-"}{absDiff}% vs ant.
      </span>
    );
  };

  // Helper for inline compact trend badge
  const renderCompactTrendBadge = (current: number, prev: number | undefined | null, lowerIsBetter: boolean = false) => {
    if (periodFilter === "todos" || prev === undefined || prev === null) return null;
    if (prev === 0) {
      if (current > 0) {
        return (
          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${lowerIsBetter ? "bg-rose-50 text-rose-600 dark:bg-rose-950/20 dark:text-rose-400" : "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/20 dark:text-emerald-400"}`}>
            +100%
          </span>
        );
      }
      return null;
    }

    const diff = ((current - prev) / prev) * 100;
    if (Math.abs(diff) < 0.5) return null;
    const isPositive = diff >= 0;
    const absDiff = Math.abs(diff).toFixed(0);

    let isGood = isPositive;
    if (lowerIsBetter) isGood = !isPositive;

    const bgClass = isGood 
      ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/20 dark:text-emerald-400" 
      : "bg-rose-50 text-rose-600 dark:bg-rose-950/20 dark:text-rose-400";

    return (
      <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold font-mono ${bgClass}`}>
        {isPositive ? "↑" : "↓"} {absDiff}%
      </span>
    );
  };

  const viewOptions = [
    { id: "ejecutiva", label: "Vista Ejecutiva", icon: "💼", desc: "KPIs simplificados" },
    { id: "bento", label: "Bento Consolidado", icon: "🍱", desc: "Resumen balanceado" },
    { id: "compacta", label: "Vista Compacta", icon: "🗂", desc: "Alta densidad (13)" },
    { id: "analitica", label: "Vista Analítica", icon: "📊", desc: "Gráficos principales" },
    { id: "desglosada", label: "Vista Desglosada", icon: "📋", desc: "Detalle extendido (13)" }
  ] as const;

  const handleViewModeChange = (mode: typeof viewMode) => {
    if (!isPersonalizable) return;
    setViewMode(mode);
    localStorage.setItem("dashboard_layout_preference", mode);
  };

  // Define details for all 13 indicators
  const cardsData = [
    {
      id: "capital_prestado",
      categoria: "capital",
      titulo: "Capital Prestado",
      valor: formatCurrency(stats.capitalPrestado, moneda),
      trend: renderTrend(stats.capitalPrestado, prevStats?.capitalPrestado),
      compactTrend: renderCompactTrendBadge(stats.capitalPrestado, prevStats?.capitalPrestado),
      iconColor: "text-emerald-500",
      iconBg: "bg-emerald-500/5",
      icon: <DollarSign size={14} />,
      desc: "Monto histórico total colocado en préstamos"
    },
    {
      id: "capital_recuperado",
      categoria: "capital",
      titulo: "Capital Recuperado",
      valor: formatCurrency(stats.capitalCobrado, moneda),
      trend: renderTrend(stats.capitalCobrado, prevStats?.capitalCobrado),
      compactTrend: renderCompactTrendBadge(stats.capitalCobrado, prevStats?.capitalCobrado),
      iconColor: "text-emerald-500",
      iconBg: "bg-emerald-500/5",
      icon: <CheckCircle2 size={14} />,
      desc: "Capital neto devuelto por los clientes"
    },
    {
      id: "capital_pendiente",
      categoria: "capital",
      titulo: "Capital Pendiente",
      valor: formatCurrency(stats.balancePendienteTotal, moneda),
      trend: renderTrend(stats.balancePendienteTotal, prevStats?.balancePendienteTotal, true),
      compactTrend: renderCompactTrendBadge(stats.balancePendienteTotal, prevStats?.balancePendienteTotal, true),
      iconColor: "text-indigo-500",
      iconBg: "bg-indigo-500/5",
      icon: <Briefcase size={14} />,
      desc: "Cartera activa de capital pendiente de cobro"
    },
    {
      id: "intereses_generados",
      categoria: "intereses",
      titulo: "Intereses Generados",
      valor: formatCurrency(stats.interesGeneradoTotal, moneda),
      trend: renderTrend(stats.interesGeneradoTotal, prevStats?.interesGeneradoTotal),
      compactTrend: renderCompactTrendBadge(stats.interesGeneradoTotal, prevStats?.interesGeneradoTotal),
      iconColor: "text-blue-500",
      iconBg: "bg-blue-500/5",
      icon: <Target size={14} />,
      desc: "Intereses devengados por contratos vigentes"
    },
    {
      id: "intereses_cobrados",
      categoria: "intereses",
      titulo: "Intereses Cobrados",
      valor: formatCurrency(stats.interesCobrado, moneda),
      trend: renderTrend(stats.interesCobrado, prevStats?.interesCobrado),
      compactTrend: renderCompactTrendBadge(stats.interesCobrado, prevStats?.interesCobrado),
      iconColor: "text-blue-500",
      iconBg: "bg-blue-500/5",
      icon: <CheckCircle2 size={14} />,
      desc: "Intereses efectivamente percibidos"
    },
    {
      id: "mora_generada",
      categoria: "mora",
      titulo: "Mora Generada",
      valor: formatCurrency(stats.totalMoraGenerada, moneda),
      trend: renderTrend(stats.totalMoraGenerada, prevStats?.totalMoraGenerada, true),
      compactTrend: renderCompactTrendBadge(stats.totalMoraGenerada, prevStats?.totalMoraGenerada, true),
      iconColor: "text-rose-500",
      iconBg: "bg-rose-500/5",
      icon: <AlertTriangle size={14} />,
      desc: "Recargos aplicados por días de atraso"
    },
    {
      id: "mora_cobrada",
      categoria: "mora",
      titulo: "Mora Cobrada",
      valor: formatCurrency(stats.totalMoraCobrada, moneda),
      trend: renderTrend(stats.totalMoraCobrada, prevStats?.totalMoraCobrada),
      compactTrend: renderCompactTrendBadge(stats.totalMoraCobrada, prevStats?.totalMoraCobrada),
      iconColor: "text-emerald-500",
      iconBg: "bg-emerald-500/5",
      icon: <CheckCircle2 size={14} />,
      desc: "Recargos por mora recuperados"
    },
    {
      id: "mora_pendiente",
      categoria: "mora",
      titulo: "Mora Pendiente",
      valor: formatCurrency(stats.totalMoraPendiente, moneda),
      trend: renderTrend(stats.totalMoraPendiente, prevStats?.totalMoraPendiente, true),
      compactTrend: renderCompactTrendBadge(stats.totalMoraPendiente, prevStats?.totalMoraPendiente, true),
      iconColor: "text-rose-500",
      iconBg: "bg-rose-500/5",
      icon: <Coins size={14} />,
      desc: "Mora acumulada pendiente por percibir"
    },
    {
      id: "total_depositado",
      categoria: "depositos",
      titulo: "Total Depositado",
      valor: formatCurrency(stats.totalDepositado, moneda),
      trend: renderTrend(stats.totalDepositado, prevStats?.totalDepositado),
      compactTrend: renderCompactTrendBadge(stats.totalDepositado, prevStats?.totalDepositado),
      iconColor: "text-sky-500",
      iconBg: "bg-sky-500/5",
      icon: <PiggyBank size={14} />,
      desc: "Total transferido a cuentas bancarias"
    },
    {
      id: "caja_pendiente",
      categoria: "caja",
      titulo: "Caja por Cerrar",
      valor: formatCurrency(stats.cajaPendientePorCerrar, moneda),
      trend: renderTrend(stats.cajaPendientePorCerrar, prevStats?.cajaPendientePorCerrar, true),
      compactTrend: renderCompactTrendBadge(stats.cajaPendientePorCerrar, prevStats?.cajaPendientePorCerrar, true),
      iconColor: "text-amber-500",
      iconBg: "bg-amber-500/5",
      icon: <Clock size={14} />,
      desc: "Efectivo en mano de cobradores sin rendir"
    },
    {
      id: "prestamos_activos",
      categoria: "metas",
      titulo: "Préstamos Activos",
      valor: stats.prestamosActivos,
      trend: renderTrend(stats.prestamosActivos, prevStats?.prestamosActivos),
      compactTrend: renderCompactTrendBadge(stats.prestamosActivos, prevStats?.prestamosActivos),
      iconColor: "text-emerald-500",
      iconBg: "bg-emerald-500/5",
      icon: <Activity size={14} />,
      desc: "Contratos vigentes al día"
    },
    {
      id: "prestamos_vencidos",
      categoria: "mora",
      titulo: "Préstamos Vencidos",
      valor: stats.prestamosAtrasados,
      trend: renderTrend(stats.prestamosAtrasados, prevStats?.prestamosAtrasados, true),
      compactTrend: renderCompactTrendBadge(stats.prestamosAtrasados, prevStats?.prestamosAtrasados, true),
      iconColor: "text-rose-500",
      iconBg: "bg-rose-500/5",
      icon: <AlertTriangle size={14} />,
      desc: "Contratos con cuotas vencidas activas"
    },
    {
      id: "prestamos_liquidados",
      categoria: "metas",
      titulo: "Préstamos Liquidados",
      valor: stats.prestamosSaldados,
      trend: renderTrend(stats.prestamosSaldados, prevStats?.prestamosSaldados),
      compactTrend: renderCompactTrendBadge(stats.prestamosSaldados, prevStats?.prestamosSaldados),
      iconColor: "text-blue-500",
      iconBg: "bg-blue-500/5",
      icon: <CheckCircle2 size={14} />,
      desc: "Contratos saldados en su totalidad"
    }
  ];

  // Helper to check if a card category is visible based on active customized modules
  const isCardVisible = (cardId: string, cat: string) => {
    // If user is a cobrador, apply strict business limits
    if (usuario?.rol === "Cobrador") {
      // Cobradores can ONLY see Caja por Cerrar, Metas/Activos/Liquidados, and nothing else
      return ["caja_pendiente", "prestamos_activos", "prestamos_liquidados"].includes(cardId);
    }
    
    // Normal visibility checks
    if (cat === "capital") return visibleWidgets.capital ?? true;
    if (cat === "intereses") return visibleWidgets.intereses ?? true;
    if (cat === "mora") return visibleWidgets.mora ?? true;
    if (cat === "caja") return visibleWidgets.caja ?? true;
    if (cat === "depositos") return visibleWidgets.depositos ?? true;
    if (cat === "metas") return visibleWidgets.metas ?? true;
    return true;
  };

  // Order cards as requested
  const orderedCards = cardOrder
    .map(id => cardsData.find(c => c.id === id))
    .filter((c): c is NonNullable<typeof c> => !!c && isCardVisible(c.id, c.categoria));

  return (
    <div className="space-y-5">
      
      {/* 1. VIEW MODE SELECTOR TOOLBAR */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-3 bg-zinc-50 dark:bg-zinc-900/40 p-3 rounded-2xl border border-zinc-150 dark:border-zinc-800">
        <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
          <Info size={14} className="text-emerald-500 shrink-0" />
          <div className="leading-tight">
            <span className="font-bold text-gray-700 dark:text-zinc-200">Distribución de Pantalla:</span>
            {!isPersonalizable ? (
              <span className="text-[10px] text-indigo-500 font-semibold flex items-center gap-0.5 mt-0.5">
                <Lock size={10} /> Preestablecido por Empresa
              </span>
            ) : (
              <span className="text-[10px] text-zinc-400 block mt-0.5">
                Alterna la disposición según tu rol o dispositivo
              </span>
            )}
          </div>
        </div>

        {/* Buttons layout */}
        <div className="flex flex-wrap items-center gap-1 bg-white dark:bg-zinc-950 p-1 rounded-xl shadow-3xs border border-zinc-200/50 dark:border-zinc-800/80 w-full xl:w-auto">
          {viewOptions.map(opt => {
            const isActive = viewMode === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                disabled={!isPersonalizable}
                title={opt.desc}
                onClick={() => handleViewModeChange(opt.id)}
                className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 text-[11px] font-extrabold rounded-lg transition-all cursor-pointer ${
                  isActive 
                    ? "bg-emerald-500 text-white shadow-xs" 
                    : "text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-900"
                } ${!isPersonalizable ? "opacity-60 cursor-not-allowed" : ""}`}
              >
                <span>{opt.icon}</span>
                <span>{opt.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. RENDER VIEW MODE: VISTA EJECUTIVA (5 CORE FINANCIAL KPI CARDS) */}
      {viewMode === "ejecutiva" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          
          {/* Executive Card 1: Capital Activo Pendiente */}
          {isCardVisible("capital_pendiente", "capital") && (
            <div className="bg-gradient-to-br from-white to-zinc-50/30 dark:from-[#121214] dark:to-zinc-950 border border-zinc-150 dark:border-zinc-800 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black uppercase tracking-widest text-zinc-400 dark:text-zinc-555 flex items-center gap-1">
                    💼 Capital Neto
                  </span>
                  {renderCompactTrendBadge(stats.balancePendienteTotal, prevStats?.balancePendienteTotal, true)}
                </div>
                <h4 className="text-[11px] font-bold text-gray-500">Capital Activo Pendiente</h4>
                <p className="text-2xl font-black text-zinc-900 dark:text-white font-mono tracking-tight leading-none">
                  {formatCurrency(stats.balancePendienteTotal, moneda)}
                </p>
              </div>
              <div className="text-[10px] text-zinc-400 dark:text-zinc-500 mt-4 pt-2 border-t border-zinc-100 dark:border-zinc-900 font-semibold">
                Monto total de cartera vigente
              </div>
            </div>
          )}

          {/* Executive Card 2: Cobros del Período */}
          {isCardVisible("capital_recuperado", "capital") && (
            <div className="bg-gradient-to-br from-white to-zinc-50/30 dark:from-[#121214] dark:to-zinc-950 border border-zinc-150 dark:border-zinc-800 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black uppercase tracking-widest text-emerald-500 flex items-center gap-1">
                    📈 Cobros Hoy
                  </span>
                  {renderCompactTrendBadge(stats.cobrosDelDia, prevStats?.cobrosDelDia)}
                </div>
                <h4 className="text-[11px] font-bold text-gray-500">Cobrado del Período</h4>
                <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono tracking-tight leading-none">
                  {formatCurrency(stats.cobrosDelDia, moneda)}
                </p>
              </div>
              <div className="text-[10px] text-emerald-500/80 mt-4 pt-2 border-t border-zinc-100 dark:border-zinc-900 font-semibold">
                Efectivo + depósitos cobrados hoy
              </div>
            </div>
          )}

          {/* Executive Card 3: Mora Activa Pendiente */}
          {isCardVisible("mora_pendiente", "mora") && (
            <div className="bg-gradient-to-br from-white to-zinc-50/30 dark:from-[#121214] dark:to-zinc-950 border border-zinc-150 dark:border-zinc-800 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black uppercase tracking-widest text-rose-500 flex items-center gap-1">
                    ⚠️ Mora Pendiente
                  </span>
                  {renderCompactTrendBadge(stats.totalMoraPendiente, prevStats?.totalMoraPendiente, true)}
                </div>
                <h4 className="text-[11px] font-bold text-gray-500">Mora Activa Pendiente</h4>
                <p className="text-2xl font-black text-rose-600 dark:text-rose-500 font-mono tracking-tight leading-none">
                  {formatCurrency(stats.totalMoraPendiente, moneda)}
                </p>
              </div>
              <div className="text-[10px] text-rose-500/80 mt-4 pt-2 border-t border-zinc-100 dark:border-zinc-900 font-semibold">
                Riesgo de atraso de clientes
              </div>
            </div>
          )}

          {/* Executive Card 4: Caja por Cerrar */}
          {isCardVisible("caja_pendiente", "caja") && (
            <div className="bg-gradient-to-br from-white to-zinc-50/30 dark:from-[#121214] dark:to-zinc-950 border border-zinc-150 dark:border-zinc-800 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black uppercase tracking-widest text-amber-500 flex items-center gap-1">
                    🔑 Operativa
                  </span>
                  {renderCompactTrendBadge(stats.cajaPendientePorCerrar, prevStats?.cajaPendientePorCerrar, true)}
                </div>
                <h4 className="text-[11px] font-bold text-gray-500">Caja por Cerrar</h4>
                <p className="text-2xl font-black text-amber-600 dark:text-amber-500 font-mono tracking-tight leading-none">
                  {formatCurrency(stats.cajaPendientePorCerrar, moneda)}
                </p>
              </div>
              <div className="text-[10px] text-amber-500/80 mt-4 pt-2 border-t border-zinc-100 dark:border-zinc-900 font-semibold">
                Efectivo por liquidar en oficinas
              </div>
            </div>
          )}

          {/* Executive Card 5: Total Depositado */}
          {isCardVisible("total_depositado", "depositos") && (
            <div className="bg-gradient-to-br from-white to-zinc-50/30 dark:from-[#121214] dark:to-zinc-950 border border-zinc-150 dark:border-zinc-800 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black uppercase tracking-widest text-sky-500 flex items-center gap-1">
                    🏦 Bancos
                  </span>
                  {renderCompactTrendBadge(stats.totalDepositado, prevStats?.totalDepositado)}
                </div>
                <h4 className="text-[11px] font-bold text-gray-500">Total Depositado</h4>
                <p className="text-2xl font-black text-sky-600 dark:text-sky-400 font-mono tracking-tight leading-none">
                  {formatCurrency(stats.totalDepositado, moneda)}
                </p>
              </div>
              <div className="text-[10px] text-sky-500/80 mt-4 pt-2 border-t border-zinc-100 dark:border-zinc-900 font-semibold">
                Tesorería conciliada bancaria
              </div>
            </div>
          )}

        </div>
      )}

      {/* 3. RENDER VIEW MODE: BENTO CONSOLIDADO (5 CONSOLIDATED PROGRESS CARDS) */}
      {(viewMode === "bento" || viewMode === "analitica") && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          
          {/* Card 1: Flujo de Capital */}
          {isCardVisible("capital_pendiente", "capital") && (
            <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 p-5 rounded-3xl shadow-3xs flex flex-col justify-between hover:border-emerald-500/20 transition-all group">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest flex items-center gap-1">
                    <Briefcase size={10} className="text-emerald-500" />
                    Flujo de Capital
                  </span>
                  {renderCompactTrendBadge(stats.balancePendienteTotal, prevStats?.balancePendienteTotal, true)}
                </div>
                <div>
                  <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 font-sans">Capital Activo Pendiente</span>
                  <p className="text-xl font-black text-gray-900 dark:text-white font-mono tracking-tight leading-tight mt-0.5">
                    {formatCurrency(stats.balancePendienteTotal, moneda)}
                  </p>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-zinc-400 font-sans">Recuperación:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-mono">
                      {stats.capitalPrestado > 0 ? ((stats.capitalCobrado / stats.capitalPrestado) * 100).toFixed(0) : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-zinc-50 dark:bg-zinc-900 h-1.5 rounded-full overflow-hidden border border-zinc-150 dark:border-zinc-850">
                    <div 
                      className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full"
                      style={{ width: `${stats.capitalPrestado > 0 ? Math.min((stats.capitalCobrado / stats.capitalPrestado) * 100, 100) : 0}%` }}
                    />
                  </div>
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-zinc-50 dark:border-zinc-900 text-[11px] space-y-1.5 font-sans">
                <div className="flex justify-between text-zinc-450">
                  <span>Prestado Total:</span>
                  <span className="font-semibold font-mono text-zinc-750 dark:text-zinc-350">{formatCurrency(stats.capitalPrestado, moneda)}</span>
                </div>
                <div className="flex justify-between text-zinc-450">
                  <span>Recuperado:</span>
                  <span className="font-semibold font-mono text-emerald-600 dark:text-emerald-400">{formatCurrency(stats.capitalCobrado, moneda)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Card 2: Rentabilidad */}
          {isCardVisible("intereses_cobrados", "intereses") && (
            <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 p-5 rounded-3xl shadow-3xs flex flex-col justify-between hover:border-blue-500/20 transition-all group">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest flex items-center gap-1">
                    <Target size={10} className="text-blue-500" />
                    Rentabilidad
                  </span>
                  {renderCompactTrendBadge(stats.interesCobrado, prevStats?.interesCobrado)}
                </div>
                <div>
                  <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 font-sans">Intereses Recaudados</span>
                  <p className="text-xl font-black text-blue-600 dark:text-blue-400 font-mono tracking-tight leading-tight mt-0.5">
                    {formatCurrency(stats.interesCobrado, moneda)}
                  </p>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-zinc-400 font-sans">Logro (ROI):</span>
                    <span className="text-blue-600 dark:text-blue-400 font-mono">
                      {stats.interesGeneradoTotal > 0 ? ((stats.interesCobrado / stats.interesGeneradoTotal) * 100).toFixed(0) : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-zinc-50 dark:bg-zinc-900 h-1.5 rounded-full overflow-hidden border border-zinc-150 dark:border-zinc-850">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-indigo-400 h-full rounded-full"
                      style={{ width: `${stats.interesGeneradoTotal > 0 ? Math.min((stats.interesCobrado / stats.interesGeneradoTotal) * 100, 100) : 0}%` }}
                    />
                  </div>
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-zinc-50 dark:border-zinc-900 text-[11px] space-y-1.5 font-sans">
                <div className="flex justify-between text-zinc-450">
                  <span>Interés Proyectado:</span>
                  <span className="font-semibold font-mono text-zinc-750 dark:text-zinc-350">{formatCurrency(stats.interesGeneradoTotal, moneda)}</span>
                </div>
                <div className="flex justify-between text-zinc-450">
                  <span>Rendimiento Bruto:</span>
                  <span className="font-bold text-indigo-500 font-mono">
                    {stats.capitalPrestado > 0 ? ((stats.interesGeneradoTotal / stats.capitalPrestado) * 100).toFixed(1) : 0}%
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Card 3: Mitigación de Mora */}
          {isCardVisible("mora_pendiente", "mora") && (
            <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 p-5 rounded-3xl shadow-3xs flex flex-col justify-between hover:border-rose-500/20 transition-all group">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest flex items-center gap-1">
                    <Coins size={10} className="text-rose-500" />
                    Mitigación Mora
                  </span>
                  {renderCompactTrendBadge(stats.totalMoraPendiente, prevStats?.totalMoraPendiente, true)}
                </div>
                <div>
                  <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 font-sans">Mora Activa Pendiente</span>
                  <p className="text-xl font-black text-rose-600 dark:text-rose-500 font-mono tracking-tight leading-tight mt-0.5">
                    {formatCurrency(stats.totalMoraPendiente, moneda)}
                  </p>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-zinc-400 font-sans">Eficiencia de Cobro:</span>
                    <span className="text-rose-600 dark:text-rose-455 font-mono">
                      {stats.totalMoraGenerada > 0 ? ((stats.totalMoraCobrada / stats.totalMoraGenerada) * 100).toFixed(0) : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-zinc-50 dark:bg-zinc-900 h-1.5 rounded-full overflow-hidden border border-zinc-150 dark:border-zinc-850">
                    <div 
                      className="bg-gradient-to-r from-rose-500 to-orange-400 h-full rounded-full"
                      style={{ width: `${stats.totalMoraGenerada > 0 ? Math.min((stats.totalMoraCobrada / stats.totalMoraGenerada) * 100, 100) : 0}%` }}
                    />
                  </div>
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-zinc-50 dark:border-zinc-900 text-[11px] space-y-1.5 font-sans">
                <div className="flex justify-between text-zinc-450">
                  <span>Mora Recargada:</span>
                  <span className="font-semibold font-mono text-zinc-750 dark:text-zinc-350">{formatCurrency(stats.totalMoraGenerada, moneda)}</span>
                </div>
                <div className="flex justify-between text-zinc-450">
                  <span>Mora Cobrada:</span>
                  <span className="font-semibold font-mono text-emerald-600 dark:text-emerald-400">{formatCurrency(stats.totalMoraCobrada, moneda)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Card 4: Tesorería & Caja */}
          {(isCardVisible("caja_pendiente", "caja") || isCardVisible("total_depositado", "depositos")) && (
            <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 p-5 rounded-3xl shadow-3xs flex flex-col justify-between hover:border-sky-500/20 transition-all group">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest flex items-center gap-1">
                    <PiggyBank size={10} className="text-sky-500" />
                    Tesorería & Caja
                  </span>
                  {renderCompactTrendBadge(stats.totalDepositado, prevStats?.totalDepositado)}
                </div>
                <div>
                  <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 font-sans">Total en Bancos</span>
                  <p className="text-xl font-black text-sky-655 dark:text-sky-400 font-mono tracking-tight leading-tight mt-0.5">
                    {formatCurrency(stats.totalDepositado, moneda)}
                  </p>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-zinc-400 font-sans">Tasa de Depósito:</span>
                    <span className="text-sky-600 dark:text-sky-455 font-mono">
                      {stats.totalDepositado + stats.cajaPendientePorCerrar > 0 
                        ? ((stats.totalDepositado / (stats.totalDepositado + stats.cajaPendientePorCerrar)) * 100).toFixed(0) 
                        : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-zinc-50 dark:bg-zinc-900 h-1.5 rounded-full overflow-hidden border border-zinc-150 dark:border-zinc-850">
                    <div 
                      className="bg-gradient-to-r from-sky-500 to-emerald-400 h-full rounded-full"
                      style={{ width: `${stats.totalDepositado + stats.cajaPendientePorCerrar > 0 ? Math.min((stats.totalDepositado / (stats.totalDepositado + stats.cajaPendientePorCerrar)) * 100, 100) : 0}%` }}
                    />
                  </div>
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-zinc-50 dark:border-zinc-900 text-[11px] space-y-1.5 font-sans">
                <div className="flex justify-between text-zinc-450">
                  <span>Efectivo en Caja:</span>
                  <span className="font-semibold font-mono text-amber-600 dark:text-amber-500">{formatCurrency(stats.cajaPendientePorCerrar, moneda)}</span>
                </div>
                <div className="flex justify-between text-zinc-450">
                  <span>Cobrado en Período:</span>
                  <span className="font-semibold font-mono text-emerald-600 dark:text-emerald-400">{formatCurrency(stats.cobrosDelDia, moneda)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Card 5: Operaciones */}
          {isCardVisible("prestamos_activos", "metas") && (
            <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 p-5 rounded-3xl shadow-3xs flex flex-col justify-between hover:border-indigo-500/20 transition-all group">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest flex items-center gap-1">
                    <Activity size={10} className="text-indigo-500" />
                    Operaciones
                  </span>
                  {renderCompactTrendBadge(stats.prestamosActivos, prevStats?.prestamosActivos)}
                </div>
                <div>
                  <span className="text-[10px] font-bold text-gray-400 dark:text-gray-500 font-sans">Préstamos Activos</span>
                  <p className="text-2xl font-black text-indigo-655 dark:text-indigo-400 tracking-tight leading-none mt-0.5 font-mono">
                    {stats.prestamosActivos}
                  </p>
                </div>
                {(() => {
                  const total = stats.prestamosActivos + stats.prestamosAtrasados + stats.prestamosSaldados || 1;
                  const pActivos = (stats.prestamosActivos / total) * 100;
                  const pAtrasados = (stats.prestamosAtrasados / total) * 100;
                  const pSaldados = (stats.prestamosSaldados / total) * 100;
                  return (
                    <div className="space-y-1 font-sans">
                      <span className="text-[10px] text-zinc-400 font-bold block">Composición de Cartera:</span>
                      <div className="w-full h-1.5 bg-zinc-50 dark:bg-zinc-900 rounded-full flex overflow-hidden border border-zinc-150 dark:border-zinc-850">
                        <div className="bg-emerald-500 h-full animate-pulse" style={{ width: `${pActivos}%` }} title={`Activos: ${pActivos.toFixed(0)}%`} />
                        <div className="bg-amber-500 h-full" style={{ width: `${pAtrasados}%` }} title={`Vencidos: ${pAtrasados.toFixed(0)}%`} />
                        <div className="bg-blue-500 h-full" style={{ width: `${pSaldados}%` }} title={`Saldados: ${pSaldados.toFixed(0)}%`} />
                      </div>
                    </div>
                  );
                })()}
              </div>
              <div className="pt-3 mt-3 border-t border-zinc-50 dark:border-zinc-900 text-[11px] space-y-1.5 font-sans">
                <div className="flex justify-between text-zinc-450">
                  <span>Atrasados (Mora):</span>
                  <span className="font-bold text-rose-550 dark:text-rose-455 font-mono">{stats.prestamosAtrasados}</span>
                </div>
                <div className="flex justify-between text-zinc-450">
                  <span>Liquidados:</span>
                  <span className="font-semibold text-blue-500 font-mono">{stats.prestamosSaldados}</span>
                </div>
              </div>
            </div>
          )}

        </div>
      )}

      {/* 4. RENDER VIEW MODE: VISTA DESGLOSADA (ALL ACTIVE/VISIBLE CARDS IN GRID WITH FULL DESIGN & DRAG HANDLES) */}
      {viewMode === "desglosada" && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-400 flex items-center gap-1 font-sans">
              📋 Vista Desglosada {isPersonalizable && <span className="text-indigo-500 text-[9px] font-medium lowercase">(arrastra las tarjetas para reordenarlas)</span>}
            </span>
            {isPersonalizable && (
              <button
                onClick={() => {
                  localStorage.removeItem("dashboard_card_order");
                  window.location.reload();
                }}
                className="flex items-center gap-1 text-[10px] font-bold text-zinc-500 hover:text-emerald-500 cursor-pointer transition-colors bg-zinc-100 dark:bg-zinc-900 px-2.5 py-1 rounded-lg"
              >
                <RotateCcw size={11} /> Restaurar Diseño
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {orderedCards.map((card, idx) => (
              <div
                key={card.id}
                draggable={isPersonalizable}
                onDragStart={(e) => handleDragStart(e, idx)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, idx)}
                className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 p-5 rounded-2xl shadow-2xs hover:shadow-xs hover:border-emerald-500/20 dark:hover:border-emerald-500/10 transition-all flex flex-col justify-between group cursor-grab active:cursor-grabbing relative overflow-hidden"
              >
                {/* Drag Handle Overlay or indicator */}
                {isPersonalizable && (
                  <div className="absolute top-2 right-2 text-zinc-300 dark:text-zinc-700 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    <GripVertical size={14} />
                  </div>
                )}
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-extrabold text-zinc-450 uppercase tracking-widest leading-none font-sans">
                      {card.titulo}
                    </span>
                    <span className={`p-1.5 ${card.iconBg} ${card.iconColor} rounded-lg shrink-0`}>
                      {card.icon}
                    </span>
                  </div>
                  <p className="text-xl font-black text-zinc-800 dark:text-zinc-100 mt-2 font-mono tracking-tight leading-none">
                    {card.valor}
                  </p>
                  <p className="text-[10px] text-zinc-400 mt-1 font-medium font-sans">
                    {card.desc}
                  </p>
                </div>
                <div className="mt-4 pt-2 border-t border-zinc-100/50 dark:border-zinc-900/60 flex items-center justify-between font-sans">
                  {card.trend}
                  {card.compactTrend}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. RENDER VIEW MODE: VISTA COMPACTA (HIGH-DENSITY EXPANDED CARDS WITH DECREASED PADDING & SMALL FONTS) */}
      {viewMode === "compacta" && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-400 flex items-center gap-1 font-sans">
              🗂 Vista Compacta de Alta Densidad {isPersonalizable && <span className="text-indigo-500 text-[9px] font-medium lowercase">(organizador rápido)</span>}
            </span>
            {isPersonalizable && (
              <button
                onClick={() => {
                  localStorage.removeItem("dashboard_card_order");
                  window.location.reload();
                }}
                className="flex items-center gap-1 text-[10px] font-bold text-zinc-500 hover:text-emerald-500 cursor-pointer transition-colors bg-zinc-100 dark:bg-zinc-900 px-2.5 py-1 rounded-lg"
              >
                <RotateCcw size={11} /> Restaurar Diseño
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 gap-2">
            {orderedCards.map((card, idx) => (
              <div
                key={card.id}
                draggable={isPersonalizable}
                onDragStart={(e) => handleDragStart(e, idx)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, idx)}
                className="bg-white dark:bg-[#121214] border border-gray-150/70 dark:border-zinc-800 p-3 rounded-xl shadow-3xs hover:border-emerald-500/30 transition-all flex flex-col justify-between cursor-grab active:cursor-grabbing group relative overflow-hidden"
              >
                {isPersonalizable && (
                  <div className="absolute top-1 right-1 text-zinc-300 dark:text-zinc-700 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    <GripVertical size={11} />
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-1">
                    <span className={`${card.iconColor} shrink-0`}>
                      {card.icon}
                    </span>
                    <span className="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 truncate leading-tight font-sans">
                      {card.titulo}
                    </span>
                  </div>
                  <p className="text-sm font-black text-zinc-800 dark:text-zinc-100 font-mono tracking-tight leading-tight">
                    {card.valor}
                  </p>
                </div>
                <div className="mt-2 pt-1 border-t border-zinc-100/40 dark:border-zinc-900/40 flex items-center justify-between text-[8px] font-sans">
                  {card.trend}
                  {card.compactTrend}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
