import React, { useState, useEffect, useMemo } from "react";
import {
  MapPin,
  Phone,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Search,
  ChevronRight,
  Check,
  X,
  RefreshCw,
  Smartphone,
  Calendar,
  Filter,
  User,
  CheckSquare,
  Coins,
  MessageSquare,
  Navigation,
  Compass,
  ExternalLink,
  Copy,
  Share2,
  SlidersHorizontal
} from "lucide-react";
import { Cliente, Prestamo, Pago, Usuario, CuotaDetalle } from "../types";
import { formatCurrency, generateRandomCode, formatLocalDate, actualizarCuotasConMora } from "../utils";
import FilterBottomSheet from "./FilterBottomSheet";
import SwipeableVisitCard from "./SwipeableVisitCard";
import WhatsAppModal from "./WhatsAppModal";
import NavigationModal from "./NavigationModal";

interface RutaCobroProps {
  clientes: Cliente[];
  prestamos: Prestamo[];
  pagos: Pago[];
  moneda: string;
  onSavePago: (pago: Pago, updatedPrestamo: Prestamo) => Promise<void>;
  currentUserProfile?: Usuario | null;
  usuarios: Usuario[];
  onAddAuditLog?: (accion: string, usuarioAfectado: string, detalles?: string) => Promise<void>;
  configuracion?: any;
}

interface EstadoVisita {
  estado: "Pendiente" | "Cobrado" | "No Localizado";
  notas?: string;
  fecha?: string;
}

export default function RutaCobro({
  clientes,
  prestamos,
  pagos,
  moneda,
  onSavePago,
  currentUserProfile,
  usuarios,
  onAddAuditLog,
  configuracion
}: RutaCobroProps) {
  const isCobrador = currentUserProfile?.rol === "Cobrador";
  
  // Select which cobrador's route we are viewing (Admins/Supervisors can select any cobrador)
  const [selectedCobradorId, setSelectedCobradorId] = useState<string>("");

  useEffect(() => {
    if (currentUserProfile) {
      if (currentUserProfile.rol === "Cobrador") {
        setSelectedCobradorId(currentUserProfile.email || "");
      } else {
        // Admin/Supervisor: default to first active cobrador if available, otherwise ""
        const firstCobrador = usuarios.find((u) => u.rol === "Cobrador" && u.activo);
        setSelectedCobradorId(firstCobrador?.email || "");
      }
    }
  }, [currentUserProfile, usuarios]);

  // Track browser connection status for Offline First confirmation
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState("");
  const [sectorFilter, setSectorFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<"Todos" | "Pendientes" | "Cobrados" | "No Localizados">("Todos");
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);

  // Swipe actions state (Gestos)
  const [swipeEnabled, setSwipeEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("swipeEnabled");
    return saved !== null ? saved === "true" : true;
  });

  useEffect(() => {
    localStorage.setItem("swipeEnabled", String(swipeEnabled));
  }, [swipeEnabled]);

  // Local state for tracking current day's visits to preserve in localStorage
  const [visitasState, setVisitasState] = useState<{ [loanId: string]: EstadoVisita }>({});

  // Payment Quick Modal States
  const [isPaying, setIsPaying] = useState(false);
  const [selectedPrestamoParaPago, setSelectedPrestamoParaPago] = useState<Prestamo | null>(null);
  const [formMonto, setFormMonto] = useState<number>(0);
  const [formNotas, setFormNotas] = useState("");
  const [isSubmittingPago, setIsSubmittingPago] = useState(false);

  // Estados de Distribución de Mora para el modal móvil
  const [useCustomDistribution, setUseCustomDistribution] = useState(false);
  const [manualMoraPago, setManualMoraPago] = useState<number>(0);
  const [manualCuotaPago, setManualCuotaPago] = useState<number>(0);

  // Detalles de Mora en Tiempo Real para el Préstamo Seleccionado
  const selectedLoanMoraDetails = useMemo(() => {
    if (!selectedPrestamoParaPago) return { cuotasConMora: [], totalUnpaidMora: 0, totalCuotaNormal: 0 };
    let rawCuotas: CuotaDetalle[] = [];
    try {
      rawCuotas = JSON.parse(selectedPrestamoParaPago.cuotasDetalle || "[]");
    } catch (e) {
      console.error(e);
    }
    const cuotasConMora = actualizarCuotasConMora(
      rawCuotas,
      selectedPrestamoParaPago.tipoMora,
      selectedPrestamoParaPago.valorMora,
      selectedPrestamoParaPago.diasToleranciaMora,
      new Date().toISOString().split("T")[0],
      configuracion?.moraMaximaMonto
    );
    const totalUnpaidMora = cuotasConMora.reduce((sum, c) => sum + Math.max(0, (c.moraMonto || 0) - (c.moraPagada || 0)), 0);
    const firstUnpaid = cuotasConMora.find(c => c.estado !== "Pagado");
    const totalCuotaNormal = firstUnpaid ? firstUnpaid.monto - firstUnpaid.montoPagado : selectedPrestamoParaPago.montoCuota;
    return { cuotasConMora, totalUnpaidMora, totalCuotaNormal };
  }, [selectedPrestamoParaPago, configuracion?.moraMaximaMonto]);

  // Distribución del pago según la política configurada
  const liveDistribution = useMemo(() => {
    const total = Number(formMonto) || 0;
    const totalMora = selectedLoanMoraDetails.totalUnpaidMora;
    const policy = configuracion?.prioridadPagoMora || "mora_first";
    
    let moraApp = 0;
    let cuotaApp = 0;
    
    if (policy === "mora_first") {
      moraApp = Math.min(total, totalMora);
      cuotaApp = Number((total - moraApp).toFixed(2));
    } else if (policy === "cuota_first") {
      const pendingInst = selectedPrestamoParaPago ? Number(selectedPrestamoParaPago.balancePendiente.toFixed(2)) : 0;
      cuotaApp = Math.min(total, pendingInst);
      moraApp = Number((total - cuotaApp).toFixed(2));
      moraApp = Math.min(moraApp, totalMora);
    } else {
      // manual or ask
      moraApp = Math.min(total, totalMora);
      cuotaApp = Number((total - moraApp).toFixed(2));
    }
    
    return { moraApp, cuotaApp };
  }, [formMonto, selectedLoanMoraDetails.totalUnpaidMora, selectedPrestamoParaPago, configuracion?.prioridadPagoMora]);

  // Sincronizar estados de cobro manual con la distribución automática
  useEffect(() => {
    if (!useCustomDistribution) {
      setManualMoraPago(liveDistribution.moraApp);
      setManualCuotaPago(liveDistribution.cuotaApp);
    }
  }, [liveDistribution, useCustomDistribution]);

  // Visit status Modal States (No Localizado/Compromiso)
  const [isLoggingVisit, setIsLoggingVisit] = useState(false);
  const [selectedPrestamoParaVisita, setSelectedPrestamoParaVisita] = useState<Prestamo | null>(null);
  const [visitNotas, setVisitNotas] = useState("");

  // WhatsApp Click-to-Chat states
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [selectedWhatsAppCliente, setSelectedWhatsAppCliente] = useState<Cliente | null>(null);
  const [selectedWhatsAppPrestamo, setSelectedWhatsAppPrestamo] = useState<Prestamo | null>(null);
  const [selectedWhatsAppMonto, setSelectedWhatsAppMonto] = useState<number | undefined>(undefined);

  // Navigation GPS states
  const [isNavigationModalOpen, setIsNavigationModalOpen] = useState(false);
  const [selectedNavigationCliente, setSelectedNavigationCliente] = useState<Cliente | null>(null);

  // Load progress from localStorage on mount/cobrador change
  useEffect(() => {
    const todayStr = new Date().toISOString().split("T")[0];
    const key = `easypres_ruta_visitas_${selectedCobradorId}_${todayStr}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      try {
        setVisitasState(JSON.parse(stored));
      } catch (e) {
        console.error("Error al cargar progreso de visitas", e);
      }
    } else {
      setVisitasState({});
    }
  }, [selectedCobradorId]);

  // Save progress to localStorage helper
  const saveVisitasState = (newState: { [loanId: string]: EstadoVisita }) => {
    const todayStr = new Date().toISOString().split("T")[0];
    const key = `easypres_ruta_visitas_${selectedCobradorId}_${todayStr}`;
    localStorage.setItem(key, JSON.stringify(newState));
    setVisitasState(newState);
  };

  // Filter cobradores for selection dropdown
  const cobradoresList = usuarios.filter((u) => u.rol === "Cobrador" && u.activo);

  // Get active/late loans assigned to selected cobrador
  const activeLoans = prestamos.filter((p) => {
    const client = clientes.find((c) => c.id === p.clienteId);
    
    // Check if matching selected cobrador or logged-in cobrador
    let cobradorIdMatch = false;
    if (selectedCobradorId) {
      cobradorIdMatch = 
        p.cobradorId?.toLowerCase() === selectedCobradorId.toLowerCase() ||
        client?.cobradorId?.toLowerCase() === selectedCobradorId.toLowerCase();
    } else if (isCobrador) {
      const userEmail = currentUserProfile?.email?.toLowerCase() || "";
      cobradorIdMatch = 
        p.cobradorId?.toLowerCase() === userEmail ||
        client?.cobradorId?.toLowerCase() === userEmail;
    } else {
      // For Admin/Supervisor, if no cobrador is selected, show all active loans
      cobradorIdMatch = true;
    }

    const isLoanActive = p.estado === "Activo" || p.estado === "Atrasado";
    const hasBalance = p.balancePendiente > 0;
    return cobradorIdMatch && isLoanActive && hasBalance;
  });

  // Unique list of clients associated with these active loans
  const assignedClients = clientes.filter((c) =>
    activeLoans.some((p) => p.clienteId === c.id)
  );

  // Group sectors based on clients addresses
  const activeSectors = Array.from(
    new Set(
      assignedClients
        .map((c) => {
          // Extract general area/sector if formatted like "Sector, Ciudad" or just clean up the address
          const parts = c.direccion.split(",");
          return parts[parts.length - 1]?.trim() || "General";
        })
        .filter(Boolean)
    )
  );

  // Map active loans to a convenient Route Item structure
  const routeItems = activeLoans.map((loan, index) => {
    const cliente = clientes.find((c) => c.id === loan.clienteId);
    
    // Parse current payment installment info
    let cuotas: CuotaDetalle[] = [];
    try {
      cuotas = JSON.parse(loan.cuotasDetalle || "[]");
    } catch {}
    
    const nextCuota = cuotas.find((c) => c.estado !== "Pagado");
    const montoCuotaEsperado = nextCuota ? nextCuota.monto : loan.montoCuota;
    
    // Check if there are payments registered TODAY for this loan
    const todayStr = new Date().toISOString().split("T")[0];
    const pagoAsociado = pagos.find(
      (p) =>
        p.prestamoId === loan.id &&
        p.fecha?.startsWith(todayStr)
    );
    const pagadoHoy = !!pagoAsociado;

    // Get visit status (override to "Cobrado" if actual payment exists for today)
    const storedStatus = visitasState[loan.id || ""] || { estado: "Pendiente" };
    const currentStatus: "Pendiente" | "Cobrado" | "No Localizado" = pagadoHoy 
      ? "Cobrado" 
      : storedStatus.estado;

    // Helper to guess sector
    const parts = cliente?.direccion.split(",") || [];
    const sector = parts[parts.length - 1]?.trim() || "General";

    return {
      id: loan.id || "",
      loan,
      cliente,
      montoCuotaEsperado,
      status: currentStatus,
      storedStatus,
      sector,
      order: index + 1,
      pagoAsociado
    };
  });

  // Filter route items based on query, sector, and status filter
  const filteredRouteItems = routeItems.filter((item) => {
    const matchesSearch =
      item.cliente?.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.loan.numero.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.cliente?.cedula.includes(searchQuery);

    const matchesSector = !sectorFilter || item.sector === sectorFilter;

    const matchesStatus =
      statusFilter === "Todos" ||
      (statusFilter === "Pendientes" && item.status === "Pendiente") ||
      (statusFilter === "Cobrados" && item.status === "Cobrado") ||
      (statusFilter === "No Localizados" && item.status === "No Localizado");

    return matchesSearch && matchesSector && matchesStatus;
  });

  // Sort: Priority to Late loans (Atrasados), then grouped by sector, then by client name
  const sortedRouteItems = [...filteredRouteItems].sort((a, b) => {
    // 1. Overdue loans first
    if (a.loan.estado === "Atrasado" && b.loan.estado !== "Atrasado") return -1;
    if (a.loan.estado !== "Atrasado" && b.loan.estado === "Atrasado") return 1;

    // 2. Group by sector alphabetically
    const sectorCompare = a.sector.localeCompare(b.sector);
    if (sectorCompare !== 0) return sectorCompare;

    // 3. Alphabetical by client name
    return (a.cliente?.nombre || "").localeCompare(b.cliente?.nombre || "");
  });

  // Calculation summaries
  const totalEsperadoRuta = routeItems.reduce((sum, item) => sum + item.montoCuotaEsperado, 0);
  
  // Realized collection today
  const todayStr = new Date().toISOString().split("T")[0];
  const cobradoHoyRuta = pagos
    .filter((p) => p.fecha?.startsWith(todayStr) && activeLoans.some((l) => l.id === p.prestamoId))
    .reduce((sum, p) => sum + p.monto, 0);

  const visitasCompletadas = routeItems.filter((item) => item.status !== "Pendiente").length;
  const totalVisitas = routeItems.length;

  // Handler: Save Quick Payment
  const handleRegisterPaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPrestamoParaPago || formMonto <= 0) return;

    const loan = selectedPrestamoParaPago;
    const { cuotasConMora, totalUnpaidMora } = selectedLoanMoraDetails;
    const maxPermitido = Number((loan.balancePendiente + totalUnpaidMora).toFixed(2));

    if (formMonto > maxPermitido) {
      alert(`El monto no puede exceder el total pendiente del préstamo incluyendo recargos (${formatCurrency(maxPermitido, moneda)})`);
      return;
    }

    // Determine the split between Mora and scheduled installment
    let moraPagado = useCustomDistribution ? Number(manualMoraPago) : liveDistribution.moraApp;
    let cuotaPagado = useCustomDistribution ? Number(manualCuotaPago) : liveDistribution.cuotaApp;

    // Double check that split sums to formMonto
    const calculatedSum = Number((moraPagado + cuotaPagado).toFixed(2));
    if (Math.abs(calculatedSum - formMonto) > 0.02) {
      // Re-normalize if floating errors occur
      cuotaPagado = Number((formMonto - moraPagado).toFixed(2));
    }

    // POLICY FLOW: "Cobrar solo la cuota" (Omitting Mora) warning
    if (totalUnpaidMora > 0 && moraPagado < totalUnpaidMora) {
      if (configuracion?.requerirAutorizacionOmitir) {
        const pin = prompt(`AUTORIZACIÓN REQUERIDA: Este cliente tiene una mora acumulada de ${formatCurrency(totalUnpaidMora, moneda)}.\nIntroduzca la clave de Administrador o Supervisor para omitir cobrar la mora y registrar solo la cuota:`);
        if (pin !== "1234" && pin !== "admin") {
          alert("Clave de seguridad inválida. No tiene autorización para omitir el recargo de mora.");
          return;
        }
      } else {
        const confirmOmit = window.confirm(
          `Este cliente tiene una mora pendiente de ${formatCurrency(totalUnpaidMora, moneda)}.\n¿Desea cobrar solamente la cuota y dejar la mora pendiente para futuras visitas?`
        );
        if (!confirmOmit) {
          return;
        }
      }
    }

    setIsSubmittingPago(true);

    try {
      const balanceAntes = loan.balancePendiente;

      // Allocation-match to the pending cuotas
      let capitalPagado = 0;
      let interesPagado = 0;
      let remainingMoraToDistribute = moraPagado;
      let remainingCuotaToDistribute = cuotaPagado;

      const updatedCuotas = cuotasConMora.map((c) => {
        // 1. Pay pending late fee for this installment first
        const unpaidMoraInCuota = Math.max(0, (c.moraMonto || 0) - (c.moraPagada || 0));
        let currentCuotaMoraPaid = 0;
        if (unpaidMoraInCuota > 0 && remainingMoraToDistribute > 0) {
          currentCuotaMoraPaid = Math.min(remainingMoraToDistribute, unpaidMoraInCuota);
          remainingMoraToDistribute = Number((remainingMoraToDistribute - currentCuotaMoraPaid).toFixed(2));
        }

        // 2. Pay scheduled installment amount
        const cuotaPending = c.monto - c.montoPagado;
        let currentCuotaAmtPaid = 0;
        if (cuotaPending > 0 && remainingCuotaToDistribute > 0) {
          currentCuotaAmtPaid = Math.min(remainingCuotaToDistribute, cuotaPending);
          remainingCuotaToDistribute = Number((remainingCuotaToDistribute - currentCuotaAmtPaid).toFixed(2));
          
          // Calculate capital and interest ratios paid
          const ratio = currentCuotaAmtPaid / c.monto;
          capitalPagado += c.capital * ratio;
          interesPagado += c.interes * ratio;
        }

        const totalMontoPagado = Number((c.montoPagado + currentCuotaAmtPaid).toFixed(2));
        const totalMoraPagada = Number(((c.moraPagada || 0) + currentCuotaMoraPaid).toFixed(2));

        let finalEstado: "Pagado" | "Pendiente" | "Parcial" = c.estado;
        if (totalMontoPagado >= c.monto) {
          finalEstado = "Pagado";
        } else if (totalMontoPagado > 0) {
          finalEstado = "Parcial";
        }

        return {
          ...c,
          montoPagado: totalMontoPagado,
          moraPagada: totalMoraPagada,
          estado: finalEstado
        };
      });

      capitalPagado = Number(capitalPagado.toFixed(2));
      interesPagado = Number(interesPagado.toFixed(2));

      // Scheduled balance (representing outstanding principal) decreases strictly by capital component paid
      const balanceDespues = Number(Math.max(0, balanceAntes - capitalPagado).toFixed(2));

      let nuevoEstado = loan.estado;
      if (balanceDespues <= 0) {
        nuevoEstado = "Saldado";
      }

      const nextPending = updatedCuotas.find((c) => c.estado !== "Pagado");
      const proximaCuotaFecha = nextPending ? nextPending.fechaVence : loan.fechaVencimiento;

      const updatedLoan: Prestamo = {
        ...loan,
        balancePendiente: balanceDespues,
        estado: nuevoEstado,
        proximaCuotaFecha,
        cuotasDetalle: JSON.stringify(updatedCuotas)
      };

      const reciboNo = generateRandomCode("REC");
      const newPago: Pago = {
        reciboNo,
        prestamoId: loan.id || "",
        clienteId: loan.clienteId,
        clienteNombre: loan.clienteNombre,
        prestamoNumero: loan.numero,
        fecha: new Date().toISOString(),
        monto: formMonto,
        tipoPago: formMonto >= loan.balancePendiente + totalUnpaidMora ? "Pago Completo" : "Pago de Cuota",
        capitalPagado,
        interesPagado,
        moraPagado,
        balanceAntes,
        balanceDespues,
        notas: formNotas || "Registrado en Ruta de Cobro",
        cobradorId: currentUserProfile?.email || "",
        cobradorNombre: currentUserProfile?.nombre || "Cobrador de Campo"
      };

      await onSavePago(newPago, updatedLoan);

      // Log audit
      if (onAddAuditLog) {
        await onAddAuditLog(
          "Registro de Pago en Campo",
          `Pago ID: ${reciboNo}`,
          `Préstamo: ${loan.numero}, Monto: ${moneda}${formMonto}`
        );
      }

      // Mark local state as Cobrado
      const updatedVisitas = {
        ...visitasState,
        [loan.id || ""]: {
          estado: "Cobrado" as const,
          notas: formNotas || "Pago cobrado en campo",
          fecha: new Date().toISOString()
        }
      };
      saveVisitasState(updatedVisitas);

      setIsPaying(false);
      setSelectedPrestamoParaPago(null);
      setFormMonto(0);
      setFormNotas("");
      alert(`¡Pago de ${formatCurrency(formMonto, moneda)} registrado con éxito! Recibo: ${reciboNo}`);
    } catch (err: any) {
      console.error(err);
      const errMsg = err?.message || String(err);
      alert("Error al registrar el pago: " + errMsg);
    } finally {
      setIsSubmittingPago(false);
    }
  };

  // Handler: Log Visit Note (No Localizado)
  const handleLogVisitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPrestamoParaVisita) return;

    const loanId = selectedPrestamoParaVisita.id || "";
    const updatedVisitas = {
      ...visitasState,
      [loanId]: {
        estado: "No Localizado" as const,
        notas: visitNotas || "No localizado / Pospuesto",
        fecha: new Date().toISOString()
      }
    };
    saveVisitasState(updatedVisitas);

    if (onAddAuditLog) {
      onAddAuditLog(
        "Bitácora de Ruta",
        `Cliente: ${selectedPrestamoParaVisita.clienteNombre}`,
        `Visita fallida/nota de ruta: ${visitNotas}`
      ).catch(console.error);
    }

    setIsLoggingVisit(false);
    setSelectedPrestamoParaVisita(null);
    setVisitNotas("");
  };

  // Reset progress button
  const handleResetRoute = () => {
    if (confirm("¿Estás seguro de que deseas reiniciar el progreso de visitas para el día de hoy?")) {
      saveVisitasState({});
    }
  };

  const getWhatsAppReceiptLink = (
    clienteNombre: string,
    telefono: string,
    reciboNo: string,
    monto: number,
    balanceDespues: number,
    cobradorNombre: string,
    fecha?: string
  ) => {
    const cleanPhone = telefono ? telefono.replace(/\D/g, "") : "";
    const formattedDate = fecha
      ? new Date(fecha).toLocaleDateString() +
        " " +
        new Date(fecha).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      : new Date().toLocaleDateString();

    const text = `*REGISTRO DE PAGO - RECIBO DIGITAL* 🧾\n` +
      `━━━━━━━━━━━━━━━━━━━\n` +
      `👤 *Cliente:* ${clienteNombre}\n` +
      `🔢 *Nro Recibo:* ${reciboNo}\n` +
      `📅 *Fecha:* ${formattedDate}\n` +
      `💵 *Monto Recibido:* ${formatCurrency(monto, moneda)}\n` +
      `📉 *Balance Restante:* ${formatCurrency(balanceDespues, moneda)}\n` +
      `👤 *Atendido por:* ${cobradorNombre}\n` +
      `━━━━━━━━━━━━━━━━━━━\n` +
      `¡Muchas gracias por su abono! 🙏✨`;

    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
  };

  const handleCopyReceipt = (
    clienteNombre: string,
    reciboNo: string,
    monto: number,
    balanceDespues: number,
    cobradorNombre: string,
    fecha?: string
  ) => {
    const formattedDate = fecha
      ? new Date(fecha).toLocaleDateString() +
        " " +
        new Date(fecha).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      : new Date().toLocaleDateString();

    const text = `REGISTRO DE PAGO - RECIBO DIGITAL 🧾\n` +
      `━━━━━━━━━━━━━━━━━━━\n` +
      `Cliente: ${clienteNombre}\n` +
      `Nro Recibo: ${reciboNo}\n` +
      `Fecha: ${formattedDate}\n` +
      `Monto Recibido: ${formatCurrency(monto, moneda)}\n` +
      `Balance Restante: ${formatCurrency(balanceDespues, moneda)}\n` +
      `Atendido por: ${cobradorNombre}\n` +
      `━━━━━━━━━━━━━━━━━━━\n` +
      `¡Muchas gracias por su abono! 🙏`;

    navigator.clipboard.writeText(text);
    alert("¡Texto del recibo copiado al portapapeles!");
  };

  return (
    <div className="space-y-6 max-w-md mx-auto px-1 sm:px-0 font-sans" id="ruta-cobro-screen">
      {/* Header Widget */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 rounded-xl">
              <Navigation className="animate-pulse" size={18} />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900 dark:text-zinc-100 tracking-tight">Ruta de Cobro</h2>
              <p className="text-[10px] text-gray-500 font-medium">Asignación para visitas de campo hoy</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className={`inline-block w-1.5 h-1.5 rounded-full ${isOnline ? "bg-emerald-500" : "bg-amber-500 animate-pulse"}`}></span>
                <span className="text-[9px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">
                  {isOnline ? "Modo En Línea" : "Desconectado (Seguro)"}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {/* Acciones Rápidas (Swipe) Toggle */}
            <label className="inline-flex items-center gap-1.5 cursor-pointer select-none" title="Activar/Desactivar deslizamiento rápido">
              <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Deslizar</span>
              <div className="relative">
                <input
                  type="checkbox"
                  checked={swipeEnabled}
                  onChange={(e) => setSwipeEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-7 h-4 bg-zinc-200 dark:bg-zinc-800 rounded-full peer peer-checked:after:translate-x-3 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-emerald-500" />
              </div>
            </label>

            <button
              onClick={handleResetRoute}
              className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-200 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg transition-all"
              title="Reiniciar ruta"
              id="btn-reset-route"
            >
              <RefreshCw size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Control Panel: For non-cobradores to select route */}
      {!isCobrador && (
        <div className="bg-amber-50/70 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-950/40 rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-1.5">
            <User className="text-amber-600" size={15} />
            <h3 className="text-xs font-bold text-amber-800 dark:text-amber-400 uppercase tracking-wider">
              Control de Supervisión
            </h3>
          </div>
          <p className="text-[10px] text-amber-800/80 dark:text-amber-400/80 leading-relaxed">
            Como Administrador/Supervisor, puedes seleccionar y visualizar la ruta de cobros asignada a cualquiera de tus cobradores activos para hoy.
          </p>
          <div>
            <select
              value={selectedCobradorId}
              onChange={(e) => setSelectedCobradorId(e.target.value)}
              className="w-full text-xs font-medium bg-white dark:bg-[#18181b] border border-gray-200 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              id="select-cobrador-route"
            >
              <option value="">-- Seleccionar Cobrador --</option>
              {cobradoresList.map((c) => (
                <option key={c.email} value={c.email}>
                  {c.nombre} ({c.email})
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* Summary KPI Panel - Highly readable for mobile */}
      <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm space-y-4">
        {/* Progress header */}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Visitas de Hoy</p>
            <p className="text-xl font-black text-gray-800 dark:text-zinc-100">
              {visitasCompletadas} <span className="text-gray-300 font-light">/</span> {totalVisitas}
            </p>
          </div>
          <div className="text-right space-y-0.5">
            <p className="text-[10px] text-emerald-600/80 dark:text-emerald-400/80 font-bold uppercase tracking-wider">Cobrado Hoy</p>
            <p className="text-lg font-black text-emerald-600 dark:text-emerald-400">
              {formatCurrency(cobradoHoyRuta, moneda)}
            </p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-100 dark:bg-zinc-800 rounded-full h-2">
          <div
            className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
            style={{ width: `${totalVisitas > 0 ? (visitasCompletadas / totalVisitas) * 100 : 0}%` }}
          />
        </div>

        {/* Dynamic route targets */}
        <div className="grid grid-cols-2 gap-3 border-t border-gray-50 dark:border-zinc-800/60 pt-3 text-xs">
          <div className="bg-zinc-50 dark:bg-zinc-900/40 p-2.5 rounded-xl space-y-0.5">
            <span className="text-[10px] font-semibold text-gray-400">Meta de Cobro</span>
            <p className="font-bold text-gray-700 dark:text-zinc-300">
              {formatCurrency(totalEsperadoRuta, moneda)}
            </p>
          </div>
          <div className="bg-zinc-50 dark:bg-zinc-900/40 p-2.5 rounded-xl space-y-0.5">
            <span className="text-[10px] font-semibold text-gray-400">Pendiente</span>
            <p className="font-bold text-rose-500">
              {formatCurrency(Math.max(0, totalEsperadoRuta - cobradoHoyRuta), moneda)}
            </p>
          </div>
        </div>
      </div>

      {/* Filters Accordion/Bar */}
      <div className="space-y-2">
        <div className="flex gap-2 items-center">
          {/* Search bar */}
          <div className="relative flex-1">
            <span className="absolute left-3.5 top-2.5 text-gray-400">
              <Search size={14} />
            </span>
            <input
              type="text"
              placeholder="Buscar cliente, cédula..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-xl text-gray-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-sm"
              id="search-route-input"
            />
          </div>

          {/* Sector filter */}
          {activeSectors.length > 0 && (
            <select
              value={sectorFilter}
              onChange={(e) => setSectorFilter(e.target.value)}
              className="hidden sm:block text-xs bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-xl px-2.5 py-2 text-gray-800 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-sm"
              id="select-sector-filter"
            >
              <option value="">Sectores</option>
              {activeSectors.map((sector) => (
                <option key={sector} value={sector}>
                  {sector}
                </option>
              ))}
            </select>
          )}

          {/* Filters toggle button for mobile bottom sheet */}
          <button
            onClick={() => setIsFilterSheetOpen(true)}
            className="p-2 border rounded-xl bg-white dark:bg-[#121214] border-gray-100 dark:border-zinc-800 text-gray-500 hover:text-emerald-500 hover:border-emerald-500/30 transition-all relative cursor-pointer active:scale-95 flex items-center justify-center min-h-[34px]"
            title="Filtros avanzados de ruta"
          >
            <SlidersHorizontal size={14} />
            {(statusFilter !== "Todos" || sectorFilter !== "") && (
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full border border-white dark:border-zinc-950" />
            )}
          </button>
        </div>

        {/* Quick horizontal status tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none" id="status-tabs">
          {(["Todos", "Pendientes", "Cobrados", "No Localizados"] as const).map((status) => {
            const isActive = statusFilter === status;
            return (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all flex-shrink-0 border ${
                  isActive
                    ? "bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 border-zinc-900 dark:border-zinc-100"
                    : "bg-white dark:bg-[#121214] text-gray-500 border-gray-100 dark:border-zinc-800 hover:bg-gray-50"
                }`}
              >
                {status}
              </button>
            );
          })}
        </div>
      </div>

      {/* Visits List */}
      {swipeEnabled && sortedRouteItems.length > 0 && (
        <div className="lg:hidden flex items-center gap-2.5 px-3.5 py-2.5 bg-emerald-500/10 dark:bg-emerald-500/5 border border-emerald-500/20 dark:border-emerald-900/30 rounded-xl text-[10px] font-bold text-emerald-700 dark:text-emerald-400 select-none animate-fade-in">
          <span className="flex h-2 w-2 relative shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <span className="leading-relaxed">
            💡 <strong>Acciones Rápidas:</strong> Desliza un cliente hacia la <strong>izquierda para Abonar 💸</strong> o hacia la <strong>derecha para Posponer ⏳</strong>.
          </span>
        </div>
      )}

      <div className="space-y-3" id="visits-list">
        {sortedRouteItems.length === 0 ? (
          <div className="text-center py-10 bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl space-y-2">
            <Smartphone className="mx-auto text-gray-300" size={32} />
            <p className="text-xs text-gray-400 font-medium">No se encontraron visitas con los filtros seleccionados.</p>
          </div>
        ) : (
          sortedRouteItems.map((item, idx) => {
            const isLate = item.loan.estado === "Atrasado";
            
            // Extract installment progress details safely
            let cuotas: CuotaDetalle[] = [];
            try {
              if (item.loan.cuotasDetalle) {
                cuotas = JSON.parse(item.loan.cuotasDetalle);
              }
            } catch (e) {
              console.error("Error parsing cuotasDetalle inside card", e);
            }
            
            const totalCuotas = item.loan.plazoCuotas || cuotas.length;
            const cuotasPagadas = cuotas.filter(c => c.estado === "Pagado").length;
            const actualCuotaNum = cuotas.findIndex(c => c.estado !== "Pagado") + 1;

            // Generate initials for customer avatar
            const clientInitials = item.cliente?.nombre
              ? item.cliente.nombre.split(" ").slice(0, 2).map(n => n[0]).join("").toUpperCase()
              : "CL";

            // Determine border and color states
            let cardBorder = "border-zinc-200 dark:border-zinc-850/80";
            let stateBorderLeft = "border-l-4 border-l-zinc-350 dark:border-l-zinc-700";
            
            if (item.status === "Cobrado") {
              cardBorder = "border-emerald-500/20 bg-emerald-50/5 dark:bg-emerald-950/5";
              stateBorderLeft = "border-l-4 border-l-emerald-500";
            } else if (item.status === "No Localizado") {
              cardBorder = "border-amber-500/20 bg-amber-50/5 dark:bg-amber-950/5";
              stateBorderLeft = "border-l-4 border-l-amber-500";
            } else if (isLate) {
              cardBorder = "border-rose-500/20";
              stateBorderLeft = "border-l-4 border-l-rose-500";
            }

            // Google Maps query URL helper
            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
              `${item.cliente?.direccion || ""} ${item.cliente?.nombre || ""}`
            )}`;

            return (
              <SwipeableVisitCard
                key={item.id}
                disabled={!swipeEnabled || item.status !== "Pendiente"}
                onPospone={() => {
                  setSelectedPrestamoParaVisita(item.loan);
                  setIsLoggingVisit(true);
                }}
                onAbonar={() => {
                  setSelectedPrestamoParaPago(item.loan);
                  setFormMonto(item.montoCuotaEsperado);
                  setIsPaying(true);
                }}
              >
                <div
                  className={`relative bg-white dark:bg-[#121214] border rounded-2xl shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden ${cardBorder} ${stateBorderLeft}`}
                >
                {/* Upper Status Line & Route ID */}
                <div className="flex items-center justify-between px-4 pt-3.5 pb-2 border-b border-zinc-100/60 dark:border-zinc-900/60">
                  <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                    <MapPin size={11} className="text-zinc-400" />
                    Turno #{idx + 1} • {item.sector || "General"}
                  </span>
                  
                  {/* Color-Coded Status Badge */}
                  {item.status === "Cobrado" ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-450 border border-emerald-500/20">
                      <CheckCircle2 size={10} className="stroke-[2.5]" /> Cobrado
                    </span>
                  ) : item.status === "No Localizado" ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-450 border border-amber-500/20">
                      <AlertTriangle size={10} /> Pospuesto
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-zinc-50 text-zinc-500 dark:bg-zinc-800/80 dark:text-zinc-400 border border-zinc-200 dark:border-zinc-700/50">
                      <Clock size={10} /> Pendiente
                    </span>
                  )}
                </div>

                {/* Content Slip Area */}
                <div className="p-4 space-y-3.5">
                  {/* Client Identification with Avatar */}
                  <div className="flex items-start gap-3">
                    {/* Customer Initials Avatar */}
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 select-none border shadow-xs
                      ${item.status === "Cobrado" ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/20" : 
                        isLate ? "bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 border-rose-100 dark:border-rose-900/20" : 
                        "bg-zinc-50 dark:bg-zinc-900 text-zinc-650 dark:text-zinc-350 border-zinc-200 dark:border-zinc-800"}`}
                    >
                      {clientInitials}
                    </div>

                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <h4 className="font-extrabold text-sm text-zinc-900 dark:text-zinc-100 tracking-tight">
                          {item.cliente?.nombre}
                        </h4>
                        
                        <div className="flex gap-1 items-center shrink-0">
                          {isLate && (
                            <span className="inline-flex px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wide bg-rose-500 text-white animate-pulse">
                              Atrasado
                            </span>
                          )}
                          <span className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-[9px] font-mono font-bold text-zinc-500">
                            {item.cliente?.codigo}
                          </span>
                        </div>
                      </div>

                      {/* Map Location Link */}
                      {item.cliente?.direccion && (
                        <div className="flex items-start gap-1 text-[11px] text-zinc-500 dark:text-zinc-400 group leading-relaxed">
                          <MapPin size={12} className="text-zinc-400 shrink-0 mt-0.5" />
                          <div className="flex-1">
                            <span>{item.cliente.direccion}</span>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedNavigationCliente(item.cliente || null);
                                setIsNavigationModalOpen(true);
                              }}
                              className="inline-flex items-center gap-0.5 text-[10px] font-extrabold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 ml-1.5 underline decoration-dotted tracking-tight cursor-pointer"
                            >
                              <Compass size={10} className="stroke-[2.5]" /> Cómo llegar
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Core Slip Stats: Loan metrics */}
                  <div className="bg-zinc-50/70 dark:bg-[#151518] border border-zinc-150/40 dark:border-zinc-850/50 p-3 rounded-xl space-y-3 shadow-2xs">
                    {/* Primary metrics grid */}
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="space-y-0.5">
                        <span className="text-[9px] text-gray-400 dark:text-zinc-500 font-bold uppercase tracking-wider block">Modalidad</span>
                        <span className="font-extrabold text-zinc-700 dark:text-zinc-200">
                          {item.loan.frecuenciaPago}
                        </span>
                      </div>
                      <div className="space-y-0.5 text-center">
                        <span className="text-[9px] text-gray-400 dark:text-zinc-500 font-bold uppercase tracking-wider block">Monto Cuota</span>
                        <span className="font-black text-emerald-600 dark:text-emerald-400">
                          {formatCurrency(item.montoCuotaEsperado, moneda)}
                        </span>
                      </div>
                      <div className="space-y-0.5 text-right">
                        <span className="text-[9px] text-rose-450 font-bold uppercase tracking-wider block">Deuda Restante</span>
                        <span className="font-extrabold text-rose-500">
                          {formatCurrency(item.loan.balancePendiente, moneda)}
                        </span>
                      </div>
                    </div>

                    {/* Progress tracker bar */}
                    <div className="pt-2 border-t border-zinc-150/50 dark:border-zinc-800/50">
                      <div className="flex justify-between text-[9px] text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wide mb-1">
                        <span>Progreso de Cuotas</span>
                        <span>{cuotasPagadas} / {totalCuotas} Cuotas</span>
                      </div>
                      
                      {/* Visual Progress bar representing paid percentage */}
                      <div className="w-full bg-zinc-200 dark:bg-zinc-800 h-1.5 rounded-full overflow-hidden flex">
                        <div 
                          className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                          style={{ width: `${Math.round((cuotasPagadas / (totalCuotas || 1)) * 100)}%` }}
                        />
                      </div>
                      
                      {item.status === "Pendiente" && (
                        <p className="text-[9px] text-zinc-450 dark:text-zinc-400 mt-1 font-mono">
                          Cobrando hoy: <strong className="text-zinc-700 dark:text-zinc-300">Cuota #{actualCuotaNum}</strong> de {totalCuotas}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Visit Notes Box */}
                  {item.storedStatus.notas && (
                    <div className="p-2.5 bg-zinc-50/50 dark:bg-zinc-900/30 rounded-xl border border-dashed border-zinc-150 dark:border-zinc-800 text-[10px] text-zinc-500 dark:text-zinc-400 italic flex items-start gap-1.5">
                      <MessageSquare size={12} className="text-zinc-400 shrink-0 mt-0.5" />
                      <span>Nota de ruta: {item.storedStatus.notas}</span>
                    </div>
                  )}

                  {/* Touch Friendly Bottom Navigation / Actions Bar */}
                  <div className="flex gap-2 pt-1 border-t border-zinc-50 dark:border-zinc-900/50">
                    {/* Click-to-call & WhatsApp targets with 44px height */}
                    {item.cliente?.telefono && (
                      <div className="flex gap-1.5 shrink-0">
                        <a
                          href={`tel:${item.cliente.telefono}`}
                          className="min-h-[44px] w-11 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-750 rounded-xl flex items-center justify-center text-zinc-600 dark:text-zinc-300 transition-colors"
                          title="Llamar Cliente"
                        >
                          <Phone size={14} className="stroke-[2.5]" />
                        </a>
                        <button
                          onClick={() => {
                            setSelectedWhatsAppCliente(item.cliente || null);
                            setSelectedWhatsAppPrestamo(item.loan || null);
                            setSelectedWhatsAppMonto(item.montoCuotaEsperado);
                            setIsWhatsAppModalOpen(true);
                          }}
                          className="min-h-[44px] w-11 bg-emerald-50 hover:bg-emerald-100/80 dark:bg-emerald-950/20 dark:hover:bg-emerald-950/40 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 transition-colors"
                          title="Enviar WhatsApp"
                        >
                          <MessageSquare size={14} className="stroke-[2.5]" />
                        </button>
                      </div>
                    )}

                    {item.status === "Pendiente" ? (
                      <>
                        {/* Pospone Action Key */}
                        <button
                          onClick={() => {
                            setSelectedPrestamoParaVisita(item.loan);
                            setIsLoggingVisit(true);
                          }}
                          className="min-h-[44px] flex-1 px-3 border border-zinc-250 hover:bg-zinc-50 dark:border-zinc-800 dark:hover:bg-zinc-900 text-zinc-650 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <AlertTriangle size={13} /> Pospone
                        </button>

                        {/* Cobrar Cuota Main Action Key */}
                        <button
                          onClick={() => {
                            setSelectedPrestamoParaPago(item.loan);
                            setFormMonto(item.montoCuotaEsperado);
                            setIsPaying(true);
                          }}
                          className="min-h-[44px] flex-[1.5] px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                        >
                          <Coins size={14} /> Registrar Abono
                        </button>
                      </>
                    ) : item.status === "Cobrado" ? (
                      <div className="flex-1 flex gap-2 w-full">
                        {/* Copy Digital Slip Receipt */}
                        <button
                          onClick={() => {
                            if (item.pagoAsociado) {
                              handleCopyReceipt(
                                item.cliente?.nombre || "",
                                item.pagoAsociado.reciboNo,
                                item.pagoAsociado.monto,
                                item.pagoAsociado.balanceDespues,
                                item.pagoAsociado.cobradorNombre || "",
                                item.pagoAsociado.fecha
                              );
                            } else {
                              handleCopyReceipt(
                                item.cliente?.nombre || "",
                                "REC-LOCAL",
                                item.montoCuotaEsperado,
                                Math.max(0, item.loan.balancePendiente - item.montoCuotaEsperado),
                                currentUserProfile?.nombre || "Cobrador de Campo"
                              );
                            }
                          }}
                          className="min-h-[44px] flex-1 px-3 border border-zinc-200 dark:border-zinc-800 text-zinc-650 dark:text-zinc-350 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-colors"
                          title="Copiar texto del recibo"
                          id={`btn-copy-receipt-${item.id}`}
                        >
                          <Copy size={13} /> Copiar
                        </button>

                        {/* Send Digital Receipt over WhatsApp */}
                        <a
                          href={
                            item.pagoAsociado
                              ? getWhatsAppReceiptLink(
                                  item.cliente?.nombre || "",
                                  item.cliente?.telefono || "",
                                  item.pagoAsociado.reciboNo,
                                  item.pagoAsociado.monto,
                                  item.pagoAsociado.balanceDespues,
                                  item.pagoAsociado.cobradorNombre || "",
                                  item.pagoAsociado.fecha
                                )
                              : getWhatsAppReceiptLink(
                                  item.cliente?.nombre || "",
                                  item.cliente?.telefono || "",
                                  "REC-LOCAL",
                                  item.montoCuotaEsperado,
                                  Math.max(0, item.loan.balancePendiente - item.montoCuotaEsperado),
                                  currentUserProfile?.nombre || "Cobrador de Campo"
                                )
                          }
                          target="_blank"
                          rel="noreferrer"
                          className="min-h-[44px] flex-[1.5] px-4 bg-[#25D366] hover:bg-[#128C7E] text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all"
                          title="Enviar Recibo por WhatsApp"
                          id={`btn-whatsapp-receipt-${item.id}`}
                        >
                          <Share2 size={13} /> Enviar Recibo
                        </a>
                      </div>
                    ) : (
                      /* Reschedule / Visit complete label fallback */
                      <div className="w-full min-h-[44px] bg-zinc-50 dark:bg-zinc-900/20 border border-zinc-150/40 dark:border-zinc-850/40 rounded-xl flex items-center justify-center text-[11px] text-zinc-400 font-bold gap-1.5">
                        <Check size={13} className="text-emerald-500 stroke-[2.5]" /> Registro de Pospuesto Completado
                      </div>
                    )}
                  </div>
                </div>
              </div>
              </SwipeableVisitCard>
            );
          })
        )}
      </div>

      {/* MODAL: Registrar Cobro (Mobile optimized modal dialog) */}
      {isPaying && selectedPrestamoParaPago && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in" id="quick-pago-modal">
          <div className="bg-white dark:bg-[#121214] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-zinc-800">
              <div className="space-y-0.5">
                <span className="text-[9px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-wider">Abono de Campo</span>
                <h3 className="text-sm font-bold text-gray-900 dark:text-zinc-100">Registrar Pago</h3>
              </div>
              <button
                onClick={() => {
                  setIsPaying(false);
                  setSelectedPrestamoParaPago(null);
                }}
                className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-200"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-gray-400 font-semibold block uppercase">Cliente</span>
              <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">
                {selectedPrestamoParaPago.clienteNombre}
              </p>
              <p className="text-[10px] text-gray-400 font-mono">
                Préstamo: {selectedPrestamoParaPago.numero} (Pendiente: {formatCurrency(selectedPrestamoParaPago.balancePendiente, moneda)})
              </p>
            </div>

            {/* ADVISORY CARD: Late fees detected on mobile route */}
            {selectedLoanMoraDetails.totalUnpaidMora > 0 && (
              <div className="bg-rose-50 dark:bg-rose-950/25 border border-rose-200 dark:border-rose-900/40 p-3 rounded-xl space-y-1.5 text-[11px]">
                <div className="flex items-center gap-1 text-rose-600 dark:text-rose-400 font-extrabold uppercase tracking-wide text-[10px]">
                  ⚠️ Cliente con mora acumulada
                </div>
                <div className="grid grid-cols-2 gap-y-1 font-semibold text-zinc-600 dark:text-zinc-300">
                  <span>Cuota del día:</span>
                  <span className="text-right text-zinc-900 dark:text-white font-bold">{formatCurrency(selectedLoanMoraDetails.totalCuotaNormal, moneda)}</span>
                  <span>Mora acumulada:</span>
                  <span className="text-right text-rose-500 font-bold">+{formatCurrency(selectedLoanMoraDetails.totalUnpaidMora, moneda)}</span>
                  <span className="col-span-2 border-t border-rose-200/50 dark:border-rose-900/40 my-0.5"></span>
                  <span className="text-zinc-900 dark:text-white font-extrabold text-[9px] uppercase">Total recomendado:</span>
                  <span className="text-right text-emerald-600 dark:text-emerald-400 font-black">
                    {formatCurrency(Number((selectedLoanMoraDetails.totalCuotaNormal + selectedLoanMoraDetails.totalUnpaidMora).toFixed(2)), moneda)}
                  </span>
                </div>
              </div>
            )}

            <form onSubmit={handleRegisterPaymentSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-500 uppercase">Monto a Cobrar ({moneda})</label>
                <input
                  type="number"
                  step="any"
                  required
                  value={formMonto || ""}
                  onChange={(e) => setFormMonto(parseFloat(e.target.value) || 0)}
                  className="w-full text-lg font-black bg-zinc-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl px-4 py-3 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-center"
                  placeholder="0.00"
                  id="quick-pago-monto"
                />
              </div>

              {/* ROUTE DISTRIBUTION PANEL */}
              <div className="p-3 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-100 dark:border-zinc-800 rounded-xl space-y-2 text-[11px]">
                <div className="flex justify-between items-center pb-1 border-b border-zinc-200/50 dark:border-zinc-800">
                  <span className="font-bold text-gray-700 dark:text-zinc-300">Distribución de Fondos:</span>
                  <button
                    type="button"
                    onClick={() => setUseCustomDistribution(!useCustomDistribution)}
                    className="text-[9px] text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 font-bold uppercase tracking-wider"
                  >
                    {useCustomDistribution ? "Auto" : "Manual"}
                  </button>
                </div>

                {useCustomDistribution ? (
                  <div className="grid grid-cols-2 gap-2 pt-0.5 animate-fade-in">
                    <div>
                      <label className="block text-[9px] text-gray-400 uppercase font-semibold mb-0.5">A Mora</label>
                      <input
                        type="number"
                        step="any"
                        min="0"
                        max={selectedLoanMoraDetails.totalUnpaidMora}
                        value={manualMoraPago}
                        onChange={e => {
                          const val = Math.max(0, Number(e.target.value));
                          setManualMoraPago(val);
                          setManualCuotaPago(Math.max(0, Number((formMonto - val).toFixed(2))));
                        }}
                        className="w-full px-2 py-1 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded font-mono font-bold text-rose-500 text-center"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] text-gray-400 uppercase font-semibold mb-0.5">A Cuota</label>
                      <input
                        type="number"
                        step="any"
                        min="0"
                        value={manualCuotaPago}
                        onChange={e => {
                          const val = Math.max(0, Number(e.target.value));
                          setManualCuotaPago(val);
                          setManualMoraPago(Math.max(0, Number((formMonto - val).toFixed(2))));
                        }}
                        className="w-full px-2 py-1 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded font-mono font-bold text-emerald-600 text-center"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-y-0.5 text-gray-500">
                    <span>Mora abonada:</span>
                    <span className="text-right font-mono font-extrabold text-rose-500">+{formatCurrency(liveDistribution.moraApp, moneda)}</span>
                    <span>Cuota abonada:</span>
                    <span className="text-right font-mono font-extrabold text-emerald-600">{formatCurrency(liveDistribution.cuotaApp, moneda)}</span>
                  </div>
                )}
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-500 uppercase">Notas / Comentario</label>
                <textarea
                  rows={2}
                  value={formNotas}
                  onChange={(e) => setFormNotas(e.target.value)}
                  placeholder="Ej. Cobro en efectivo de la cuota del día..."
                  className="w-full text-xs bg-zinc-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  id="quick-pago-notas"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsPaying(false);
                    setSelectedPrestamoParaPago(null);
                  }}
                  className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-700 dark:text-zinc-300 font-semibold text-xs rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingPago || formMonto <= 0}
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md disabled:opacity-50"
                >
                  {isSubmittingPago ? "Procesando..." : "Confirmar Cobro"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Pospone / No Localizado (Mobile note dialog) */}
      {isLoggingVisit && selectedPrestamoParaVisita && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in" id="quick-visit-modal">
          <div className="bg-white dark:bg-[#121214] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-zinc-800">
              <div className="space-y-0.5">
                <span className="text-[9px] text-amber-600 dark:text-amber-400 font-bold uppercase tracking-wider">Bitácora de Campo</span>
                <h3 className="text-sm font-bold text-gray-900 dark:text-zinc-100">Pospone Visita</h3>
              </div>
              <button
                onClick={() => {
                  setIsLoggingVisit(false);
                  setSelectedPrestamoParaVisita(null);
                }}
                className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-200"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-gray-400 font-semibold block uppercase">Cliente</span>
              <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">
                {selectedPrestamoParaVisita.clienteNombre}
              </p>
            </div>

            <form onSubmit={handleLogVisitSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-500 uppercase">Motivo / Notas de visita</label>
                <select
                  onChange={(e) => setVisitNotas(e.target.value)}
                  className="w-full text-xs bg-zinc-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  id="select-visit-reason"
                >
                  <option value="">-- Seleccionar un motivo rápido --</option>
                  <option value="Cliente no se encontraba en casa">Cliente no se encontraba en casa</option>
                  <option value="Se comprometió a pagar mañana">Se comprometió a pagar mañana</option>
                  <option value="Solicitó prórroga para fin de mes">Solicitó prórroga para fin de mes</option>
                  <option value="Local cerrado / Negocio no abrió">Local cerrado / Negocio no abrió</option>
                  <option value="No tiene efectivo hoy, reprogramar visita">No tiene efectivo hoy, reprogramar visita</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-500 uppercase">Comentario personalizado (Opcional)</label>
                <textarea
                  rows={2}
                  value={visitNotas}
                  onChange={(e) => setVisitNotas(e.target.value)}
                  placeholder="Detalles adicionales sobre la visita o compromiso acordado..."
                  className="w-full text-xs bg-zinc-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-xl px-3 py-2 text-gray-800 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  id="custom-visit-comment"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsLoggingVisit(false);
                    setSelectedPrestamoParaVisita(null);
                  }}
                  className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-700 dark:text-zinc-300 font-semibold text-xs rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={!visitNotas.trim()}
                  className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-md disabled:opacity-50"
                >
                  Guardar Bitácora
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mobile Filter Bottom Sheet */}
      <FilterBottomSheet
        isOpen={isFilterSheetOpen}
        onClose={() => setIsFilterSheetOpen(false)}
        title="Filtros de Ruta de Cobro"
        onClear={() => {
          setStatusFilter("Todos");
          setSectorFilter("");
        }}
      >
        <div className="space-y-4">
          {/* Filtro de Estado de Visita */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Estado de la Visita
            </label>
            <div className="space-y-2">
              {([
                { id: "Todos", label: "Todas las visitas" },
                { id: "Pendientes", label: "Pendientes hoy" },
                { id: "Cobrados", label: "Cobrados hoy" },
                { id: "No Localizados", label: "No localizados / Compromisos" }
              ] as const).map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setStatusFilter(opt.id)}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                    statusFilter === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  <span>{opt.label}</span>
                  {statusFilter === opt.id && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro de Sectores */}
          {activeSectors.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                Filtrar por Sector
              </label>
              <div className="space-y-2">
                <button
                  onClick={() => setSectorFilter("")}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                    sectorFilter === ""
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  <span>Todos los sectores</span>
                  {sectorFilter === "" && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                </button>

                {activeSectors.map((sector) => (
                  <button
                    key={sector}
                    onClick={() => setSectorFilter(sector)}
                    className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                      sectorFilter === sector
                        ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                        : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                    }`}
                  >
                    <span>{sector}</span>
                    {sectorFilter === sector && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </FilterBottomSheet>

      {/* WhatsApp Modal for Quick Click-to-Chat */}
      <WhatsAppModal
        isOpen={isWhatsAppModalOpen}
        onClose={() => {
          setIsWhatsAppModalOpen(false);
          setSelectedWhatsAppCliente(null);
          setSelectedWhatsAppPrestamo(null);
          setSelectedWhatsAppMonto(undefined);
        }}
        cliente={selectedWhatsAppCliente}
        prestamo={selectedWhatsAppPrestamo}
        moneda={moneda}
        montoSugerido={selectedWhatsAppMonto}
      />

      {/* GPS Navigation Modal */}
      <NavigationModal
        isOpen={isNavigationModalOpen}
        onClose={() => {
          setIsNavigationModalOpen(false);
          setSelectedNavigationCliente(null);
        }}
        cliente={selectedNavigationCliente}
      />
    </div>
  );
}
