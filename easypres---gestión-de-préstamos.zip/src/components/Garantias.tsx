import React, { useState, useMemo } from "react";
import {
  Plus,
  Search,
  ShieldCheck,
  DollarSign,
  Camera,
  X,
  FileText,
  User,
  CheckCircle,
  Clock,
  Briefcase,
  Trash2
} from "lucide-react";
import { Cliente, Prestamo, Garantia, Usuario, checkPermission } from "../types";
import { formatCurrency } from "../utils";

interface GarantiasProps {
  garantias: Garantia[];
  prestamos: Prestamo[];
  clientes: Cliente[];
  moneda: string;
  onSave: (garantia: Garantia) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  currentUserProfile?: Usuario | null;
}

export default function Garantias({
  garantias,
  prestamos,
  clientes,
  moneda,
  onSave,
  onDelete,
  currentUserProfile
}: GarantiasProps) {
  const canCreate = checkPermission(currentUserProfile, "garantias", "crear");
  const canEdit = checkPermission(currentUserProfile, "garantias", "editar");
  const canDelete = checkPermission(currentUserProfile, "garantias", "eliminar");
  const canExport = checkPermission(currentUserProfile, "garantias", "exportar");
  const [searchQuery, setSearchQuery] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form states
  const [formPrestamoId, setFormPrestamoId] = useState("");
  const [formDescripcion, setFormDescripcion] = useState("");
  const [formValorEstimado, setFormValorEstimado] = useState<number>(0);
  const [formFotografia, setFormFotografia] = useState("");
  const [formEstado, setFormEstado] = useState<"Pendiente" | "Entregada" | "Devuelta" | "Liquidada">("Pendiente");

  // Search filtered collaterals
  const filteredGarantias = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return garantias;
    return garantias.filter(
      g =>
        g.descripcion.toLowerCase().includes(q) ||
        g.clienteNombre.toLowerCase().includes(q) ||
        g.estado.toLowerCase().includes(q)
    );
  }, [garantias, searchQuery]);

  // Handle photo upload Base64 conversion
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormFotografia(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit collateral
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    if (!formPrestamoId || !formDescripcion || formValorEstimado <= 0) {
      alert("Por favor rellene todos los campos obligatorios.");
      return;
    }

    const loan = prestamos.find(p => p.id === formPrestamoId);
    if (!loan) return;

    const payload: Garantia = {
      prestamoId: formPrestamoId,
      clienteId: loan.clienteId,
      clienteNombre: loan.clienteNombre,
      descripcion: formDescripcion,
      valorEstimado: Number(formValorEstimado),
      fotografias: formFotografia,
      estado: formEstado,
      fechaRegistro: new Date().toISOString()
    };

    try {
      setIsSubmitting(true);
      await onSave(payload);
      setIsAdding(false);
      // Reset
      setFormPrestamoId("");
      setFormDescripcion("");
      setFormValorEstimado(0);
      setFormFotografia("");
    } catch (err) {
      console.error(err);
      alert("Error al registrar garantía");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateEstado = async (garantia: Garantia, nuevoEstado: typeof formEstado) => {
    const updated = { ...garantia, estado: nuevoEstado };
    try {
      await onSave(updated);
    } catch (e) {
      console.error(e);
      alert("Error al actualizar estado");
    }
  };

  return (
    <div className="space-y-6" id="garantias-module-view">
      
      {/* 1. Register Collateral overlay */}
      {isAdding && (
        <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-md max-w-lg mx-auto animate-fade-in">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="text-emerald-500" /> Registrar Fianza / Garantía
            </h2>
            <button onClick={() => setIsAdding(false)} className="p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400">
              <X size={18} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Préstamo Asociado *</label>
              <select
                value={formPrestamoId}
                onChange={e => setFormPrestamoId(e.target.value)}
                required
                className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold"
              >
                <option value="">Seleccione contrato...</option>
                {prestamos.filter(p => p.estado !== "Saldado" && p.estado !== "Cancelado").map(p => (
                  <option key={p.id} value={p.id}>
                    {p.clienteNombre} - {p.numero} (Principal: {formatCurrency(p.capitalPrestado, moneda)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Descripción del Artículo *</label>
              <input
                type="text"
                required
                placeholder="Ej: Matrícula Vehículo Honda Civic 2018 / Laptop Asus"
                value={formDescripcion}
                onChange={e => setFormDescripcion(e.target.value)}
                className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Valor Tasado Estimado *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">{moneda}</span>
                  <input
                    type="number"
                    step="any"
                    required
                    min={1}
                    value={formValorEstimado || ""}
                    onChange={e => setFormValorEstimado(Number(e.target.value))}
                    className="w-full pl-8 pr-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Estado Físico / Custodia</label>
                <select
                  value={formEstado}
                  onChange={e => setFormEstado(e.target.value as any)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold"
                >
                  <option value="Pendiente">Pendiente por Recibir</option>
                  <option value="Entregada">Bajo Custodia (Recibida)</option>
                  <option value="Devuelta">Devuelta al Cliente</option>
                  <option value="Liquidada">Liquidada / Vendida por Incumplimiento</option>
                </select>
              </div>
            </div>

            {/* Photo upload field */}
            <div className="p-3 bg-zinc-50 dark:bg-zinc-900 border rounded-xl flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {formFotografia ? (
                  <img src={formFotografia} alt="Garantia Preview" className="w-12 h-12 rounded-lg object-cover border" />
                ) : (
                  <div className="w-12 h-12 bg-zinc-200 dark:bg-zinc-800 text-gray-400 rounded-lg flex items-center justify-center"><Camera size={18} /></div>
                )}
                <div>
                  <h4 className="text-xs font-bold text-gray-800 dark:text-zinc-200">Foto del Bien</h4>
                  <p className="text-[10px] text-gray-400">Sube imagen representativa</p>
                </div>
              </div>
              <label className="cursor-pointer px-3 py-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-lg text-xs font-semibold">
                Elegir foto
                <input type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
              </label>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <button type="button" disabled={isSubmitting} onClick={() => setIsAdding(false)} className="px-4 py-2 border rounded-xl text-xs hover:bg-zinc-50 disabled:opacity-50">Cancelar</button>
              <button type="submit" disabled={isSubmitting} className="px-5 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 disabled:bg-emerald-700/60 disabled:cursor-not-allowed">
                {isSubmitting ? "Guardando..." : "Guardar Garantía"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 2. Grid Collateral Custody View */}
      {!isAdding && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-72">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 pointer-events-none">
                <Search size={16} />
              </span>
              <input
                type="text"
                placeholder="Buscar garantías por descripción o cliente..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border rounded-xl bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-xs"
              />
            </div>
            {canCreate && (
              <button
                onClick={() => setIsAdding(true)}
                className="w-full sm:w-auto px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 flex items-center justify-center gap-1.5"
              >
                <Plus size={16} /> Agregar Garantía
              </button>
            )}
          </div>

          {filteredGarantias.length === 0 ? (
            <div className="p-12 text-center text-gray-400 text-xs bg-white dark:bg-[#121214] border rounded-2xl">
              No hay garantías prendarias o depósitos registrados actualmente.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredGarantias.map(g => (
                <div
                  key={g.id}
                  className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-4 shadow-sm flex flex-col justify-between space-y-4"
                >
                  <div className="flex justify-between items-start gap-3">
                    <div className="space-y-1">
                      <span className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-[9px] font-mono font-bold text-gray-400 uppercase">
                        Garantía / Fianza
                      </span>
                      <h4 className="font-bold text-sm text-gray-800 dark:text-zinc-200">{g.descripcion}</h4>
                      <p className="text-xs text-gray-500 flex items-center gap-1"><User size={12} /> Cliente: {g.clienteNombre}</p>
                    </div>

                    <div className="flex items-start gap-2 flex-shrink-0">
                      {g.fotografias ? (
                        <img src={g.fotografias} alt="Garantia" className="w-12 h-12 object-cover rounded-lg border" />
                      ) : (
                        <div className="w-12 h-12 bg-zinc-100 dark:bg-zinc-800 text-zinc-400 rounded-lg flex items-center justify-center">
                          <Briefcase size={18} />
                        </div>
                      )}

                      {canDelete && (
                        <button
                          onClick={() => {
                            if (window.confirm("¿Estás completamente seguro de que deseas eliminar esta garantía de forma permanente? Esta acción no se puede deshacer.")) {
                              onDelete(g.id!);
                            }
                          }}
                          className="p-1.5 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40 dark:hover:text-rose-400 text-gray-400 dark:text-zinc-500 rounded-lg transition-colors cursor-pointer"
                          title="Eliminar fianza/garantía"
                        >
                          <Trash2 size={15} />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="py-2.5 border-t border-b border-zinc-50 dark:border-zinc-900 grid grid-cols-2 gap-2 text-xs font-mono">
                    <div>
                      <p className="text-[10px] text-gray-400">VALOR TASADO</p>
                      <p className="font-bold text-emerald-600">{formatCurrency(g.valorEstimado, moneda)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400">SITUACIÓN</p>
                      <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-bold mt-0.5
                        ${g.estado === "Entregada" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" : ""}
                        ${g.estado === "Pendiente" ? "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400" : ""}
                        ${g.estado === "Devuelta" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400" : ""}
                        ${g.estado === "Liquidada" ? "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400" : ""}
                      `}>
                        {g.estado}
                      </span>
                    </div>
                  </div>

                  {/* Actions to shift state */}
                  {canEdit && (
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => handleUpdateEstado(g, "Entregada")}
                        disabled={g.estado === "Entregada"}
                        className="flex-1 py-1.5 rounded-lg border text-[10px] font-bold hover:bg-zinc-50 disabled:opacity-40"
                      >
                        Custodiar
                      </button>
                      <button
                        onClick={() => handleUpdateEstado(g, "Devuelta")}
                        disabled={g.estado === "Devuelta"}
                        className="flex-1 py-1.5 rounded-lg border text-[10px] font-bold hover:bg-zinc-50 disabled:opacity-40"
                      >
                        Devolver
                      </button>
                      <button
                        onClick={() => handleUpdateEstado(g, "Liquidada")}
                        disabled={g.estado === "Liquidada"}
                        className="flex-1 py-1.5 rounded-lg border text-[10px] font-bold text-rose-600 hover:bg-rose-50 disabled:opacity-40"
                      >
                        Liquidar
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
