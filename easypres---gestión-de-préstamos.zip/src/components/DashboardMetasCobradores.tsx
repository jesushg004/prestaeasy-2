import React, { useState } from "react";
import { Target, TrendingUp, Award, Edit, Check, X, ShieldCheck } from "lucide-react";
import { formatCurrency } from "../utils";

interface CobradorLeaderboardItem {
  nombre: string;
  cobrado: number;
  capitalActivo: number;
  atrasados: number;
  totalClientes: number;
  prestamosCount: number;
  parPercent: number;
  efficiency: number;
}

interface DashboardMetasCobradoresProps {
  cobradores: CobradorLeaderboardItem[];
  moneda: string;
}

interface MetasSchema {
  diaria: number;
  semanal: number;
  mensual: number;
}

export default function DashboardMetasCobradores({ cobradores, moneda }: DashboardMetasCobradoresProps) {
  // Load goals from local storage
  const [metas, setMetas] = useState<{ [key: string]: MetasSchema }>(() => {
    try {
      const saved = localStorage.getItem("easypres_metas_cobradores");
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  // Editor states
  const [editingCobrador, setEditingCobrador] = useState<string | null>(null);
  const [inputDiaria, setInputDiaria] = useState<string>("");
  const [inputSemanal, setInputSemanal] = useState<string>("");
  const [inputMensual, setInputMensual] = useState<string>("");

  // Get metas with proportional fallbacks based on collector portfolio
  const getMetasForCobrador = (name: string, activeCapital: number): MetasSchema => {
    const custom = metas[name];
    if (custom) return custom;
    
    // Proportional suggestion
    const base = activeCapital > 0 ? activeCapital : 50000;
    return {
      diaria: Math.round(base * 0.015) || 750,
      semanal: Math.round(base * 0.08) || 4000,
      mensual: Math.round(base * 0.30) || 15000,
    };
  };

  const handleStartEdit = (name: string, activeCapital: number) => {
    const current = getMetasForCobrador(name, activeCapital);
    setInputDiaria(current.diaria.toString());
    setInputSemanal(current.semanal.toString());
    setInputMensual(current.mensual.toString());
    setEditingCobrador(name);
  };

  const handleSaveEdit = (name: string) => {
    const d = parseFloat(inputDiaria) || 0;
    const w = parseFloat(inputSemanal) || 0;
    const m = parseFloat(inputMensual) || 0;

    const updated = {
      ...metas,
      [name]: { diaria: d, semanal: w, mensual: m }
    };

    setMetas(updated);
    localStorage.setItem("easypres_metas_cobradores", JSON.stringify(updated));
    setEditingCobrador(null);
  };

  // Performance classification helper
  const getPerformanceLabel = (pct: number) => {
    if (pct >= 90) return { label: "Excelente", color: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-200" };
    if (pct >= 70) return { label: "Aceptable", color: "bg-sky-100 text-sky-800 dark:bg-sky-950/40 dark:text-sky-400 border-sky-200" };
    return { label: "Bajo", color: "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400 border-rose-200" };
  };

  return (
    <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-3xl p-5 shadow-sm space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-100 dark:border-zinc-800/40 pb-4">
        <div>
          <h4 className="text-sm font-extrabold text-gray-900 dark:text-white flex items-center gap-1.5">
            <Target className="text-emerald-500" size={16} /> Metas de Recaudación y Rendimiento Operacional
          </h4>
          <p className="text-xs text-gray-400">
            Control de cumplimiento y clasificación automática de desempeño. Las metas se ajustan proporcionalmente o de forma personalizada.
          </p>
        </div>
        <span className="text-[10px] bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 font-bold px-3 py-1 rounded-full border border-emerald-100/40 flex items-center gap-1 shrink-0">
          <ShieldCheck size={11} /> Configurable
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {cobradores.map(c => {
          const m = getMetasForCobrador(c.nombre, c.capitalActivo);
          
          // Calculate compliance percentage on monthly goal
          const compliancePct = m.mensual > 0 ? (c.cobrado / m.mensual) * 100 : 0;
          const perf = getPerformanceLabel(compliancePct);

          const isEditing = editingCobrador === c.nombre;

          return (
            <div 
              key={c.nombre}
              className="p-5 rounded-2xl border border-zinc-150/80 dark:border-zinc-800 bg-zinc-50/20 dark:bg-zinc-900/10 space-y-4 hover:shadow-xs transition-shadow relative overflow-hidden"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-bold text-gray-900 dark:text-white text-sm">{c.nombre}</h5>
                  <p className="text-[11px] text-gray-400">{c.totalClientes} clientes • Cartera de {formatCurrency(c.capitalActivo, moneda)}</p>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${perf.color}`}>
                    Rendimiento: {perf.label}
                  </span>
                  
                  {!isEditing ? (
                    <button
                      onClick={() => handleStartEdit(c.nombre, c.capitalActivo)}
                      title="Editar metas personalizadas"
                      className="p-1.5 hover:bg-zinc-150 dark:hover:bg-zinc-800 text-zinc-500 dark:text-zinc-400 rounded-lg transition-all cursor-pointer"
                    >
                      <Edit size={13} />
                    </button>
                  ) : (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleSaveEdit(c.nombre)}
                        className="p-1 bg-emerald-500 text-white rounded hover:bg-emerald-600 transition-colors cursor-pointer"
                        title="Guardar"
                      >
                        <Check size={13} />
                      </button>
                      <button
                        onClick={() => setEditingCobrador(null)}
                        className="p-1 bg-rose-500 text-white rounded hover:bg-rose-600 transition-colors cursor-pointer"
                        title="Cancelar"
                      >
                        <X size={13} />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {isEditing ? (
                <div className="grid grid-cols-3 gap-2 bg-zinc-100 dark:bg-zinc-900 p-3 rounded-xl border border-zinc-200/50 dark:border-zinc-800 animate-fade-in">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-zinc-400 block uppercase">Meta Diaria</label>
                    <input
                      type="number"
                      value={inputDiaria}
                      onChange={e => setInputDiaria(e.target.value)}
                      className="w-full text-xs font-mono font-bold bg-white dark:bg-zinc-800 text-gray-900 dark:text-white border border-zinc-200 dark:border-zinc-700 rounded-lg px-2 py-1 focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-zinc-400 block uppercase">Meta Semanal</label>
                    <input
                      type="number"
                      value={inputSemanal}
                      onChange={e => setInputSemanal(e.target.value)}
                      className="w-full text-xs font-mono font-bold bg-white dark:bg-zinc-800 text-gray-900 dark:text-white border border-zinc-200 dark:border-zinc-700 rounded-lg px-2 py-1 focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-zinc-400 block uppercase">Meta Mensual</label>
                    <input
                      type="number"
                      value={inputMensual}
                      onChange={e => setInputMensual(e.target.value)}
                      className="w-full text-xs font-mono font-bold bg-white dark:bg-zinc-800 text-gray-900 dark:text-white border border-zinc-200 dark:border-zinc-700 rounded-lg px-2 py-1 focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 bg-zinc-50 dark:bg-zinc-900/40 rounded-xl border border-zinc-100 dark:border-zinc-800/40">
                    <p className="text-[9px] font-extrabold text-zinc-400 uppercase tracking-wide">Meta Diaria</p>
                    <p className="font-mono font-black text-zinc-800 dark:text-zinc-200 mt-0.5">{formatCurrency(m.diaria, moneda)}</p>
                  </div>
                  <div className="p-2 bg-zinc-50 dark:bg-zinc-900/40 rounded-xl border border-zinc-100 dark:border-zinc-800/40">
                    <p className="text-[9px] font-extrabold text-zinc-400 uppercase tracking-wide">Meta Semanal</p>
                    <p className="font-mono font-black text-zinc-800 dark:text-zinc-200 mt-0.5">{formatCurrency(m.semanal, moneda)}</p>
                  </div>
                  <div className="p-2 bg-zinc-50 dark:bg-zinc-900/40 rounded-xl border border-zinc-100 dark:border-zinc-800/40">
                    <p className="text-[9px] font-extrabold text-zinc-400 uppercase tracking-wide">Meta Mensual</p>
                    <p className="font-mono font-black text-zinc-800 dark:text-zinc-200 mt-0.5">{formatCurrency(m.mensual, moneda)}</p>
                  </div>
                </div>
              )}

              {/* Progress and compliance bars */}
              <div className="space-y-2">
                <div className="flex justify-between items-baseline text-xs font-bold">
                  <span className="text-zinc-400 flex items-center gap-1">
                    <Award size={12} className="text-amber-500" />
                    Monto Cobrado (Periodo):
                  </span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-450 font-black">
                    {formatCurrency(c.cobrado, moneda)} ({compliancePct.toFixed(1)}%)
                  </span>
                </div>

                <div className="w-full bg-zinc-100 dark:bg-zinc-800 h-2.5 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${compliancePct >= 90 ? "bg-emerald-500" : compliancePct >= 70 ? "bg-sky-500" : "bg-rose-500"}`}
                    style={{ width: `${Math.min(compliancePct, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
