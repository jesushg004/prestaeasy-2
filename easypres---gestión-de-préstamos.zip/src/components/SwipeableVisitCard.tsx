import React, { useState, useRef, useEffect } from "react";
import { AlertTriangle, Coins, Sparkles } from "lucide-react";

interface SwipeableVisitCardProps {
  children: React.ReactNode;
  onPospone: () => void;
  onAbonar: () => void;
  disabled?: boolean;
  key?: string | number;
}

export default function SwipeableVisitCard({
  children,
  onPospone,
  onAbonar,
  disabled = false
}: SwipeableVisitCardProps) {
  const [translateX, setTranslateX] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [isOpen, setIsOpen] = useState<"left" | "right" | null>(null);

  const startX = useRef(0);
  const startY = useRef(0);
  const currentX = useRef(0);
  const currentY = useRef(0);
  const cardRef = useRef<HTMLDivElement>(null);

  // Close swipe state if clicking outside or tapping the card while open
  useEffect(() => {
    if (isOpen) {
      const handleOutsideClick = (e: MouseEvent | TouchEvent) => {
        if (cardRef.current && !cardRef.current.contains(e.target as Node)) {
          close();
        }
      };
      document.addEventListener("mousedown", handleOutsideClick);
      document.addEventListener("touchstart", handleOutsideClick);
      return () => {
        document.removeEventListener("mousedown", handleOutsideClick);
        document.removeEventListener("touchstart", handleOutsideClick);
      };
    }
  }, [isOpen]);

  const close = () => {
    setTranslateX(0);
    setIsOpen(null);
  };

  if (disabled) {
    return <div className="relative">{children}</div>;
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    startX.current = e.touches[0].clientX;
    startY.current = e.touches[0].clientY;
    currentX.current = e.touches[0].clientX;
    currentY.current = e.touches[0].clientY;
    setIsSwiping(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping) return;

    currentX.current = e.touches[0].clientX;
    currentY.current = e.touches[0].clientY;

    const deltaX = currentX.current - startX.current;
    const deltaY = currentY.current - startY.current;

    // If swiping vertically, let the page scroll and ignore horizontal swipe
    if (Math.abs(deltaY) > Math.abs(deltaX) && Math.abs(deltaY) > 10 && translateX === 0) {
      setIsSwiping(false);
      return;
    }

    // Calculate next translation based on previous state
    let nextTranslateX = deltaX;
    if (isOpen === "left") {
      nextTranslateX = 80 + deltaX;
    } else if (isOpen === "right") {
      nextTranslateX = -80 + deltaX;
    }

    // Clamp translation to a maximum of 120px to prevent visual breakage
    if (nextTranslateX > 110) {
      nextTranslateX = 110 + (nextTranslateX - 110) * 0.2; // Rubber band effect
    } else if (nextTranslateX < -110) {
      nextTranslateX = -110 + (nextTranslateX + 110) * 0.2; // Rubber band effect
    }

    setTranslateX(nextTranslateX);
  };

  const handleTouchEnd = () => {
    if (!isSwiping) return;
    setIsSwiping(false);

    // Determine snap points
    if (translateX > 45) {
      // Snap open left side (revealing "Pospone")
      setTranslateX(84);
      setIsOpen("left");
    } else if (translateX < -45) {
      // Snap open right side (revealing "Abonar")
      setTranslateX(-84);
      setIsOpen("right");
    } else {
      // Snap back to closed
      close();
    }
  };

  return (
    <div className="relative overflow-hidden rounded-2xl group select-none" ref={cardRef}>
      {/* Background Left Action (Amber/Pospone) */}
      <div 
        className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-amber-500 to-amber-600 dark:from-amber-600 dark:to-amber-700 text-white rounded-2xl flex flex-col items-center justify-center gap-1 cursor-pointer select-none transition-all active:brightness-90"
        style={{
          opacity: translateX > 0 ? Math.min(1, translateX / 80) : 0,
          zIndex: translateX > 0 ? 10 : 0
        }}
        onClick={(e) => {
          e.stopPropagation();
          onPospone();
          close();
        }}
      >
        <AlertTriangle size={18} className="text-white animate-pulse" />
        <span className="text-[10px] font-black uppercase tracking-wider">Pospone</span>
      </div>

      {/* Background Right Action (Emerald/Abonar) */}
      <div 
        className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-emerald-600 to-emerald-500 dark:from-emerald-700 dark:to-emerald-600 text-white rounded-2xl flex flex-col items-center justify-center gap-1 cursor-pointer select-none transition-all active:brightness-90"
        style={{
          opacity: translateX < 0 ? Math.min(1, Math.abs(translateX) / 80) : 0,
          zIndex: translateX < 0 ? 10 : 0
        }}
        onClick={(e) => {
          e.stopPropagation();
          onAbonar();
          close();
        }}
      >
        <Coins size={18} className="text-white animate-bounce mt-1" />
        <span className="text-[10px] font-black uppercase tracking-wider">Abonar</span>
      </div>

      {/* Foreground Swipeable Card Body */}
      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onClick={(e) => {
          if (isOpen) {
            e.stopPropagation();
            e.preventDefault();
            close();
          }
        }}
        className="relative z-20 transition-transform duration-200 ease-out select-none cursor-grab active:cursor-grabbing"
        style={{
          transform: `translateX(${translateX}px)`,
          touchAction: "pan-y"
        }}
      >
        {children}

        {/* Accidental Swipe Safeguard Overlay */}
        {isOpen && (
          <div 
            className="absolute inset-0 z-40 bg-zinc-900/5 dark:bg-black/15 rounded-2xl backdrop-blur-xs flex items-center justify-center transition-all animate-fade-in"
            onClick={(e) => {
              e.stopPropagation();
              close();
            }}
          >
            <div className="bg-white/95 dark:bg-zinc-900/95 shadow-xl border border-zinc-150 dark:border-zinc-800 px-3 py-1.5 rounded-full flex items-center gap-1.5 pointer-events-none">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <span className="text-[10px] font-bold text-gray-500 dark:text-zinc-400">
                Acción revelada • Toca el botón lateral o desliza para cancelar
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
