import React, { useState, useMemo } from "react";
import {
  Plus,
  Search,
  Landmark,
  FileText,
  Calendar,
  DollarSign,
  Calculator,
  Printer,
  RefreshCw,
  XCircle,
  Clock,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Eye,
  ArrowLeft,
  X,
  Coins,
  Wallet,
  AlertTriangle,
  TrendingUp,
  User,
  MoreVertical,
  MoreHorizontal,
  Check,
  SlidersHorizontal
} from "lucide-react";
import { Cliente, Prestamo, CuotaDetalle, Usuario, checkPermission, Pago } from "../types";
import { formatCurrency, generarPlanPagos, generateRandomCode, formatLocalDate, actualizarCuotasConMora } from "../utils";
import FilterBottomSheet from "./FilterBottomSheet";

interface PrestamosProps {
  prestamos: Prestamo[];
  clientes: Cliente[];
  moneda: string;
  onSave: (prestamo: Prestamo) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  tasaInteresDefecto: number;
  currentUserProfile?: Usuario | null;
  pagos?: Pago[];
  setActiveModule?: (module: string) => void;
}

export default function Prestamos({
  prestamos,
  clientes,
  moneda,
  onSave,
  onDelete,
  tasaInteresDefecto,
  currentUserProfile,
  pagos = [],
  setActiveModule
}: PrestamosProps) {
  const canCreate = checkPermission(currentUserProfile, "prestamos", "crear");
  const canEdit = checkPermission(currentUserProfile, "prestamos", "editar");
  const canDelete = checkPermission(currentUserProfile, "prestamos", "eliminar");
  const canExport = checkPermission(currentUserProfile, "prestamos", "exportar");
  // Navigation states
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPrestamo, setSelectedPrestamo] = useState<Prestamo | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showContractPrint, setShowContractPrint] = useState<Prestamo | null>(null);

  // Form states
  const [formNumero, setFormNumero] = useState("");
  const [formClienteId, setFormClienteId] = useState("");
  const [formCapital, setFormCapital] = useState(10000);
  const [formTasa, setFormTasa] = useState(tasaInteresDefecto || 10);
  const [formTipoInteres, setFormTipoInteres] = useState<"Interés Simple" | "Cuota Fija (Amortizable)" | "Interés Diario" | "Método San">("Cuota Fija (Amortizable)");
  const [formFrecuencia, setFormFrecuencia] = useState<"Diario" | "Interdiario" | "Semanal" | "Quincenal" | "Mensual">("Mensual");
  const [formPlazo, setFormPlazo] = useState(12); // 12 months/installments
  const [formFechaInicio, setFormFechaInicio] = useState(new Date().toISOString().split("T")[0]);
  const [formEstado, setFormEstado] = useState<"Activo" | "Atrasado" | "Saldado" | "Cancelado">("Activo");
  const [formMetodoDesembolso, setFormMetodoDesembolso] = useState("Efectivo");
  const [formCuentaDestino, setFormCuentaDestino] = useState("");
  const [formFiadorNombre, setFormFiadorNombre] = useState("");
  const [formFiadorCedula, setFormFiadorCedula] = useState("");
  const [formFiadorTelefono, setFormFiadorTelefono] = useState("");
  const [formRequiereFiador, setFormRequiereFiador] = useState(false);
  
  // Programación de primer pago y gracia
  const [formProgramarModo, setFormProgramarModo] = useState<"standard" | "gracia" | "fecha_personalizada">("standard");
  const [formDiasGracia, setFormDiasGracia] = useState<number | "">("");
  const [formFechaPrimerPago, setFormFechaPrimerPago] = useState<string>("");

  // Configuración de Moras / Recargos
  const [formActivarMora, setFormActivarMora] = useState<boolean>(false);
  const [formTipoMora, setFormTipoMora] = useState<"none" | "fixed_once" | "percentage_on_cuota" | "fixed_daily">("none");
  const [formValorMora, setFormValorMora] = useState<number | "">("");
  const [formDiasToleranciaMora, setFormDiasToleranciaMora] = useState<number | "">("");

  // Refinance state triggers
  const [refinancingFromId, setRefinancingFromId] = useState<string | null>(null);

  // Alert collapsing state
  const [isAlertCollapsed, setIsAlertCollapsed] = useState(true);

  // Advanced Filter states
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState("todos"); // 'todos', 'Pendiente', 'Activo', 'Atrasado', 'Saldado', 'Cancelado'
  const [cobradorFilter, setCobradorFilter] = useState("todos");
  const [frecuenciaFilter, setFrecuenciaFilter] = useState("todos"); // 'todos', 'Diario', 'Semanal', 'Quincenal', 'Mensual'
  const [sortBy, setSortBy] = useState("recientes"); // 'recientes', 'cliente_asc', 'monto_desc', 'balance_desc'

  // Extract unique cobradores present in the list for mobile filtering
  const availableCobradores = useMemo(() => {
    const list: { id: string; nombre: string }[] = [];
    const ids = new Set<string>();
    prestamos.forEach(p => {
      if (p.cobradorId && p.cobradorNombre && !ids.has(p.cobradorId)) {
        ids.add(p.cobradorId);
        list.push({ id: p.cobradorId, nombre: p.cobradorNombre });
      }
    });
    return list;
  }, [prestamos]);

  // Search loans
  const filteredPrestamos = useMemo(() => {
    let result = [...prestamos];

    // Search query filter
    const q = searchQuery.toLowerCase().trim();
    if (q) {
      result = result.filter(
        p =>
          p.numero.toLowerCase().includes(q) ||
          p.clienteNombre.toLowerCase().includes(q) ||
          p.estado.toLowerCase().includes(q)
      );
    }

    // Status filter
    if (statusFilter !== "todos") {
      result = result.filter(p => p.estado === statusFilter);
    }

    // Cobrador filter
    if (cobradorFilter !== "todos") {
      result = result.filter(p => p.cobradorId === cobradorFilter);
    }

    // Frecuencia filter
    if (frecuenciaFilter !== "todos") {
      result = result.filter(p => p.frecuenciaPago === frecuenciaFilter);
    }

    // Sorting
    result.sort((a, b) => {
      if (sortBy === "recientes") {
        return b.numero.localeCompare(a.numero);
      }
      if (sortBy === "cliente_asc") {
        return a.clienteNombre.localeCompare(b.clienteNombre);
      }
      if (sortBy === "monto_desc") {
        return b.capitalPrestado - a.capitalPrestado;
      }
      if (sortBy === "balance_desc") {
        return b.balancePendiente - a.balancePendiente;
      }
      return 0;
    });

    return result;
  }, [prestamos, searchQuery, statusFilter, cobradorFilter, frecuenciaFilter, sortBy]);

  // Live Simulated Amortization Schedule
  const simulacion = useMemo(() => {
    const cap = Number(formCapital);
    const term = Number(formPlazo);
    const tasa = Number(formTasa);
    if (isNaN(cap) || cap <= 0 || isNaN(term) || term <= 0 || !formFechaInicio) {
      return { cuotas: [], interesTotal: 0, montoTotal: 0, montoCuota: 0 };
    }
    return generarPlanPagos(
      cap,
      isNaN(tasa) || tasa < 0 ? 0 : tasa,
      formTipoInteres,
      formFrecuencia,
      term,
      formFechaInicio,
      formProgramarModo === "gracia" && formDiasGracia !== "" ? Number(formDiasGracia) : undefined,
      formProgramarModo === "fecha_personalizada" && formFechaPrimerPago ? formFechaPrimerPago : undefined
    );
  }, [formCapital, formTasa, formTipoInteres, formFrecuencia, formPlazo, formFechaInicio, formProgramarModo, formDiasGracia, formFechaPrimerPago]);

  // Check active loans and credit alerts for selected customer
  const clientAlerts = useMemo(() => {
    if (!formClienteId) return null;
    const clientLoans = prestamos.filter(
      p => p.clienteId === formClienteId && p.estado !== "Saldado" && p.estado !== "Cancelado"
    );
    const activeCount = clientLoans.length;
    const totalBalance = clientLoans.reduce((sum, p) => sum + p.balancePendiente, 0);
    return { activeCount, totalBalance };
  }, [formClienteId, prestamos]);

  const getAmortizationDescription = (tipo: string) => {
    switch (tipo) {
      case "Cuota Fija (Amortizable)":
        return "Las cuotas son iguales durante todo el plazo. Al principio se amortiza menos capital y más interés (Amortización Francesa).";
      case "Interés Simple":
        return "El interés se calcula de forma fija sobre el capital inicial y se divide equitativamente entre las cuotas.";
      case "Interés Diario":
        return "El interés se acumula y calcula de forma fija/diaria sobre el saldo total.";
      case "Método San":
        return "Plan de ahorro o préstamo sin interés (Cuotas puras para ayuda mutua o cooperativas).";
      default:
        return "";
    }
  };

  const handleToggleFiador = (checked: boolean) => {
    setFormRequiereFiador(checked);
    if (!checked) {
      setFormFiadorNombre("");
      setFormFiadorCedula("");
      setFormFiadorTelefono("");
    }
  };

  // Open Add Form
  const handleOpenAdd = () => {
    setFormNumero(generateRandomCode("PRE"));
    setFormClienteId(clientes[0]?.id || "");
    setFormCapital(10000);
    setFormTasa(tasaInteresDefecto || 10);
    setFormTipoInteres("Cuota Fija (Amortizable)");
    setFormFrecuencia("Mensual");
    setFormPlazo(6);
    setFormFechaInicio(new Date().toISOString().split("T")[0]);
    setFormEstado("Activo");
    setFormMetodoDesembolso("Efectivo");
    setFormCuentaDestino("");
    setFormFiadorNombre("");
    setFormFiadorCedula("");
    setFormFiadorTelefono("");
    setFormRequiereFiador(false);
    setFormProgramarModo("standard");
    setFormDiasGracia("");
    setFormFechaPrimerPago("");
    setFormActivarMora(false);
    setFormTipoMora("none");
    setFormValorMora("");
    setFormDiasToleranciaMora("");
    setRefinancingFromId(null);
    setIsAlertCollapsed(true);
    setIsAdding(true);
    setIsEditing(false);
  };

  // Submit loan
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (refinancingFromId || isEditing) {
      if (!canEdit) {
        alert("No tienes permisos para editar o refinanciar préstamos.");
        return;
      }
    } else {
      if (!canCreate) {
        alert("No tienes permisos para registrar nuevos préstamos.");
        return;
      }
    }
    if (!formClienteId) {
      alert("Por favor seleccione un cliente.");
      return;
    }

    const selectedCli = clientes.find(c => c.id === formClienteId);
    if (!selectedCli) return;

    // Calculate details
    const plan = simulacion;
    const finalDate = plan.cuotas[plan.cuotas.length - 1]?.fechaVence || formFechaInicio;

    const payload: Prestamo = {
      numero: formNumero,
      clienteId: formClienteId,
      clienteNombre: selectedCli.nombre,
      capitalPrestado: Number(formCapital),
      tasaInteres: Number(formTasa),
      tipoInteres: formTipoInteres,
      frecuenciaPago: formFrecuencia,
      plazoCuotas: Number(formPlazo),
      fechaInicio: formFechaInicio,
      fechaVencimiento: finalDate,
      montoCuota: plan.montoCuota,
      mora: 0,
      balancePendiente: Number(formCapital),
      interesTotal: plan.interesTotal,
      montoTotal: plan.montoTotal,
      estado: formEstado,
      proximaCuotaFecha: plan.cuotas[0]?.fechaVence || formFechaInicio,
      cuotasDetalle: JSON.stringify(plan.cuotas),
      metodoDesembolso: formMetodoDesembolso,
      cuentaDestino: formCuentaDestino,
      fiadorNombre: formFiadorNombre,
      fiadorCedula: formFiadorCedula,
      fiadorTelefono: formFiadorTelefono,
      diasGracia: formProgramarModo === "gracia" && formDiasGracia !== "" ? Number(formDiasGracia) : undefined,
      fechaPrimerPago: formProgramarModo === "fecha_personalizada" && formFechaPrimerPago ? formFechaPrimerPago : undefined,
      tipoMora: formActivarMora ? formTipoMora : "none",
      valorMora: formActivarMora && formValorMora !== "" ? Number(formValorMora) : 0,
      diasToleranciaMora: formActivarMora && formDiasToleranciaMora !== "" ? Number(formDiasToleranciaMora) : 0
    };

    if (isEditing && selectedPrestamo?.id) {
      payload.id = selectedPrestamo.id;
      payload.mora = selectedPrestamo.mora;
      // Keep existing payments/mora balances if updated
    }

    try {
      await onSave(payload);

      // If we are refinancing, cancel the older loan
      if (refinancingFromId) {
        const oldLoan = prestamos.find(p => p.id === refinancingFromId);
        if (oldLoan) {
          const cancelledLoan = { ...oldLoan, estado: "Cancelado" as const, balancePendiente: 0 };
          await onSave(cancelledLoan);
        }
      }

      setIsAdding(false);
      setIsEditing(false);
      setSelectedPrestamo(null);
      setRefinancingFromId(null);
    } catch (err: any) {
      console.error(err);
      const errMsg = err?.message || String(err);
      alert("Error al emitir el préstamo: " + errMsg);
    }
  };

  // Open Refinance workflow
  const handleRefinance = (loan: Prestamo) => {
    if (!canEdit) {
      alert("No tienes permisos para refinanciar préstamos.");
      return;
    }
    // Generate new code
    setFormNumero(generateRandomCode("PRE"));
    setFormClienteId(loan.clienteId);
    // loaded with unpaid balance as default capital
    setFormCapital(loan.balancePendiente);
    setFormTasa(loan.tasaInteres);
    setFormTipoInteres(loan.tipoInteres);
    setFormFrecuencia(loan.frecuenciaPago);
    setFormPlazo(loan.plazoCuotas);
    setFormFechaInicio(new Date().toISOString().split("T")[0]);
    setFormEstado("Activo");
    setFormMetodoDesembolso(loan.metodoDesembolso || "Efectivo");
    setFormCuentaDestino(loan.cuentaDestino || "");
    setFormFiadorNombre(loan.fiadorNombre || "");
    setFormFiadorCedula(loan.fiadorCedula || "");
    setFormFiadorTelefono(loan.fiadorTelefono || "");
    setFormRequiereFiador(!!loan.fiadorNombre);
    setFormProgramarModo("standard");
    setFormDiasGracia("");
    setFormFechaPrimerPago("");
    setFormActivarMora(loan.tipoMora ? loan.tipoMora !== "none" : false);
    setFormTipoMora(loan.tipoMora || "none");
    setFormValorMora(loan.valorMora !== undefined ? loan.valorMora : "");
    setFormDiasToleranciaMora(loan.diasToleranciaMora !== undefined ? loan.diasToleranciaMora : "");
    setRefinancingFromId(loan.id || null);
    setIsAlertCollapsed(true);

    setIsAdding(true);
    setIsEditing(false);
    setSelectedPrestamo(null);
  };

  // Cancel Loan
  const handleCancelLoan = async (loan: Prestamo) => {
    if (!canDelete) {
      alert("No tienes permisos para cancelar préstamos.");
      return;
    }
    if (confirm("¿Seguro que desea Cancelar este préstamo? Su balance se ajustará a 0 y quedará inactivo.")) {
      const cancelled: Prestamo = {
        ...loan,
        estado: "Cancelado",
        balancePendiente: 0
      };
      try {
        await onSave(cancelled);
        setSelectedPrestamo(cancelled);
      } catch (err: any) {
        console.error(err);
        const errMsg = err?.message || String(err);
        alert("Error al cancelar préstamo: " + errMsg);
      }
    }
  };

  // Reactivate a mistakenly cancelled loan (Undo cancellation)
  const handleReactivateLoan = async (loan: Prestamo) => {
    if (!canDelete) {
      alert("No tienes permisos para reactivar préstamos.");
      return;
    }
    
    // Calculate restored balance based on payment history
    const pagosDelPrestamo = pagos.filter(
      (p) => p.prestamoId === loan.id || p.prestamoNumero === loan.numero
    );
    const totalCapitalPagado = pagosDelPrestamo.reduce((sum, p) => sum + (p.capitalPagado || 0), 0);
    const balanceRestaurado = Math.max(0, loan.capitalPrestado - totalCapitalPagado);

    if (
      confirm(
        `¿Estás seguro de que deseas reactivar este préstamo cancelado por error?\n\n` +
        `• El estado volverá a "Activo" (o "Atrasado" según corresponda).\n` +
        `• Se restaurará el balance de capital pendiente (Saldo insoluto) calculado: ${formatCurrency(balanceRestaurado, moneda)} (Capital original ${formatCurrency(loan.capitalPrestado, moneda)} menos capital pagado ${formatCurrency(totalCapitalPagado, moneda)}).`
      )
    ) {
      const nuevoEstado = balanceRestaurado <= 0 ? "Saldado" : "Activo";
      
      const reactivated: Prestamo = {
        ...loan,
        estado: nuevoEstado,
        balancePendiente: balanceRestaurado
      };
      
      try {
        await onSave(reactivated);
        setSelectedPrestamo(reactivated);
      } catch (err: any) {
        console.error(err);
        const errMsg = err?.message || String(err);
        alert("Error al reactivar el préstamo: " + errMsg);
      }
    }
  };

  // Print contract
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="prestamos-module-view">
      
      {/* 1. Add / Emit Loan Form */}
      {isAdding && (
        <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-md max-w-4xl mx-auto animate-fade-in">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Landmark className="text-emerald-500" />
              {refinancingFromId ? "Refinanciar Préstamo" : "Emitir Nuevo Préstamo"}
            </h2>
            <button
              onClick={() => setIsAdding(false)}
              className="p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400"
            >
              <X size={18} />
            </button>
          </div>

          {refinancingFromId && (
            <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30 text-amber-800 dark:text-amber-400 text-xs rounded-xl font-medium">
              Nota: Refinanciar cancelará automáticamente el préstamo anterior y transferirá el balance restante al nuevo capital prestado.
            </div>
          )}

          {clientAlerts && clientAlerts.activeCount > 0 && (
            <div className="mb-3 overflow-hidden rounded-xl border border-rose-100 dark:border-rose-950/40 bg-rose-50/70 dark:bg-rose-950/10 text-rose-800 dark:text-rose-400 transition-all duration-200">
              {/* Header collapsible */}
              <button
                type="button"
                onClick={() => setIsAlertCollapsed(!isAlertCollapsed)}
                className="w-full py-2 px-3 flex items-center justify-between text-left focus:outline-none hover:bg-rose-100/20 dark:hover:bg-rose-950/20 transition-colors"
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="text-sm shrink-0">⚠️</span>
                  <div className="flex items-center gap-2 overflow-hidden min-w-0">
                    <span className="font-bold text-[11px] uppercase tracking-wider truncate">
                      Alerta de Riesgo Crediticio
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 font-bold border border-rose-200/40 dark:border-rose-800/40 shrink-0">
                      {clientAlerts.activeCount} activo(s)
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-rose-600 dark:text-rose-400 shrink-0 ml-2">
                  <span className="hidden sm:inline">{isAlertCollapsed ? "MOSTRAR" : "OCULTAR"}</span>
                  {isAlertCollapsed ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
                </div>
              </button>

              {/* Body */}
              {!isAlertCollapsed && (
                <div className="px-3 pb-2.5 pt-1.5 border-t border-rose-100/40 dark:border-rose-900/10 text-[11px] font-medium animate-fade-in space-y-1">
                  <p className="leading-normal">
                    Este cliente ya tiene <strong className="font-extrabold text-rose-700 dark:text-rose-300">{clientAlerts.activeCount} préstamo(s) activo(s)</strong> con un balance pendiente acumulado de <strong className="font-extrabold text-rose-700 dark:text-rose-300">{formatCurrency(clientAlerts.totalBalance, moneda)}</strong>.
                  </p>
                  <p className="text-[10px] text-rose-500/90 dark:text-rose-400/90 font-normal">
                    💡 Asegúrese de evaluar exhaustivamente la capacidad de pago antes de desembolsar nuevos fondos.
                  </p>
                </div>
              )}
            </div>
          )}

          <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: Config */}
            <div className="lg:col-span-7 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Nro. de Préstamo</label>
                  <input
                    type="text"
                    value={formNumero}
                    disabled
                    className="w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-gray-500 font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Cliente Solicitante *</label>
                  <select
                    value={formClienteId}
                    onChange={e => {
                      setFormClienteId(e.target.value);
                      setIsAlertCollapsed(true);
                    }}
                    required
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                  >
                    <option value="">Seleccione un cliente...</option>
                    {clientes.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.nombre} ({c.codigo})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Monto Principal (Capital) *</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 text-xs">{moneda}</span>
                    <input
                      type="number"
                      step="any"
                      required
                      min={100}
                      value={formCapital}
                      onChange={e => setFormCapital(Number(e.target.value))}
                      className="w-full pl-8 pr-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Tasa de Interés (%) *</label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="0"
                    value={formTasa}
                    onChange={e => setFormTasa(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Tipo de Amortización</label>
                  <select
                    value={formTipoInteres}
                    onChange={e => setFormTipoInteres(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                  >
                    <option value="Cuota Fija (Amortizable)">Cuota Fija (Amortización Francesa)</option>
                    <option value="Interés Simple">Interés Simple Fijo</option>
                    <option value="Interés Diario">Interés Diario Devengado</option>
                    <option value="Método San">Método San (Plan Sin Interés / Ahorro)</option>
                  </select>
                  <p className="mt-1.5 text-[10px] leading-relaxed text-zinc-400 font-medium">
                    ℹ️ {getAmortizationDescription(formTipoInteres)}
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Frecuencia de Cobro</label>
                  <select
                    value={formFrecuencia}
                    onChange={e => setFormFrecuencia(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                  >
                    <option value="Diario">Cobro Diario (Lun-Sáb)</option>
                    <option value="Interdiario">Cobro Interdiario (Cada 2 días)</option>
                    <option value="Semanal">Semanal</option>
                    <option value="Quincenal">Quincenal (Cada 15 días)</option>
                    <option value="Mensual">Mensual</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Plazo total (Cuotas)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="120"
                    value={formPlazo}
                    onChange={e => setFormPlazo(Number(e.target.value))}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 font-bold text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Fecha de Desembolso</label>
                  <input
                    type="date"
                    required
                    value={formFechaInicio}
                    onChange={e => setFormFechaInicio(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Método de Desembolso</label>
                  <select
                    value={formMetodoDesembolso}
                    onChange={e => setFormMetodoDesembolso(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                  >
                    <option value="Efectivo">💵 Efectivo</option>
                    <option value="Transferencia Bancaria">🏦 Transferencia Bancaria</option>
                    <option value="Cheque">✍️ Cheque</option>
                    <option value="Depósito">💳 Depósito / Otro</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Cuenta de Destino (Si aplica)</label>
                  <input
                    type="text"
                    placeholder="Ej. Banco Popular Ahorros #123456"
                    value={formCuentaDestino}
                    onChange={e => setFormCuentaDestino(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                  />
                </div>

                {/* Programación de primer pago y gracia (Mutuamente excluyentes) */}
                <div className="sm:col-span-2 p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-200/60 dark:border-zinc-800/60 mt-2 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">📅</span>
                    <div>
                      <h4 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                        Programación del Primer Pago
                      </h4>
                      <p className="text-[10px] text-gray-400">
                        Seleccione una opción para personalizar el inicio del plan de cobros.
                      </p>
                    </div>
                  </div>

                  <div className="pt-1">
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Tipo de Programación</label>
                    <select
                      value={formProgramarModo}
                      onChange={e => {
                        const val = e.target.value as "standard" | "gracia" | "fecha_personalizada";
                        setFormProgramarModo(val);
                        if (val === "standard") {
                          setFormDiasGracia("");
                          setFormFechaPrimerPago("");
                        } else if (val === "gracia") {
                          setFormFechaPrimerPago("");
                        } else if (val === "fecha_personalizada") {
                          setFormDiasGracia("");
                        }
                      }}
                      className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-800 dark:text-zinc-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                    >
                      <option value="standard">Regular (Calculado automáticamente según frecuencia)</option>
                      <option value="gracia">Opción A: Días de Gracia (Diferir el inicio)</option>
                      <option value="fecha_personalizada">Opción B: Fecha Exacta del Primer Pago</option>
                    </select>
                  </div>

                  {formProgramarModo === "gracia" && (
                    <div className="p-3 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl space-y-1 animate-fade-in mt-2">
                      <label className="block text-[10px] font-bold text-gray-400 uppercase">Número de Días de Gracia</label>
                      <input
                        type="number"
                        min="1"
                        max="365"
                        placeholder="Ej. 15 (Días)"
                        value={formDiasGracia}
                        onChange={e => setFormDiasGracia(e.target.value === "" ? "" : Math.abs(Number(e.target.value)))}
                        className="w-full px-3 py-1.5 border rounded-lg bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                      />
                      <p className="text-[10px] text-gray-400">
                        La primera cuota se desplazará {formDiasGracia || 0} días adicionales con respecto al cálculo normal.
                      </p>
                    </div>
                  )}

                  {formProgramarModo === "fecha_personalizada" && (
                    <div className="p-3 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl space-y-1 animate-fade-in mt-2">
                      <label className="block text-[10px] font-bold text-gray-400 uppercase">Fecha Exacta del Primer Pago</label>
                      <input
                        type="date"
                        required
                        value={formFechaPrimerPago}
                        onChange={e => setFormFechaPrimerPago(e.target.value)}
                        className="w-full px-3 py-1.5 border rounded-lg bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                      />
                      <p className="text-[10px] text-gray-400">
                        La cuota #1 vencerá el día seleccionado. Las siguientes cuotas se calcularán espaciadas desde esa fecha.
                      </p>
                    </div>
                  )}
                </div>

                {/* Configuración de Moras / Recargos */}
                <div className="sm:col-span-2 p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-200/60 dark:border-zinc-800/60 mt-2 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-base">⚠️</span>
                      <div>
                        <h4 className="text-xs font-bold text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
                          Mora y Recargos por Incumplimiento
                        </h4>
                        <p className="text-[10px] text-gray-400">
                          Active recargos automáticos para cuotas que se paguen fuera de la fecha límite.
                        </p>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        id="toggle-mora-checkbox"
                        checked={formActivarMora}
                        onChange={e => {
                          const checked = e.target.checked;
                          setFormActivarMora(checked);
                          if (checked) {
                            setFormTipoMora("percentage_on_cuota");
                            setFormValorMora(5);
                            setFormDiasToleranciaMora(3);
                          } else {
                            setFormTipoMora("none");
                            setFormValorMora("");
                            setFormDiasToleranciaMora("");
                          }
                        }}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-zinc-200 dark:bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                    </label>
                  </div>

                  {formActivarMora && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1 animate-fade-in">
                      {/* Tipo de Mora */}
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">
                          Tipo de Recargo
                        </label>
                        <select
                          value={formTipoMora}
                          onChange={e => setFormTipoMora(e.target.value as any)}
                          className="w-full px-3 py-1.5 border rounded-lg bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        >
                          <option value="percentage_on_cuota">Porcentaje (%) sobre cuota vencida</option>
                          <option value="fixed_daily">Monto Fijo Diario acumulado</option>
                          <option value="fixed_once">Monto Fijo Único por cuota</option>
                        </select>
                      </div>

                      {/* Valor de Mora */}
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">
                          {formTipoMora === "percentage_on_cuota" ? "Porcentaje (%)" : "Valor / Monto"}
                        </label>
                        <input
                          type="number"
                          min="0.01"
                          step="any"
                          required
                          placeholder={formTipoMora === "percentage_on_cuota" ? "Ej. 5" : "Ej. 100"}
                          value={formValorMora}
                          onChange={e => setFormValorMora(e.target.value === "" ? "" : Number(e.target.value))}
                          className="w-full px-3 py-1.5 border rounded-lg bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>

                      {/* Días de Tolerancia de Pago */}
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1 flex items-center gap-1">
                          Días de Tolerancia 💡
                        </label>
                        <input
                          type="number"
                          min="0"
                          required
                          placeholder="Ej. 3 días"
                          value={formDiasToleranciaMora}
                          onChange={e => setFormDiasToleranciaMora(e.target.value === "" ? "" : Math.abs(Number(e.target.value)))}
                          className="w-full px-3 py-1.5 border rounded-lg bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>

                      <div className="sm:col-span-3 text-[10px] bg-emerald-50/50 dark:bg-emerald-950/10 p-2.5 rounded-xl text-emerald-800 dark:text-emerald-300 border border-emerald-500/10">
                        <span className="font-bold">💡 Aclaración Importante:</span> Los <strong>Días de Tolerancia</strong> representan un margen de cortesía por cuota (el cliente puede pagar tarde hasta ese límite sin recargo). No choca con los <strong>Días de Gracia de Emisión</strong>, los cuales únicamente posponen la fecha inicial de cobro del préstamo completo.
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-150 dark:border-zinc-800/60 mt-4 space-y-4">
                <div className="flex items-center justify-between p-3 bg-zinc-50 dark:bg-zinc-900/40 rounded-xl border border-zinc-150 dark:border-zinc-800/60">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">🛡️</span>
                    <div>
                      <label className="text-xs font-semibold text-gray-700 dark:text-zinc-200 cursor-pointer" htmlFor="toggle-fiador-checkbox">
                        ¿Requiere Fiador / Garante?
                      </label>
                      <p className="text-[10px] text-gray-400">Marque esta casilla si este préstamo cuenta con un garante solidario</p>
                    </div>
                  </div>
                  <input
                    id="toggle-fiador-checkbox"
                    type="checkbox"
                    checked={formRequiereFiador}
                    onChange={e => handleToggleFiador(e.target.checked)}
                    className="h-4 w-4 rounded border-zinc-300 text-emerald-600 focus:ring-emerald-500 accent-emerald-500 cursor-pointer"
                  />
                </div>

                {formRequiereFiador && (
                  <div className="space-y-3 p-4 bg-emerald-50/5 dark:bg-emerald-950/5 rounded-2xl border border-emerald-100/10 dark:border-emerald-900/10 animate-fade-in">
                    <h4 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                       🛡️ Datos del Fiador / Garante (Co-signatario)
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Nombre Completo del Fiador *</label>
                        <input
                          type="text"
                          required={formRequiereFiador}
                          placeholder="Ej. Juan Pérez"
                          value={formFiadorNombre}
                          onChange={e => setFormFiadorNombre(e.target.value)}
                          className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Cédula del Fiador</label>
                        <input
                          type="text"
                          placeholder="Ej. 001-0000000-0"
                          value={formFiadorCedula}
                          onChange={e => setFormFiadorCedula(e.target.value)}
                          className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-semibold text-gray-400 uppercase mb-1">Teléfono del Fiador</label>
                        <input
                          type="text"
                          placeholder="Ej. 809-555-1234"
                          value={formFiadorTelefono}
                          onChange={e => setFormFiadorTelefono(e.target.value)}
                          className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t border-zinc-100 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-4 py-2 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-colors dark:text-zinc-300"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition-colors shadow-md shadow-emerald-600/10"
                >
                  Desembolsar Préstamo
                </button>
              </div>
            </div>

            {/* Right Column: Simulated Summary & Installment List */}
            <div className="lg:col-span-5 bg-zinc-50 dark:bg-[#18181b] border border-zinc-150 dark:border-zinc-800/80 rounded-2xl p-4 space-y-4">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                <Calculator size={14} className="text-emerald-500" /> Simulador de Cuotas
              </h3>

              {/* Dynamic totals calculated on the fly */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 bg-white dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-900 rounded-xl">
                  <p className="text-[10px] text-gray-400 font-medium">Cuota Estimada</p>
                  <p className="text-lg font-extrabold text-emerald-600">{formatCurrency(simulacion.montoCuota, moneda)}</p>
                </div>
                <div className="p-2.5 bg-white dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-900 rounded-xl">
                  <p className="text-[10px] text-gray-400 font-medium">Interés Estimado</p>
                  <p className="text-lg font-bold text-gray-700 dark:text-zinc-300">{formatCurrency(simulacion.interesTotal, moneda)}</p>
                </div>
                <div className="p-2.5 bg-white dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-900 rounded-xl col-span-2">
                  <p className="text-[10px] text-gray-400 font-medium">Desembolso Total Retornable</p>
                  <p className="text-xl font-black text-zinc-900 dark:text-white">{formatCurrency(simulacion.montoTotal, moneda)}</p>
                </div>
              </div>

              {/* Distribution Bar */}
              {simulacion.montoTotal > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-zinc-100 dark:border-zinc-800/50">
                  <div className="flex justify-between text-[9px] font-bold uppercase text-gray-400">
                    <span>Distribución del Retorno</span>
                    <span>
                      {Math.round((Number(formCapital) / simulacion.montoTotal) * 100)}% Cap / {Math.max(0, 100 - Math.round((Number(formCapital) / simulacion.montoTotal) * 100))}% Int
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-zinc-200 dark:bg-zinc-900 overflow-hidden flex">
                    <div 
                      style={{ width: `${Math.round((Number(formCapital) / simulacion.montoTotal) * 100)}%` }} 
                      className="bg-emerald-500 h-full transition-all duration-300" 
                    />
                    <div 
                      style={{ width: `${Math.max(0, 100 - Math.round((Number(formCapital) / simulacion.montoTotal) * 100))}%` }} 
                      className="bg-amber-500 h-full transition-all duration-300" 
                    />
                  </div>
                  <div className="flex justify-between text-[9px] text-gray-400 font-medium">
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Capital ({formatCurrency(Number(formCapital), moneda)})</span>
                    <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Interés ({formatCurrency(simulacion.interesTotal, moneda)})</span>
                  </div>
                </div>
              )}

              {/* Preview Installment List */}
              <div className="space-y-1.5 max-h-56 overflow-y-auto">
                <p className="text-[10px] font-bold text-gray-400 uppercase">Calendario de Pagos Propuesto</p>
                {simulacion.cuotas.map(c => (
                  <div
                    key={c.numero}
                    className="flex justify-between items-center p-2 rounded-lg bg-white dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 text-[11px]"
                  >
                    <span className="font-semibold text-gray-400">Cuota {c.numero}</span>
                    <span className="font-mono text-zinc-500">{formatLocalDate(c.fechaVence)}</span>
                    <span className="font-bold text-emerald-600">{formatCurrency(c.monto, moneda)}</span>
                  </div>
                ))}
              </div>
            </div>

          </form>
        </div>
      )}

      {/* 2. Print Contract Layout */}
      {showContractPrint && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex justify-center items-center p-2 sm:p-4 print:p-0 print:bg-white" id="contract-overlay">
          <div className="bg-white dark:bg-zinc-950 text-gray-900 dark:text-zinc-100 max-w-2xl w-full max-h-[90vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden relative border border-zinc-200 dark:border-zinc-800/80 animate-fade-in print:shadow-none print:border-none print:max-h-full print:bg-white">
            
            {/* Header controls */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-zinc-100 dark:border-zinc-800/80 print:hidden flex-shrink-0">
              <h3 className="font-bold text-base sm:text-lg text-gray-800 dark:text-white">Contrato de Préstamo Financiero</h3>
              <div className="flex gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3.5 py-2 bg-zinc-900 dark:bg-zinc-800 hover:bg-black dark:hover:bg-zinc-700 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <Printer size={14} /> Imprimir / PDF
                </button>
                <button
                  onClick={() => setShowContractPrint(null)}
                  className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-900 rounded-xl text-gray-400 dark:text-zinc-500 dark:hover:text-zinc-300 transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Scrollable Print Body Container */}
            <div className="overflow-y-auto flex-1 p-6 space-y-6 print:p-0 print:overflow-visible">
              <div className="space-y-6 text-xs text-justify leading-relaxed print:text-sm">
                <div className="text-center space-y-2">
                  <h1 className="text-xl font-bold tracking-tight uppercase text-gray-900 dark:text-white">CONTRATO DE PRÉSTAMO Y AMORTIZACIÓN</h1>
                  <p className="text-gray-500 dark:text-zinc-400 text-[10px] font-mono">REFERENCIA: {showContractPrint.numero}</p>
                </div>

                <p className="text-gray-700 dark:text-zinc-300">
                  De una parte, la entidad de intermediación financiera y crediticia denominada en lo sucesivo como{" "}
                  <strong>EL ACREEDOR</strong>, de otra parte el ciudadano(a) <strong>{showContractPrint.clienteNombre}</strong>,{" "}
                  en lo sucesivo denominado como <strong>EL DEUDOR</strong>, {showContractPrint.fiadorNombre && (
                    <>
                      y de la otra parte el ciudadano(a) <strong>{showContractPrint.fiadorNombre}</strong> (Cédula: {showContractPrint.fiadorCedula || "N/A"}, Tel: {showContractPrint.fiadorTelefono || "N/A"}), en lo sucesivo denominado como <strong>EL FIADOR / GARANTE SOLIDARIO</strong>,{" "}
                    </>
                  )}
                  convienen formalizar el presente acto bajo las cláusulas descritas a continuación:
                </p>

                <div className="p-4 bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-150 dark:border-zinc-800 rounded-2xl space-y-1.5 font-mono text-[11px] grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5">
                  <p className="text-gray-700 dark:text-zinc-300"><strong>CÓDIGO DE CONTRATO:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{showContractPrint.numero}</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>CAPITAL DESEMBOLSADO:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{formatCurrency(showContractPrint.capitalPrestado, moneda)}</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>TASA DE INTERÉS:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{showContractPrint.tasaInteres}% ({showContractPrint.tipoInteres})</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>FRECUENCIA DE COBRO:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{showContractPrint.frecuenciaPago}</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>PLAZO CONTRATADO:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{showContractPrint.plazoCuotas} cuota(s)</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>MONTO POR CUOTA:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{formatCurrency(showContractPrint.montoCuota, moneda)}</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>FECHA DE EMISIÓN:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{formatLocalDate(showContractPrint.fechaInicio)}</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>FECHA DE VENCIMIENTO:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{formatLocalDate(showContractPrint.fechaVencimiento)}</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>MÉTODO DE DESEMBOLSO:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{showContractPrint.metodoDesembolso || "Efectivo"}</span></p>
                  <p className="text-gray-700 dark:text-zinc-300"><strong>CUENTA DE DESTINO:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{showContractPrint.cuentaDestino || "N/A"}</span></p>
                  {showContractPrint.fiadorNombre && (
                    <>
                      <p className="text-gray-700 dark:text-zinc-300"><strong>FIADOR / GARANTE:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold uppercase">{showContractPrint.fiadorNombre}</span></p>
                      <p className="text-gray-700 dark:text-zinc-300"><strong>CÉDULA FIADOR:</strong> <span className="text-zinc-900 dark:text-zinc-100 font-bold">{showContractPrint.fiadorCedula || "N/A"}</span></p>
                    </>
                  )}
                </div>

                <div>
                  <h4 className="font-bold uppercase mb-1 text-gray-900 dark:text-white">Primera: Cláusula de Cumplimiento de Pagos</h4>
                  <p className="text-gray-700 dark:text-zinc-300">
                    EL DEUDOR se compromete de manera formal e irrevocable a pagar al ACREEDOR la cuota acordada según la frecuencia estipulada, 
                    hasta la satisfacción total del capital de {formatCurrency(showContractPrint.capitalPrestado, moneda)} más los intereses 
                    adicionales pactados que ascienden a la suma de {formatCurrency(showContractPrint.interesTotal, moneda)}.
                  </p>
                </div>

                <div>
                  <h4 className="font-bold uppercase mb-1 text-gray-900 dark:text-white">Segunda: Mora por Incumplimiento</h4>
                  <p className="text-gray-700 dark:text-zinc-300">
                    La falta de pago de cualquiera de las cuotas en la fecha límite establecida devengará automáticamente un interés de mora. 
                    Adicionalmente, el impago prolongado de dos o más cuotas otorgará derecho al ACREEDOR a declarar el préstamo como vencido, 
                    pudiendo exigir el pago inmediato del saldo insoluto.
                  </p>
                </div>

                {showContractPrint.fiadorNombre && (
                  <div>
                    <h4 className="font-bold uppercase mb-1 text-gray-900 dark:text-white">Tercera: Responsabilidad Solidaria del Fiador</h4>
                    <p className="text-gray-700 dark:text-zinc-300">
                      EL FIADOR / GARANTE SOLIDARIO se constituye en deudor solidario, principal pagador y fiador incondicional de todas 
                      y cada una de las obligaciones contraídas por EL DEUDOR mediante el presente contrato, respondiendo con todo su patrimonio 
                      por el saldo total adeudado.
                    </p>
                  </div>
                )}

                <div className={`pt-8 grid ${showContractPrint.fiadorNombre ? "grid-cols-3 gap-6" : "grid-cols-2 gap-12"} text-center border-t border-zinc-150 dark:border-zinc-800`}>
                  <div>
                    <div className="border-b border-zinc-900 dark:border-zinc-700 w-full max-w-[150px] mx-auto h-8"></div>
                    <p className="font-semibold mt-2 text-gray-900 dark:text-white text-[11px]">EL ACREEDOR</p>
                    <p className="text-[10px] text-gray-400 dark:text-zinc-500">EasyPres Representaciones</p>
                  </div>
                  <div>
                    <div className="border-b border-zinc-900 dark:border-zinc-700 w-full max-w-[150px] mx-auto h-8"></div>
                    <p className="font-semibold mt-2 text-gray-900 dark:text-white text-[11px]">{showContractPrint.clienteNombre}</p>
                    <p className="text-[10px] text-gray-400 dark:text-zinc-500">EL DEUDOR</p>
                  </div>
                  {showContractPrint.fiadorNombre && (
                    <div>
                      <div className="border-b border-zinc-900 dark:border-zinc-700 w-full max-w-[150px] mx-auto h-8"></div>
                      <p className="font-semibold mt-2 text-gray-900 dark:text-white text-[11px]">{showContractPrint.fiadorNombre}</p>
                      <p className="text-[10px] text-gray-400 dark:text-zinc-500">EL FIADOR / GARANTE</p>
                    </div>
                  )}
                </div>

                {/* Bottom Close Action (Mobile Friendly) */}
                <div className="pt-6 border-t border-zinc-100 dark:border-zinc-800/80 flex justify-end print:hidden">
                  <button
                    onClick={() => setShowContractPrint(null)}
                    className="w-full sm:w-auto px-5 py-2.5 bg-gray-150 hover:bg-gray-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-gray-700 dark:text-zinc-300 font-bold text-xs rounded-xl transition-colors text-center"
                  >
                    Cerrar Documento
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 3. Detail and installments checker (if not in add form) */}
      {!isAdding && (
        <>
          {selectedPrestamo ? (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
              <button
                onClick={() => setSelectedPrestamo(null)}
                className="flex items-center gap-1 text-xs font-bold text-gray-500 hover:text-emerald-500 transition-colors"
              >
                <ArrowLeft size={14} /> Volver a la lista
              </button>

              <div className="flex flex-col sm:flex-row justify-between items-start border-b border-zinc-100 dark:border-zinc-800/60 pb-6 gap-4">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 font-mono text-[10px] text-gray-500 dark:text-gray-400 font-bold uppercase tracking-wider">
                      {selectedPrestamo.numero}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide border
                      ${selectedPrestamo.estado === "Activo" ? "bg-emerald-50/60 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-500/10" : ""}
                      ${selectedPrestamo.estado === "Atrasado" ? "bg-rose-50/60 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400 border-rose-500/10" : ""}
                      ${selectedPrestamo.estado === "Saldado" ? "bg-blue-50/60 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400 border-blue-500/10" : ""}
                      ${selectedPrestamo.estado === "Cancelado" ? "bg-zinc-50/60 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400 border-zinc-500/10" : ""}
                    `}>
                      {selectedPrestamo.estado}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Préstamo de {selectedPrestamo.clienteNombre}</h2>
                  <p className="text-xs text-gray-400">Desembolsado el: <span className="font-mono font-medium">{formatLocalDate(selectedPrestamo.fechaInicio)}</span></p>
                </div>

                <div className="flex gap-2 flex-wrap">
                  {canExport && (
                    <button
                      onClick={() => setShowContractPrint(selectedPrestamo)}
                      className="px-3.5 py-2 border border-zinc-200 dark:border-zinc-800 rounded-xl flex items-center gap-1.5 text-xs font-semibold hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-colors"
                    >
                      <Printer size={14} /> Contrato
                    </button>
                  )}
                  {selectedPrestamo.estado !== "Saldado" && selectedPrestamo.estado !== "Cancelado" && (
                    <>
                      {canEdit && (
                        <button
                          onClick={() => handleRefinance(selectedPrestamo)}
                          className="px-3.5 py-2 border border-emerald-100 dark:border-emerald-900/30 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 rounded-xl flex items-center gap-1.5 text-xs font-semibold transition-colors"
                        >
                          <RefreshCw size={14} /> Refinanciar
                        </button>
                      )}
                      {canDelete && (
                        <button
                          onClick={() => handleCancelLoan(selectedPrestamo)}
                          className="px-3.5 py-2 border border-rose-100 dark:border-rose-900/30 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-xl flex items-center gap-1.5 text-xs font-semibold transition-colors"
                        >
                          <XCircle size={14} /> Cancelar Préstamo
                        </button>
                      )}
                    </>
                  )}
                  {selectedPrestamo.estado === "Cancelado" && canDelete && (
                    <button
                      onClick={() => handleReactivateLoan(selectedPrestamo)}
                      className="px-3.5 py-2 bg-emerald-600 text-white hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600 rounded-xl flex items-center gap-1.5 text-xs font-semibold shadow-sm transition-all"
                    >
                      <RefreshCw size={14} /> Reactivar Préstamo (Deshacer)
                    </button>
                  )}
                </div>
              </div>

              {/* Financial balances */}
              {(() => {
                let totalMora = 0;
                let outstandingMora = 0;
                let outstandingInterest = 0;
                let originalCuotas: CuotaDetalle[] = [];
                try {
                  originalCuotas = JSON.parse(selectedPrestamo.cuotasDetalle || "[]");
                  const cuotasConMora = actualizarCuotasConMora(
                    originalCuotas,
                    selectedPrestamo.tipoMora,
                    selectedPrestamo.valorMora,
                    selectedPrestamo.diasToleranciaMora
                  );
                  totalMora = cuotasConMora.reduce((sum, c) => sum + (c.moraMonto || 0), 0);
                  outstandingMora = cuotasConMora.reduce((sum, c) => sum + Math.max(0, (c.moraMonto || 0) - (c.moraPagada || 0)), 0);
                  outstandingInterest = originalCuotas.reduce((sum, c) => {
                    const ratio = c.monto > 0 ? c.montoPagado / c.monto : 0;
                    return sum + (c.interes - c.interes * ratio);
                  }, 0);
                } catch (e) {
                  console.error(e);
                }

                const outstandingCapital = selectedPrestamo.balancePendiente;
                const totalACobrar = outstandingCapital + outstandingInterest + outstandingMora;
                const capitalPagadoAcumulado = selectedPrestamo.capitalPrestado - outstandingCapital;
                const interesPagadoAcumulado = selectedPrestamo.interesTotal - outstandingInterest;
                const totalMontoCobrado = capitalPagadoAcumulado + interesPagadoAcumulado;

                return (
                  <div className="space-y-6">
                    {/* Origin / Original Terms Grid */}
                    <div>
                      <h4 className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider mb-2">
                        Origen y Estructura del Préstamo
                      </h4>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="p-3 bg-zinc-50 dark:bg-zinc-900/30 border border-zinc-150 dark:border-zinc-800/80 rounded-xl">
                          <p className="text-[10px] text-gray-400 uppercase font-semibold">Capital Desembolsado</p>
                          <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mt-1">{formatCurrency(selectedPrestamo.capitalPrestado, moneda)}</p>
                        </div>
                        <div className="p-3 bg-zinc-50 dark:bg-zinc-900/30 border border-zinc-150 dark:border-zinc-800/80 rounded-xl">
                          <p className="text-[10px] text-gray-400 uppercase font-semibold">Intereses Pactados</p>
                          <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mt-1">{formatCurrency(selectedPrestamo.interesTotal, moneda)}</p>
                        </div>
                        <div className="p-3 bg-zinc-50 dark:bg-zinc-900/30 border border-zinc-150 dark:border-zinc-800/80 rounded-xl">
                          <p className="text-[10px] text-gray-400 uppercase font-semibold">Total Contratado</p>
                          <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mt-1">{formatCurrency(selectedPrestamo.montoTotal, moneda)}</p>
                        </div>
                        <div className="p-3 bg-zinc-50 dark:bg-zinc-900/30 border border-zinc-150 dark:border-zinc-800/80 rounded-xl">
                          <p className="text-[10px] text-gray-400 uppercase font-semibold">Retorno Recaudado</p>
                          <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400 mt-1">{formatCurrency(totalMontoCobrado, moneda)}</p>
                        </div>
                      </div>
                    </div>

                    {/* Breakdown of Outstanding Debt */}
                    <div>
                      <h4 className="text-[10px] font-bold text-zinc-600 dark:text-zinc-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                        <span className="inline-block w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></span>
                        Desglose Detallado de Deuda Exigible (Pendiente)
                      </h4>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                        {/* Capital Pendiente */}
                        <div className="p-4 bg-amber-500/[0.03] dark:bg-amber-500/[0.015] border border-amber-500/20 dark:border-amber-500/10 rounded-2xl border-l-4 border-l-amber-500 shadow-sm">
                          <p className="text-[10px] text-amber-600 dark:text-amber-400 uppercase font-black tracking-wider">Capital Pendiente</p>
                          <p className="text-lg font-black text-amber-700 dark:text-amber-300 mt-1.5" title="Saldo Insoluto únicamente">{formatCurrency(outstandingCapital, moneda)}</p>
                          <p className="text-[9px] text-gray-400 dark:text-zinc-500 mt-0.5">Saldo Insoluto</p>
                        </div>

                        {/* Intereses Pendientes */}
                        <div className="p-4 bg-violet-500/[0.03] dark:bg-violet-500/[0.015] border border-violet-500/20 dark:border-violet-500/10 rounded-2xl border-l-4 border-l-violet-500 shadow-sm">
                          <p className="text-[10px] text-violet-600 dark:text-violet-400 uppercase font-black tracking-wider">Interés Pendiente</p>
                          <p className="text-lg font-black text-violet-700 dark:text-violet-300 mt-1.5">{formatCurrency(outstandingInterest, moneda)}</p>
                          <p className="text-[9px] text-gray-400 dark:text-zinc-500 mt-0.5">Intereses no cobrados</p>
                        </div>

                        {/* Mora Pendiente */}
                        <div className="p-4 bg-rose-500/[0.03] dark:bg-rose-500/[0.015] border border-rose-500/20 dark:border-rose-500/10 rounded-2xl border-l-4 border-l-rose-500 shadow-sm">
                          <p className="text-[10px] text-rose-600 dark:text-rose-400 uppercase font-black tracking-wider">Mora Pendiente</p>
                          <p className={`text-lg font-black mt-1.5 ${outstandingMora > 0 ? "text-rose-600 dark:text-rose-400" : "text-gray-400 dark:text-zinc-500"}`}>{formatCurrency(outstandingMora, moneda)}</p>
                          <p className="text-[9px] text-gray-400 dark:text-zinc-500 mt-0.5">Late fees acumuladas</p>
                        </div>

                        {/* Otros Cargos */}
                        <div className="p-4 bg-zinc-500/[0.03] dark:bg-zinc-500/[0.015] border border-zinc-500/20 dark:border-zinc-500/10 rounded-2xl border-l-4 border-l-zinc-500 shadow-sm">
                          <p className="text-[10px] text-zinc-500 dark:text-zinc-400 uppercase font-black tracking-wider">Otros Cargos</p>
                          <p className="text-lg font-black text-zinc-400 dark:text-zinc-500 mt-1.5">{formatCurrency(0, moneda)}</p>
                          <p className="text-[9px] text-gray-400 dark:text-zinc-500 mt-0.5">Cargos/Comisiones</p>
                        </div>

                        {/* Total a Cobrar / Balance Exigible */}
                        <div className="p-4 bg-blue-500/[0.03] dark:bg-blue-500/[0.015] border border-blue-500/20 dark:border-blue-500/10 rounded-2xl border-l-4 border-l-blue-500 col-span-2 md:col-span-1 shadow-sm">
                          <p className="text-[10px] text-blue-600 dark:text-blue-400 uppercase font-black tracking-wider">Total a Cobrar</p>
                          <p className="text-lg font-black text-blue-600 dark:text-blue-400 mt-1.5">{formatCurrency(totalACobrar, moneda)}</p>
                          <p className="text-[9px] text-gray-400 dark:text-zinc-500 mt-0.5">Capital + Interés + Mora</p>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Configuration & Disbursement details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-zinc-50 dark:bg-zinc-900/40 rounded-2xl border border-zinc-150 dark:border-zinc-800 text-xs">
                <div>
                  <p className="text-[10px] text-gray-400 font-semibold uppercase">Tipo de Amortización</p>
                  <p className="font-semibold text-zinc-800 dark:text-zinc-200 mt-0.5">{selectedPrestamo.tipoInteres}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-semibold uppercase">Frecuencia de Cobro</p>
                  <p className="font-semibold text-zinc-800 dark:text-zinc-200 mt-0.5">{selectedPrestamo.frecuenciaPago}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-semibold uppercase">Método de Desembolso</p>
                  <p className="font-semibold text-zinc-800 dark:text-zinc-200 mt-0.5">
                    {selectedPrestamo.metodoDesembolso || "Efectivo 💵"}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-semibold uppercase">Cuenta de Destino</p>
                  <p className="font-semibold text-zinc-800 dark:text-zinc-200 mt-0.5">
                    {selectedPrestamo.cuentaDestino || "N/A"}
                  </p>
                </div>
              </div>

              {selectedPrestamo.fiadorNombre && (
                <div className="p-4 bg-emerald-50/10 dark:bg-emerald-950/5 border border-emerald-100/30 dark:border-emerald-900/20 rounded-2xl text-xs space-y-2">
                  <h4 className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                    🛡️ Fiador / Garante Asociado (Co-signatario)
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <p className="text-[10px] text-gray-400 font-semibold uppercase">Nombre Completo</p>
                      <p className="font-semibold text-zinc-800 dark:text-zinc-200 mt-0.5">{selectedPrestamo.fiadorNombre}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 font-semibold uppercase">Cédula</p>
                      <p className="font-semibold text-zinc-800 dark:text-zinc-200 mt-0.5">{selectedPrestamo.fiadorCedula || "N/A"}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 font-semibold uppercase">Teléfono</p>
                      <p className="font-semibold text-zinc-800 dark:text-zinc-200 mt-0.5">{selectedPrestamo.fiadorTelefono || "N/A"}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Installments table checklist */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-gray-900 dark:text-white">Calendario de Cuotas y Amortización</h3>
                
                {/* Desktop view: Full table */}
                <div className="hidden md:block border border-zinc-100 dark:border-zinc-800 rounded-2xl overflow-x-auto text-xs">
                  <table className="w-full min-w-[700px] text-left border-collapse">
                    <thead>
                      <tr className="bg-zinc-50 dark:bg-zinc-900 text-gray-400 font-semibold border-b">
                        <th className="p-3">Nro. Cuota</th>
                        <th className="p-3">Monto Cuota</th>
                        <th className="p-3">Capital Amort.</th>
                        <th className="p-3">Interés</th>
                        <th className="p-3">Vencimiento</th>
                        <th className="p-3">Recargo (Mora)</th>
                        <th className="p-3">Estado</th>
                        <th className="p-3 text-right">Saldo Insoluto</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(() => {
                        try {
                          const rawCuotas: CuotaDetalle[] = JSON.parse(selectedPrestamo.cuotasDetalle || "[]");
                          const cuotas = actualizarCuotasConMora(
                            rawCuotas,
                            selectedPrestamo.tipoMora,
                            selectedPrestamo.valorMora,
                            selectedPrestamo.diasToleranciaMora
                          );
                          return cuotas.map(c => (
                            <tr key={c.numero} className="border-b hover:bg-zinc-50 dark:hover:bg-zinc-900/40">
                              <td className="p-3 font-bold text-gray-400">Cuota {c.numero}</td>
                              <td className="p-3 font-semibold">{formatCurrency(c.monto, moneda)}</td>
                              <td className="p-3 text-gray-500">{formatCurrency(c.capital, moneda)}</td>
                              <td className="p-3 text-gray-500">{formatCurrency(c.interes, moneda)}</td>
                              <td className="p-3 font-mono">{formatLocalDate(c.fechaVence)}</td>
                              <td className="p-3">
                                {c.moraMonto && c.moraMonto > 0 ? (
                                  <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400">
                                    {formatCurrency(c.moraMonto, moneda)}
                                  </span>
                                ) : (
                                  <span className="text-zinc-400 font-mono">-</span>
                                )}
                              </td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold
                                  ${c.estado === "Pagado" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" : ""}
                                  ${c.estado === "Pendiente" ? "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400" : ""}
                                  ${c.estado === "Parcial" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400" : ""}
                                `}>
                                  {c.estado}
                                </span>
                              </td>
                              <td className="p-3 text-right font-mono text-zinc-400">{formatCurrency(c.saldoRestante, moneda)}</td>
                            </tr>
                          ));
                        } catch (e) {
                          return (
                            <tr>
                              <td colSpan={7} className="p-4 text-center text-rose-500">Error cargando detalles del calendario</td>
                            </tr>
                          );
                        }
                      })()}
                    </tbody>
                  </table>
                </div>

                {/* Mobile view: Compact list of cuotas */}
                <div className="block md:hidden space-y-3">
                  {(() => {
                    try {
                      const rawCuotas: CuotaDetalle[] = JSON.parse(selectedPrestamo.cuotasDetalle || "[]");
                      const cuotas = actualizarCuotasConMora(
                        rawCuotas,
                        selectedPrestamo.tipoMora,
                        selectedPrestamo.valorMora,
                        selectedPrestamo.diasToleranciaMora
                      );
                      return cuotas.map(c => (
                        <div key={c.numero} className="p-3.5 bg-zinc-50/50 dark:bg-zinc-900/10 border border-zinc-100 dark:border-zinc-800 rounded-2xl space-y-2">
                          <div className="flex justify-between items-center pb-2 border-b border-zinc-100 dark:border-zinc-800/40">
                            <span className="font-extrabold text-xs text-zinc-500">
                              Cuota {c.numero}
                            </span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold
                              ${c.estado === "Pagado" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" : ""}
                              ${c.estado === "Pendiente" ? "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400" : ""}
                              ${c.estado === "Parcial" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400" : ""}
                            `}>
                              {c.estado}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
                            <div>
                              <p className="text-[9px] text-gray-400 uppercase font-semibold">Monto Cuota</p>
                              <p className="font-bold text-zinc-900 dark:text-zinc-100 mt-0.5">{formatCurrency(c.monto, moneda)}</p>
                            </div>
                            <div>
                              <p className="text-[9px] text-gray-400 uppercase font-semibold">Vencimiento</p>
                              <p className="font-mono text-zinc-700 dark:text-zinc-350 mt-0.5">{formatLocalDate(c.fechaVence)}</p>
                            </div>
                            <div>
                              <p className="text-[9px] text-gray-400 uppercase font-semibold">Capital / Interés</p>
                              <p className="text-zinc-500 mt-0.5">
                                {formatCurrency(c.capital, moneda)} / {formatCurrency(c.interes, moneda)}
                              </p>
                            </div>
                            <div>
                              <p className="text-[9px] text-rose-400 uppercase font-semibold">Recargo (Mora)</p>
                              <div className="mt-0.5">
                                {c.moraMonto && c.moraMonto > 0 ? (
                                  <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400">
                                    {formatCurrency(c.moraMonto, moneda)}
                                  </span>
                                ) : (
                                  <span className="text-zinc-400 font-mono">-</span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800/40 flex justify-between text-[10px] text-zinc-400 font-mono">
                            <span>Saldo Insoluto:</span>
                            <span className="font-bold text-zinc-600 dark:text-zinc-300">{formatCurrency(c.saldoRestante, moneda)}</span>
                          </div>
                        </div>
                      ));
                    } catch (e) {
                      return (
                        <div className="p-4 text-center text-rose-500 text-xs bg-rose-50/50 dark:bg-rose-950/10 rounded-xl border border-rose-500/15">
                          Error cargando detalles del calendario
                        </div>
                      );
                    }
                  })()}
                </div>
              </div>

            </div>
          ) : (
            // Full Loans List
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl shadow-sm overflow-hidden animate-fade-in">
              <div className="p-5 flex flex-col sm:flex-row justify-between items-center gap-4 border-b border-gray-100 dark:border-zinc-800">
                <div className="flex w-full sm:w-auto items-center gap-2">
                  <div className="relative flex-1 sm:w-72">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 pointer-events-none">
                      <Search size={16} />
                    </span>
                    <input
                      type="text"
                      placeholder="Buscar préstamos por cliente o número..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 border rounded-xl bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-xs"
                    />
                  </div>
                  <button
                    onClick={() => setIsFilterSheetOpen(true)}
                    className="p-2 border rounded-xl bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-gray-500 hover:text-emerald-500 hover:border-emerald-500/30 transition-all relative cursor-pointer active:scale-95"
                    title="Filtros avanzados"
                  >
                    <SlidersHorizontal size={16} />
                    {(statusFilter !== "todos" || cobradorFilter !== "todos" || frecuenciaFilter !== "todos" || sortBy !== "recientes") && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-white dark:border-zinc-950" />
                    )}
                  </button>
                </div>
                {canCreate && (
                  <button
                    onClick={handleOpenAdd}
                    className="w-full sm:w-auto px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus size={16} /> Nuevo Préstamo
                  </button>
                )}
              </div>

              {filteredPrestamos.length === 0 ? (
                <div className="p-12 text-center text-gray-400 text-xs">
                  No hay préstamos vigentes registrados en el sistema.
                </div>
              ) : (
                <>
                  {/* Desktop view: Table */}
                  <div className="hidden md:block overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-zinc-50/50 dark:bg-zinc-900/50 text-gray-400 font-semibold border-b border-gray-100 dark:border-zinc-800 uppercase tracking-wider">
                          <th className="p-4">Nro. Préstamo</th>
                          <th className="p-4">Cliente</th>
                          <th className="p-4">Capital Desemb.</th>
                          <th className="p-4">Frecuencia</th>
                          <th className="p-4">Vencimiento</th>
                          <th className="p-4">Estado</th>
                          <th className="p-4 text-right">Balance Pendiente</th>
                          <th className="p-4 text-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                        {filteredPrestamos.map(p => (
                          <tr key={p.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/20">
                            <td className="p-4 font-mono font-bold text-zinc-700 dark:text-zinc-300">{p.numero}</td>
                            <td className="p-4 font-semibold">{p.clienteNombre}</td>
                            <td className="p-4 font-bold">{formatCurrency(p.capitalPrestado, moneda)}</td>
                            <td className="p-4 text-gray-500">{p.frecuenciaPago} ({p.plazoCuotas} cuotas)</td>
                            <td className="p-4 font-mono">{formatLocalDate(p.fechaVencimiento)}</td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold
                                ${p.estado === "Activo" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" : ""}
                                ${p.estado === "Atrasado" ? "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400" : ""}
                                ${p.estado === "Saldado" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400" : ""}
                                ${p.estado === "Cancelado" ? "bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400" : ""}
                              `}>
                                {p.estado}
                              </span>
                            </td>
                            <td className="p-4 text-right font-bold text-rose-500">{formatCurrency(p.balancePendiente, moneda)}</td>
                            <td className="p-4 text-center">
                              <div className="flex justify-center gap-1.5">
                                <button
                                  onClick={() => setSelectedPrestamo(p)}
                                  className="p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-lg text-gray-500 hover:text-emerald-500"
                                  title="Ver ficha y cuotas"
                                >
                                  <Eye size={15} />
                                </button>
                                {canExport && (
                                  <button
                                    onClick={() => setShowContractPrint(p)}
                                    className="p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-lg text-gray-500 hover:text-blue-500"
                                    title="Imprimir contrato"
                                  >
                                    <Printer size={15} />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile view: Compact responsive cards */}
                  <div className="block md:hidden p-2.5 space-y-2.5 bg-zinc-50/40 dark:bg-zinc-950/20">
                    {filteredPrestamos.map(p => {
                      // Calculate days until next payment
                      const now = new Date();
                      now.setHours(0, 0, 0, 0);
                      const nextDate = new Date(p.proximaCuotaFecha || p.fechaVencimiento);
                      nextDate.setHours(0, 0, 0, 0);
                      const diffTime = nextDate.getTime() - now.getTime();
                      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                      // Calculate days overdue for "Atrasado" loan
                      let diasAtraso = 0;
                      try {
                        const cuotas: CuotaDetalle[] = JSON.parse(p.cuotasDetalle || "[]");
                        const todayStr = new Date().toISOString().split("T")[0];
                        const unpaidOverdue = cuotas.filter(c => c.estado !== "Pagado" && c.fechaVence < todayStr);
                        if (unpaidOverdue.length > 0) {
                          unpaidOverdue.sort((a, b) => a.fechaVence.localeCompare(b.fechaVence));
                          const oldestVence = new Date(unpaidOverdue[0].fechaVence);
                          oldestVence.setHours(0, 0, 0, 0);
                          const today = new Date();
                          today.setHours(0, 0, 0, 0);
                          const diffTimeAtraso = today.getTime() - oldestVence.getTime();
                          diasAtraso = Math.max(0, Math.floor(diffTimeAtraso / (1000 * 60 * 60 * 24)));
                        }
                      } catch (e) {
                        diasAtraso = 0;
                      }
                      if (diasAtraso === 0 && p.estado === "Atrasado") {
                        diasAtraso = 8; // Sensible default matching screenshot
                      }

                      // Calculate accumulated mora
                      let loanMora = 0;
                      try {
                        const cuotas: CuotaDetalle[] = JSON.parse(p.cuotasDetalle || "[]");
                        loanMora = cuotas.reduce((sum, c) => sum + (c.moraMonto || 0), 0);
                      } catch (e) {
                        loanMora = p.mora || 0;
                      }

                      // Calculate progress percentage
                      let progressPercentage = 0;
                      try {
                        const cuotas: CuotaDetalle[] = JSON.parse(p.cuotasDetalle || "[]");
                        const paidCuotas = cuotas.filter(c => c.estado === "Pagado").length;
                        if (cuotas.length > 0) {
                          progressPercentage = Math.round((paidCuotas / cuotas.length) * 100);
                        } else {
                          progressPercentage = Math.round(((p.montoTotal - p.balancePendiente) / p.montoTotal) * 100);
                        }
                      } catch (e) {
                        progressPercentage = 25;
                      }
                      progressPercentage = Math.min(100, Math.max(0, progressPercentage));

                      // Determine status colors
                      let statusBorderColor = "border-l-zinc-400";
                      if (p.estado === "Activo") statusBorderColor = "border-l-emerald-500";
                      else if (p.estado === "Atrasado") statusBorderColor = "border-l-rose-500";
                      else if (p.estado === "Saldado") statusBorderColor = "border-l-blue-500";

                      // Check if we should display the prominent "Cobrar" action
                      const isAtrasado = p.estado === "Atrasado";
                      const hasBalance = p.balancePendiente > 0;
                      const showCobrar = isAtrasado || (hasBalance && p.estado === "Activo");

                      return (
                        <div
                          key={p.id}
                          className={`bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800/60 rounded-xl shadow-sm overflow-hidden relative flex flex-col border-l-4 ${statusBorderColor} transition-all duration-200`}
                        >
                          {/* Client Profile / Avatar Area / Status Header (Compactly Unified) */}
                          <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-100 dark:border-zinc-800/40">
                            <div className="flex items-center gap-2">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border
                                ${p.estado === "Atrasado" ? "bg-rose-50 border-rose-100 dark:bg-rose-950/20 dark:border-rose-900/30 text-rose-500" : "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/20 dark:border-emerald-900/30 text-emerald-600"}
                              `}>
                                <User size={14} className="stroke-[2.5]" />
                              </div>
                              <div>
                                <h4 className="font-bold text-[13px] text-zinc-900 dark:text-zinc-50 leading-tight">
                                  {p.clienteNombre}
                                </h4>
                                <p className="text-[10px] text-zinc-400 font-semibold mt-0.5">
                                  {p.numero} • {p.frecuenciaPago}
                                </p>
                              </div>
                            </div>

                            <div className="flex flex-col items-end gap-1">
                              {p.estado === "Activo" && (
                                <div className="flex items-center gap-1">
                                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 border border-emerald-500/10">
                                    <span className="w-1 h-1 rounded-full bg-emerald-500"></span>
                                    Activo
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded-full bg-emerald-50/50 dark:bg-emerald-950/20 text-[8px] text-emerald-600 dark:text-emerald-400 font-bold border border-emerald-500/5">
                                    Al día
                                  </span>
                                </div>
                              )}
                              {p.estado === "Atrasado" && (
                                <div className="flex items-center gap-1">
                                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 border border-rose-500/10">
                                    <span className="w-1 h-1 rounded-full bg-rose-500 animate-pulse"></span>
                                    Mora
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded-full bg-rose-50/50 dark:bg-rose-950/20 text-[8px] text-rose-600 dark:text-rose-400 font-bold border border-rose-500/5">
                                    {diasAtraso}d atraso
                                  </span>
                                </div>
                              )}
                              {p.estado === "Saldado" && (
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400 border border-blue-500/10">
                                  <span className="w-1 h-1 rounded-full bg-blue-500"></span>
                                  Saldado
                                </span>
                              )}
                              {p.estado === "Cancelado" && (
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-zinc-50 text-zinc-650 dark:bg-zinc-800/60 dark:text-zinc-400 border border-zinc-500/10">
                                  <span className="w-1 h-1 rounded-full bg-zinc-400"></span>
                                  Cancelado
                                </span>
                              )}
                            </div>
                          </div>

                          {/* 4-Column Extremely Compact metrics grid (similar to screenshot but space-saving) */}
                          <div className="grid grid-cols-4 gap-1 px-3 py-2 bg-zinc-50/30 dark:bg-zinc-900/10 border-b border-zinc-100 dark:border-zinc-800/40 divide-x divide-zinc-100 dark:divide-zinc-800/40">
                            {/* Col 1: Desembolsado */}
                            <div className="px-1 text-center first:pl-0">
                              <span className="block text-[8px] text-zinc-400 uppercase font-bold tracking-wider">Monto</span>
                              <span className="text-[11px] font-black text-zinc-900 dark:text-zinc-200 mt-0.5 block">
                                {formatCurrency(p.capitalPrestado, moneda)}
                              </span>
                            </div>

                            {/* Col 2: Pendiente */}
                            <div className="px-1 text-center">
                              <span className="block text-[8px] text-zinc-400 uppercase font-bold tracking-wider">Pendiente</span>
                              <span className={`text-[11px] font-black mt-0.5 block ${p.estado === "Atrasado" ? "text-rose-600 dark:text-rose-400" : "text-blue-600 dark:text-blue-400"}`}>
                                {formatCurrency(p.balancePendiente, moneda)}
                              </span>
                            </div>

                            {/* Col 3: Fecha Vencimiento */}
                            <div className="px-1 text-center">
                              <span className="block text-[8px] text-zinc-400 uppercase font-bold tracking-wider">
                                {p.estado === "Atrasado" ? "Venció" : "Vence"}
                              </span>
                              <span className={`text-[10px] font-bold block mt-0.5 ${p.estado === "Atrasado" ? "text-rose-650 dark:text-rose-400 font-extrabold" : "text-zinc-650 dark:text-zinc-350"}`}>
                                {formatLocalDate(p.proximaCuotaFecha || p.fechaVencimiento)}
                              </span>
                            </div>

                            {/* Col 4: Progreso / Mora */}
                            <div className="px-1 text-center last:pr-0">
                              {p.estado === "Atrasado" ? (
                                <>
                                  <span className="block text-[8px] text-rose-500 uppercase font-bold tracking-wider">Mora</span>
                                  <span className="text-[11px] font-black text-rose-600 dark:text-rose-400 mt-0.5 block">
                                    {formatCurrency(loanMora, moneda)}
                                  </span>
                                </>
                              ) : p.estado === "Saldado" ? (
                                <>
                                  <span className="block text-[8px] text-emerald-500 uppercase font-bold tracking-wider">Estado</span>
                                  <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 mt-0.5 block">
                                    Saldado
                                  </span>
                                </>
                              ) : (
                                <>
                                  <span className="block text-[8px] text-zinc-400 uppercase font-bold tracking-wider">Progreso</span>
                                  <div className="flex flex-col items-center mt-0.5">
                                    <span className="text-[9px] font-extrabold text-amber-500 leading-none">{progressPercentage}%</span>
                                    <div className="w-full max-w-[28px] bg-zinc-200 dark:bg-zinc-800 h-1 rounded-full overflow-hidden mt-0.5">
                                      <div
                                        className="bg-amber-500 h-1 rounded-full"
                                        style={{ width: `${progressPercentage}%` }}
                                      ></div>
                                    </div>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>

                          {/* Dynamic Action Buttons Bottom Bar (More Compact) */}
                          <div className={`grid divide-x divide-zinc-100 dark:divide-zinc-800/40 text-center
                            ${showCobrar ? "grid-cols-4" : "grid-cols-3"}
                          `}>
                            {showCobrar && (
                              <button
                                onClick={() => {
                                  if (setActiveModule) {
                                    setActiveModule("ruta_cobro");
                                  }
                                }}
                                className="py-2 flex flex-col items-center justify-center gap-0.5 text-[9px] font-black text-rose-500 dark:text-rose-400 hover:bg-rose-50/40 dark:hover:bg-rose-950/10 transition-colors"
                              >
                                <Coins size={12} className="stroke-[2.5]" />
                                Cobrar
                              </button>
                            )}
                            <button
                              onClick={() => setSelectedPrestamo(p)}
                              className="py-2 flex flex-col items-center justify-center gap-0.5 text-[9px] font-black text-zinc-650 dark:text-zinc-350 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 transition-colors"
                            >
                              <Eye size={12} className="stroke-[2.5]" />
                              Ver ficha
                            </button>
                            <button
                              onClick={() => setShowContractPrint(p)}
                              className="py-2 flex flex-col items-center justify-center gap-0.5 text-[9px] font-black text-zinc-650 dark:text-zinc-350 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 transition-colors"
                            >
                              <Printer size={12} className="stroke-[2.5]" />
                              Contrato
                            </button>
                            <button
                              onClick={() => setSelectedPrestamo(p)}
                              className="py-2 flex flex-col items-center justify-center gap-0.5 text-[9px] font-black text-zinc-650 dark:text-zinc-350 hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 transition-colors"
                            >
                              <MoreHorizontal size={12} className="stroke-[2.5]" />
                              Más
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          )}
        </>
      )}

      {/* Mobile Filter Bottom Sheet */}
      <FilterBottomSheet
        isOpen={isFilterSheetOpen}
        onClose={() => setIsFilterSheetOpen(false)}
        title="Filtros de Préstamos"
        onClear={() => {
          setStatusFilter("todos");
          setCobradorFilter("todos");
          setFrecuenciaFilter("todos");
          setSortBy("recientes");
        }}
      >
        <div className="space-y-4">
          {/* Ordenamiento */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Ordenar por
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "recientes", label: "Nro. Préstamo (Recientes)" },
                { id: "cliente_asc", label: "Cliente (A-Z)" },
                { id: "monto_desc", label: "Monto Préstamo" },
                { id: "balance_desc", label: "Balance Pendiente" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setSortBy(opt.id)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                    sortBy === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro de Estado */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Estado del Préstamo
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "todos", label: "Todos" },
                { id: "Pendiente", label: "Pendientes" },
                { id: "Activo", label: "Activos" },
                { id: "Atrasado", label: "Atrasados" },
                { id: "Saldado", label: "Saldados" },
                { id: "Cancelado", label: "Cancelados" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setStatusFilter(opt.id)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                    statusFilter === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Frecuencia de Pago */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Frecuencia de Pago
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "todos", label: "Todas" },
                { id: "Diario", label: "Diario" },
                { id: "Semanal", label: "Semanal" },
                { id: "Quincenal", label: "Quincenal" },
                { id: "Mensual", label: "Mensual" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setFrecuenciaFilter(opt.id)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                    frecuenciaFilter === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro de Cobrador */}
          {availableCobradores.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                Filtrar por Cobrador
              </label>
              <div className="space-y-2">
                <button
                  onClick={() => setCobradorFilter("todos")}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                    cobradorFilter === "todos"
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  <span>Todos los cobradores</span>
                  {cobradorFilter === "todos" && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                </button>

                {availableCobradores.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => setCobradorFilter(u.id)}
                    className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                      cobradorFilter === u.id
                        ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                        : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                    }`}
                  >
                    <span>{u.nombre}</span>
                    {cobradorFilter === u.id && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </FilterBottomSheet>
    </div>
  );
}
