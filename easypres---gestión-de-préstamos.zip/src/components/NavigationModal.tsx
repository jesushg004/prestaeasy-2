import React, { useState, useEffect } from "react";
import { X, MapPin, Compass, ExternalLink, Info } from "lucide-react";
import { Cliente } from "../types";

interface NavigationModalProps {
  isOpen: boolean;
  onClose: () => void;
  cliente: Cliente | null;
}

export default function NavigationModal({ isOpen, onClose, cliente }: NavigationModalProps) {
  const [deviceIsIOS, setDeviceIsIOS] = useState<boolean>(false);

  useEffect(() => {
    // Basic iOS detection
    const isIOS =
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    setDeviceIsIOS(isIOS);
  }, []);

  if (!isOpen || !cliente) return null;

  const direccion = cliente.direccion || "";
  const nombre = cliente.nombre || "Cliente";

  // Check if address contains coordinates (e.g., "18.4861, -69.9312" or similar)
  const coordMatch = /(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)/.exec(direccion);
  const coordinates = coordMatch ? { lat: coordMatch[1], lng: coordMatch[2] } : null;

  // Build URLs based on whether we have exact coordinates or a text address
  const googleMapsUrl = coordinates
    ? `https://www.google.com/maps/dir/?api=1&destination=${coordinates.lat},${coordinates.lng}`
    : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(direccion)}`;

  const wazeUrl = coordinates
    ? `https://waze.com/ul?ll=${coordinates.lat},${coordinates.lng}&navigate=yes`
    : `https://waze.com/ul?q=${encodeURIComponent(direccion)}&navigate=yes`;

  const appleMapsUrl = coordinates
    ? `https://maps.apple.com/?daddr=${coordinates.lat},${coordinates.lng}`
    : `https://maps.apple.com/?daddr=${encodeURIComponent(direccion)}`;

  const handleOpenApp = (url: string) => {
    window.open(url, "_blank");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white dark:bg-[#121214] border border-zinc-150 dark:border-zinc-800 rounded-3xl w-full max-w-sm overflow-hidden shadow-xl animate-scale-in">
        
        {/* Header */}
        <div className="p-5 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between bg-zinc-50/50 dark:bg-zinc-950/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Compass size={18} className="stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900 dark:text-zinc-100">
                Cómo llegar a destino
              </h3>
              <p className="text-[10px] text-gray-400 dark:text-zinc-500 font-medium">
                Selecciona tu aplicación de mapas favorita
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-200 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg transition-all"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          
          {/* Target Info */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider block">
              Cliente & Dirección
            </span>
            <div className="p-3.5 bg-zinc-50 dark:bg-zinc-900/60 rounded-2xl border border-zinc-100 dark:border-zinc-800/80 space-y-1">
              <p className="text-xs font-bold text-gray-800 dark:text-zinc-100">{nombre}</p>
              <div className="flex items-start gap-1 text-[11px] text-gray-500 dark:text-zinc-400">
                <MapPin size={12} className="text-gray-400 shrink-0 mt-0.5" />
                <span className="leading-relaxed break-words">{direccion}</span>
              </div>
              {coordinates && (
                <div className="pt-1.5 flex items-center gap-1.5 border-t border-zinc-150/50 dark:border-zinc-800/50 text-[9px] text-emerald-600 dark:text-emerald-400 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Coordenadas detectadas: {coordinates.lat}, {coordinates.lng}</span>
                </div>
              )}
            </div>
          </div>

          {/* Navigation Buttons List */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider block">
              Abrir en Aplicación de Navegación
            </span>
            
            <div className="space-y-2">
              {/* Google Maps Button */}
              <button
                type="button"
                onClick={() => handleOpenApp(googleMapsUrl)}
                className="w-full p-3.5 rounded-2xl border border-zinc-150 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-gray-700 dark:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-900 font-semibold text-xs flex items-center justify-between transition-all active:scale-[0.98] group"
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">🗺️</span>
                  <div className="text-left">
                    <p className="font-bold">Google Maps</p>
                    <p className="text-[9px] text-gray-400 dark:text-zinc-500 font-normal">Navegación paso a paso</p>
                  </div>
                </div>
                <ExternalLink size={14} className="text-gray-400 group-hover:text-emerald-500 transition-colors" />
              </button>

              {/* Waze Button */}
              <button
                type="button"
                onClick={() => handleOpenApp(wazeUrl)}
                className="w-full p-3.5 rounded-2xl border border-zinc-150 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-gray-700 dark:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-900 font-semibold text-xs flex items-center justify-between transition-all active:scale-[0.98] group"
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">🚗</span>
                  <div className="text-left">
                    <p className="font-bold">Waze</p>
                    <p className="text-[9px] text-gray-400 dark:text-zinc-500 font-normal">Tránsito en tiempo real</p>
                  </div>
                </div>
                <ExternalLink size={14} className="text-gray-400 group-hover:text-emerald-500 transition-colors" />
              </button>

              {/* Apple Maps (Show always or make prominent if deviceIsIOS) */}
              {(deviceIsIOS || true) && (
                <button
                  type="button"
                  onClick={() => handleOpenApp(appleMapsUrl)}
                  className={`w-full p-3.5 rounded-2xl border bg-white dark:bg-zinc-950 text-gray-700 dark:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-900 font-semibold text-xs flex items-center justify-between transition-all active:scale-[0.98] group ${
                    deviceIsIOS ? "border-emerald-500/40 shadow-xs" : "border-zinc-150 dark:border-zinc-800"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🍎</span>
                    <div className="text-left">
                      <p className="font-bold flex items-center gap-1">
                        Apple Maps
                        {deviceIsIOS && (
                          <span className="px-1 py-0.2 bg-emerald-500/10 text-emerald-600 rounded text-[8px] font-bold">
                            Recomendado
                          </span>
                        )}
                      </p>
                      <p className="text-[9px] text-gray-400 dark:text-zinc-500 font-normal">Mapa nativo de iOS</p>
                    </div>
                  </div>
                  <ExternalLink size={14} className="text-gray-400 group-hover:text-emerald-500 transition-colors" />
                </button>
              )}
            </div>
          </div>

          <div className="p-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-150 dark:border-zinc-850 rounded-2xl flex items-start gap-2 text-[10px] text-gray-500 dark:text-zinc-400 leading-relaxed">
            <Info size={12} className="shrink-0 text-emerald-500 mt-0.5" />
            <span>
              La aplicación seleccionada se abrirá en tu dispositivo de forma automática con las direcciones para llegar al domicilio registrado.
            </span>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-100 dark:border-zinc-800 flex justify-end bg-zinc-50/50 dark:bg-zinc-950/20">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-gray-500 hover:text-gray-700 dark:text-zinc-400 dark:hover:text-zinc-200"
          >
            Cerrar
          </button>
        </div>

      </div>
    </div>
  );
}
