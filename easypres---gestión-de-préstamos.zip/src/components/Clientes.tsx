import React, { useState, useMemo, useRef, useEffect } from "react";
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Camera,
  User,
  FileText,
  Phone,
  Mail,
  MapPin,
  Eye,
  ArrowLeft,
  X,
  PlusCircle,
  EyeOff,
  SlidersHorizontal,
  MessageCircle
} from "lucide-react";
import { Cliente, Prestamo, Pago, Usuario, checkPermission } from "../types";
import { formatCurrency, generateRandomCode } from "../utils";
import FilterBottomSheet from "./FilterBottomSheet";
import WhatsAppModal from "./WhatsAppModal";

interface ClientesProps {
  clientes: Cliente[];
  prestamos: Prestamo[];
  pagos: Pago[];
  moneda: string;
  onSave: (cliente: Cliente) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  currentUserProfile?: Usuario | null;
  usuarios?: Usuario[];
  initialSearchQuery?: string;
  initialSelectedClienteId?: string;
  onClearInitialSelection?: () => void;
  onReassignClient?: (clienteId: string, cobradorId: string, motivo: string, tipo: "Inicial" | "Permanente" | "Temporal") => Promise<void>;
}

export default function Clientes({
  clientes,
  prestamos,
  pagos,
  moneda,
  onSave,
  onDelete,
  currentUserProfile,
  usuarios = [],
  initialSearchQuery = "",
  initialSelectedClienteId = "",
  onClearInitialSelection,
  onReassignClient
}: ClientesProps) {
  const canCreate = checkPermission(currentUserProfile, "clientes", "crear");
  const canEdit = checkPermission(currentUserProfile, "clientes", "editar");
  const canDelete = checkPermission(currentUserProfile, "clientes", "eliminar");
  const canExport = checkPermission(currentUserProfile, "clientes", "exportar");
  // Navigation states
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [selectedCliente, setSelectedCliente] = useState<Cliente | null>(null);

  // Direct individual assignment modal state
  const [showReassignModal, setShowReassignModal] = useState(false);
  const [reassignCobradorEmail, setReassignCobradorEmail] = useState("");
  const [reassignMotivo, setReassignMotivo] = useState("");
  const [isSubmittingReassign, setIsSubmittingReassign] = useState(false);

  // Sync direct navigation selections from BI Dashboard
  useEffect(() => {
    if (initialSearchQuery) {
      setSearchQuery(initialSearchQuery);
    }
    if (initialSelectedClienteId) {
      const found = clientes.find((c) => c.id === initialSelectedClienteId);
      if (found) {
        setSelectedCliente(found);
      }
    }
    // Clear selection state in parent so it doesn't trigger on every switch
    if (initialSearchQuery || initialSelectedClienteId) {
      onClearInitialSelection?.();
    }
  }, [initialSearchQuery, initialSelectedClienteId, clientes, onClearInitialSelection]);
  const [isEditing, setIsEditing] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  // Form states
  const [formCodigo, setFormCodigo] = useState("");
  const [formNombre, setFormNombre] = useState("");
  const [formCedula, setFormCedula] = useState("");
  const [formTelefono, setFormTelefono] = useState("");
  const [formDireccion, setFormDireccion] = useState("");
  const [formCorreo, setFormCorreo] = useState("");
  const [formFoto, setFormFoto] = useState("");
  const [formReferenciasPersonales, setFormReferenciasPersonales] = useState("");
  const [formReferenciasLaborales, setFormReferenciasLaborales] = useState("");
  const [formCobradorId, setFormCobradorId] = useState("");
  const [formCobradorNombre, setFormCobradorNombre] = useState("");

  // Camera states
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Advanced Filter states
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState("todos"); // 'todos', 'activos', 'sin_prestamos'
  const [cobradorFilter, setCobradorFilter] = useState("todos");
  const [sortBy, setSortBy] = useState("nombre_asc"); // 'nombre_asc', 'nombre_desc', 'codigo_asc', 'recientes'

  // Column visibility state
  const [visibleColumns, setVisibleColumns] = useState<{
    fotoCodigo: boolean;
    nombre: boolean;
    cedula: boolean;
    telefono: boolean;
    direccion: boolean;
    prestamos: boolean;
  }>(() => {
    const saved = localStorage.getItem("clientesVisibleColumns");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      fotoCodigo: true,
      nombre: true,
      cedula: true,
      telefono: true,
      direccion: true,
      prestamos: true,
    };
  });

  useEffect(() => {
    localStorage.setItem("clientesVisibleColumns", JSON.stringify(visibleColumns));
  }, [visibleColumns]);

  // WhatsApp Click-to-Chat states
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [selectedWhatsAppCliente, setSelectedWhatsAppCliente] = useState<Cliente | null>(null);
  const [selectedWhatsAppPrestamo, setSelectedWhatsAppPrestamo] = useState<Prestamo | null>(null);

  // Filter clients
  const filteredClientes = useMemo(() => {
    let result = [...clientes];

    // Search query filter
    const q = searchQuery.toLowerCase().trim();
    if (q) {
      result = result.filter(
        c =>
          c.nombre.toLowerCase().includes(q) ||
          c.cedula.toLowerCase().includes(q) ||
          c.codigo.toLowerCase().includes(q) ||
          c.telefono.toLowerCase().includes(q)
      );
    }

    // Status filter
    if (statusFilter !== "todos") {
      result = result.filter(c => {
        const clientLoans = prestamos.filter(p => p.clienteId === c.id);
        const hasActive = clientLoans.some(p => p.estado === "Activo" || p.estado === "Atrasado");
        if (statusFilter === "activos") {
          return hasActive;
        } else if (statusFilter === "sin_prestamos") {
          return clientLoans.length === 0;
        }
        return true;
      });
    }

    // Cobrador filter
    if (cobradorFilter !== "todos") {
      result = result.filter(c => c.cobradorId === cobradorFilter);
    }

    // Sorting
    result.sort((a, b) => {
      if (sortBy === "nombre_asc") {
        return a.nombre.localeCompare(b.nombre);
      }
      if (sortBy === "nombre_desc") {
        return b.nombre.localeCompare(a.nombre);
      }
      if (sortBy === "codigo_asc") {
        return a.codigo.localeCompare(b.codigo);
      }
      if (sortBy === "recientes") {
        return b.codigo.localeCompare(a.codigo);
      }
      return 0;
    });

    return result;
  }, [clientes, searchQuery, statusFilter, cobradorFilter, sortBy, prestamos]);

  // Open Add Form
  const handleOpenAdd = () => {
    // Generate code
    const baseCode = generateRandomCode("CLI");
    setFormCodigo(baseCode);
    setFormNombre("");
    setFormCedula("");
    setFormTelefono("");
    setFormDireccion("");
    setFormCorreo("");
    setFormFoto("");
    setFormReferenciasPersonales("");
    setFormReferenciasLaborales("");
    setFormCobradorId("");
    setFormCobradorNombre("");
    setIsAdding(true);
    setIsEditing(false);
  };

  // Open Edit Form
  const handleOpenEdit = (cliente: Cliente) => {
    setFormCodigo(cliente.codigo);
    setFormNombre(cliente.nombre);
    setFormCedula(cliente.cedula);
    setFormTelefono(cliente.telefono);
    setFormDireccion(cliente.direccion);
    setFormCorreo(cliente.correo || "");
    setFormFoto(cliente.foto || "");
    setFormReferenciasPersonales(cliente.referenciasPersonales || "");
    setFormReferenciasLaborales(cliente.referenciasLaborales || "");
    setFormCobradorId(cliente.cobradorId || "");
    setFormCobradorNombre(cliente.cobradorNombre || "");
    setIsEditing(true);
    setIsAdding(false);
  };

  // Submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing && !canEdit) {
      alert("No tienes permisos para editar clientes.");
      return;
    }
    if (!isEditing && !canCreate) {
      alert("No tienes permisos para registrar nuevos clientes.");
      return;
    }
    if (!formNombre || !formCedula || !formTelefono || !formDireccion) {
      alert("Por favor rellene todos los campos obligatorios.");
      return;
    }

    // Default to logging operator if cobrador is creating and no other cobrador was selected
    const finalCobradorId = formCobradorId || (currentUserProfile?.rol === "Cobrador" ? currentUserProfile.email : "");
    const finalCobradorNombre = formCobradorNombre || (currentUserProfile?.rol === "Cobrador" ? currentUserProfile.nombre : "");

    const payload: Cliente = {
      codigo: formCodigo,
      nombre: formNombre,
      cedula: formCedula,
      telefono: formTelefono,
      direccion: formDireccion,
      correo: formCorreo,
      foto: formFoto,
      referenciasPersonales: formReferenciasPersonales,
      referenciasLaborales: formReferenciasLaborales,
      fechaRegistro: isEditing && selectedCliente ? selectedCliente.fechaRegistro : new Date().toISOString(),
      cobradorId: finalCobradorId,
      cobradorNombre: finalCobradorNombre
    };

    if (isEditing && selectedCliente?.id) {
      payload.id = selectedCliente.id;
    }

    try {
      await onSave(payload);
      setIsAdding(false);
      setIsEditing(false);
      setSelectedCliente(null);
    } catch (err: any) {
      console.error(err);
      const errMsg = err?.message || String(err);
      alert("Error al guardar cliente: " + errMsg);
    }
  };

  // Delete client
  const handleDelete = async (id: string) => {
    if (!canDelete) {
      alert("No tienes permisos para eliminar clientes.");
      return;
    }

    // Validar si el cliente tiene préstamos activos o pendientes
    const tienePrestamosActivos = prestamos.some(
      (p) => p.clienteId === id && (p.estado === "Activo" || p.estado === "Atrasado" || p.balancePendiente > 0)
    );

    if (tienePrestamosActivos) {
      alert("No se puede eliminar este cliente porque tiene préstamos activos o con saldo pendiente.");
      return;
    }

    if (confirm("¿Está seguro de que desea eliminar este cliente? Perderá su ficha personal.")) {
      try {
        await onDelete(id);
        setSelectedCliente(null);
      } catch (err) {
        console.error(err);
        alert("Error al eliminar cliente");
      }
    }
  };

  // File picker handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormFoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Start Camera Stream
  const startCamera = async () => {
    try {
      setShowCamera(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 300, height: 300 } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error("Camera access error", err);
      alert("No se pudo acceder a la cámara. Por favor use el selector de archivos.");
      setShowCamera(false);
    }
  };

  // Capture Photo
  const capturePhoto = () => {
    if (videoRef.current && streamRef.current) {
      const canvas = document.createElement("canvas");
      canvas.width = 300;
      canvas.height = 300;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, 300, 300);
        const dataUrl = canvas.toDataURL("image/jpeg");
        setFormFoto(dataUrl);
      }
      stopCamera();
    }
  };

  // Stop Camera Stream
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setShowCamera(false);
  };

  // Derived client lists
  const clientLoans = useMemo(() => {
    if (!selectedCliente?.id) return [];
    return prestamos.filter(p => p.clienteId === selectedCliente.id);
  }, [selectedCliente, prestamos]);

  const clientPayments = useMemo(() => {
    if (!selectedCliente?.id) return [];
    return pagos.filter(p => p.clienteId === selectedCliente.id);
  }, [selectedCliente, pagos]);

  const handleReassignSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCliente || !onReassignClient) return;
    if (!reassignCobradorEmail) {
      alert("Por favor seleccione un cobrador.");
      return;
    }
    try {
      setIsSubmittingReassign(true);
      const isInitial = !selectedCliente.cobradorId;
      await onReassignClient(
        selectedCliente.id!,
        reassignCobradorEmail,
        reassignMotivo || "Asignación directa individual",
        isInitial ? "Inicial" : "Permanente"
      );
      // Update selected client details locally
      const updatedMatch = usuarios.find(u => u.email === reassignCobradorEmail);
      setSelectedCliente({
        ...selectedCliente,
        cobradorId: reassignCobradorEmail,
        cobradorNombre: updatedMatch ? updatedMatch.nombre : reassignCobradorEmail
      });
      setShowReassignModal(false);
      setReassignMotivo("");
      alert("Cobrador asignado de forma exitosa.");
    } catch (err: any) {
      alert("Error al asignar cobrador: " + err.message);
    } finally {
      setIsSubmittingReassign(false);
    }
  };

  return (
    <div className="space-y-6" id="clientes-module-view">
      {/* 1. Add / Edit form overlay or pane */}
      {(isAdding || isEditing) && (
        <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-md max-w-2xl mx-auto animate-fade-in">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <User className="text-emerald-500" />
              {isAdding ? "Registrar Nuevo Cliente" : "Editar Cliente"}
            </h2>
            <button
              onClick={() => {
                setIsAdding(false);
                setIsEditing(false);
                stopCamera();
              }}
              className="p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-gray-400"
            >
              <X size={18} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Código (Automático)</label>
                <input
                  type="text"
                  value={formCodigo}
                  disabled
                  className="w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-gray-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Nombre Completo *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: Juan Pérez"
                  value={formNombre}
                  onChange={e => setFormNombre(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Cédula / Identificación *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej: 001-0000000-0"
                  value={formCedula}
                  onChange={e => setFormCedula(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Teléfono Móvil *</label>
                <input
                  type="tel"
                  required
                  placeholder="Ej: 809-555-1234"
                  value={formTelefono}
                  onChange={e => setFormTelefono(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Dirección Completa *</label>
                <input
                  type="text"
                  required
                  placeholder="Calle, No. Casa, Barrio, Ciudad"
                  value={formDireccion}
                  onChange={e => setFormDireccion(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Correo Electrónico (Opcional)</label>
                <input
                  type="email"
                  placeholder="juan@gmail.com"
                  value={formCorreo}
                  onChange={e => setFormCorreo(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800"
                />
              </div>

              {currentUserProfile?.rol !== "Cobrador" && (
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase mb-1">Cobrador Asignado (Control)</label>
                  <select
                    value={formCobradorId}
                    onChange={(e) => {
                      const selectedEmail = e.target.value;
                      setFormCobradorId(selectedEmail);
                      const matched = usuarios.find((u) => u.email === selectedEmail);
                      setFormCobradorNombre(matched ? matched.nombre : "");
                    }}
                    className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-bold text-emerald-600 dark:text-emerald-400"
                  >
                    <option value="">-- Sin Cobrador Asignado --</option>
                    {usuarios
                      .filter((u) => u.rol === "Cobrador" && (u.activo || u.email === formCobradorId))
                      .map((cob, idx) => (
                        <option key={`${cob.id || cob.uid || 'cob'}-${cob.email || idx}-${idx}`} value={cob.email}>
                          {cob.nombre} ({cob.email}){!cob.activo ? " [Inactivo]" : ""}
                        </option>
                      ))}
                  </select>
                </div>
              )}

              {/* Photo Upload Section */}
              <div className="flex flex-col sm:flex-row gap-4 md:col-span-2 p-3 bg-zinc-50 dark:bg-zinc-900 rounded-xl items-center justify-between">
                <div className="flex items-center gap-3">
                  {formFoto ? (
                    <img
                      src={formFoto}
                      alt="Preview"
                      className="w-16 h-16 rounded-full object-cover border border-emerald-500"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-full bg-zinc-200 dark:bg-zinc-800 flex items-center justify-center text-gray-400">
                      <Camera size={24} />
                    </div>
                  )}
                  <div>
                    <h4 className="text-xs font-bold text-gray-800 dark:text-zinc-200">Fotografía de Perfil</h4>
                    <p className="text-[10px] text-gray-400">Sube un archivo o captura con tu cámara</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <label className="cursor-pointer px-3 py-1.5 bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 text-xs font-semibold rounded-lg hover:bg-zinc-300 dark:hover:bg-zinc-700 transition-colors">
                    Sugerir Foto
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                  {!showCamera ? (
                    <button
                      type="button"
                      onClick={startCamera}
                      className="px-3 py-1.5 bg-emerald-600 text-white text-xs font-semibold rounded-lg hover:bg-emerald-700 transition-colors"
                    >
                      Tomar Cámara
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopCamera}
                      className="px-3 py-1.5 bg-rose-600 text-white text-xs font-semibold rounded-lg hover:bg-rose-700 transition-colors"
                    >
                      Cancelar Cámara
                    </button>
                  )}
                </div>
              </div>

              {/* Camera overlay box */}
              {showCamera && (
                <div className="md:col-span-2 flex flex-col items-center p-3 bg-black rounded-xl">
                  <video ref={videoRef} className="w-full max-w-[280px] h-[200px] object-cover rounded-lg mb-2" />
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="px-4 py-2 bg-emerald-500 text-white text-xs font-bold rounded-xl"
                  >
                    Tomar Captura
                  </button>
                </div>
              )}

              {/* References */}
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Referencias Personales</label>
                <textarea
                  rows={2}
                  placeholder="Nombre completo, teléfono y relación..."
                  value={formReferenciasPersonales}
                  onChange={e => setFormReferenciasPersonales(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Referencias Laborales</label>
                <textarea
                  rows={2}
                  placeholder="Empresa, teléfono, puesto..."
                  value={formReferenciasLaborales}
                  onChange={e => setFormReferenciasLaborales(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-zinc-100 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setIsEditing(false);
                  stopCamera();
                }}
                className="px-4 py-2 border rounded-xl hover:bg-zinc-50 dark:hover:bg-zinc-900 text-sm"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 transition-all"
              >
                Guardar Cliente
              </button>
            </div>
          </form>
        </div>
      )}

  // 2. List & Detail Section (If not editing/adding)
      {!isAdding && !isEditing && (
        <>
          {/* Detailed client view */}
          {selectedCliente ? (
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl p-6 shadow-sm space-y-6 animate-fade-in">
              <button
                onClick={() => setSelectedCliente(null)}
                className="flex items-center gap-1 text-xs font-bold text-gray-500 hover:text-emerald-500"
              >
                <ArrowLeft size={14} /> Volver a la lista
              </button>

              <div className="flex flex-col md:flex-row gap-6 justify-between items-start border-b border-zinc-100 dark:border-zinc-800 pb-6">
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {selectedCliente.foto ? (
                    <img
                      src={selectedCliente.foto}
                      alt={selectedCliente.nombre}
                      className="w-24 h-24 rounded-full object-cover border-2 border-emerald-500 shadow-sm"
                    />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-400 flex items-center justify-center font-bold text-2xl">
                      {selectedCliente.nombre.charAt(0)}
                    </div>
                  )}

                  <div className="text-center sm:text-left space-y-1">
                    <span className="px-2.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 font-mono text-xs text-gray-400 font-semibold uppercase">
                      {selectedCliente.codigo}
                    </span>
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">{selectedCliente.nombre}</h2>
                    <p className="text-sm text-gray-400 flex items-center justify-center sm:justify-start gap-1">
                      <FileText size={14} /> Cédula: {selectedCliente.cedula}
                    </p>
                    {selectedCliente.cobradorNombre && (
                      <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center justify-center sm:justify-start gap-1 bg-emerald-500/10 px-2 py-0.5 rounded-lg w-fit mt-1.5" id="detail-cobrador-badge">
                        Cobrador: {selectedCliente.cobradorNombre}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 w-full sm:w-auto">
                  {currentUserProfile?.rol !== "Cobrador" && (
                    <button
                      type="button"
                      onClick={() => {
                        setReassignCobradorEmail(selectedCliente.cobradorId || "");
                        setReassignMotivo("");
                        setShowReassignModal(true);
                      }}
                      className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:bg-emerald-950/30 dark:hover:bg-emerald-950/50 dark:text-emerald-400 rounded-xl flex items-center justify-center gap-1.5 text-xs font-semibold"
                      id="btn-direct-reassign"
                    >
                      <User size={14} /> Asignar Cobrador
                    </button>
                  )}
                  {canEdit && (
                    <button
                      onClick={() => handleOpenEdit(selectedCliente)}
                      className="flex-1 sm:flex-initial px-4 py-2 border rounded-xl flex items-center justify-center gap-1.5 text-xs font-semibold hover:bg-zinc-50 dark:hover:bg-zinc-900"
                    >
                      <Edit2 size={14} /> Editar
                    </button>
                  )}
                  {canDelete && (
                    <button
                      onClick={() => handleDelete(selectedCliente.id || "")}
                      className="flex-1 sm:flex-initial px-4 py-2 border border-rose-100 dark:border-rose-900/30 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-xl flex items-center justify-center gap-1.5 text-xs font-semibold"
                    >
                      <Trash2 size={14} /> Eliminar
                    </button>
                  )}
                </div>
              </div>

              {/* Detail Info Tabs */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Column 1: Contact details */}
                <div className="bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100 dark:border-zinc-800/60 p-4 rounded-2xl space-y-4">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Datos de Contacto</h3>
                  
                  <div className="space-y-3 text-xs">
                    <p className="flex items-center gap-2.5 text-gray-600 dark:text-zinc-300">
                      <Phone size={14} className="text-emerald-500" />
                      <strong>Teléfono:</strong> {selectedCliente.telefono}
                      {selectedCliente.telefono && (
                        <button
                          onClick={() => {
                            const clientLoan = prestamos.find(p => p.clienteId === selectedCliente.id && p.estado === "Activo") 
                              || prestamos.find(p => p.clienteId === selectedCliente.id);
                            setSelectedWhatsAppCliente(selectedCliente);
                            setSelectedWhatsAppPrestamo(clientLoan || null);
                            setIsWhatsAppModalOpen(true);
                          }}
                          className="ml-1 p-1 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/25 rounded-md transition-colors flex items-center gap-1 text-[10px] font-bold"
                          title="Enviar mensaje de WhatsApp"
                        >
                          <MessageCircle size={12} /> WhatsApp
                        </button>
                      )}
                    </p>
                    {selectedCliente.correo && (
                      <p className="flex items-center gap-2.5 text-gray-600 dark:text-zinc-300">
                        <Mail size={14} className="text-emerald-500" />
                        <strong>Correo:</strong> {selectedCliente.correo}
                      </p>
                    )}
                    <p className="flex items-start gap-2.5 text-gray-600 dark:text-zinc-300">
                      <MapPin size={14} className="text-emerald-500 flex-shrink-0 mt-0.5" />
                      <span><strong>Dirección:</strong> {selectedCliente.direccion}</span>
                    </p>
                    <p className="text-gray-400 text-[10px] pt-2 border-t border-zinc-100 dark:border-zinc-800">
                      Registrado el {new Date(selectedCliente.fechaRegistro).toLocaleString("es-ES")}
                    </p>
                  </div>
                </div>

                {/* Column 2: References */}
                <div className="bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100 dark:border-zinc-800/60 p-4 rounded-2xl space-y-4">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Referencias</h3>
                  
                  <div className="space-y-4 text-xs">
                    <div>
                      <h4 className="font-bold text-gray-700 dark:text-zinc-300 mb-1">Referencia Personal</h4>
                      <p className="text-gray-500 bg-white dark:bg-zinc-950 p-2 rounded-lg border border-zinc-100 dark:border-zinc-800">
                        {selectedCliente.referenciasPersonales || "No registrada"}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-bold text-gray-700 dark:text-zinc-300 mb-1">Referencia Laboral</h4>
                      <p className="text-gray-500 bg-white dark:bg-zinc-950 p-2 rounded-lg border border-zinc-100 dark:border-zinc-800">
                        {selectedCliente.referenciasLaborales || "No registrada"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Column 3: Stats Summary */}
                <div className="bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-100 dark:border-zinc-800/60 p-4 rounded-2xl space-y-4 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Resumen de Cuenta</h3>
                    <div className="space-y-2 text-xs pt-3">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Préstamos Solicitados:</span>
                        <span className="font-bold">{clientLoans.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Préstamos Activos:</span>
                        <span className="font-bold text-emerald-600">{clientLoans.filter(l => l.estado === "Activo" || l.estado === "Atrasado").length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Balance Pendiente:</span>
                        <span className="font-bold text-rose-500">
                          {formatCurrency(clientLoans.reduce((sum, l) => sum + (l.estado !== "Saldado" && l.estado !== "Cancelado" ? l.balancePendiente : 0), 0), moneda)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 flex gap-2">
                    <button
                      onClick={() => alert("Historial médico / Documentos en regla para préstamos futuros")}
                      className="w-full text-center py-2 bg-zinc-200 dark:bg-zinc-800 rounded-lg text-xs font-bold"
                    >
                      Verificar Documentos
                    </button>
                  </div>
                </div>

              </div>

              {/* Loan history table */}
              <div className="space-y-2">
                <h3 className="text-sm font-bold text-gray-900 dark:text-white">Historial de Préstamos ({clientLoans.length})</h3>
                {clientLoans.length === 0 ? (
                  <p className="text-xs text-gray-400 p-4 bg-zinc-50 dark:bg-zinc-900 rounded-xl text-center border">
                    Este cliente aún no tiene préstamos registrados.
                  </p>
                ) : (
                  <div className="border border-zinc-100 dark:border-zinc-800 rounded-xl overflow-x-auto">
                    <table className="w-full min-w-[700px] text-xs text-left border-collapse">
                      <thead>
                        <tr className="bg-zinc-50 dark:bg-zinc-900 text-gray-400 font-semibold border-b">
                          <th className="p-3">Nro. Préstamo</th>
                          <th className="p-3">Monto Capital</th>
                          <th className="p-3">Tasa %</th>
                          <th className="p-3">Frecuencia</th>
                          <th className="p-3">Vence</th>
                          <th className="p-3">Estado</th>
                          <th className="p-3 text-right">Balance Pendiente</th>
                        </tr>
                      </thead>
                      <tbody>
                        {clientLoans.map(l => (
                          <tr key={l.id} className="border-b hover:bg-zinc-50 dark:hover:bg-zinc-900/40">
                            <td className="p-3 font-mono font-bold text-zinc-700 dark:text-zinc-300">{l.numero}</td>
                            <td className="p-3 font-bold">{formatCurrency(l.capitalPrestado, moneda)}</td>
                            <td className="p-3">{l.tasaInteres}% ({l.tipoInteres})</td>
                            <td className="p-3">{l.frecuenciaPago}</td>
                            <td className="p-3">{new Date(l.fechaVencimiento).toLocaleDateString("es-ES")}</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold
                                ${l.estado === "Activo" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400" : ""}
                                ${l.estado === "Atrasado" ? "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400" : ""}
                                ${l.estado === "Saldado" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400" : ""}
                                ${l.estado === "Cancelado" ? "bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400" : ""}
                              `}>
                                {l.estado}
                              </span>
                            </td>
                            <td className="p-3 text-right font-bold text-rose-500">{formatCurrency(l.balancePendiente, moneda)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Payment history table */}
              <div className="space-y-2">
                <h3 className="text-sm font-bold text-gray-900 dark:text-white">Historial de Pagos ({clientPayments.length})</h3>
                {clientPayments.length === 0 ? (
                  <p className="text-xs text-gray-400 p-4 bg-zinc-50 dark:bg-zinc-900 rounded-xl text-center border">
                    Este cliente aún no ha registrado pagos en el sistema.
                  </p>
                ) : (
                  <div className="border border-zinc-100 dark:border-zinc-800 rounded-xl overflow-x-auto">
                    <table className="w-full min-w-[700px] text-xs text-left border-collapse">
                      <thead>
                        <tr className="bg-zinc-50 dark:bg-zinc-900 text-gray-400 font-semibold border-b">
                          <th className="p-3">Recibo</th>
                          <th className="p-3">Nro. Préstamo</th>
                          <th className="p-3">Fecha Pago</th>
                          <th className="p-3">Tipo de Pago</th>
                          <th className="p-3">Amort. Capital</th>
                          <th className="p-3">Interés Pagado</th>
                          <th className="p-3 text-right">Monto Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {clientPayments.map(p => (
                          <tr key={p.id} className="border-b hover:bg-zinc-50 dark:hover:bg-zinc-900/40">
                            <td className="p-3 font-mono font-bold text-zinc-700 dark:text-zinc-300">{p.reciboNo}</td>
                            <td className="p-3 font-mono text-zinc-400">{p.prestamoNumero}</td>
                            <td className="p-3">{new Date(p.fecha).toLocaleDateString("es-ES")}</td>
                            <td className="p-3">{p.tipoPago}</td>
                            <td className="p-3">{formatCurrency(p.capitalPagado, moneda)}</td>
                            <td className="p-3">{formatCurrency(p.interesPagado, moneda)}</td>
                            <td className="p-3 text-right font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(p.monto, moneda)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

            </div>
          ) : (
            // Full Clients list table
            <div className="bg-white dark:bg-[#121214] border border-gray-100 dark:border-zinc-800 rounded-2xl shadow-sm overflow-hidden animate-fade-in">
              <div className="p-5 flex flex-col sm:flex-row justify-between items-center gap-4 border-b border-gray-100 dark:border-zinc-800">
                <div className="flex w-full sm:w-auto items-center gap-2">
                  <div className="relative flex-1 sm:w-72">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400 pointer-events-none">
                      <Search size={16} />
                    </span>
                    <input
                      type="text"
                      placeholder="Buscar por nombre, cédula, código..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 border rounded-xl bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-xs"
                    />
                  </div>
                  <button
                    onClick={() => setIsFilterSheetOpen(true)}
                    className="p-2 border rounded-xl bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-gray-500 hover:text-emerald-500 hover:border-emerald-500/30 transition-all relative cursor-pointer active:scale-95"
                    title="Filtros avanzados"
                  >
                    <SlidersHorizontal size={16} />
                    {(statusFilter !== "todos" || cobradorFilter !== "todos" || sortBy !== "nombre_asc") && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-white dark:border-zinc-950" />
                    )}
                  </button>
                </div>
                {canCreate && (
                  <button
                    onClick={handleOpenAdd}
                    className="w-full sm:w-auto px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus size={16} /> Registrar Cliente
                  </button>
                )}
              </div>

              {filteredClientes.length === 0 ? (
                <div className="p-12 text-center text-gray-400 text-xs">
                  No se encontraron clientes registrados que coincidan con la búsqueda.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-zinc-50/50 dark:bg-zinc-900/50 text-gray-400 font-semibold border-b border-gray-100 dark:border-zinc-800 uppercase tracking-wider font-sans">
                        {visibleColumns.fotoCodigo && <th className="p-4">Foto / Código</th>}
                        {visibleColumns.nombre && <th className="p-4">Nombre Completo</th>}
                        {visibleColumns.cedula && <th className="p-4">Cédula</th>}
                        {visibleColumns.telefono && <th className="p-4">Teléfono</th>}
                        {visibleColumns.direccion && <th className="p-4">Dirección</th>}
                        {visibleColumns.prestamos && <th className="p-4 text-center">Préstamos</th>}
                        <th className="p-4 text-right">Acción</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50 dark:divide-zinc-900/60">
                      {filteredClientes.map(c => {
                        const countLoans = prestamos.filter(p => p.clienteId === c.id).length;
                        return (
                          <tr key={c.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/20">
                            {visibleColumns.fotoCodigo && (
                              <td className="p-4">
                                <div className="flex items-center gap-3">
                                  {c.foto ? (
                                    <img
                                      src={c.foto}
                                      alt={c.nombre}
                                      className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                                    />
                                  ) : (
                                    <div className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-400 flex items-center justify-center font-bold">
                                      {c.nombre.charAt(0)}
                                    </div>
                                  )}
                                  <span className="font-mono text-[10px] font-bold text-gray-400 bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded">
                                    {c.codigo}
                                  </span>
                                </div>
                              </td>
                            )}
                            {visibleColumns.nombre && (
                              <td className="p-4 font-semibold text-gray-800 dark:text-zinc-200">{c.nombre}</td>
                            )}
                            {visibleColumns.cedula && <td className="p-4">{c.cedula}</td>}
                            {visibleColumns.telefono && (
                              <td className="p-4">
                                <div className="flex items-center gap-1.5">
                                  <span>{c.telefono}</span>
                                  {c.telefono && (
                                    <button
                                      onClick={() => {
                                        const clientLoan = prestamos.find(p => p.clienteId === c.id && p.estado === "Activo") 
                                          || prestamos.find(p => p.clienteId === c.id);
                                        setSelectedWhatsAppCliente(c);
                                        setSelectedWhatsAppPrestamo(clientLoan || null);
                                        setIsWhatsAppModalOpen(true);
                                      }}
                                      className="p-1 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/25 rounded-md transition-colors"
                                      title="Enviar mensaje de WhatsApp"
                                    >
                                      <MessageCircle size={14} />
                                    </button>
                                  )}
                                </div>
                              </td>
                            )}
                            {visibleColumns.direccion && <td className="p-4 max-w-[180px] truncate">{c.direccion}</td>}
                            {visibleColumns.prestamos && (
                              <td className="p-4 text-center">
                                <span className="px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 font-bold text-[10px]">
                                  {countLoans}
                                </span>
                              </td>
                            )}
                            <td className="p-4 text-right">
                              <button
                                onClick={() => setSelectedCliente(c)}
                                className="p-1.5 text-gray-500 hover:text-emerald-500 rounded-lg hover:bg-black/5 dark:hover:bg-white/5"
                                title="Ver ficha del cliente"
                              >
                                <Eye size={16} />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Mobile Filter Bottom Sheet */}
      <FilterBottomSheet
        isOpen={isFilterSheetOpen}
        onClose={() => setIsFilterSheetOpen(false)}
        title="Filtros de Clientes"
        onClear={() => {
          setStatusFilter("todos");
          setCobradorFilter("todos");
          setSortBy("nombre_asc");
          setVisibleColumns({
            fotoCodigo: true,
            nombre: true,
            cedula: true,
            telefono: true,
            direccion: true,
            prestamos: true,
          });
        }}
      >
        <div className="space-y-4">
          {/* Ordenamiento */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Ordenar por
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "nombre_asc", label: "Nombre (A-Z)" },
                { id: "nombre_desc", label: "Nombre (Z-A)" },
                { id: "codigo_asc", label: "Código (Asc)" },
                { id: "recientes", label: "Recientes" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setSortBy(opt.id)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${
                    sortBy === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro de Estado de Préstamos */}
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              Préstamos Vigentes
            </label>
            <div className="space-y-2">
              {[
                { id: "todos", label: "Todos los clientes" },
                { id: "activos", label: "Sólo con Préstamos Activos" },
                { id: "sin_prestamos", label: "Sin préstamos registrados" }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setStatusFilter(opt.id)}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                    statusFilter === opt.id
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  <span>{opt.label}</span>
                  {statusFilter === opt.id && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                </button>
              ))}
            </div>
          </div>

          {/* Filtro de Cobrador Asignado */}
          {usuarios.filter((u) => u.rol === "Cobrador").length > 0 && (
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                Cobrador Asignado
              </label>
              <div className="space-y-2">
                <button
                  onClick={() => setCobradorFilter("todos")}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                    cobradorFilter === "todos"
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                      : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                  }`}
                >
                  <span>Todos los cobradores</span>
                  {cobradorFilter === "todos" && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                </button>

                {usuarios
                  .filter((u) => u.rol === "Cobrador")
                  .map((u) => (
                    <button
                      key={u.id}
                      onClick={() => setCobradorFilter(u.id)}
                      className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer ${
                        cobradorFilter === u.id
                          ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold"
                          : "bg-zinc-50 dark:bg-zinc-900/40 border-zinc-200/50 dark:border-zinc-800/60 text-gray-600 dark:text-zinc-400"
                      }`}
                    >
                      <span>{u.nombre}</span>
                      {cobradorFilter === u.id && <span className="w-2 h-2 rounded-full bg-emerald-500" />}
                    </button>
                  ))}
              </div>
            </div>
          )}

          {/* Seleccionar Columnas Visibles */}
          <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800/80">
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2.5">
              Columnas Visibles
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { key: "fotoCodigo", label: "Foto / Código" },
                { key: "nombre", label: "Nombre" },
                { key: "cedula", label: "Cédula" },
                { key: "telefono", label: "Teléfono" },
                { key: "direccion", label: "Dirección" },
                { key: "prestamos", label: "Préstamos" },
              ].map((col) => {
                const isVisible = visibleColumns[col.key as keyof typeof visibleColumns];
                return (
                  <button
                    key={col.key}
                    type="button"
                    onClick={() => {
                      // Ensure at least one column remains visible so it is not completely blank
                      const activeKeys = Object.entries(visibleColumns).filter(([_, v]) => v).map(([k]) => k);
                      if (isVisible && activeKeys.length <= 1 && activeKeys.includes(col.key)) {
                        return; // Prevent hiding the last remaining column
                      }
                      setVisibleColumns((prev) => ({
                        ...prev,
                        [col.key]: !isVisible,
                      }));
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold text-left border transition-all flex items-center justify-between cursor-pointer active:scale-[0.98] ${
                      isVisible
                        ? "bg-emerald-500/5 border-emerald-500/20 text-emerald-600 dark:text-emerald-400"
                        : "bg-zinc-50/50 dark:bg-zinc-900/10 border-zinc-200/40 dark:border-zinc-800/40 text-gray-400 dark:text-zinc-600"
                    }`}
                  >
                    <span>{col.label}</span>
                    <span className={`w-2 h-2 rounded-full transition-all ${isVisible ? "bg-emerald-500" : "bg-zinc-200 dark:bg-zinc-800"}`} />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </FilterBottomSheet>

      {/* Individual Reassignment Modal */}
      {showReassignModal && selectedCliente && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="modal-reassign-cobrador">
          <div className="bg-white dark:bg-[#121214] border border-zinc-100 dark:border-zinc-850 rounded-2xl max-w-md w-full max-h-[90vh] flex flex-col overflow-hidden shadow-xl">
            {/* Header */}
            <div className="px-5 py-4 border-b border-zinc-100 dark:border-zinc-800 flex justify-between items-center bg-zinc-50 dark:bg-zinc-900/40">
              <div>
                <h3 className="text-sm font-bold text-gray-900 dark:text-white">Asignar Cobrador a Cliente</h3>
                <p className="text-[10px] text-gray-400 mt-0.5">Cliente: <span className="font-bold text-emerald-500">{selectedCliente.nombre}</span></p>
              </div>
              <button
                type="button"
                onClick={() => setShowReassignModal(false)}
                className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 p-1 rounded-lg"
              >
                <X size={16} />
              </button>
            </div>

            {/* Content (internal scroll) */}
            <form onSubmit={handleReassignSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
              {/* Load Balancing Recommendation alert */}
              {(() => {
                const potentialCobradores = usuarios.filter(u => (u.rol === "Cobrador" || u.rol === "Supervisor") && u.activo);
                let recommendedCobrador = null;
                if (potentialCobradores.length > 0) {
                  let minClients = Infinity;
                  recommendedCobrador = potentialCobradores[0];
                  potentialCobradores.forEach(u => {
                    const count = clientes.filter(c => c.cobradorId === u.email).length;
                    if (count < minClients) {
                      minClients = count;
                      recommendedCobrador = u;
                    }
                  });
                }

                return (
                  <>
                    {recommendedCobrador && (
                      <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 text-xs space-y-1">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                          💡 Recomendación Inteligente
                        </span>
                        <p className="text-gray-500 dark:text-zinc-300">
                          Se recomienda asignar a <strong className="text-gray-700 dark:text-zinc-200">{recommendedCobrador.nombre}</strong> por poseer actualmente la menor carga de cobro en cartera ({clientes.filter(c => c.cobradorId === recommendedCobrador.email).length} clientes).
                        </p>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Seleccionar Cobrador *</label>
                      <select
                        required
                        value={reassignCobradorEmail}
                        onChange={e => setReassignCobradorEmail(e.target.value)}
                        className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs font-bold text-zinc-800 dark:text-zinc-100"
                      >
                        <option value="">-- Selecciona un Cobrador --</option>
                        {potentialCobradores.map(cob => {
                          const clientCount = clientes.filter(c => c.cobradorId === cob.email).length;
                          const loanSum = prestamos.filter(p => p.cobradorId === cob.email && (p.estado === "Activo" || p.estado === "Atrasado")).reduce((sum, p) => sum + p.capitalPrestado, 0);
                          const isRec = recommendedCobrador?.email === cob.email;
                          return (
                            <option key={cob.id || cob.uid || cob.email} value={cob.email}>
                              {cob.nombre} - {clientCount} cl. ({formatCurrency(loanSum, moneda)}) {isRec ? "⭐ (Recomendado)" : ""}
                            </option>
                          );
                        })}
                      </select>
                    </div>

                    {/* Load details display */}
                    {reassignCobradorEmail && (
                      <div className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 p-3 rounded-xl text-xs space-y-2">
                        <span className="font-bold text-gray-700 dark:text-zinc-200 uppercase tracking-wider text-[10px]">Métricas de Carga del Cobrador</span>
                        <div className="grid grid-cols-2 gap-3 text-center">
                          <div className="bg-white dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 p-2 rounded-lg">
                            <span className="block text-[10px] text-gray-400">Clientes Asignados</span>
                            <strong className="text-sm font-bold text-emerald-600">
                              {clientes.filter(c => c.cobradorId === reassignCobradorEmail).length}
                            </strong>
                          </div>
                          <div className="bg-white dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 p-2 rounded-lg">
                            <span className="block text-[10px] text-gray-400">Saldo Cartera</span>
                            <strong className="text-sm font-bold text-zinc-700 dark:text-zinc-200">
                              {formatCurrency(prestamos.filter(p => p.cobradorId === reassignCobradorEmail && (p.estado === "Activo" || p.estado === "Atrasado")).reduce((sum, p) => sum + p.capitalPrestado, 0), moneda)}
                            </strong>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                );
              })()}

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Motivo / Notas de Asignación *</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Escriba la razón de la asignación o transferencia..."
                  value={reassignMotivo}
                  onChange={e => setReassignMotivo(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800 text-xs"
                />
              </div>

              {/* Action buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-100 dark:border-zinc-850">
                <button
                  type="button"
                  onClick={() => setShowReassignModal(false)}
                  className="px-4 py-2 border rounded-xl hover:bg-zinc-50 dark:hover:bg-zinc-900 text-xs font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingReassign}
                  className="px-5 py-2 bg-emerald-600 text-white text-xs font-semibold rounded-xl hover:bg-emerald-700 transition-all flex items-center gap-1"
                >
                  {isSubmittingReassign ? "Asignando..." : "Asignar Cobrador"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* WhatsApp Modal for Quick Click-to-Chat */}
      <WhatsAppModal
        isOpen={isWhatsAppModalOpen}
        onClose={() => {
          setIsWhatsAppModalOpen(false);
          setSelectedWhatsAppCliente(null);
          setSelectedWhatsAppPrestamo(null);
        }}
        cliente={selectedWhatsAppCliente}
        prestamo={selectedWhatsAppPrestamo}
        moneda={moneda}
      />
    </div>
  );
}
