import React, { useMemo } from "react";
import { 
  Users, 
  AlertTriangle, 
  Clock, 
  Coins, 
  CheckCircle2, 
  ChevronRight,
  AlertCircle
} from "lucide-react";
import { Prestamo, CuotaDetalle } from "../types";
import { formatCurrency } from "../utils";
import { todayStr } from "../utils/dashboardHelpers";

interface DashboardCriticalClientsProps {
  prestamos: Prestamo[];
  moneda: string;
  onNavigateToCliente?: (clienteId: string, search?: string) => void;
}

export default function DashboardCriticalClients({ 
  prestamos, 
  moneda, 
  onNavigateToCliente 
}: DashboardCriticalClientsProps) {

  // 1. Clientes con mayor mora
  const clientesMayorMora = useMemo(() => {
    return prestamos
      .filter(p => (p.mora || 0) > 0 && p.estado !== "Cancelado" && p.estado !== "Saldado")
      .map(p => ({
        id: p.id,
        clienteId: p.clienteId,
        clienteNombre: p.clienteNombre,
        prestamoNumero: p.numero,
        montoMora: p.mora || 0,
        balancePendiente: p.balancePendiente
      }))
      .sort((a, b) => b.montoMora - a.montoMora)
      .slice(0, 5);
  }, [prestamos]);

  // 2. Clientes con varias cuotas vencidas (>= 2 cuotas vencidas)
  const clientesCuotasVencidas = useMemo(() => {
    const list: { clienteId: string; clienteNombre: string; prestamoId: string; prestamoNumero: string; cuotasVencidasCount: number; montoVencido: number }[] = [];
    
    prestamos.forEach(p => {
      if ((p.estado === "Activo" || p.estado === "Atrasado") && p.cuotasDetalle) {
        try {
          const cuotas: CuotaDetalle[] = JSON.parse(p.cuotasDetalle);
          if (Array.isArray(cuotas)) {
            let vencidasCount = 0;
            let montoVencido = 0;
            cuotas.forEach(c => {
              if (c.estado !== "Pagado" && new Date(c.fechaVence) < new Date(todayStr)) {
                vencidasCount++;
                montoVencido += (c.monto - c.montoPagado);
              }
            });
            if (vencidasCount >= 2) {
              list.push({
                clienteId: p.clienteId,
                clienteNombre: p.clienteNombre,
                prestamoId: p.id || "",
                prestamoNumero: p.numero,
                cuotasVencidasCount: vencidasCount,
                montoVencido
              });
            }
          }
        } catch (e) {}
      }
    });

    return list.sort((a, b) => b.cuotasVencidasCount - a.cuotasVencidasCount).slice(0, 5);
  }, [prestamos]);

  // 3. Préstamos próximos a vencer (last installment's due date is within next 15 days)
  const prestamosProximosVencer = useMemo(() => {
    const list: { clienteId: string; clienteNombre: string; prestamoId: string; prestamoNumero: string; diasParaVencer: number; fechaVencimiento: string; balancePendiente: number }[] = [];

    prestamos.forEach(p => {
      if ((p.estado === "Activo" || p.estado === "Atrasado") && p.cuotasDetalle) {
        try {
          const cuotas: CuotaDetalle[] = JSON.parse(p.cuotasDetalle);
          if (Array.isArray(cuotas) && cuotas.length > 0) {
            const lastCuota = cuotas[cuotas.length - 1];
            if (lastCuota) {
              const diffTime = new Date(lastCuota.fechaVence).getTime() - new Date(todayStr).getTime();
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
              if (diffDays > 0 && diffDays <= 15) {
                list.push({
                  clienteId: p.clienteId,
                  clienteNombre: p.clienteNombre,
                  prestamoId: p.id || "",
                  prestamoNumero: p.numero,
                  diasParaVencer: diffDays,
                  fechaVencimiento: lastCuota.fechaVence,
                  balancePendiente: p.balancePendiente
                });
              }
            }
          }
        } catch (e) {}
      }
    });

    return list.sort((a, b) => a.diasParaVencer - b.diasParaVencer).slice(0, 5);
  }, [prestamos]);

  // 4. Préstamos próximos a liquidarse (outstanding balance <= 10% of capital)
  const prestamosProximosLiquidarse = useMemo(() => {
    return prestamos
      .filter(p => (p.estado === "Activo" || p.estado === "Atrasado") && p.balancePendiente > 0 && p.balancePendiente <= p.capitalPrestado * 0.10)
      .map(p => ({
        clienteId: p.clienteId,
        clienteNombre: p.clienteNombre,
        prestamoId: p.id || "",
        prestamoNumero: p.numero,
        capitalPrestado: p.capitalPrestado,
        balancePendiente: p.balancePendiente,
        porcentajeRestante: (p.balancePendiente / p.capitalPrestado) * 100
      }))
      .sort((a, b) => a.porcentajeRestante - b.porcentajeRestante)
      .slice(0, 5);
  }, [prestamos]);

  return (
    <div className="space-y-6">
      <div className="border-t border-zinc-100 dark:border-zinc-800/60 pt-6">
        <h3 className="text-base font-extrabold text-gray-950 dark:text-white flex items-center gap-2 mb-1" id="critical-clients-title">
          <AlertCircle className="text-rose-600 dark:text-rose-400" size={18} />
          Supervisión de Clientes Críticos y Operaciones BI
        </h3>
        <p className="text-xs text-gray-400">
          Análisis predictivo de cartera: alertas tempranas de impagos, moras elevadas y vencimientos inminentes.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Mayor Mora */}
        <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-zinc-100 dark:border-zinc-800/40 pb-2">
              <span className="text-xs font-bold text-gray-900 dark:text-zinc-200 flex items-center gap-1.5">
                <Coins className="text-rose-500" size={14} /> Mayor Mora Activa
              </span>
              <span className="text-[10px] bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 font-bold px-2 py-0.5 rounded">
                Ranking
              </span>
            </div>
            {clientesMayorMora.length === 0 ? (
              <p className="text-[11px] text-zinc-400 py-4 text-center">No hay clientes con mora registrada.</p>
            ) : (
              <div className="space-y-2">
                {clientesMayorMora.map(item => (
                  <div 
                    key={item.id}
                    onClick={() => onNavigateToCliente?.(item.clienteId, item.clienteNombre)}
                    className="group flex items-center justify-between p-2 rounded-xl bg-zinc-50/50 hover:bg-zinc-100/60 dark:bg-zinc-900/30 dark:hover:bg-zinc-900/60 cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="text-[11px] font-bold text-gray-900 dark:text-white truncate group-hover:text-emerald-500 transition-colors">
                        {item.clienteNombre}
                      </p>
                      <p className="text-[9px] text-zinc-450 dark:text-zinc-500 font-mono">
                        N° {item.prestamoNumero}
                      </p>
                    </div>
                    <div className="text-right shrink-0 flex items-center gap-1">
                      <span className="text-xs font-black text-rose-600 dark:text-rose-400 font-mono">
                        {formatCurrency(item.montoMora, moneda)}
                      </span>
                      <ChevronRight size={10} className="text-zinc-300 dark:text-zinc-600" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Card 2: Varias Cuotas Vencidas */}
        <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-zinc-100 dark:border-zinc-800/40 pb-2">
              <span className="text-xs font-bold text-gray-900 dark:text-zinc-200 flex items-center gap-1.5">
                <AlertTriangle className="text-amber-500" size={14} /> ≥ 2 Cuotas Vencidas
              </span>
              <span className="text-[10px] bg-amber-50 dark:bg-amber-950/20 text-amber-600 dark:text-amber-400 font-bold px-2 py-0.5 rounded">
                Riesgo Alto
              </span>
            </div>
            {clientesCuotasVencidas.length === 0 ? (
              <p className="text-[11px] text-zinc-400 py-4 text-center">Nivel óptimo: 0 clientes con atraso recurrente.</p>
            ) : (
              <div className="space-y-2">
                {clientesCuotasVencidas.map(item => (
                  <div 
                    key={item.prestamoId}
                    onClick={() => onNavigateToCliente?.(item.clienteId, item.clienteNombre)}
                    className="group flex items-center justify-between p-2 rounded-xl bg-zinc-50/50 hover:bg-zinc-100/60 dark:bg-zinc-900/30 dark:hover:bg-zinc-900/60 cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="text-[11px] font-bold text-gray-900 dark:text-white truncate group-hover:text-emerald-500 transition-colors">
                        {item.clienteNombre}
                      </p>
                      <p className="text-[9px] text-zinc-450 dark:text-zinc-500 font-mono">
                        {item.cuotasVencidasCount} cuotas vencidas • {formatCurrency(item.montoVencido, moneda)}
                      </p>
                    </div>
                    <ChevronRight size={10} className="text-zinc-300 dark:text-zinc-650 shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Card 3: Próximos a Vencer (Maturity) */}
        <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-zinc-100 dark:border-zinc-800/40 pb-2">
              <span className="text-xs font-bold text-gray-900 dark:text-zinc-200 flex items-center gap-1.5">
                <Clock className="text-sky-500" size={14} /> Próximos a Vencer (15d)
              </span>
              <span className="text-[10px] bg-sky-50 dark:bg-sky-950/20 text-sky-600 dark:text-sky-400 font-bold px-2 py-0.5 rounded">
                Agenda
              </span>
            </div>
            {prestamosProximosVencer.length === 0 ? (
              <p className="text-[11px] text-zinc-400 py-4 text-center">No hay contratos terminando esta quincena.</p>
            ) : (
              <div className="space-y-2">
                {prestamosProximosVencer.map(item => (
                  <div 
                    key={item.prestamoId}
                    onClick={() => onNavigateToCliente?.(item.clienteId, item.clienteNombre)}
                    className="group flex items-center justify-between p-2 rounded-xl bg-zinc-50/50 hover:bg-zinc-100/60 dark:bg-zinc-900/30 dark:hover:bg-zinc-900/60 cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="text-[11px] font-bold text-gray-900 dark:text-white truncate group-hover:text-emerald-500 transition-colors">
                        {item.clienteNombre}
                      </p>
                      <p className="text-[9px] text-zinc-450 dark:text-zinc-500 font-mono">
                        Vence en: {item.diasParaVencer}d ({item.fechaVencimiento})
                      </p>
                    </div>
                    <ChevronRight size={10} className="text-zinc-300 dark:text-zinc-650 shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Card 4: Próximos a Liquidarse */}
        <div className="bg-white dark:bg-[#121214] border border-gray-150 dark:border-zinc-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-zinc-100 dark:border-zinc-800/40 pb-2">
              <span className="text-xs font-bold text-gray-900 dark:text-zinc-200 flex items-center gap-1.5">
                <CheckCircle2 className="text-emerald-500" size={14} /> Listo para Liquidar (&lt;10%)
              </span>
              <span className="text-[10px] bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 font-bold px-2 py-0.5 rounded">
                Cierre
              </span>
            </div>
            {prestamosProximosLiquidarse.length === 0 ? (
              <p className="text-[11px] text-zinc-400 py-4 text-center">No hay contratos cercanos al 90% amortizado.</p>
            ) : (
              <div className="space-y-2">
                {prestamosProximosLiquidarse.map(item => (
                  <div 
                    key={item.prestamoId}
                    onClick={() => onNavigateToCliente?.(item.clienteId, item.clienteNombre)}
                    className="group flex items-center justify-between p-2 rounded-xl bg-zinc-50/50 hover:bg-zinc-100/60 dark:bg-zinc-900/30 dark:hover:bg-zinc-900/60 cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="text-[11px] font-bold text-gray-900 dark:text-white truncate group-hover:text-emerald-500 transition-colors">
                        {item.clienteNombre}
                      </p>
                      <p className="text-[9px] text-zinc-450 dark:text-zinc-500 font-mono">
                        Saldo: {formatCurrency(item.balancePendiente, moneda)} ({item.porcentajeRestante.toFixed(1)}% rest)
                      </p>
                    </div>
                    <ChevronRight size={10} className="text-zinc-300 dark:text-zinc-650 shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
